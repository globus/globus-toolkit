#ifndef HAVE_DIRNAME

char *dirname(const char *path);

#endif
