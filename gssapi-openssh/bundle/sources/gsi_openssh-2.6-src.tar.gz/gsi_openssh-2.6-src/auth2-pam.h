/* $Id: auth2-pam.h,v 1.1.1.1 2002/03/11 15:10:36 jbasney Exp $ */

#include "includes.h"
#ifdef USE_PAM

int	auth2_pam(Authctxt *authctxt);

#endif /* USE_PAM */
