/*
 * fake library for ssh
 *
 * This file is included in getaddrinfo.c and getnameinfo.c.
 * See getaddrinfo.c and getnameinfo.c.
 */

/* $Id: fake-gai-errnos.h,v 1.1.1.1 2002/03/11 15:10:45 jbasney Exp $ */

/* for old netdb.h */
#ifndef EAI_NODATA
#define EAI_NODATA	1
#define EAI_MEMORY	2
#endif
