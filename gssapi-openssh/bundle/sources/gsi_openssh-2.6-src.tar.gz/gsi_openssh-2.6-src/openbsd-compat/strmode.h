/* $Id: strmode.h,v 1.1.1.1 2002/03/11 15:10:47 jbasney Exp $ */

#ifndef HAVE_STRMODE

void strmode(register mode_t mode, register char *p);

#endif
