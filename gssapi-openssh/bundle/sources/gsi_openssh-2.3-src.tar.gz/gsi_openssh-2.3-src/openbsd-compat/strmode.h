/* $Id$ */

#ifndef HAVE_STRMODE

void strmode(register mode_t mode, register char *p);

#endif
