/* globus_config.h.  Generated from globus_config.h.in by configure.  */
/*
 * Copyright 1999-2006 University of Chicago
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define HAVE_PTHREAD 1
/* #undef HAVE_PTHREAD_INIT_FUNC */
#define HAVE_PTHREAD_PREEMPTIVE 1
/* #undef HAVE_PTHREAD_SCHED */
/* #undef _POSIX_PTHREAD_SEMANTICS  */
/* #undef HAVE_WINDOWS_THREADS */
#define HAVE_THREAD_SAFE_SELECT 1
#define HAVE_THREAD_SAFE_STDIO 1
/* #undef _REENTRANT */
/* #undef BUILD_LITE */
/* #undef BUILD_DEBUG */
/* #undef BUILD_STATIC_ONLY */

/* #undef TARGET_ARCH_SOLARIS */
/* #undef TARGET_ARCH_AIX */
/* #undef TARGET_ARCH_AIX5 */
/* #undef TARGET_ARCH_HPUX */
/* #undef TARGET_ARCH_HPUX11 */
/* #undef TARGET_ARCH_HPUX */
/* #undef TARGET_ARCH_LINUX */
/* #undef TARGET_ARCH_X86 */
/* #undef TARGET_ARCH_LINUX */
/* #undef TARGET_ARCH_X86_64 */
/* #undef TARGET_ARCH_LINUX */
/* #undef TARGET_ARCH_IA64 */
/* #undef TARGET_ARCH_LINUX */
/* #undef TARGET_ARCH_AXP */
/* #undef TARGET_ARCH_FREEBSD */
#define TARGET_ARCH_BSD 1
#define TARGET_ARCH_DARWIN 1
#define TARGET_ARCH_BSD 1
/* #undef TARGET_ARCH_CYGWIN */
/* #undef TARGET_ARCH_X86 */
/* #undef TARGET_ARCH_LINUX */
/* #undef TARGET_ARCH_LINUX */
/* #undef TARGET_ARCH_ARM */
/* #undef TARGET_ARCH_WIN32 */
/* #undef TARGET_ARCH_X86 */


#ifdef NET_OS
/* #undef TARGET_ARCH_NETOS */
#endif

/* #undef HAVE_MALLOC_H */
#define HAVE_PWD_H 1
#define HAVE_DIRENT_H 1
#define HAVE_SYS_FILE_H 1
#define GLOBUS_TIMESPEC_EXISTS 1
#define HAVE_NETINET_IN_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_SYSCTL_H 1
/* #undef HAVE_IO_H */
#define HAVE_SYS_SIGNAL_H 1
#define HAVE_UNISTD_H 1
#define HAVE_NETDB_H 1
#define HAVE_SYS_PARAM_H 1
#define HAVE_FCNTL_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_STRING_H 1
#define HAVE_CTYPE_H 1
#define HAVE_SYS_SOCKET_H 1
#define HAVE_STDARG_H 1
#define HAVE_ARPA_INET_H 1
#define HAVE_NET_IF_ARP_H 1
#define HAVE_NET_IF_DL_H 1
#define HAVE_IFADDRS_H 1
#define HAVE_SYS_IOCTL_H 1
#define HAVE_NET_IF_H 1
/* #undef HAVE_GMTIME_R */
/* #undef HAVE_SYS_INTTYPES_H */
#define HAVE_INTTYPES_H 1
#define HAVE_STDINT_H 1
/* #undef HAVE_LIMITS */
#define HAVE_LIMITS_H 1
/* #undef HAVE_NDIR_H */
#define HAVE_NETINET_TCP_H 1
/* #undef HAVE_NO_CONDATTR_DEFAULT */
/* #undef HAVE_NO_PTHREAD_SETKIND */
/* #undef HAVE_ONEXIT */
/* #undef HAVE_PTHREAD_PRIO_MINMAX */
#define HAVE_SEEKDIR 1
#define HAVE_TELLDIR 1
#define HAVE_WRITEV 1
#define HAVE_READV 1
#define HAVE_SIGNAL_H 1
/* #undef HAVE_SNPRINTF */
#define HAVE_STRERROR 1
/* #undef HAVE_STRNCASECMP */
/* #undef HAVE_SYS_DIR_H */
/* #undef HAVE_SYS_LIMITS_H */
/* #undef HAVE_SYS_NDIR_H */
/* #undef HAVE_SYS_TYPES */
#define HAVE_SYS_WAIT_H 1
#define HAVE_WAITPID 1
/* #undef HAVE_VSNPRINTF */
#define HAVE_STRTOUL 1
#define HAVE_LIBC_H 1
#define HAVE_SYSLOG_H 1
/* #undef HAVE_WINSOCK2_H */

/* NET+OS 6.x */
/* #undef HAVE_SOCKAPI_H */
/* #undef HAVE_TX_API_H */

#define HAVE_SYS_UIO_H 1
#define HAVE_STRUCT_IOVEC 1
#define HAVE_MEMMOVE 1
/* #undef IOV_MAX */
#define RETSIGTYPE void
#define HAVE_ATEXIT 1
#define TIME_WITH_SYS_TIME 1
#define HAVE_ALLOCA_H 1
#define HAVE_SOCKLEN_T 1
#define HAVE_GETHOSTNAME 1
#define HAVE_GETHOSTBYADDR 1
#define HAVE_GETADDRINFO 1
#define HAVE_GETNAMEINFO 1
#define HAVE_GETSERVBYNAME 1
#define HAVE_GETPROTOBYNUMBER 1
#define HAVE_GETEUID 1
#define HAVE_GETPWNAM 1
#define HAVE_GETPWUID 1
#define HAVE_INET_NTOA 1
#define HAVE_INET_PTON 1
#define HAVE_INET_ADDR 1
#define HAVE_FORK 1
#define HAVE_DIR 1
#define HAVE_SIGACTION 1
#define HAVE_SENDMSG 1
#define HAVE_RECVMSG 1
#define HAVE_WAIT3 1
#define HAVE_SIGHOLD 1
#define HAVE_SIGBLOCK 1
#define HAVE_SIGSET 1
#define HAVE_GETWD 1
#define HAVE_GETCWD 1
#define HAVE_USLEEP 1
#define HAVE_STRPTIME 1
#define HAVE_FREEADDRINFO 1
#define HAVE_OPENDIR 1
#define HAVE_CLOSEDIR 1
#define HAVE_READDIR 1
#define HAVE_REWINDDIR 1
#define HAVE_NRAND48 1
#define HAVE_MKTIME 1
#define HAVE_GAI_STRERROR 1
#define HAVE_POLL 1

#define GLOBUS_OFF_T long long
#define GLOBUS_OFF_T_FORMAT "lld"

#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_LONG 4

#define HAVE_INT8_T 1
#define HAVE_INT16_T 1
#define HAVE_INT32_T 1
#define HAVE_INT64_T 1

#define HAVE_UINT8_T 1
#define HAVE_UINT16_T 1
#define HAVE_UINT32_T 1
#define HAVE_UINT64_T 1

#ifndef HAVE_INT8_T
/* #undef int8_t */
#endif

#ifndef HAVE_INT16_T
/* #undef int16_t */
#endif

#ifndef HAVE_INT32_T
/* #undef int32_t */
#endif

#ifndef HAVE_INT64_T
/* #undef int64_t */
#endif

#ifndef HAVE_UINT8_T
/* #undef uint8_t */
#endif

#ifndef HAVE_UINT16_T
/* #undef uint16_t */
#endif

#ifndef HAVE_UINT32_T
/* #undef uint32_t */
#endif

#ifndef HAVE_UINT64_T
/* #undef uint64_t */
#endif

/* Number of bits in a file offset, on hosts where this is settable. */
#ifndef _FILE_OFFSET_BITS
/* #undef _FILE_OFFSET_BITS */
#endif

/* Define to make fseeko etc. visible, on some hosts. */
#ifndef _LARGEFILE_SOURCE
/* #undef _LARGEFILE_SOURCE */
#endif

/* Define for large files, on AIX-style hosts. */
#ifndef _LARGE_FILES
/* #undef _LARGE_FILES */
#endif
