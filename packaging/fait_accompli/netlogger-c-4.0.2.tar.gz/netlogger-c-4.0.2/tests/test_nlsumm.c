static const volatile char rcsid[] =
    "$Id: test_nlsumm.c 130 2007-08-22 14:09:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nlsumm.c
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "nldbg.h"
#include "util.h"
#include "nl.h"
#include "nlparams.h"
#include "nlint.h"
#include "nllist.h"
#include "nlsumm.h"
#include "nlsummrec.h"
#include "nlsummseq.h"
#include "nlsummstate.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

#define REC_TIME 2
#define REC_VAL 3.14

static NL_rec_t *create_good_record(const char *event)
{
    struct timeval t;
    double v = REC_VAL;
    NL_rec_t *rec;

    t.tv_sec = REC_TIME;
    t.tv_usec = 0;
    rec = NL_rec(4);
    NL_rec_add(rec, NL_fld("ts", 2, &t, sizeof(struct timeval), 't'));
    NL_rec_add(rec,
               NL_fld("event", 5, (char *) event, strlen(event), 's'));
    NL_rec_add(rec, NL_fld("guid", 4, "guid1", 5, 's'));
    NL_rec_add(rec, NL_fld("result", 6, &v, sizeof(double), 'd'));

    return rec;
}

static NL_rec_t *create_rec(void *event_val, unsigned event_val_n,
                            char event_val_type, char *id, double *value)
{
    struct timeval t;
    NL_rec_t *rec;
    int n;

    n = 2;
    if (id)
        n++;
    if (value)
        n++;

    t.tv_sec = REC_TIME;
    t.tv_usec = 0;
    rec = NL_rec(n);
    NL_rec_add(rec, NL_fld("ts", 2, &t, sizeof(struct timeval), 't'));
    NL_rec_add(rec,
               NL_fld("event", 5, event_val, event_val_n, event_val_type));
    if (id)
        NL_rec_add(rec, NL_fld("guid", 4, id, strlen(id), 's'));
    if (value)
        NL_rec_add(rec, NL_fld("value", 5, value, sizeof(double), 'd'));
    return rec;
}

/* no-op callbacks */

char *g_dummy = "dummy";

void *nop_istate(NL_params_T params)
{
    return g_dummy;
}

int nop_process(NL_summstate_T state)
{
    return 0;
}

void nop_flush(NL_summstate_T state)
{
    return;
}

void nop_free(void *obj)
{
    return;
}


TEST_PROTO(createDelete)
{
    NL_summ_T obj;

    obj = NL_summ();
    NL_summ_del(obj);

    return 0;
}

TEST_PROTO(addLog)
{
    NL_summ_T obj;
    NL_log_T log;

    log = NL_open("/dev/null");
    obj = NL_summ();
    NL_summ_add_log(obj, log);
    NL_summ_del(obj);
    NL_close(log);

    return 0;
}

TEST_PROTO(addSequence)
{
    const int N = 99;
    NL_summ_T obj;
    NL_summseq_T seq[N];
    int i;

    DBG1("- add %d sequences\n", N);
    obj = NL_summ();
    for (i = 0; i < N; i++) {
        NL_subject_T subj;
        seq[i] = NL_summseq();
        NL_summ_add_sequence(obj, seq[i]);
        subj = NL_summseq_get_output_rec_subject(seq[i]);
        assert(subj);
        NL_subject_notify(subj, NULL);
    }
    DBG("- delete\n");
    NL_summ_del(obj);

    return 0;
}

int g_flushes = 0;
void count_flush(NL_summstate_T state)
{
    g_flushes++;
}

TEST_PROTO(flush)
{
    NL_summ_T obj;
    NL_summseq_T seq;
    NL_log_T log;
    char *e = "haha";
    int r, j;

    DBG("- create summ and sequence\n");
    obj = NL_summ();
    seq = NL_summseq();
    DBG("- add selectors\n");
    for (j = 0; j < 3; j++) {
        char ee[20];
        sprintf(ee, "%s.%d", e, j);
        r = NL_summseq_add_selector(seq, "event", ee, strlen(ee));
        assert(0 == r);
        r = NL_summseq_add_id_field(seq, j, "guid");
        assert(0 == r);
    }
    DBG("- set info\n");
    r = NL_summseq_set_info(seq, NL_params(),
                            nop_istate, nop_process, count_flush,
                            nop_free);
    assert(0 == r);
    DBG("- add sequence to summ\n");
    NL_summ_add_sequence(obj, seq);
    DBG("- open log\n");
    log = NL_open("/dev/null");
    NL_set_level(log, NL_LVL_INFO);
    DBG("- add log to summ\n");
    NL_summ_add_log(obj, log);
    DBG("- write event\n");
    NL_write(log, NL_LVL_INFO, "haha.1", "guid=s", "banana");
    g_flushes = 0;
    DBG("- do flush\n");
    NL_flush(log);
    assert(g_flushes == 1);
    DBG("- delete summ\n");
    NL_summ_del(obj);
    DBG("- close log\n");
    NL_close(log);

    return 0;
}

/* this function is not part of the public API, but it is
 * still nice to test it separately. */
extern NL_list_T NL_summ_match_record(NL_summ_T self, NL_rec_t * record);

TEST_PROTO(matchRecord)
{
    NL_summ_T obj;
    NL_list_T m;
    NL_rec_t *rec;
    int i, j, r;

    obj = NL_summ();
    assert(obj);
    DBG1("- add %d sequences\n", 5);
    for (i = 0; i < 5; i++) {
        NL_summseq_T seq = NL_summseq();
        for (j = 0; j < 3; j++) {
            int v = (i + 1) * j;
            r = NL_summseq_add_selector(seq, "event", &v, sizeof(v));
            assert(0 == r);
            r = NL_summseq_add_id_field(seq, j, "guid");
            assert(0 == r);
        }
        NL_summseq_add_value_field(seq, 2, "value");
        r = NL_summseq_set_info(seq, NL_params(),
                                nop_istate, nop_process, nop_flush,
                                nop_free);
        assert(0 == r);
        NL_summ_add_sequence(obj, seq);
    }
    DBG("- match NULL record (fail)\n");
    m = NL_summ_match_record(obj, NULL);
    assert(0 == NL_list_len(m));
    DBG("- match non-NULL records\n");
    /*
       event=((0,1,2),
       (0,2,4),
       (0,3,6),
       (0,4,8),
       (0,5,10))

       i             matches
       0               5
       2,4             2
       1,3,5,6,8,10    1
       else            0

     */
    for (i = -1; i < 13; i++) {
        int n, e;
        double v;

        if (-1 == i) {
            /* leave out ID field (expect failure) */
            j = 0;
            rec = create_rec(&i, sizeof(j), 'i', NULL, NULL);
        }
        else if (0 == i) {
            rec = create_rec(&i, sizeof(i), 'i', "my.id", NULL);
        }
        else {
            rec = create_rec(&i, sizeof(i), 'i', "an.id", &v);
        }
        assert(rec);
        m = NL_summ_match_record(obj, rec);
        assert(m);
        n = NL_list_len(m);
        switch (i) {
        case -1:
            e = 0;
            break;
        case 0:
            e = 5;
            break;
        case 2:
        case 4:
            e = 2;
            break;
        case 1:
        case 3:
        case 5:
        case 6:
        case 8:
        case 10:
            e = 1;
            break;
        default:
            e = 0;
        }
        DBG3("-- event #%d => expect %d matches, got %d\n", i, e, n);
        assert(n == e);
        NL_rec_del(rec);
        NL_list_del(m, (NL_list_free_data) NL_summrec_del);
    }
    DBG("- delete\n");
    NL_summ_del(obj);

    return 0;
}

/* note: this is a lousy test; see one of the integrated tests
 * for something that checks to see whether it worked
 */
TEST_PROTO(newRecord)
{
    NL_summ_T obj;
    NL_summseq_T seq;
    NL_log_T log;
    int r, j;

    obj = NL_summ();
    seq = NL_summseq();
    for (j = 0; j < 3; j++) {
        int v = j;
        r = NL_summseq_add_selector(seq, "event", &v, sizeof(v));
        assert(0 == r);
        r = NL_summseq_add_id_field(seq, j, "guid");
        assert(0 == r);
    }
    r = NL_summseq_set_info(seq, NL_params(),
                            nop_istate, nop_process, nop_flush, nop_free);
    assert(0 == r);
    NL_summ_add_sequence(obj, seq);
    log = NL_open("/dev/null");
    NL_summ_add_log(obj, log);
    NL_write(log, NL_LVL_INFO, "joke", "fruit_flies_like=s", "banana");
    NL_summ_del(obj);
    NL_close(log);

    return 0;
}

TEST_PROTO(removeLog)
{
    const int N = 99;
    NL_summ_T obj;
    NL_log_T log[N];
    int i, r;

    DBG1("- open %d logs to /dev/null\n", N);
    for (i = 0; i < N; i++) {
        log[i] = NL_open("/dev/null");
        assert(log[i]);
    }
    obj = NL_summ();
    DBG("- remove NULL log (fail)\n");
    assert(-1 == NL_summ_remove_log(obj, NULL));
    DBG1("- add %d logs\n", N);
    for (i = 0; i < N; i++) {
        NL_summ_add_log(obj, log[i]);
    }
    DBG1("- remove %d logs\n", N - 1);
    assert(-1 == NL_summ_remove_log(obj, NULL));
    for (i = 1; i < N; i++) {
        r = NL_summ_remove_log(obj, log[i]);
        assert(0 == r);
    }
    DBG("- remove NULL log (fail)\n");
    assert(-1 == NL_summ_remove_log(obj, NULL));
    DBG("- remove prev. removed log (fail)\n");
    assert(-1 == NL_summ_remove_log(obj, log[N / 2]));
    DBG("- delete (removing 1 log)\n");
    NL_summ_del(obj);

    return 0;
}

TEST_PROTO(writeRecord)
{
    NL_summ_T obj;
    NL_log_T log;
    NL_summstate_reclevel_T rl;

    obj = NL_summ();

    DBG("- output not set\n");
    rl = NL_summstate_reclevel(create_good_record("foo"), NL_LVL_DEBUG);
    NL_summ_write_record(obj, rl);

    DBG("- output set\n");
    log = NL_open("/dev/null");
    NL_summ_set_output(obj, log);
    rl = NL_summstate_reclevel(create_good_record("bar"), NL_LVL_DEBUG);
    NL_summ_write_record(obj, rl);
    // NO! log is 'owned' by summ_T
    // NL_close(log);
    NL_summ_del(obj);

    return 0;
}

/* --- some simple integrated tests --- */

/* create start/end sequence */

static NL_summseq_T create_sequence(char *bevent, char *id, char *value)
{
    int r, i;
    char *event;
    char *suffix[] = { "start", "end" };
    NL_summseq_T seq = NL_summseq();

    DBG1("-- create %s.{start,end} sequence\n", bevent);
    event = malloc(8 + strlen(bevent));
    for (i = 0; i < 2; i++) {
        sprintf(event, "%s.%s", bevent, suffix[i]);
        r = NL_summseq_add_selector(seq, "event", event, strlen(event));
        assert(0 == r);
        r = NL_summseq_add_id_field(seq, i, id);
        assert(0 == r);
    }
    r = NL_summseq_add_value_field(seq, 1, value);
    assert(0 == r);

    return seq;
}


/* === Integrated test #1 === */

/* summarizer method callbacks */

struct i1_data {
    NL_rec_t *rec[2];
};
void *i1_istate(NL_params_T params)
{
    char *event, *summ_event;
    struct i1_data *data;
    int i;
    struct timeval tv;

    data = malloc(sizeof(struct i1_data));
    assert(data);
    assert(0== NL_params_get_string(params, "event", &event));
    summ_event = malloc(strlen(event) + 6);
    sprintf(summ_event, "summ.%s", event);
    for (i = 0; i < 2; i++) {
        NL_rec_t *rec = NL_rec(4);
        NL_rec_add(rec, NL_fld("ts", 2, &tv, sizeof(tv), 't'));
        NL_rec_add(rec, NL_fld("event", 5,
                               summ_event, strlen(summ_event), 's'));
        NL_rec_add(rec, NL_fld("pos", 3, &i, sizeof(int), 'i'));
        NL_rec_add(rec, NL_fld("len", 3, &i, sizeof(int), 'i'));
        data->rec[i] = rec;
    }
    free(summ_event);
    return data;
}

int i1_process(NL_summstate_T state)
{
    struct timeval tv;
    struct i1_data *mydata = (struct i1_data *) state->data;
    NL_rec_t *rec;

    rec = mydata->rec[state->pos];
    tv.tv_sec = (int) (state->ts_usec / 1000000LL);
    tv.tv_usec = (int) (state->ts_usec - tv.tv_sec * 1000000LL);
    memcpy(rec->fields[0]->value, &tv, sizeof(tv));
    memcpy((rec->fields)[2]->value, &(state->pos), sizeof(int));
    memcpy((rec->fields)[3]->value, &(state->sequence_len), sizeof(int));
    NL_summstate_write_record(state, rec, NL_LVL_INFO);
    return 0;
}

void i1_flush(NL_summstate_T state)
{
    return;
}

void i1_free(void *obj)
{
	struct i1_data *self = (struct i1_data*)obj;
    NL_rec_del(self->rec[0]);
	NL_rec_del(self->rec[1]);
}

void *i2_istate(NL_params_T params)
{
    return g_dummy;
}

int i2_process(NL_summstate_T state)
{
    return 0;
}

void i2_flush(NL_summstate_T state)
{
    return;
}

void i2_free(void *obj)
{
    return;
}

/* Integraged Tests */

/* factor out some common setup code */
void
integrated_setup(char *base_event, NL_summ_T * objp,
                 NL_log_T * log1p, NL_log_T * log2p,
                 char **summ_destp, char *log1_dest,
                 int consume_flag,
                 NL_summseq_init_state_fn istate,
                 NL_summseq_process_fn process_record,
                 NL_summseq_flush_fn flush_state, NL_free_fn free_state)
{
    NL_summ_T obj;
    NL_params_T params;
    NL_summseq_T seq;
    NL_log_T log1, log2;
    char *summ_dest;
    char wd[1024];
    int r;

    assert(NULL != getcwd(wd, sizeof(wd)));
    DBG("- create summ\n");
    obj = NL_summ();
    DBG1("- create log #1 -> %s\n", log1_dest);
    log1 = NL_open(log1_dest);
    NL_set_level(log1, NL_LVL_INFO);

    DBG("- create sequence, set info & summ fn\n");
    seq = create_sequence(base_event, "guid", "value");
    assert(seq);
    if (consume_flag) {
        NL_summseq_set_consume(seq, consume_flag);
    }
    params = NL_params();
    NL_params_append(params, "event", base_event, strlen(base_event));
    r = NL_summseq_set_info(seq, params, istate, process_record,
                            flush_state, free_state);
    assert(0 == r);
    DBG("- add sequence to summ\n");
    NL_summ_add_sequence(obj, seq);
    DBG("- add log to summ\n");
    NL_summ_add_log(obj, log1);
    summ_dest = tempnam(wd, "summ-");
    assert(summ_dest);
    DBG1("- create log #2 -> %s\n", summ_dest);
    log2 = NL_open(summ_dest);
    NL_set_level(log2, NL_LVL_INFO);
    assert(log2);
    DBG("- set log #2 as summ output\n");
    NL_summ_set_output(obj, log2);

    *objp = obj;
    *log1p = log1;
    *log2p = log2;
    *summ_destp = summ_dest;
}

static void
integrated_shutdown(NL_summ_T obj, NL_log_T log1, char *summ_dest)
{
    DBG("- remove log#1 from summ\n");
    NL_summ_remove_log(obj, log1);
    DBG("- close log #1\n");
    NL_close(log1);
    DBG("- close summ\n");
    NL_summ_del(obj);
    DBG("- cleanup\n");
    unlink(summ_dest);
}

TEST_PROTO(integrated1)
{
    NL_summ_T obj;
    NL_log_T log1, log2;
    char *base_event = "elmos_world";
    char *summ_dest;
    int i, nrec = 11;
    FILE *ofile;
    char buf[1024];

    integrated_setup(base_event, &obj, &log1, &log2, &summ_dest,
                     "/dev/null", 0, i1_istate, i1_process, i1_flush,
                     i1_free);

    DBG1("- write %d record(s) to log #1\n", nrec);
    for (i = 0; i < nrec; i++) {
        char event[64];
        sprintf(event, "%s.start", base_event);
        NL_write(log1, NL_LVL_INFO, event, "guid=i", 1);
        sprintf(event, "%s.end", base_event);
        NL_write(log1, NL_LVL_INFO, event, "guid=i value=d", 1, 3.14 * i);
    }
    DBG("- flush log #\n");
    NL_flush(log1);
    NL_flush(log2);
    DBG1("- check output in %s\n", summ_dest);
    /* ts=2007-08-21T18:44:50.154732Z event=summ.elmos_world pos=0 len=2 */
    ofile = fopen(summ_dest, "r");
    assert(ofile);
    i = 0;
    while (fgets(buf, sizeof(buf), ofile)) {
        int buflen = strlen(buf);

        assert(buflen == 66);
        assert(strstr(buf, "event=summ.elmos_world"));
        assert(strstr(buf, "len=2"));
        if (i % 2) {
            assert(strstr(buf, "pos=1"));
        }
        else {
            assert(strstr(buf, "pos=0"));
        }
        assert(!strncmp("ts=20", buf, 5));
        i++;
    }
    assert(i == nrec * 2);

    integrated_shutdown(obj, log1, summ_dest);

    return 0;
}

TEST_PROTO(integratedConsume)
{
    NL_summ_T obj;
    NL_log_T log1, log2;
    NL_params_T params;
    char *base_event = "elmos_world";
    char *summ_dest, *log_dest;
    int consume_flag, i, nrec = 1000;
    struct stat stat_result;
    char wd[1024];

    for (consume_flag = 0; consume_flag < 2; consume_flag++) {
        DBG1("- setup, with consume flag=%d\n", consume_flag);
        params = NL_params();
        assert(NULL != getcwd(wd, sizeof(wd)));
        log_dest = tempnam(wd, "log-");
        integrated_setup(base_event, &obj, &log1, &log2, &summ_dest,
                         log_dest, consume_flag, i2_istate, i2_process,
                         i2_flush, i2_free);
        DBG1("- write %d record(s)\n", nrec);
        for (i = 0; i < nrec; i++) {
            char event[64];
            int r;
            sprintf(event, "%s.start", base_event);
            r = NL_write(log1, NL_LVL_INFO, event, "guid=i", 1);
            assert(0 == r);
            sprintf(event, "%s.end", base_event);
            r = NL_write(log1, NL_LVL_INFO, event, "guid=i value=d", 1,
                         3.14 * i);
            assert(0 == r);
        }
        DBG("- flush logs\n");
        NL_flush(log1);
        NL_flush(log2);
        assert(0 == stat(log_dest, &stat_result));
        switch (consume_flag) {
        case 0:
            DBG("- verify some output\n");
            assert(0 < stat_result.st_size);
            break;
        case 1:
            DBG("- verify NO output\n");
            assert(0 == stat_result.st_size);
            break;
        }
        integrated_shutdown(obj, log1, summ_dest);
        unlink(log_dest);
    }

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_createDelete();
    test_addLog();
    test_addSequence();
    test_flush();
    test_matchRecord();
    test_newRecord();
    test_removeLog();
    test_writeRecord();
    /* integrated */
    test_integrated1();
    test_integratedConsume();
    //test_integratedTsumm();

    return g_num_failed;
}
