/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nlsummrec.c
 */
#ifndef lint
static const volatile char rcsid[] =
    "$Id: test_nlsummrec.c 130 2007-08-22 14:09:32Z dang $";
#endif

#include "nldbg.h"
#include "util.h"
#include "nlint.h"
#include "nlsummint.h"


/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

#define REC_TIME 2
#define REC_VAL 3.14

NL_rec_t *create_good_record(const char *event)
{
    struct timeval t;
    double v = REC_VAL;
    NL_rec_t *rec;

    t.tv_sec = REC_TIME;
    t.tv_usec = 0;
    rec = NL_rec(4);
    NL_rec_add(rec, NL_fld("ts", 2, &t, sizeof(struct timeval), 't'));
    NL_rec_add(rec, NL_fld("event", 5, (char *) event, 7, 's'));
    NL_rec_add(rec, NL_fld("guid", 4, "guid1", 5, 's'));
    NL_rec_add(rec, NL_fld("result", 6, &v, sizeof(double), 'd'));

    return rec;
}

NL_rec_t *create_record_missing_ids(void)
{
    double v = 1;
    NL_rec_t *rec;

    rec = NL_rec(2);
    NL_rec_add(rec, NL_fld("ts", 2, &v, sizeof(double), 'd'));
    NL_rec_add(rec, NL_fld("event", 5, "Event.1", 7, 's'));

    return rec;
}

NL_rec_t *create_record_missing_values(void)
{
    double v = 1;
    NL_rec_t *rec;

    rec = NL_rec(3);
    NL_rec_add(rec, NL_fld("ts", 2, &v, sizeof(double), 'd'));
    NL_rec_add(rec, NL_fld("event", 5, "Event.1", 7, 's'));
    NL_rec_add(rec, NL_fld("guid", 4, "guid1", 5, 's'));

    return rec;
}

NL_summseq_T create_sequence(void)
{
    NL_summseq_T obj = NL_summseq();
    unsigned i;

    NL_summseq_add_selector(obj, "event", "Event.1", 7);
    NL_summseq_add_selector(obj, "event", "Event.2", 7);
    NL_summseq_add_selector(obj, "event", "Event.3", 7);

    for (i = 0; i < 3; i++) {
        NL_summseq_add_id_field(obj, i, "guid");
    }
    NL_summseq_add_value_field(obj, 2, "result");

    return obj;
}

/* create when record has all ids/values */
TEST_PROTO(create)
{
    NL_summrec_T obj;
    NL_summseq_T seq;
    NL_rec_t *recp;

    DBG("- init\n");
    seq = create_sequence();
    assert(seq);
    recp = create_good_record("Event.1");
    assert(recp);

    DBG("- create / good record\n");
    obj = NL_summrec(recp, 1, seq);
    assert(obj);
    NL_summrec_del(obj);

    DBG("- create / record missing ids\n");
    recp = create_record_missing_ids();
    assert(recp);
    obj = NL_summrec(recp, 1, seq);
    assert(NULL == obj);

    DBG("- create / record missing values\n");
    recp = create_record_missing_values();
    obj = NL_summrec(recp, 2, seq);
    assert(NULL == obj);

    DBG("- done\n");

    return 0;
}

TEST_PROTO(getAction)
{
    NL_summrec_T obj;
    NL_observer_cb action;

    obj = NL_summrec(create_good_record("Event.1"), 1, create_sequence());
    action = NL_summrec_get_action(obj);
    assert(action == NL_summrec_process);

    return 0;
}

void *p_init(void *x)
{
    static char *g_dummy = "foo";
    return g_dummy;
}

int p_process(NL_summstate_T state)
{
    DBG2("-- time=%lld(us) num_values=%d\n", state->ts_usec,
         state->values_n);
    assert(state);
    assert(REC_TIME == state->ts_usec / 1e6);
    assert(state->values_n == 1);
    assert(REC_VAL == state->values[0]);

    return 0;
}

void p_flush(NL_summstate_T state)
{;
}

void p_free(void *x)
{
    return;
}

TEST_PROTO(process)
{
    NL_summrec_T obj;
    NL_summseq_T seq;
    NL_rec_t *recp;
    int r;

    DBG("- init\n");
    seq = create_sequence();
    assert(seq);
    recp = create_good_record("Event.3");
    assert(recp);

    DBG("- before NL_summseq_set_info (fail)\n");
    obj = NL_summrec(recp, 2, seq);
    assert(obj);
    r = NL_summrec_process(obj, recp);
    assert(-1 == r);
    NL_summrec_del(obj);

    DBG("- after NL_summseq_set_info\n");
    r = NL_summseq_set_info(seq, NL_alist(), p_init, p_process, p_flush,
                            p_free);
    assert(0 == r);
    obj = NL_summrec(recp, 2, seq);
    assert(obj);
    r = NL_summrec_process(obj, recp);
    assert(0 == r);

    NL_summrec_del(obj);

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_create();
    test_getAction();
    test_process();
    return g_num_failed;
}
