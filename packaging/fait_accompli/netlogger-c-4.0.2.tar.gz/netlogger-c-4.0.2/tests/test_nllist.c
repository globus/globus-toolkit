static const volatile char rcsid[] =
    "$Id: test_nllist.c 112 2007-08-17 17:04:59Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nllist.c
 */

#include "nllist.h"
#include "nldbg.h"
#include "util.h"

/* List of error messages */
const char *g_err[] = {
    NULL                               /* sentinel */
};

struct timeval tmv1, tmv2;
#define TIMER_START do {                     \
        gettimeofday(&tmv1,0);               \
    } while(0)
#define TIMER_STOP(Y) do {                               \
        gettimeofday(&tmv2,0);                           \
        (Y) = tmv2.tv_sec - tmv1.tv_sec +                \
            (tmv2.tv_usec - tmv1.tv_usec) / 1e6;         \
    } while(0)

/* data */
char *letter[] = { "a", "b", "c", "d", "e", "f" };
enum { A, B, C, D, E, F };

void freeme(void *x)
{
    DBG1("-- freeme() called for '%s'\n", ((char *) x));
    free(x);
}

void dontfreeme(void *x)
{
    DBG1("-- dontfreeme() called for '%s'\n", ((char *) x));
}

TEST_PROTO(create)
{
    NL_list_T obj;

    obj = NL_list();
    assert(obj);
    NL_list_del(obj, NULL);

    return 0;
}

TEST_PROTO(delete)
{
    NL_list_T obj;

    DBG("- empty, freeme\n");
    obj = NL_list();
    assert(obj);
    NL_list_del(obj, freeme);

    DBG("- empty, NULL\n");
    obj = NL_list();
    assert(obj);
    NL_list_del(obj, NULL);

    DBG("- 1 item, freeme\n");
    obj = NL_list();
    assert(obj);
    NL_list_append(obj, strdup("test"));
    NL_list_del(obj, freeme);

    DBG("- 1 letter, NULL\n");
    obj = NL_list();
    assert(obj);
    NL_list_append(obj, letter[A]);
    NL_list_del(obj, NULL);

    DBG("- 1 letter, dontfreeme\n");
    obj = NL_list();
    assert(obj);
    NL_list_append(obj, letter[A]);
    NL_list_del(obj, dontfreeme);

    return 0;
}

TEST_PROTO(insert)
{
    NL_list_T obj;

    obj = NL_list();
    DBG("- 0,a\n");
    NL_list_insert(obj, 0, letter[A]); /* a */
    DBG("- 0,b\n");
    NL_list_insert(obj, 0, letter[B]); /* b,a */
    DBG("- 1,c\n");
    NL_list_insert(obj, 1, letter[C]); /* b,c,a */
    DBG("- 3,d\n");
    NL_list_insert(obj, 3, letter[D]); /* b,c,a,d */
    assert(NL_list_len(obj) == 4);
    assert(NL_list_get(obj, 0) == letter[B]);
    assert(NL_list_get(obj, 1) == letter[C]);
    assert(NL_list_get(obj, 2) == letter[A]);
    assert(NL_list_get(obj, 3) == letter[D]);
    DBG("- delete\n");
    NL_list_del(obj, NULL);

    return 0;
}

TEST_PROTO(append)
{
    NL_list_T obj;

    obj = NL_list();
    NL_list_append(obj, letter[A]);    /* a */
    NL_list_append(obj, letter[B]);    /* a,b */
    assert(NL_list_len(obj) == 2);
    assert(NL_list_get(obj, 0) == letter[A]);
    assert(NL_list_get(obj, 1) == letter[B]);
    NL_list_del(obj, NULL);

    return 0;
}

TEST_PROTO(iter)
{
    NL_list_T obj;
    int i, j;
    void *node;

    obj = NL_list();

    for (i = 0; i < 6; i++) {
        NL_list_append(obj, letter[i]);
        for (j = 0, node = NL_list_iter(obj); node;
             node = NL_list_next_node(obj, node), j++) {
            assert((char *) NL_list_node_data(node) == letter[j]);
        }
    }
    NL_list_del(obj, NULL);

    return 0;
}

TEST_PROTO(get)
{
    NL_list_T obj;
    int i;

    obj = NL_list();

    for (i = 0; i < 6; i++) {
        NL_list_append(obj, letter[i]);
        assert(NL_list_get(obj, (unsigned) i) == letter[i]);
    }
    NL_list_del(obj, dontfreeme);

    return 0;
}

TEST_PROTO(len)
{
    NL_list_T obj;
    int i;

    obj = NL_list();

    for (i = 0; i < 6; i++) {
        assert(NL_list_len(obj) == i);
        NL_list_append(obj, letter[i]);
        assert(NL_list_len(obj) == i + 1);
    }
    NL_list_del(obj, NULL);

    return 0;
}

TEST_PROTO(one)
{
    NL_list_T obj;
    void *node;
    int i;
    double n;

    for (i = 0; i < 1000; i++) {
        obj = NL_list();
        NL_list_append(obj, &n);
        for (node = NL_list_iter(obj); node;
             node = NL_list_next_node(obj, node)) {
            void *data = NL_list_node_data(node);
            assert(data == &n);
        }
        NL_list_del(obj, NULL);
    }
    return 0;
}

TEST_PROTO(remove)
{
    const int N = 20;
    NL_list_T obj;
    void *x[N];
    int i;

    DBG("- init added\n");
    for (i = 0; i < N; i++) {
        x[i] = (void *) i + 1;
    }
    DBG("- init list\n");
    obj = NL_list();
    assert(obj);
    DBG("- remove NULL (fail)\n");
    assert(-1 == NL_list_remove(obj, NULL));
    DBG("- append to list\n");
    for (i = 0; i < N; i++) {
        NL_list_append(obj, x[i]);
    }
    DBG("- remove NULL (fail)\n");
    assert(-1 == NL_list_remove(obj, NULL));
    DBG("- remove in rev. order\n");
    for (i = N - 1; i >= 0; i--) {
        int r = NL_list_remove(obj, x[i]);
        assert(0 == r);
    }
    DBG("- double remove (fail)\n");
    for (i = 0; i < N; i++) {
        assert(-1 == NL_list_remove(obj, x[i]));
    }
    DBG("- delete\n");
    NL_list_del(obj, NULL);

    return 0;
}

TEST_PROTO(replace)
{
    NL_list_T obj;

    obj = NL_list();
    assert(obj);
    DBG("- empty list (fail)\n");
    assert(-1 == NL_list_replace(obj, 0, NULL, freeme));
    NL_list_append(obj, letter[A]);
    DBG("- replace 1st item\n");
    assert(0 == NL_list_replace(obj, 0, NULL, NULL));
    DBG("- replace non-existent 2nd item (fail)\n");
    assert(-1 == NL_list_replace(obj, 1, NULL, freeme));
    NL_list_append(obj, strdup("freeable"));
    DBG("- replace 1st item, NULL free\n");
    assert(0 == NL_list_replace(obj, 0, NULL, NULL));
    DBG("- replace 2nd item with NULL, freeme\n");
    assert(0 == NL_list_replace(obj, 1, NULL, freeme));
    DBG("- replace NULL item, freeme\n");
    assert(0 == NL_list_replace(obj, 1, NULL, freeme));
    DBG("- delete\n");
    NL_list_del(obj, NULL);

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_create();
    test_delete();
    test_insert();
    test_append();
    test_iter();
    test_get();
    test_len();
    test_one();
    test_remove();
    test_replace();
    return 0;
}
