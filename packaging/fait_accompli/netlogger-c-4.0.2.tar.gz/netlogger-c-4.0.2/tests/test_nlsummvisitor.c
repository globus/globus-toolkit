static const volatile char rcsid[] =
    "$Id: template.c 108 2007-08-16 00:22:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nlsummvisitor.c
 */

#include "nldbg.h"
#include "util.h"
#include "nlsummseq.h"
#include "nlsummvisitor.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

TEST_PROTO(create)
{
    NL_summvisitor_T obj;

    DBG("- null obj\n");
    NL_summvisitor_del(NULL);

    DBG("- null data\n");
    obj = NL_summvisitor();
    NL_summvisitor_del(obj);

    DBG("- string data, free()\n");
    obj = NL_summvisitor();
    obj->data = strdup("hello there");
    obj->free_fn = free;
    NL_summvisitor_del(obj);

    return 0;
}

int g_x_ctr = 0;

void x_visit(NL_summvisitor_T obj, void *d)
{
    g_x_ctr++;
    return;
}

void walk_visit(NL_summvisitor_T obj, void *d)
{
    NL_summseq_T seq = (NL_summseq_T) d;

    g_x_ctr = 1;
    NL_summvisitor_walk_table(obj, NL_summseq_get_states(seq));

    return;
}

TEST_PROTO(visit)
{
    NL_summvisitor_T obj;
    NL_summseq_T seq;
    NL_summstate_T state;
    char *foo = "foo";
    int i;
    const int n = 10;

    seq = NL_summseq();
    state = NL_summstate(seq, NULL, NULL);

    DBG("- visit summstate\n");
    obj = NL_summvisitor();
    obj->visit_summstate = x_visit;
    obj->data = foo;
    NL_summvisitor_visit_summstate(obj, state);

    DBG("- visit summseq, do nothing\n");
    obj->visit_summseq = x_visit;
    NL_summvisitor_visit_summseq(obj, seq);

    DBG("- visit summseq, walk empty table\n");
    obj->visit_summseq = walk_visit;
    NL_summvisitor_visit_summseq(obj, seq);
    assert(g_x_ctr == 1);

    DBG("- visit summseq, walk non-empty table\n");
    NL_summseq_add_selector(seq, "foo", "bar", 3);
    NL_summseq_add_id_field(seq, 0, "id");
    DBG1("-- add %d states\n", n);
    for (i = 0; i < n; i++) {
        int is_new;
        NL_summseq_get_state(seq, &i, sizeof(int), &is_new);
        assert(is_new);
    }
    DBG("-- visit sequence\n");
    NL_summvisitor_visit_summseq(obj, seq);
    assert(g_x_ctr == 1 + n);

    NL_summvisitor_del(obj);

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_create();
    test_visit();

    return g_num_failed;
}
