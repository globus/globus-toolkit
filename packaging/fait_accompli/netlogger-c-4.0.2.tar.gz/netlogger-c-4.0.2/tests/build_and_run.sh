#!/bin/sh
# Build and run a test
#
usage () {
    p=`basename $0`
    echo "usage: $p test_suite [-d] [testName]"
    echo "  -d       Debug (set TEST_DEBUG in env)"
}
#
export TEST_DEBUG
if test "$#" -lt 1 -o "$1" = "-h" 
then
    usage
    exit
fi
suite=$1
shift
if test x"$1" = "x-d"
then
    TEST_DEBUG=1
    dbgmode="yes"
    shift
else
    unset TEST_DEBUG
    dbgmode="no"
fi
testname="$1"
#
stars="**********************************************"
echo "$stars"
echo "*    Library"
echo "$stars"
( cd ../lib && make CFLAGS="-g" )
if [ $suite = test_nlio ]
then
    ( cd ../programs && make CFLAGS="-g" )
fi
if [ $? -eq 0 ]
then
    echo "$stars"
    echo "*  $suite $testname"
    echo "*  Debug mode = $dbgmode"
    echo "$stars"
    make $suite  && ( trap '' 1 2 3 5 6 15; ./$suite $testname )
fi
