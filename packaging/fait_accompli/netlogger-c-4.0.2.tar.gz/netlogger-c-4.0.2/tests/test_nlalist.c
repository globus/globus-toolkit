static const volatile char rcsid[] =
    "$Id: template.c 108 2007-08-16 00:22:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nlalist.c
 */

#include "nldbg.h"
#include "util.h"
#include "nlalist.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

TEST_PROTO(data)
{
    NL_adata_T data, data2;
    int64_t i64;
    const char *str = "elmo wants to be your friend";
    char *s;
    
    DBG("- NULL value\n");
    data = NL_adata(NULL, 0, 0);
    assert(data);
    assert(0 == strlen(NL_adata_as_str(data,' ')));
    NL_adata_del(data);
    
    DBG("- get value\n");
    data = NL_adata(&i64, 8, 1);
    assert(data);
    assert(i64 == *((int64_t*)NL_adata_get_value(data)));
    NL_adata_del(data);

    DBG("- get value (no copy)\n");
    data = NL_adata(&i64, 8, 0);
    assert(data);
    assert(&i64 == NL_adata_get_value(data));
    NL_adata_del(data);
    
    DBG("- as string\n");
    data = NL_adata((void*)str, strlen(str), 0);
    assert(data);
    s = NL_adata_as_str(data, ' ');
    assert(0 == strcmp(s, str));
    
    DBG("- cmp\n");
    data2 = NL_adata(s, strlen(s), 0);
    assert(0 == NL_adata_cmp(data, data2));
    free(s);
    NL_adata_del(data2);
    data2 = NL_adata(&i64, 8, 0);
    assert(0 != NL_adata_cmp(data, data2));
    NL_adata_del(data2);

    DBG("- copy\n");
    DBG("-- something\n");
    data2 = NL_adata_copy(data);
    assert(0 == NL_adata_cmp(data, data2));
    NL_adata_del(data);
    data = NL_adata((void*)str, strlen(str), 0);
    assert(0 == NL_adata_cmp(data, data2));
    NL_adata_del(data);
    NL_adata_del(data2);    
    DBG("-- NULL contents\n");
    data = NL_adata(NULL, 0, 0);
    assert(data);
    data2 = NL_adata_copy(data);
    assert(data2);
    assert(0 == NL_adata_cmp(data, data2));
    NL_adata_del(data);
    NL_adata_del(data2);    
    DBG("-- NULL pointer\n");
    data = NULL;
    data2 = NL_adata_copy(data);
    assert(!data2);
    NL_adata_del(data);
    NL_adata_del(data2);    
                
    return 0;
}

TEST_PROTO(node)
{
    NL_adata_T k, v;
    NL_anode_T n, n2;
    int x;
    
    DBG("- NULL key and value\n");
    k = v = NULL;
    n = NL_anode(k,v);
    assert(n);
    NL_anode_del(n);
    
    DBG("- some key and value\n");
    k = NL_adata("foo", 3, 1);
    assert(k);
    v = NL_adata(&x, sizeof(x), 1);
    assert(v);
    n = NL_anode(k,v);
    assert(n);
    
    DBG("- get key\n");
    assert(k == NL_anode_get_key(n));
    
    DBG("- get value\n");
    assert(v == NL_anode_get_value(n));
    
    DBG("- cmp\n");
    DBG("-- with NULL (fail)\n");
    n2 = NL_anode(NULL, NULL);
    assert(0 != NL_anode_cmp(n2,n));
    NL_anode_del(n2);
    DBG("-- with similar\n");
    n2 = NL_anode(NL_adata_copy(k), NL_adata_copy(v));
    assert(0 == NL_anode_cmp(n2,n));
    NL_anode_del(n2);

    NL_anode_del(n);
    
    return 0;
}

TEST_PROTO(list)
{
    NL_alist_T a, b;
    int i;
        
    DBG("- create/delete\n");
    a = NL_alist();
    assert(a);
    NL_alist_del(a);
    
    DBG("- append\n");
    a = NL_alist();
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        n = NL_anode(NL_adata(&i, 4, 1), NULL);
        NL_alist_append(a, n);
    }
    NL_alist_del(a);
    
    DBG("- copy\n");
    a = NL_alist();
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        n = NL_anode(NL_adata(&i, 4, 1), NULL);
        NL_alist_append(a, n);
    }
    DBG("-- do copy\n");
    b = NL_alist_copy(a);
    DBG("-- del copy\n");
    NL_alist_del(a);
    NL_alist_del(b);
    
    DBG("- get by index\n");
    a = NL_alist();
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        n = NL_anode(NL_adata(&i, sizeof(int), 1), NULL);
        NL_alist_append(a, n);
    }
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        int kk;
        n = NL_alist_get_by_index(a, i);
        kk = *((int*)NL_adata_get_value(NL_anode_get_key(n)));
        assert(kk == i);
    }
    NL_alist_del(a);    

    DBG("- get by key\n");
    a = NL_alist();
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        char *ss = strdup("hello");
        n = NL_anode(NL_adata(&i, sizeof(int), 1), 
                     NL_adata(ss, strlen(ss), 0));
        NL_alist_append(a, n);
    }
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        NL_adata_T di;
        int kk;
        char *ss;
        di = NL_adata(&i, sizeof(i), 0);
        n = NL_alist_get_by_key(a, di);
        kk = *((int*)NL_adata_get_value(NL_anode_get_key(n)));
        assert(kk == i);
        ss = NL_adata_get_value(NL_anode_get_value(n));
        assert(0 == strcmp(ss, "hello"));
        NL_adata_del(di);
    }
    NL_alist_del(a);    
        
    DBG("- insert\n");
    a = NL_alist();
    {
        int expected[] = { 1, 3, 2, 0, 4 };
        NL_anode_T n;
        DBG("-- do insertions\n");
        for (i=0; i < 4; i++) {
            n = NL_anode(NL_adata(&i, sizeof(i), 1), NULL);
            NL_alist_insert(a, i/2, n);
        }
        i = 4;
        n = NL_anode(NL_adata(&i, sizeof(i), 1), NULL);
        NL_alist_insert(a, 4, n);
        assert(NL_list_len(a) == 5);
        DBG("-- check\n");
        for (i=0; i < 5; i++) {
            int v = *((int*)NL_adata_get_value(NL_anode_get_key(
                       NL_alist_get_by_index(a, i))));
            /*printf("@@ i=%d expected=%d v=%d\n", i, expected[i], v);*/
            assert(v == expected[i]);
        }
    }
    NL_alist_del(a);
        
    DBG("- len\n");
    a = NL_alist();
    assert(NL_alist_len(a) == 0);
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        n = NL_anode(NL_adata(&i, 4, 1), NULL);
        NL_alist_append(a, n);
        n = NL_anode(NL_adata(&i, 4, 1), NULL);
        NL_alist_insert(a, 0, n);
        assert(NL_alist_len(a) == 2 * (i+1));
    }
    NL_alist_del(a);
    
    DBG("- remove\n");
    a = NL_alist();
    for (i=0; i < 1000; i++) {
        NL_anode_T n;
        n = NL_anode(NL_adata(&i, sizeof(int), 1), NULL);
        NL_alist_append(a, n);
    }
    assert(NL_alist_len(a) == 1000);
    for (i=0; i < 800; i += 2) {
        NL_anode_T n;
        assert(NL_alist_len(a) == 1000 - i);
        n = NL_alist_get_by_index(a, 199);
        assert(n == NL_alist_remove(a, n));
        NL_anode_del(n);
        n = NL_alist_get_by_index(a, 0);
        assert(n == NL_alist_remove(a, n));
        NL_anode_del(n);
    }
    NL_alist_del(a);    
    
    DBG("- readonly\n");
    a = NL_alist();
    NL_alist_set_read_only(a, 1);
    {
        NL_anode_T n;
        int i=1;
        n = NL_anode(NL_adata(&i, sizeof(int), 1), NULL);
        NL_alist_append(a, n);
        assert(NL_alist_len(a) == 0);
        NL_alist_insert(a, 0, n);
        assert(NL_alist_len(a) == 0);
        NL_alist_remove(a, n);
        assert(NL_alist_len(a) == 0);        
    }
    NL_alist_set_read_only(a, 0);
    {
        NL_anode_T n;
        int i=1;
        n = NL_anode(NL_adata(&i, sizeof(int), 1), NULL);
        NL_alist_append(a, n);
        assert(NL_alist_len(a) == 1);
        n = NL_anode(NL_adata(&i, sizeof(int), 1), NULL);
        NL_alist_insert(a, 0, n);
        assert(NL_alist_len(a) == 2);
        NL_alist_remove(a, n);
        assert(NL_alist_len(a) == 1);        
    }
    NL_alist_del(a);
    
    DBG("- del\n");
    NL_alist_del(NULL);
    
    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_data();
    test_node();
    test_list();
    return g_num_failed;
}
