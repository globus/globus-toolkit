static const volatile char rcsid[] = "$Id$";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nltransfer.c
 */

#include <math.h>                      /* sqrt */
#include <sys/types.h>                 /* getpid */
#include <unistd.h>                    /* getpid */
#include "nldbg.h"
#include "util.h"
#include "nltransfer.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

TEST_PROTO(init)
{
    NL_summ_T summ = NL_summ();
    int r;

    DBG("- NULL summarizer (fail)\n");
    assert(-1 == NL_transfer_init(NULL, 0, NL_LVL_INFO));
    DBG("- Negative log level (fail)\n");
    assert(-1 == NL_transfer_init(summ, -1LL, -1));
    DBG("- Negative time interval\n");
    r = NL_transfer_init(summ, -1LL, NL_LVL_INFO);
    EASSERT(0 == r);

    NL_summ_del(summ);

    return 0;
}

void verify_last_event_contains(const char *filename, const char *str)
{
    FILE *fp = fopen(filename, "r");
    char buf[1024];

    assert(fp);
    while (fgets(buf, sizeof(buf), fp));
    fclose(fp);
    if (NULL == strstr(buf, str)) {
        SAY2("Could not find '%s' in '%s'\n", str, buf);
        assert(0);
    }
}

TEST_PROTO(startEnd)
{
    NL_summ_T summ = NL_summ();
    NL_log_T log, o_log;
    char tmpfile[32];

    DBG("- init\n");
    sprintf(tmpfile, "test_nltransfer_%d.log", getpid());
    o_log = NL_open(tmpfile);
    EASSERT(NULL != o_log);
    log = NL_open("-");
    EASSERT(NULL != log);
    EASSERT(0 == NL_transfer_init(summ, -1LL, NL_LVL_INFO));
    NL_summ_add_log(summ, log);
    NL_summ_set_output(summ, o_log);

    DBG("- bad stream id (noop)\n");
    NL_transfer_start(log, NL_LVL_INFO, NL_TRANSFER_DISK_READ, NULL, 0, 0);

    DBG("- NULL guid\n");
    NL_transfer_start(log, NL_LVL_INFO, NL_TRANSFER_DISK_READ, NULL, 1, 0);
    NL_transfer_end(log, NL_LVL_INFO, NL_TRANSFER_DISK_READ, NULL, 1, 0,
                    1);
    NL_transfer_finalize(summ);
    verify_last_event_contains(tmpfile, "disk.read");

    DBG("- some guid\n");
    NL_transfer_start(log, NL_LVL_INFO, NL_TRANSFER_NET_WRITE, "guid", 1,
                      0);
    NL_transfer_end(log, NL_LVL_INFO, NL_TRANSFER_NET_WRITE, "guid", 1, 0,
                    1);
    NL_transfer_finalize(summ);
    verify_last_event_contains(tmpfile, "net.write");
    verify_last_event_contains(tmpfile, "guid=guid");

    DBG("- cleanup\n");
    NL_summ_del(summ);
    NL_close(log);
    unlink(tmpfile);

    return 0;
}

TEST_PROTO(finalize)
{
    NL_summ_T summ = NL_summ();
    NL_log_T log, o_log;
    char tmpfile[32];

    DBG("- tolerate NULL summarizer\n");
    NL_transfer_finalize(NULL);

    DBG("- naked finalize\n");
    NL_transfer_finalize(summ);

    DBG("- with init\n");
    sprintf(tmpfile, "test_nltransfer_%d.log", getpid());
    o_log = NL_open(tmpfile);
    EASSERT(NULL != o_log);
    log = NL_open("-");
    EASSERT(NULL != log);
    EASSERT(0 == NL_transfer_init(summ, -1LL, NL_LVL_INFO));
    NL_summ_add_log(summ, log);
    NL_summ_set_output(summ, o_log);
    NL_transfer_finalize(summ);

    DBG("- cleanup\n");
    NL_summ_del(summ);
    NL_close(log);
    unlink(tmpfile);

    return 0;
}

TEST_PROTO(getNumStreams)
{
    NL_summ_T summ = NL_summ();
    NL_log_T log;
    int i, guid_i, max_expected;
    unsigned n;
    const char *guids[] = { NULL, "it's a wonderful guid" };
    NL_transfer_op_t op;

    DBG("- init\n");
    log = NL_open("-");
    EASSERT(NULL != log);
    EASSERT(0 == NL_transfer_init(summ, -1LL, NL_LVL_INFO));
    NL_summ_add_log(summ, log);

    max_expected = 3;
    op = NL_TRANSFER_DISK_READ;
    for (guid_i = 0; guid_i < sizeof(guids) / sizeof(char *); guid_i++) {
        char *guid = (char *) guids[guid_i];
        DBG2("- guid='%s', from 0 to %d streams\n", guid ? guid : "(null)",
             max_expected);
        /* 0 streams */
        DBG("-- 0 streams\n");
        NL_transfer_finalize(summ);
        n = NL_transfer_get_num_streams(summ, op, guid);
        assert(0 == n);
        for (i = 1; i <= max_expected; i++) {
            DBG1("-- %d streams\n", i);
            /* add a stream */
            NL_transfer_start(log, NL_LVL_INFO, op, guid, i, 0);
            NL_transfer_end(log, NL_LVL_INFO, op, guid, i, 0, 1);
            /* get current number */
            NL_transfer_finalize(summ);
            n = NL_transfer_get_num_streams(summ, op, guid);
            assert(i == n);
            n = NL_transfer_get_num_streams(summ, op + 1, guid);
            assert(0 == n);
        }
    }

    return 0;
}

TEST_PROTO(getResults)
{
    NL_summ_T summ = NL_summ();
    NL_log_T log, o_log;
    char tmpfile[32], *my_guid;
    int i, j, r, nstreams;
    const int N = 100;
    NL_transfer_result_t data;

    DBG("- init\n");
    sprintf(tmpfile, "test_nltransfer_%d.log", getpid());
    o_log = NL_open(tmpfile);
    EASSERT(NULL != o_log);
    log = NL_open("-");
    EASSERT(NULL != log);
    EASSERT(0 == NL_transfer_init(summ, -1LL, NL_LVL_INFO));
    NL_summ_add_log(summ, log);
    NL_summ_set_output(summ, o_log);

    for (nstreams = 1; nstreams < 4; nstreams++) {
        DBG1("* NULL guid, %d stream.ids\n", nstreams);
        for (i = 0; i < N; i++) {
            for (j = 1; j <= nstreams; j++) {
                NL_transfer_start(log, NL_LVL_INFO, NL_TRANSFER_DISK_READ,
                                  NULL, j, 0);
                NL_transfer_end(log, NL_LVL_INFO, NL_TRANSFER_DISK_READ,
                                NULL, j, 0, 1);
            }
        }
        NL_transfer_finalize(summ);
        r = NL_transfer_get_result(summ, NL_TRANSFER_DISK_READ,
                                   NULL, -1, 1, &data);
        assert(1 == r);        
        DBG2("-- data count = %lld, expected = %lld\n", data.count, N);
        assert(data.count == N);
        assert(data.value_count == N);
        assert(data.duration < 0.001 * N);      /* over 1ms second per iter: bad */
        assert(data.value_min == 1);
        assert(data.value_max == 1);
        assert(EQ_EPS(data.value_sd, 0, 0.001));
        DBG("-- look for non-existent event (fail)\n");
        r = NL_transfer_get_result(summ, NL_TRANSFER_NET_READ, NULL, -1,
                                   1, &data);
        assert(-1 == r);
        DBG("-- look for non-existent guid (fail)\n");
        r = NL_transfer_get_result(summ, NL_TRANSFER_DISK_READ, "X", -1,
                                   1, &data);
        assert(-1 == r);

        DBG1("* non-NULL guid, %d stream.id's\n", nstreams);
        r = NL_get_guid(&my_guid);
        if (-1 == r) {
            r = NL_get_someid(&my_guid);
            assert(0 == r);
        }
        for (i = 0; i < N; i++) {
            for (j = 1; j <= nstreams; j++) {
                NL_transfer_start(log, NL_LVL_INFO, NL_TRANSFER_DISK_READ,
                                  my_guid, j, 0);
                NL_transfer_end(log, NL_LVL_INFO, NL_TRANSFER_DISK_READ,
                                my_guid, j, 0, 1);
            }
        }
        NL_transfer_finalize(summ);
        DBG("- get specific guid\n");
        r = NL_transfer_get_result(summ, NL_TRANSFER_DISK_READ,
                                   my_guid, -1, 1, &data);
        assert(1 == r);
        DBG1("-- data count = %lld\n", data.count);
        assert(data.count == N);
        DBG("- get any guid\n");
        r = NL_transfer_get_result(summ, NL_TRANSFER_DISK_READ,
                                   NULL, -1, 1, &data);
        assert(1 == r);
        DBG1("-- data count = %lld\n", data.count);
        assert(data.count == N);
        DBG("- get all streams\n");
        r = NL_transfer_get_result(summ, NL_TRANSFER_DISK_READ,
                                   my_guid, -1, 0, &data);
        assert(nstreams == r);
        DBG1("-- data count = %lld\n", data.count);
        assert(data.count == N * nstreams);
        DBG("- look for non-existent event (fail)\n");
        r = NL_transfer_get_result(summ, NL_TRANSFER_NET_READ, NULL, -1, 1,
                                   &data);
        assert(-1 == r);
        DBG("- look for non-existent guid (fail)\n");
        r = NL_transfer_get_result(summ, NL_TRANSFER_DISK_READ, "X", -1, 1,
                                   &data);
        assert(-1 == r);

        free(my_guid);
    }
    DBG("- cleanup\n");
    NL_summ_del(summ);
    NL_close(log);
    unlink(tmpfile);

    return 0;
}

TEST_PROTO(verifyResults)
{
    NL_summ_T summ;
    NL_log_T log, o_log;
    void *guid = NULL;
    int i, j;
    const int N = 17, M = 33;
    NL_transfer_op_t op = NL_TRANSFER_DISK_READ;
    NL_transfer_result_t ri, r0;
    double m_sum;

    /* initialize */
    DBG("- init\n");
    summ = NL_summ();
    log = NL_open("-");
    EASSERT(NULL != log);
    NL_summ_add_log(summ, log);
    o_log = NL_open("/dev/null");
    EASSERT(NULL != o_log);
    NL_summ_set_output(summ, o_log);
    EASSERT(0 == NL_transfer_init(summ, -1LL, NL_LVL_INFO));
    /* loop up to N streams */
    DBG1("- 1 .. %d streams\n", N);
    for (i = 1; i <= N; i++) {
        /* do M start/end pairs */
        for (j = 1; j <= M; j++) {
            NL_transfer_start(log, NL_LVL_INFO, op, guid, i, 0);
            NL_transfer_end(log, NL_LVL_INFO, op, guid, i, 0, j);
        }
        /* get results */
        NL_transfer_finalize(summ);
        NL_transfer_get_result(summ, op, guid, -1, i, &ri);
        NL_transfer_get_result(summ, op, guid, -1, 0, &r0);
        /* check results */
        assert(r0.count == i * M && ri.count == M);
        assert(r0.value_min == 1 && ri.value_min == 1);
        assert(r0.value_max == M && ri.value_max == M);
        m_sum = M * (M + 1) / 2;
        assert(r0.value_sum == i * m_sum && ri.value_sum == m_sum);
        assert(r0.value_mean == m_sum / M && ri.value_mean == m_sum / M);
        assert(r0.time_min <= ri.time_min && r0.time_max >= ri.time_max);
        assert(r0.ratio_min <= ri.ratio_min
               && r0.ratio_max >= ri.ratio_max);
    }
    DBG("- cleanup\n");
    NL_summ_del(summ);
    NL_close(log);

    return 0;
}

TEST_PROTO(verifyResults2)
{
#define M 101
    NL_summ_T summ;
    NL_log_T log, o_log;
    void *guid = NULL;
    int i;
    NL_transfer_op_t op = NL_TRANSFER_DISK_READ;
    NL_transfer_result_t ri;
    double deltat[M], value[M];
    double vsum, vmean, vvar, vsd;
    double rsum, rmean, rvar, rsd;
    struct timespec short_time, rem_time;

    /* initialize */
    DBG("- init\n");
    summ = NL_summ();
    log = NL_open("-");
    EASSERT(NULL != log);
    NL_summ_add_log(summ, log);
    o_log = NL_open("/dev/null");
    EASSERT(NULL != o_log);
    NL_summ_set_output(summ, o_log);
    EASSERT(0 == NL_transfer_init(summ, -1LL, NL_LVL_INFO));
    short_time.tv_sec = 0;
    short_time.tv_nsec = 100000;       /* .1ms */
    /* do M start/end pairs */
    for (i = 0; i < M; i++) {
        double dt = 0;
        value[i] = (i % 100) + 1;      /* no zeroes, as these are dropped */
        TIMER_START;
        NL_transfer_start(log, NL_LVL_INFO, op, guid, 1, 0);
        nanosleep(&short_time, &rem_time);
        NL_transfer_end(log, NL_LVL_INFO, op, guid, 1, 0, value[i]);
        TIMER_STOP(dt);
        deltat[i] = dt;
    }
    /* get results */
    NL_transfer_finalize(summ);
    NL_transfer_get_result(summ, op, guid, -1, 1, &ri);
    /*printf("@@ FROM NL_TRANSFER: vmean=%lf vsd=%lf ; rmean=%lf rsd=%lf\n",
       ri.value_mean, ri.value_sd, ri.ratio_mean, ri.ratio_sd); */
    /* calculate by hand */
    vsum = rsum = 0.;
    for (i = 0; i < M; i++) {
        vsum += value[i];
        rsum += value[i] / deltat[i];
    }
    vmean = vsum / M;
    rmean = rsum / M;
    vvar = rvar = 0.;
    for (i = 0; i < M; i++) {
        vvar += (value[i] - vmean) * (value[i] - vmean);
        rvar +=
            (value[i] / deltat[i] - rmean) * (value[i] / deltat[i] -
                                              rmean);
    }
    vvar = vvar / M;
    rvar = rvar / M;
    vsd = sqrt(vvar);
    rsd = sqrt(rvar);
    /*printf("@@ BY HAND         : vmean=%lf vsd=%lf ; rmean=%lf rsd=%lf\n",
       vmean, vsd, rmean, rsd); */
    /* check results */
    DBG("- check results");
    assert(ri.count == M);
    assert(ri.value_mean == vmean);
    assert(EQ_EPS(ri.ratio_mean, rmean, 0.2 * rmean));
    assert(EQ_EPS(ri.ratio_sd, rsd, 0.2 * rsd));
    assert(EQ_EPS(ri.value_sd, vsd, 0.2 * vsd));

    DBG("- cleanup\n");
    NL_summ_del(summ);
    NL_close(log);

    return 0;
}

#undef M

/* factored-out functionality for result string tests */
char* buildResultString(int nstreams, NL_transfer_op_t *ops)
{
    NL_summ_T summ;
    NL_log_T log, o_log;
    int i, j, k;
    const int M = 11;
    struct timespec short_time, rem_time;
	char *s;

    /* initialize */
    DBG("- init\n");
    summ = NL_summ();
    log = NL_open("-");
    EASSERT(NULL != log);
    NL_summ_add_log(summ, log);
    o_log = NL_open(NULL);
    EASSERT(NULL != o_log);
    NL_summ_set_shared_output(summ, o_log);
    EASSERT(0 == NL_transfer_init(summ, -1LL, NL_LVL_INFO));
    short_time.tv_sec = 0;
    short_time.tv_nsec = 100000;       /* .1ms */
    /* do M start/end pairs */
    for (i = 0; i < M; i++) {
        for (j = 0; j < 2; j++) {
            for (k = 0; k < nstreams; k++) {
                NL_transfer_start(log, NL_LVL_INFO, ops[j], "hello", k, i);
                nanosleep(&short_time, &rem_time);
                NL_transfer_end(log, NL_LVL_INFO, ops[j], "hello", k, i,
                                3.0 * i);
            }
        }
    }
    /* get results */
    DBG("- finalize\n");
    NL_transfer_finalize(summ);
    DBG("- get result string\n");
    s = NL_transfer_get_result_string(summ, "hello");
	NL_summ_del(summ);
	NL_close(o_log);

	return s;
}

TEST_PROTO(resultString)
{
    char *result_str;
    const int nstreams = 13;
    NL_transfer_op_t ops[2] =
        { NL_TRANSFER_DISK_READ, NL_TRANSFER_NET_WRITE };
    int i;
    char *p;
    
    result_str = buildResultString(nstreams, ops);
    DBG("- check result string\n");
    if (NULL == result_str)
        PRINT_ERR;
    assert(result_str);
    DBG1("Result string:\n%s", result_str);
    /* count newlines */
    for (i = 0, p = result_str; *p; p++)
        if ('\n' == *p)
            i++;
    assert(i == sizeof(ops) / sizeof(NL_transfer_op_t) * nstreams);
    /* free up result */
    DBG("- free result string\n");
    free(result_str);
    
    return 0;
}

TEST_PROTO(bottleneck)
{
    int result;
    char *r1, *r2;
    NL_transfer_op_t snd_ops[2] =
        { NL_TRANSFER_DISK_READ, NL_TRANSFER_NET_WRITE };
    NL_transfer_op_t rcv_ops[2] =
        { NL_TRANSFER_DISK_WRITE, NL_TRANSFER_NET_READ };  
    NL_transfer_btl_t btl;  

    DBG("- build result strings\n");
    r1 = buildResultString(5, snd_ops);
    assert(r1);
    r2 = buildResultString(5, rcv_ops);
    assert(r2);
    DBG("- get bottleneck\n");
    result = NL_transfer_get_bottleneck(r1, r2, &btl);
    assert(0 == result);
    assert(btl.result == NL_BTL_UNKNOWN);
    DBG("- get bottleneck, 2 NULLs\n");
    result = NL_transfer_get_bottleneck(NULL, NULL, &btl);
    assert(0 == result);
    assert(btl.result = NL_BTL_MISSING_DATA);
    DBG("- get bottleneck, 1 NULL\n");
    result = NL_transfer_get_bottleneck(r1, NULL, &btl);
    assert(0 == result);
    assert(btl.result = NL_BTL_MISSING_DATA);
    result = NL_transfer_get_bottleneck(NULL, r2, &btl);
    assert(0 == result);
    assert(btl.result = NL_BTL_MISSING_DATA);
   
    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_init();
    test_startEnd();
    test_finalize();
    test_getNumStreams();
    test_getResults();
    test_verifyResults();
    test_verifyResults2();
    test_resultString();
    test_bottleneck();

    return g_num_failed;
}
