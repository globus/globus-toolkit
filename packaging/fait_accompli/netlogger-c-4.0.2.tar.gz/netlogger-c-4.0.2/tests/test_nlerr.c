static const volatile char rcsid[] =
    "$Id: test_nlerr.c 108 2007-08-16 00:22:32Z dang $";
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for internal error reporting routines
 *
 * Usage: nlerr_test
 */
#include <assert.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#include "nlerr.h"
#include "util.h"

const char *g_err[] = { };

TEST_PROTO(same)
{
    const char *s;
    const char *msg = "test error";
    int i, again;

    DBG("\nsame thing comes out as went in?\n");
    for (again = 0; again < 3; again++) {
        for (i = 0; i < 10; i++) {
            NL_err_add("%s %d", msg, i);
        }
        s = NL_err_str();
        for (i = 0; i < 10; i++) {
            char buf[100];
            sprintf(buf, "%s %d", msg, i);
            assert(strstr(s, buf));
        }
    }

    return 0;
}

TEST_PROTO(large)
{
    int i, again;
    char *s;

    DBG("\noverflow the buffer\n");
    for (again = 0; again < 3; again++) {
        NL_err_clear();
        for (i = 0; i < 2000; i++) {
            NL_err_add("This (%d) is a sample error. Woo-hoo", i);
        }
        s = NL_err_str();
        assert(strlen(s) == NL_ERR_MAX);
    }
    /*printf("@@ message='%s'\n",s); */

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);

    test_same();
    test_large();

    return 0;
}
