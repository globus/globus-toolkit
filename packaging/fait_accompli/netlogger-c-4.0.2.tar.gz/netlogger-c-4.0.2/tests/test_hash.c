static const volatile char rcsid[] =
    "$Id: test_hash.c 125 2007-08-21 06:24:25Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for simple chained hash table.
 *
 * Usage: test_hash
 */

#include "nlhash.h"
#include "nldbg.h"
#include "util.h"

#include <sys/time.h>

/* List of error messages */
const char *g_err[] = {
    NULL                               /* sentinel */
};

struct timeval tmv1, tmv2;
#define TIMER_START do {                     \
        gettimeofday(&tmv1,0);               \
    } while(0)
#define TIMER_STOP(Y) do {                               \
        gettimeofday(&tmv2,0);                           \
        (Y) = tmv2.tv_sec - tmv1.tv_sec +                \
            (tmv2.tv_usec - tmv1.tv_usec) / 1e6;         \
    } while(0)

struct mydata {
    char *s;
    int v;
};

void mydata_free(void *d)
{
    struct mydata *datap = (struct mydata *) d;
    assert(datap);
    free(datap->s);
    free(datap);
}

TEST_PROTO(correctness)
{
    int i, n = 10;
    NL_hash_T h3;
    struct mydata *datap;

    DBG("- put keys\n");
    h3 = NL_hash(n);
    for (i = 0; i < n; i++) {
        char key[5];
        sprintf(key, "%d", i);
        datap = malloc(sizeof(struct mydata));
        datap->s = strdup(key);
        datap->v = i;
        NL_hash_put(h3, key, strlen(key), datap, 0);
    }
    DBG("- get and check keys\n");
    for (i = 0; i < n; i++) {
        char key[5];
        NL_hash_node_t node;
        int klen;

        sprintf(key, "%d", i);
        klen = strlen(key);
        NL_HASH_GET(h3, key, klen, datap);
        assert(datap);
        assert(datap->v == i);
    }
    DBG("- delete\n");
    NL_hash_del(h3, mydata_free);

    return 0;
}

void node_count(NL_hash_T tbl, NL_hash_node_t node, void *mydata)
{
    ++*((int *) mydata);
}

TEST_PROTO(visit)
{
    int i, n = 100, m;
    NL_hash_T h3;

    h3 = NL_hash(n);
    for (i = 0; i < n; i++) {
        char key[4];
        char *value;
        sprintf(key, "%d", i);
        value = strdup(key);
        NL_hash_put(h3, key, strlen(key), value, 0);
    }
    m = 0;
    NL_hash_visit(h3, node_count, &m);
    if (m != n) {
        printf("\n (m) %d != %d (n)\n", m, n);
        assert(m == n);
    }
    return 0;
}

void _speed(char test, int m, double *elapsed)
{
#define N 1000
    int load, i, j, n = N;
    NL_hash_T h3;
    char keys[N][8];
    int keylens[N];
    void *value;

    for (i = 0; i < n; i++) {
        sprintf(keys[i], "xxxx%d", i);
        keylens[i] = strlen(keys[i]);
    }
    memset(elapsed, 0, sizeof(elapsed));
    for (load = 5; load < 50; load += 5) {
        h3 = NL_hash(n);
        for (i = 0; i < n / 100 * load; i++) {
            value = (void *) strdup(keys[i]);
            NL_hash_put(h3, keys[i], keylens[i], value, 0);
        }
        switch (test) {
        case 's':
            TIMER_START;
            for (i = 0, j = 0; i < m; i++, j++) {
                if (j == n)
                    j = 0;
                NL_HASH_GET(h3, keys[j], keylens[j], value);
            }
            TIMER_STOP(elapsed[load]);
            break;
        case 'l':
            TIMER_START;
            for (i = 0, j = 0; i < m; i++, j++) {
                if (j == 2)
                    j = 0;
                NL_HASH_GET(h3, keys[j], keylens[j], value);
            }
            TIMER_STOP(elapsed[load]);
            break;
        default:
            return;
        }
        NL_hash_del(h3, free);
    }
}

TEST_PROTO(speed)
{
    int i, m = 100000;
    double elapsed[100];

    memset(elapsed, 0, sizeof(elapsed));
    DBG("- many keys:\n");
    _speed('s', m, elapsed);
    for (i = 0; i < 100; i++) {
        if (elapsed[i])
            DBG2("-- %-2d%% full = %.1lfns / get()\n", i,
                 (1e9 * elapsed[i]) / m);
    }
    memset(elapsed, 0, sizeof(elapsed));
    DBG("- only two keys:\n");
    _speed('l', m, elapsed);
    for (i = 0; i < 100; i++) {
        if (elapsed[i])
            DBG2("-- %-2d%% full = %.1lfns / get()\n", i,
                 (1e9 * elapsed[i]) / m);
    }
    return 0;
}


int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_correctness();
    test_visit();
    test_speed();

    return 0;
}
