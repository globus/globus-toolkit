static const volatile char rcsid[] =
    "$Id: template.c 108 2007-08-16 00:22:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nlparams.c
 */
#include <stdio.h>
#include "nldbg.h"
#include "util.h"
#include "nlparams.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

TEST_PROTO(params)
{
    NL_params_T p, p2;
    int i, kn, vn;
    const char *keys[] = { "k.foo", "k.bar", "k.baz" };
    int64_t values[] = { -1, 2, -3 };
    int32_t i32[] = { 1, -4, 7 }; 
    double dbl[] = { 3.3, 4.4, 5.5 };
    int64_t v;
    int32_t i32v;
    double dblv;
    char *sv;
    
    kn = sizeof(keys) / sizeof(char*);
    vn = sizeof(values) / sizeof(int64_t);
    
    DBG("- create\n");
    p = NL_params();
    assert(p);
    NL_params_del(p);
    
    DBG("- append\n");
    p = NL_params();
    for (i=0; i < 100; i++) {
        NL_params_append(p, keys[i % kn], &values[i % vn], 8);
    }    
    DBG("- copy\n");
    p2 = NL_params_copy(p);
    assert(p2);
    DBG("- get int64\n");
    assert(0 == NL_params_get_int64(p, keys[0], &v));
    assert(v == values[0]);
    assert(0 == NL_params_get_int64(p2, keys[0], &v));
    assert(v == values[0]);
    NL_params_del(p);
    NL_params_del(p2);
    
    DBG("- get int32\n");
    p = NL_params();
    NL_params_append(p, keys[1], &i32[1], 4);
    assert(0 == NL_params_get_int32(p, keys[1], &i32v));
    assert(i32v == i32[1]);
    
    DBG("- get double\n");
    NL_params_append(p, keys[0], &dbl[1], sizeof(double));
    assert(0 == NL_params_get_double(p, keys[0], &dblv));
    assert(dblv == dbl[1]);
    
    DBG("- get string\n");
    for (i=0; i < 15; i++) {
        char kbuf[128], vbuf[128];
        sprintf(kbuf,"%s%d", keys[i % kn], i);
        sprintf(vbuf,"hello%d", i);
        NL_params_append(p, kbuf, vbuf, strlen(vbuf));
        assert(0 == NL_params_get_string(p, kbuf, &sv));
        assert(0 == strcmp(sv, vbuf));
        free(sv);
    }
    
    NL_params_del(p);
    
    DBG("- del\n");
    NL_params_del(NULL);
    
    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_params();

    return g_num_failed;
}
