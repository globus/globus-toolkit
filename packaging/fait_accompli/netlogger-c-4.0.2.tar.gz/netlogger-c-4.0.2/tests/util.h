#ifndef NL_TEST_UTIL_INCLUDED
#    define NL_TEST_UTIL_INCLUDED

#    include <assert.h>
#    include <stdlib.h>
#    include <sys/time.h>
#    include <stdio.h>
#    include <string.h>
#    include <time.h>

#    include "nlint.h"
#    include "nlsummint.h"
#    include "nlerr.h"

int nl_test_dbg = 0;
extern const char *g_err[];

char *g_suite = NULL;           /* current test suite name */
char *g_test = NULL;            /* test to run, or NULL for 'all' */
int g_num_failed = 0;

#    define SAY(s) fprintf(stderr,s)
#    define SAY1(s,a1) fprintf(stderr,(s),(a1))
#    define SAY2(s,a1,a2) fprintf(stderr,s,a1,a2)
#    define SAY3(s,a1,a2,a3) fprintf(stderr,s,a1,a2,a3)
#    define DBG(s) if ( nl_test_dbg ) SAY(s)
#    define DBG1(s,a1) if ( nl_test_dbg ) SAY1((s),(a1))
#    define DBG2(s,a1,a2) if ( nl_test_dbg ) SAY2(s,a1,a2)
#    define DBG3(s,a1,a2,a3) if ( nl_test_dbg ) SAY3(s,a1,a2,a3)

#    define PRINT_ERR do { SAY1("\n** Error: %s\n", NL_err_str()); \
NL_err_clear(); } while(0)

#    define EASSERT(expr) if (!(expr)) { PRINT_ERR; assert(expr); }

void nl_test_init(int argc, char **argv)
{
    char *p;

    if (getenv("TEST_DEBUG") && strlen(getenv("TEST_DEBUG")))
        nl_test_dbg = 1;
    p = strrchr(argv[0], '/');
    if (p) {
        g_suite = strdup(p + 1);
    }
    else {
        g_suite = strdup(argv[0]);
    }
    if (strlen(g_suite) > 5 && !strncmp(g_suite, "test_", 5)) {
        g_suite += 5;                  /* skip initial 'test_' */
    }
    if (argc > 1) {
        g_test = argv[1];
    }
}

inline const char *get_err(int i)
{
    int ii;
    if (i < 0)
        return "Unspecified error";
    for (ii = 0; ii < i; ii++)
        if (!g_err[ii])
            return "Unknown error code";
    return g_err[i];
}

#    define TEST_PROTO(X)					\
  int _test_##X();					\
  void test_##X() { int r=0;      				\
    if (!g_test || !strcmp(#X , g_test)) { \
      int i, n; \
      char hdr[100], spc[80]; \
      memset(spc,0,sizeof(spc)); \
      n = sprintf(hdr, "%s::%s ",g_suite,""#X); \
      for (i=0; i < (nl_test_dbg ? 40:40-n); i++) { spc[i] = ' '; } \
      SAY(hdr);             \
    DBG("\n");                                          \
    NL_err_clear(); \
    r = _test_##X();					\
    if (r) {						\
      SAY2("%sFAIL: %s\n",spc, get_err(r-1));	\
      g_num_failed++; \
    }							\
    else {						\
      SAY1("%sok\n", spc);				\
    }							\
    } \
  }							\
  int _test_##X()

/* whether two values x,y are within e (for epsilon) of each other */
#    define EQ_EPS(x,y,e) ((x) > (y) ? (x-y <= e) : (y-x <= e))

struct timeval tmv1, tmv2;
#    define TIMER_START do {                     \
        gettimeofday(&tmv1,0);               \
    } while(0)
#    define TIMER_STOP(Y) do {                               \
        gettimeofday(&tmv2,0);                           \
        (Y) = tmv2.tv_sec - tmv1.tv_sec +                \
            (tmv2.tv_usec - tmv1.tv_usec) / 1e6;         \
    } while(0)

#endif                          /* .. INCLUDED */
