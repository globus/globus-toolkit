static const volatile char rcsid[] =
    "$Id: test_nl.c 111 2007-08-17 00:19:04Z dang $";
/* 
Copyright (c) 2004, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests nl_log.c/h
 *
 * Usage: nlsm_test
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "util.h"
#include "nl.h"

/* List of error messages */
const char *g_err[] = {
    "Cannot allocate memory",          /* 1 */
    "Bad inputs not properly handled", /* 2 */
    NULL                               /* sentinel */
};

TEST_PROTO(nlUuid)
{
    char *uuid;
    int result;

    DBG("- get uuid\n");
    result = NL_get_guid(&uuid);
    if (result > 0) {
        DBG1("  uuid = '%s'\n", uuid);
        DBG1("  uuid len = '%d'\n", (int) strlen(uuid));
        assert(result == 36);
        assert(strlen(uuid) == 36);
    }
    else {
        NL_get_someid(&uuid);
        DBG1("  someid = '%s'\n", uuid);
    }
    free(uuid);

    return 0;
}

TEST_PROTO(nlClose)
{
    char outp_file[128];
    struct stat sb[2];
    NL_log_T log;
    int stat_r, i, buffered;

    sprintf(outp_file, "/tmp/nl_close_test.%d", getpid());

    DBG("\n  create+open log handle\n");
    log = NL_open(outp_file);
    assert(log != NULL);

    /* try to find some buffering by writing a small event
     * and checking for no change in file size
     */
    NL_set_level(log, NL_LVL_INFO);
    for (i = 0, buffered = 0; !buffered && i < 1000; i++) {
        stat_r = stat(outp_file, &(sb[0]));
        assert(0 == stat_r);
        NL_write(log, NL_LVL_INFO, "A", "i=i", i);
        stat_r = stat(outp_file, &(sb[1]));
        if (sb[0].st_size == sb[1].st_size)
            buffered = 1;
    }
    /* if buffering occurred, close log
     * and check that file size changed 
     */
    if (buffered) {
        DBG("  close log handle\n");
        NL_close(log);
        stat_r = stat(outp_file, &(sb[1]));
        assert(sb[0].st_size != sb[1].st_size);
    }
    else {
        /* no buffering. oh, well.. */
        DBG("  no buffering of output, flush-on-close unverified\n");
        NL_close(log);
    }

    unlink(outp_file);

    return 0;
}

TEST_PROTO(nlExtra)
{
    int result = 0;
    NL_log_T log;
    FILE *fp;
    char buf[256], outp_file[256];

    setenv(NL_EXTRA_ENV, "EXTRA_DATA=1", 1);
    sprintf(outp_file, "/tmp/nl_extra_test.%d", getpid());
    log = NL_open(outp_file);
    NL_write(log, NL_LVL_INFO, "test", "value=d", 1.2);
    NL_close(log);
    fp = fopen(outp_file, "r");
    fgets(buf, sizeof(buf), fp);
    if (NULL == strstr(buf, "EXTRA_DATA=1")) {
        result = -1;
        goto bottom;
    }
  bottom:
    unsetenv(NL_EXTRA_ENV);
    unlink(outp_file);
    return result;
}

TEST_PROTO(nlWriteTs)
{
    char outp_file[128];
    NL_log_T log;
    NL_result_t r;
    struct timeval my_ts;
    FILE *fp;
    char buf[1024];

    sprintf(outp_file, "/tmp/nl_write_ts_test.%d", getpid());

    DBG("- create/open log handle\n");
    log = NL_open(outp_file);
    assert(log);

    /* pick silly time, format output message */
    my_ts.tv_sec = 1234567890;
    my_ts.tv_usec = 1;
    r = NL_write_ts(log, &my_ts, NL_LVL_WARN, "test", "");
    assert(r == NL_OK);
    /* close log */
    NL_close(log);
    /* check timestamp in output.
     * note: date -u -r 1234567890 +%Y-%m-%dT%H:%M:%S
     * provided the string for comparison.
     */
    DBG("- read back output\n");
    fp = fopen(outp_file, "r");
    assert(fp);
    assert(fgets(buf, sizeof(buf), fp));
    DBG("- look for correct timestamp in:\n");
    DBG1("%s\n", buf);
    assert(strstr(buf, "ts=2009-02-13T23:31:30.000001"));
    /* close file again and remove it */
    DBG("- cleanup\n");
    fclose(fp);
    unlink(outp_file);

    return 0;

}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_nlUuid();
    test_nlExtra();
    test_nlClose();
    test_nlWriteTs();

    return g_num_failed;
}
