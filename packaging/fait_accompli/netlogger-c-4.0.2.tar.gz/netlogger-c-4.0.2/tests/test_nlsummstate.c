static const volatile char rcsid[] =
    "$Id: test_nlsummstate.c 130 2007-08-22 14:09:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nlsummstate.c
 */

#include "nldbg.h"
#include "nlsummstate.h"
#include "util.h"

/* List of error messages */
const char *g_err[] = {
    NULL                               /* sentinel */
};

#define VALUE 1234.0

void free_state(void *x)
{
    double *d = (double *) x;
    assert(VALUE == (*d));
}

TEST_PROTO(create)
{
    NL_summstate_T obj;
    double *my_data = malloc(sizeof(double));

    obj = NL_summstate(NULL, NULL, NULL);
    assert(obj);
    *my_data = VALUE;
    obj = NL_summstate(NULL, my_data, free_state);
    assert(obj);
    assert((*(double *) obj->data) == VALUE);

    free(my_data);

    return 0;
}

TEST_PROTO(delete)
{
    NL_summstate_T obj;
    double *my_data = malloc(sizeof(double));

    DBG("- null obj\n");
    obj = NL_summstate(NULL, NULL, NULL);
    assert(obj);
    NL_summstate_del(obj);

    DBG("- obj with free_state\n");
    *my_data = VALUE;
    obj = NL_summstate(NULL, my_data, free_state);
    assert(obj);
    NL_summstate_del(obj);

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_create();
    test_delete();

    return g_num_failed;
}
