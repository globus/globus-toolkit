/* Tests for programs/nlio.c */

#include <pthread.h>
#include <fcntl.h>
#include <unistd.h>

#include "nlio.h"
#include "util.h"
#include "nlalist.h"
#include "nlsumm.h"

const char *g_err[] = {
    NULL
};

TEST_PROTO(bufCreateDelete)
{
    nlio_buf_T nbuf;

    nbuf = nlio_buf_new(100);
    nlio_buf_del(nbuf);

    return 0;
}

TEST_PROTO(bufClaim)
{
    nlio_buf_T nbuf;
    char *p;

    nbuf = nlio_buf_new(100);
    /* none full yet */
    p = nlio_buf_claim(nbuf, NLIO_FULL);
    assert(p == NULL);
    /* should find an empty one */
    p = nlio_buf_claim(nbuf, NLIO_EMPTY);
    assert(p != NULL);
    /* should find a 'working' one now */
    p = nlio_buf_claim(nbuf, NLIO_WORKING);
    assert(p != NULL);

    return 0;
}

TEST_PROTO(bufRelease)
{
    nlio_buf_T nbuf;
    char *p, *p2;

    nbuf = nlio_buf_new(100);
    /* get first empty slot */
    p = nlio_buf_claim(nbuf, NLIO_EMPTY);
    assert(p);
    /* mark it as full */
    nlio_buf_release(nbuf, p, NLIO_FULL);
    /* get first full slot */
    p2 = nlio_buf_claim(nbuf, NLIO_FULL);
    assert(p == p2);

    return 0;
}

TEST_PROTO(bufCorrectness)
{
#define N 30
#define N2 32
    nlio_buf_T nbuf;
    int i;
    char *pp[N2];

    DBG("\n- create buffer\n");
    nbuf = nlio_buf_new(N);            /* should really do N2 */

    DBG1("  claim %d empty slots\n", N2);
    for (i = 0; i < N2; i++) {
        pp[i] = nlio_buf_claim(nbuf, NLIO_EMPTY);
        assert(pp[i] != NULL);
    }
    DBG1("  release %d slots to full\n", N2);
    for (i = 0; i < N2; i++) {
        nlio_buf_release(nbuf, pp[i], NLIO_FULL);
    }
    DBG("  try to claim an empty spot (all full)\n");
    assert(NULL == nlio_buf_claim(nbuf, NLIO_EMPTY));

    /* try many different numbers of claim/release */
    /* first, fill up half with NLIO_EMPTY */
    for (i = 0; i < N2 / 2; i++) {
        pp[i] = nlio_buf_claim(nbuf, NLIO_FULL);
        nlio_buf_release(nbuf, pp[i], NLIO_EMPTY);
    }
    /* loop through claiming and releasing 'i' items */
    DBG1(" claim+release from 1 to %d items\n", N2 / 2);
    for (i = 1; i <= (N2 / 2); i++) {
        int j;
        char buf[N2 + 1];

        for (j = 0; j < i; j++) {
            pp[j] = nlio_buf_claim(nbuf, NLIO_FULL);
            assert(pp[j] != NULL);
        }
        for (; j < i * 2; j++) {
            pp[j] = nlio_buf_claim(nbuf, NLIO_EMPTY);
            assert(pp[j] != NULL);
        }
        nlio_buf_dump(nbuf, buf);
        DBG1("  buffer: %s\n", buf);
        for (j = 0; j < i; j++) {
            nlio_buf_release(nbuf, pp[j], NLIO_EMPTY);
        }
        for (; j < i * 2; j++) {
            nlio_buf_release(nbuf, pp[j], NLIO_FULL);
        }
    }
    /* at the end we should be right back to 1/2 empty and 1/2 full 
       test this by claiming exactly that amount
     */
    for (i = 0; i < N2 / 2; i++) {
        pp[0] = nlio_buf_claim(nbuf, NLIO_FULL);
        assert(pp[0]);
        pp[0] = nlio_buf_claim(nbuf, NLIO_EMPTY);
        assert(pp[0]);
    }
    pp[0] = nlio_buf_claim(nbuf, NLIO_FULL);
    assert(NULL == pp[0]);
    pp[0] = nlio_buf_claim(nbuf, NLIO_EMPTY);
    assert(NULL == pp[0]);

    return 0;
}

#undef N
#undef N2

TEST_PROTO(workerCreateDelete)
{
    nlio_worker_T w;
    nlio_master_T m;
    nlio_buf_T nbuf;

    nbuf = nlio_buf_new(32);
    w = nlio_worker_new(NULL, 1, 1, NLIO_READ, NLIO_DISK, nbuf);
    assert(w == NULL);
    m = nlio_master_new();
    w = nlio_worker_new(m, 1, 1, NLIO_READ, NLIO_DISK, nbuf);
    nlio_worker_del(w);

    return 0;
}

TEST_PROTO(workerRun)
{
    nlio_worker_T w, w2;
    nlio_master_T m;
    nlio_buf_T nbuf;

    DBG("- new master\n");
    m = nlio_master_new();
    DBG("- new worker\n");
    nbuf = nlio_buf_new(32);
    /* set fd to -1 so _run() will return immediately */
    w = nlio_worker_new(m, -1, 1, NLIO_READ, NLIO_DISK, nbuf);
    assert(w);
    DBG("- run worker (fail)\n");
    w2 = nlio_worker_run(w);
    assert(w2 == w);
    DBG("- delete worker\n");
    nlio_worker_del(w);

    return 0;
}

TEST_PROTO(masterCreateDelete)
{
    nlio_master_T w;

    w = nlio_master_new();
    assert(w);
    nlio_master_del(w);

    return 0;
}

TEST_PROTO(masterAccessors)
{
    nlio_master_T master;
    int i, N;

    master = nlio_master_new();
    assert(master);

    /* test file descriptor accessors; note that
     * negative values are used so nlio_master_del() won't
     * try and close them
     */
    N = 10;
    nlio_master_init_read_fds(master, N);
    for (i = 0; i < N; i++) {
        nlio_master_set_read_fd(master, i, -(i + 1));
    }
    for (i = 0; i < N; i++) {
        assert(nlio_master_get_read_fd(master, i) == -(i + 1));
    }
    nlio_master_init_write_fds(master, N);
    for (i = 0; i < N; i++) {
        nlio_master_set_write_fd(master, i, -(i + 1));
    }
    for (i = 0; i < N; i++) {
        assert(nlio_master_get_write_fd(master, i) == -(i + 1));
    }

    nlio_master_set_file(master, "this is a file");
    nlio_master_set_host(master, "localhost", 12345, 0);
    nlio_master_set_host(master, "my peer", 54321, 1);
    nlio_master_set_tcpbuf(master, 100000);

    nlio_master_set_read_eof(master);
    assert(nlio_master_get_read_eof(master) == 1);

    nlio_master_del(master);

    return 0;
}

void *do_accept(void *arg)
{
    nlio_master_T self = (nlio_master_T) arg;
    int r;

    DBG("-- start accept\n");
    r = nlio_master_accept(self);
    assert(r == 0);

    return NULL;
}

void *do_connect(void *arg)
{
    nlio_master_T self = (nlio_master_T) arg;
    int i, r;

    sleep(1);
    for (i = 0, r = 0; 0 == r && (i < 10); i++) {
        usleep(100000);
        DBG1("-- connect %d\n", i);
        r = nlio_master_connect(self);
        DBG2("-- connected %d, result code = %d\n", i, r);
    }

    return NULL;
}

TEST_PROTO(masterOpenNetwork)
{
    nlio_master_T cli_master, srv_master;
    int N;
    pthread_t cli_thr, srv_thr;

    cli_master = nlio_master_new();
    assert(cli_master);
    srv_master = nlio_master_new();
    assert(srv_master);

    /* init logs, useful for debugging */
    if (nl_test_dbg) {
        g_log = NL_open("&");
    }

    N = 10;
    /* should fail before peer/local indicated */
    DBG("- open to bogus location\n");
    DBG("-- accept\n");
    assert(-1 == nlio_master_accept(srv_master));
    DBG("-- connect\n");
    assert(-1 == nlio_master_connect(cli_master));

    /* initialize client/server */
    DBG("- init client, server\n");
    nlio_master_init_read_fds(srv_master, N);
    nlio_master_init_write_fds(srv_master, 1);
    nlio_master_set_host(srv_master, "127.0.0.1", 15888, 0);

    nlio_master_init_read_fds(cli_master, 1);
    nlio_master_init_write_fds(cli_master, N);
    nlio_master_set_host(cli_master, "127.0.0.1", 15888, 1);

    /* now try to really connect the two */
    DBG("- connect client to server\n");
    pthread_create(&srv_thr, NULL, do_accept, (void *) srv_master);
    pthread_create(&cli_thr, NULL, do_connect, (void *) cli_master);
    DBG("- join server\n");
    pthread_join(srv_thr, NULL);
    DBG("- join client\n");
    pthread_join(cli_thr, NULL);

    /* delete them */
    DBG("- delete client, server\n");
    nlio_master_del(cli_master);
    nlio_master_del(srv_master);

    return 0;
}

TEST_PROTO(masterOpenFile)
{
    nlio_master_T master;
    char tmpfile[128];
    int x;

    DBG("\n- create master obj\n");
    master = nlio_master_new();
    assert(master);

    DBG("\tset_file\n");
    sprintf(tmpfile, "test_nlio.%d", getpid());
    nlio_master_set_file(master, tmpfile);
    nlio_master_init_write_fds(master, 1);
    DBG1("\topen_file '%s'\n", tmpfile);
    x = nlio_master_open_file(master, NLIO_WRITE);
    assert(x == 0);

    DBG("\tdel master obj\n");
    nlio_master_del(master);

    x = open(tmpfile, O_RDONLY);
    assert(x >= 0);
    close(x);
    unlink(tmpfile);

    return 0;
}

int put_data(const char *f)
{
    int fd, i, n = -1;

    fd = open(f, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd >= 0) {
        for (i = 0; i < 100000; i++) {
            write(fd, "Hello, world!\n", 14);
            n += 12;
        }
        close(fd);
    }
    return n;
}


TEST_PROTO(transferBytes)
{
    nlio_master_T ms, mr;
    char tmpfile[128];
    short port = 12345;
    pthread_t rcvr_thr;
    int result, x;

    DBG("\n- create master objs\n");
    ms = nlio_master_new();
    mr = nlio_master_new();

    /* get logging going */
    g_log = NL_open("&");
    if (nl_test_dbg) {
        NL_set_level(g_log, NL_LVL_INFO);
    }
    else {
        NL_set_level(g_log, NL_LVL_WARN);
    }
    assert(0==nlio_master_init_log(ms, NL_open("send.log"), NLIO_LOG_FULL, 1.0));
    assert(0==nlio_master_init_log(mr, NL_open("recv.log"), NLIO_LOG_INT, 1.0));
    /* receiver setup */
    DBG("  receiver setup\n");
    sprintf(tmpfile, "test_nlio.%d.out", getpid());
    nlio_master_set_file(mr, tmpfile);
    nlio_master_init_write_fds(mr, 1);
    x = nlio_master_open_file(mr, NLIO_WRITE);
    assert(0 == x);
    nlio_master_set_host(mr, "localhost", port, 0);
    nlio_master_init_read_fds(mr, 8);
    /* sender setup */
    DBG("  sender setup\n");
    sprintf(tmpfile, "test_nlio.%d.in", getpid());
    assert(put_data(tmpfile) > 0);
    nlio_master_set_file(ms, tmpfile);
    nlio_master_init_read_fds(ms, 1);
    x = nlio_master_open_file(ms, NLIO_READ);
    assert(0 == x);
    nlio_master_set_host(ms, "127.0.0.1", port, 1);
    nlio_master_init_write_fds(ms, 8);
    /* start receiver, in its own thread */
    DBG("  start receiver\n");
    nlio_master_run(mr, NLIO_NETWORK, NLIO_DISK, 1, &rcvr_thr);
    sleep(3);
    /* start sender, in this thread */
    DBG("  start sender\n");
    result = nlio_master_run(ms, NLIO_DISK, NLIO_NETWORK, 0, NULL);
    assert(0 == result);
    /* join receiver thread */
/*    DBG("  join receiver\n");
    pthread_join(rcvr_thr, (void*)&result);
    assert(0 == result);
    */
    /* cleanup */
    nlio_master_del(ms);
    nlio_master_del(mr);
    sprintf(tmpfile, "test_nlio.%d.in", getpid());
    unlink(tmpfile);
    sprintf(tmpfile, "test_nlio.%d.out", getpid());
    unlink(tmpfile);

    DBG("  done!\n");

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);

    /* nlio_buf_T */
    test_bufCreateDelete();
    test_bufClaim();
    test_bufRelease();
    test_bufCorrectness();

    /* nlio_worker_T */
    test_workerCreateDelete();
    test_workerRun();

    /* nlio_master_T */
    test_masterCreateDelete();
    test_masterAccessors();
    test_masterOpenNetwork();
    test_masterOpenFile();

    /* integrated */
    /* XXX: Need to re-visit this later.
     * XXX: Currently hangs on readn()::read() in sender thread (?!)
     */
    /* test_transferBytes(); */

    return 0;
}
