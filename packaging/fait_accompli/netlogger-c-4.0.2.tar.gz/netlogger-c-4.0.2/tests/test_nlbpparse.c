static const volatile char rcsid[] =
    "$Id: template.c 108 2007-08-16 00:22:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for bpparse.c
 */

#include "nldbg.h"
#include "util.h"
#include "nlbpparse.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

TEST_PROTO(create)
{
    NL_bpparse_T parser;
        
    parser = NL_bpparse();
    assert(parser);
    NL_bpparse_del(parser);
    
    return 0;
}

TEST_PROTO(quoted)
{
    NL_bpparse_T parser;
    int r;
    NL_rec_t * recp;
    NL_log_T log;
    
    parser = NL_bpparse();
    NL_bpparse_add_str(parser, " ts=\"2 \\\" foo=3\" bar=hello ");
    NL_bpparse_add_str(parser, "more=how-are-you-doing \n");
    r = NL_bpparse_next_rec(parser, &recp);
    assert(0 == r);
    assert(recp);
    assert( 0 == memcmp(recp->fields[0]->value,"2 \" foo=3", 8));
    NL_bpparse_del(parser);
    
    return 0;
}

TEST_PROTO(perf)
{
    NL_bpparse_T parser;
    NL_rec_T recp;
    int i, j, n, e, etot;
    struct timeval t[2];
    double dt;
    
    parser = NL_bpparse();
    n = 100;
    etot = 0;
    gettimeofday(&t[0], 0);
    for (i=0; i < n; i++) {
        e = 0;
        for (j=0; j < 1000; j++) {
            if (j % 2 == 0) {
                NL_bpparse_add_str(parser, " ts=1  foo=2   bar=hello ");
                NL_bpparse_add_str(parser, "more=how-are-you-doing \n");
                NL_bpparse_add_str(parser, " ts=\"2 \\\" foo=3\" bar=hello ");
                NL_bpparse_add_str(parser, "more=how-are-you-doing \n");
                e = e + 2;
            }
            else {
                NL_bpparse_add_str(parser, "ts=2007-10-19T21:03:40.443614Z"
                                           " event=transfer.net.read.start"
                                           " level=DEBUG"
                                           " guid=-b8e532d4c8b4 stream.id=1"
                                           " block.id=0\n");
                e++;
            }
        }
        for (j=0; j < e; j++) {            
            if (-1 == NL_bpparse_next_rec(parser, &recp) || !recp) {
                SAY3("%d: event %d => '%s'\n", i, j,
                     NL_bpparse_get_err(parser));
                assert(!"next rec");
            }
        }
        etot += e;
    }
    NL_bpparse_del(parser);
    
bottom:    
    gettimeofday(&t[1], 0);
    dt = t[1].tv_sec - t[0].tv_sec + (t[1].tv_usec - t[0].tv_usec)/1e6;    
    if (nl_test_dbg) {
        printf("total=%lfs rate=%lf events/sec, time=%lfus\n", dt, 
                etot/dt, dt/etot*1e6);
    }
    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_create();
    test_quoted();
    test_perf();
    
    return g_num_failed;
}
