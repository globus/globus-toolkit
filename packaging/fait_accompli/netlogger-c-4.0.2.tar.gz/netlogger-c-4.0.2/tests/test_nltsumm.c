static const volatile char rcsid[] =
    "$Id: template.c 108 2007-08-16 00:22:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nltsumm.c
 */
#include <math.h>
#include "nldbg.h"
#include "util.h"

#include "nlparams.h"
#include "nlsummseq.h"
#include "nlwvar.h"
#include "nltsumm.h"
#include "nltsummint.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

TEST_PROTO(init)
{
    NL_params_T params;
    void *r;
    struct tsumm_data *d;
    int64_t interval;
    double dv;
    int32_t iv;
    
    DBG("- NULL (fail)\n");
    r = NL_tsumm_init(NULL);
    assert(NULL == r);

    DBG("- bad interval (fail)\n");
    params = NL_params();
    interval = -1;
    NL_params_append(params, NLTSUMM_P_INTERVAL, &interval, sizeof(interval));
    r = NL_tsumm_init(params);
    assert(NULL == r);
    NL_params_del(params);

    DBG("- bad output level (fail)\n");
    params = NL_params();
    interval = 100;
    NL_params_append(params, NLTSUMM_P_INTERVAL, &interval, 8);
    NL_params_append(params, NLTSUMM_P_LVL, "foo", 3);
    r = NL_tsumm_init(params);
    assert(NULL == r);
    NL_params_del(params);

    DBG("- max < min (fail)\n");
    params = NL_params();
    dv = 6.6;
    NL_params_append(params, NLTSUMM_P_MIN, &dv, sizeof(dv));
    dv = 5.5;
    NL_params_append(params, NLTSUMM_P_MAX, &dv, sizeof(dv));
    r = NL_tsumm_init(params);
    assert(NULL == r);
    NL_params_del(params);

    DBG("- neg. baseline (fail)\n");
    params = NL_params();
    iv = -6;
    NL_params_append(params, NLTSUMM_P_VARBASE, &iv, sizeof(iv));
    r = NL_tsumm_init(params);
    assert(NULL == r);
    NL_params_del(params);

    DBG("- NULL event (fail)\n");
    params = NL_params();
    NL_params_append(params, NLTSUMM_P_EVENT, NULL, 0);
    r = NL_tsumm_init(params);
    assert(NULL == r);
    NL_params_del(params);

    DBG("- minimal\n");
    NL_err_clear();
    params = NL_params();
    interval = 100;
    NL_params_append(params, NLTSUMM_P_INTERVAL, &interval, sizeof(interval));
    NL_params_append(params, NLTSUMM_P_EVENT, "foo", 3);
    r = NL_tsumm_init(params);
    if (!r)
        PRINT_ERR;
    assert(r);
    NL_params_del(params);
    d = (struct tsumm_data *) r;
    assert(d->interval_usec == 100);
    NL_tsumm_free_data(r);

    DBG("- maximal + extra\n");
    NL_err_clear();
    params = NL_params();
    interval = 100;
    NL_params_append(params, NLTSUMM_P_INTERVAL, &interval, sizeof(interval));
    NL_params_append(params, NLTSUMM_P_LVL, "INFO", 4);
    dv = -1;
    NL_params_append(params, NLTSUMM_P_MIN, &dv, sizeof(dv));
    dv = 1;
    NL_params_append(params, NLTSUMM_P_MAX,  &dv, sizeof(dv));
    iv = 8;
    NL_params_append(params, NLTSUMM_P_VARBASE,  &iv, sizeof(iv));
    NL_params_append(params, NLTSUMM_P_EVENT, "howdy", 5);
    NL_params_append(params, NLTSUMM_P_LVL, "INFO", 4);
    NL_params_append(params, "extra", "whatever", 8);
    r = NL_tsumm_init(params);
    if (!r)
        PRINT_ERR;
    assert(r);
    d = (struct tsumm_data *) r;
    assert(d->interval_usec == 100);
    assert(d->min_val == -1);
    assert(d->max_val == 1);
    assert(d->variance_baseline == 8);
    assert(!strcmp(d->output_event, "howdy"));
    assert(d->output_level == NL_LVL_INFO);
    NL_params_del(params);
    NL_tsumm_free_data(r);

    return 0;
}

static NL_summstate_T p_state(void)
{
    NL_summstate_T state;
    struct tsumm_data *d;
    NL_params_T params;
    int64_t interval = 100000000;
    int32_t iv;
    
    params = NL_params();
    NL_params_append(params, NLTSUMM_P_INTERVAL, &interval, sizeof(interval));
    iv = 10;
    NL_params_append(params, NLTSUMM_P_VARBASE, &iv, sizeof(iv));
    NL_params_append(params, NLTSUMM_P_EVENT, "X", 1);
    d = (struct tsumm_data *)NL_tsumm_init(params);
    assert(d);
    NL_params_del(params);
    state = NL_summstate(NULL, d, NL_tsumm_free_data);
    state->sequence_len = 2;
    state->values = malloc(sizeof(double));
    state->values_n = 1;

    return state;
}

static void
print_result(struct tsumm_data *d, double time_sd, double value_sd)
{
    struct tsumm_stats *statsp = &d->stats[0];
    if (nl_test_dbg) {
        fprintf(stderr, "-- result: n=%lld nv=%lld "
                "time:min=%lf,max=%lf,sum=%lf;sd=%lf "
                "value:min=%lf,max=%lf,sum=%lf;sd=%lf\n",
                statsp->n, statsp->nv, statsp->t_m, statsp->t_x, statsp->t_s.s, time_sd,
                statsp->v_m, statsp->v_x, statsp->v_s.s, value_sd);
    }
}

TEST_PROTO(processSame)
{
    NL_summstate_T state;
    struct tsumm_data *d;
    const int N = 10000;
    double v = 123.456;
    register int i;
    double time_sd, value_sd;
    struct tsumm_stats *statsp;
    
    DBG1("- repeat same value %d times\n", N);
    state = p_state();
    state->ts_usec = 0LL;
    state->values[0] = v;
    d = (struct tsumm_data *) state->data;
    for (i = 0; i < N; i++) {
        state->pos = 0;
        NL_tsumm_process(state);
        state->pos = 1;
        state->ts_usec += 1;
        NL_tsumm_process(state);
        state->ts_usec += 1;
    }
    /* check values */
    statsp = &d->stats[0];
    time_sd = NL_wvar_sd(statsp->t_v);
    value_sd = NL_wvar_sd(statsp->v_v);
    print_result(d, time_sd, value_sd);
    assert(N == statsp->n);
    assert(N == statsp->nv);
    assert(1e-6 == statsp->t_m);
    assert(1e-6 == statsp->t_x);
    assert(EQ_EPS(N * 1e-6, statsp->t_s.s, 1));
    assert(0 == time_sd);
    assert(v == statsp->v_m);
    assert(v == statsp->v_x);
    assert(EQ_EPS(v * N, statsp->v_s.s, 1));
    assert(0 == value_sd);
    NL_summstate_del(state);

    return 0;
}

TEST_PROTO(processRange)
{
    NL_summstate_T state;
    struct tsumm_data *d;
    struct tsumm_stats *statsp;
    const int N = 10000, M = 250;
    register int i, j;
    double time_sd, value_sd;

    DBG2("- repeat 1..%d %d times\n", M, N / M);
    state = p_state();
    state->ts_usec = 0LL;
    d = (struct tsumm_data *) state->data;
    for (i = 0; i < N / M; i++) {
        for (j = 0; j < M; j++) {
            state->pos = 0;
            NL_tsumm_process(state);
            state->pos = 1;
            state->ts_usec += 1;
            state->values[0] = j;
            NL_tsumm_process(state);
            state->ts_usec += 1;
        }
    }
    /* check values */
    statsp = &d->stats[0];
    time_sd = NL_wvar_sd(statsp->t_v);
    value_sd = NL_wvar_sd(statsp->v_v);
    print_result(d, time_sd, value_sd);
    assert(N == statsp->n);
    assert(N == statsp->nv);
    assert(1e-6 == statsp->t_m);
    assert(1e-6 == statsp->t_x);
    assert(EQ_EPS(N * 1e-6, statsp->t_s.s, 1));
    assert(0 == time_sd);
    assert(0 == statsp->v_m);
    assert(M - 1 == statsp->v_x);
    assert(N * (M - 1) / 2.0 == statsp->v_s.s);
    assert(EQ_EPS(72.17181, value_sd, 0.1));    /* sqrt(((b-a+1)^2 - 1)/12) */
    NL_summstate_del(state);

    return 0;
}

TEST_PROTO(processStdnorm)
{
    NL_summstate_T state;
    struct tsumm_data *d;
    struct tsumm_stats *statsp;    
    double v = 123.456, x;
    register int i, j;
    double time_sd, value_sd, vsum;

    x = 5;
    DBG2("- Std. normal distribution from %lf to %lf\n", -x, x);
    state = p_state();
    state->ts_usec = 0LL;
    d = (struct tsumm_data *) state->data;
    vsum = 0;
    for (v = -x; v <= x; v += 0.001) {
        /* height of normal curve at this X coord. */
        i = (int) (5000 * 0.5 * M_1_PI * exp(-0.5 * v * v));
        /*printf("@@ v=%lf * i=%d = %lf\n", v, i, (double)i * v);*/
        for (j = 0; j < i; j++) {
            state->pos = 0;
            NL_tsumm_process(state);
            state->pos = 1;
            state->ts_usec += 1;
            state->values[0] = v;
            NL_tsumm_process(state);
            state->ts_usec += 1;
        }
        vsum += (double)i * v;
    }
    /* check values */
    statsp = &d->stats[0];
    time_sd = NL_wvar_sd(statsp->t_v);
    value_sd = NL_wvar_sd(statsp->v_v);
    print_result(d, time_sd, value_sd);
    DBG1("-- vsum=%lf (compare to value: ,sum=xxx above)\n", vsum);
    assert(EQ_EPS(statsp->v_s.s, 0, 0.001)); /* mean ~ 0 */
    assert(EQ_EPS(value_sd, 1, 0.01)); /* variance ~ 1 */
    NL_summstate_del(state);

    return 0;
}

TEST_PROTO(flush)
{
    /* this is a pain to test stand-alone, but that's OK since
     * it gets tested by all the higher-level functions, in particular
     * NL_transfer_finalize() and its callee, NL_summ_flush()
     */
    NL_summstate_T state;

    DBG("- init\n");
    state = p_state();
    state->ts_usec = 0LL;
    DBG("- flush an empty state\n");
    NL_tsumm_flush(state);

    /* add one sequence */
    state->pos = 0;
    NL_tsumm_process(state);
    state->pos = 1;
    state->ts_usec += 1;
    NL_tsumm_process(state);
    state->ts_usec += 1;
    DBG("- flush 1-sequence state\n");
    NL_tsumm_flush(state);

    DBG("- cleanup\n");
    NL_summstate_del(state);

    return 0;
}

TEST_PROTO(freeData)
{
    NL_params_T params;
    void *r;
    struct tsumm_data *d;
    int i, N = 10000;
    int32_t iv;
    double dv;
    int64_t interval;

    DBG1("- free %d times\n", N);
    for (i = 0; i < N; i++) {
        params = NL_params();
        interval = 100;
        NL_params_append(params, NLTSUMM_P_INTERVAL, &interval, 
                         sizeof(interval));
        NL_params_append(params, NLTSUMM_P_LVL, "Info", 4);
        dv = -1;
        NL_params_append(params, NLTSUMM_P_MIN, &dv, sizeof(dv));
        dv = 1;
        NL_params_append(params, NLTSUMM_P_MAX, &dv, sizeof(dv));
        iv = 8;
        NL_params_append(params, NLTSUMM_P_VARBASE, &iv, sizeof(iv));
        NL_params_append(params, NLTSUMM_P_EVENT, "howdy", 5);
        NL_params_append(params, NLTSUMM_P_LVL, "Info", 4);
        NL_params_append(params, "extra", "whatever", 8);
        r = NL_tsumm_init(params);
        assert(r);
        d = (struct tsumm_data *)r;
        assert(d->interval_usec == 100);
        NL_params_del(params);
        NL_tsumm_free_data(r);
    }

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_init();
    test_processSame();
    test_processRange();
    test_processStdnorm();
    test_flush();
    test_freeData();

    return g_num_failed;
}
