static const volatile char rcsid[] =
    "$Id: template.c 108 2007-08-16 00:22:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for nlxml.c
 */
#include <stdio.h>
#include <unistd.h>

#include "nldbg.h"
#include "util.h"
#include "nlxml.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

/* Some test documents */
const char *svg1 = "<svg width='200px' height='200px'>"
    "<g style= 'stroke: red;'>" 
    "<rect x='10' y='10' width='20' height='40' />" 
    "<g style= 'fill: yellow;'>" 
    "<rect x='10' y='60' width='20' height='40' />" 
    "<g style= 'stroke-width: 5;'>" 
    "<rect x='10' y='110' width='20' height='40' />" 
    "</g> " 
    "<rect x='110' y='10' width='20' height='40' />" 
    "</g> " 
    "<rect x='110' y='60' width='20' height='40' />" 
    "</g> "  "<rect x='110' y='110' width='20' height='40' />"  "</svg>";

const char *ant1 =
    "<!--"
    "====================================================================== -->"
    
    "<!-- Ant build file (http://ant.apache.org/) for Ant 1.6.2 or above.        -->"
    
    "<!-- ====================================================================== -->"
     "" 
    "<project name='%PROJECT_ARTIFACTID%' default='jar' basedir='.'>"  ""
    
    "  <!-- ====================================================================== -->"
    
    "  <!-- Import maven-build.xml into the current project                        -->"
    
    "  <!-- ====================================================================== -->"
     ""  "  <import file='maven-build.xml'/>"  "" 
    "  <!-- ====================================================================== -->"
    
    "  <!-- Help target                                                            -->"
    
    "  <!-- ====================================================================== -->"
     ""  "  <target name='help'>" 
    "    <echo message='Please run: $ant -projecthelp'/>"  "  </target>" 
    "" 
    "  <!-- ====================================================================== -->"
    
    "  <!-- Overwrite the jar target from maven-build.xml                          -->"
    
    "  <!-- ====================================================================== -->"
     ""  "  <target name='jar'>"  "    <echo message='Nothing to do.'/>"
     "  </target>"  "</project>";

static FILE *write_file(const char *str, char *buf)
{
    FILE *f;
    char *name;
    char wd[1024];

    assert(NULL != getcwd(wd, sizeof(wd)));
    name = tempnam(wd, "nlxml-");
    f = fopen(name, "w");
    fputs(str, f);
    fclose(f);
    f = fopen(name, "r");
    assert(f);
    strcpy(buf, name);

    return f;
}

/**
 * Create new initialized obj
 */
static NL_xml_T create_obj(const char *str, int expected)
{
    NL_xml_T obj;
    FILE *fp;
    char name[2048];

    obj = NL_xml();
    assert(obj);
    fp = write_file(str, name);
    assert(expected == NL_xml_parse(obj, fp));
    fclose(fp);
    unlink(name);

    return obj;
}


TEST_PROTO(create)
{
    NL_xml_T obj;
    FILE *fp;
    char name[2048];

    DBG("- create & destroy immediately\n");
    obj = NL_xml();
    assert(obj);
    NL_xml_del(obj);

    DBG("- create, parse empty doc, destroy\n");
    obj = NL_xml();
    assert(obj);
    fp = write_file("", name);
    assert(-1 == NL_xml_parse(obj, fp));
    NL_xml_del(obj);
    fclose(fp);
    unlink(name);

    DBG("- create, parse shell doc, destroy\n");
    obj = NL_xml();
    assert(obj);
    fp = write_file("<hello/>", name);
    assert(0 == NL_xml_parse(obj, fp));
    NL_xml_del(obj);
    fclose(fp);
    unlink(name);

    return 0;
}

TEST_PROTO(parser)
{
    NL_xml_T obj;

    DBG("- svg1\n");
    obj = create_obj(svg1, 0);
    NL_xml_del(obj);

    DBG("- ant1\n");
    obj = create_obj(ant1, 0);
    NL_xml_del(obj);

    return 0;
}

TEST_PROTO(getData)
{
    return 1;
}

TEST_PROTO(goto)
{
    NL_xml_T obj;
    int r;


    obj = create_obj("<test>"
                     "<foo>"
                     "<bar>1</bar>" "<bar>2</bar>" "</foo>" "</test>", 0);

    DBG("- absolute\n");
    r = NL_xml_goto(obj, "/test/foo/bar");
    assert(0 == r);
    assert(0 == strcmp(NL_xml_get_data(obj), "1"));

    DBG("- absolute with index\n");
    r = NL_xml_goto(obj, "/test/foo/bar[1]");
    assert(0 == r);
    assert(0 == strcmp(NL_xml_get_data(obj), "1"));
    r = NL_xml_goto(obj, NL_xml_idx(obj, "/test/foo/bar", 2));
    assert(0 == r);
    assert(0 == strcmp(NL_xml_get_data(obj), "2"));

    DBG("- go up with '..'\n");
    r = NL_xml_goto(obj, "/..");
    assert(0 == r);
    r = NL_xml_goto(obj, "/test/foo/bar");
    assert(0 == r);
    r = NL_xml_goto(obj, "../bar[2]");
    assert(0 == r);
    assert(0 == strcmp(NL_xml_get_data(obj), "2"));
    r = NL_xml_goto(obj, "/test/foo/../foo/bar");
    assert(0 == r);
    assert(0 == strcmp(NL_xml_get_data(obj), "1"));


    NL_xml_del(obj);

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_create();
    test_parser();
    test_goto();

    return g_num_failed;
}
