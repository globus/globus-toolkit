/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
const volatile char rcsid[] = "$Id$";

/*
 * Unit tests for nlsummseq.c
 */

#include "nldbg.h"
#include "util.h"
#include "nlparams.h"
#include "nlsummseq.h"
#include "nlsummstate.h"
#include "nlsummvisitor.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};


/* dummy functions */

int g_processed = 0;

static void *x_getstate(NL_params_T params)
{
    return &g_processed;
}

int x_process(NL_summstate_T state)
{
    DBG("-- process record\n");
    g_processed++;
    return 0;
}

void x_flush(NL_summstate_T state)
{
    DBG("-- flush state\n");
}


void x_free(void *foo)
{
    DBG("-- free state\n");
}

/* -- Tests -- */

TEST_PROTO(create)
{
    NL_summseq_T obj;

    obj = NL_summseq();
    assert(obj);
    NL_summseq_del(obj);

    return 0;
}

TEST_PROTO(delete)
{
    NL_summseq_del(NL_summseq());
    NL_summseq_del(NULL);

    return 0;
}

/* visitor func that sets data to (int)999 */
void set_999(NL_summvisitor_T self, void *x)
{
    *((int *) self->data) = 999;
}

TEST_PROTO(accept)
{
    NL_summseq_T obj;
    NL_summvisitor_T visitor;
    int r, sval = 12345;

    obj = NL_summseq();
    r = NL_summseq_add_selector(obj, "sel1", &sval, sizeof(sval));
    assert(0 == r);

    DBG("- NULL visitor\n");
    NL_summseq_accept(obj, NULL);

    DBG("- empty visitor\n");
    visitor = NL_summvisitor();
    NL_summseq_accept(obj, visitor);
    NL_summvisitor_del(visitor);

    DBG("- initialized visitor\n");
    visitor = NL_summvisitor();
    visitor->data = &sval;
    visitor->visit_summseq = set_999;
    NL_summseq_accept(obj, visitor);
    assert(sval == 999);
    NL_summvisitor_del(visitor);
    NL_summseq_del(obj);

    return 0;
}

TEST_PROTO(addSelector)
{
    NL_summseq_T obj;
    int i, r, sval = 12345;

    obj = NL_summseq();
    r = NL_summseq_add_selector(obj, "sel1", &sval, sizeof(sval));
    assert(0 == r);
    r = NL_summseq_add_selector(obj, "sel1", &sval, sizeof(sval));
    assert(-1 == r);
    for (i = 0; i < 1000; i++) {
        char s[10];
        sprintf(s, "Hello%d", i);
        r = NL_summseq_add_selector(obj, s, &sval, sizeof(sval));
        assert(0 == r);
    }
    NL_summseq_del(obj);

    return 0;
}

#define PRINTIT(x) ((x == 1) || (x % 33) == 0)

/* Tests both add_id_field and add_value_field */
#define ADD_FIELD(F) do {\
	NL_summseq_T obj = NL_summseq();\
	int i, j, r;\
		\
	DBG("- add to empty obj (fail)\n");\
	assert(-1 == NL_summseq_add_##F##_field(obj, 0, "foo"));\
	DBG("- add NULL to empty obj (fail)\n");\
	assert(-1 == NL_summseq_add_##F##_field(obj, 0, NULL));\
	NL_summseq_del(obj);\
	\
	for (i=1; i < 100; i++) {\
		obj = NL_summseq();\
		if (PRINTIT(i)) {	\
			DBG1("- make %d item obj\n", i);\
		}\
		for (j=0; j < i; j++) {\
			char sel[10];\
			sprintf(sel,"hello%d", j);\
			NL_summseq_add_selector(obj, sel, &j, sizeof(j));\
		}\
		if (PRINTIT(i)) {	\
			DBG1("- add to %d item obj\n", i);\
		}\
		for (j=-1; j <= i; j++) {\
			char idfield[10];\
			sprintf(idfield,"hello%d", j);\
			if (PRINTIT(i) && PRINTIT(j)) {\
				DBG2("-- add field '%s' to %d-th event\n", idfield, j);\
			}\
			r = NL_summseq_add_##F##_field(obj, j, idfield);\
			assert(((j < 0 || j == i) ? -1 : 0) == r);\
			if (PRINTIT(i) && PRINTIT(j)) {\
				DBG1("-- add field (null) to %d-th event\n", j);\
			}\
			r = NL_summseq_add_##F##_field(obj, j, NULL);\
			assert(-1 == r);\
		}\
		for (j=0; j < i; j++) {\
			char idfield[10];\
			sprintf(idfield,"hello%d", j);\
			if (PRINTIT(i) && PRINTIT(j)) {\
				DBG2("-- add *duplicate* field '%s' to %d-th event\n", idfield, j);\
			}\
			r = NL_summseq_add_##F##_field(obj, j, idfield);\
			assert(-1 == r);\
		}\
		NL_summseq_del(obj);\
	}\
} while(0)

TEST_PROTO(addIdField)
{
    ADD_FIELD(id);
    return 0;
}

TEST_PROTO(addValueField)
{
    ADD_FIELD(value);
    return 0;
}

TEST_PROTO(consume)
{
    NL_summseq_T obj;

    DBG("- off by default\n");
    obj = NL_summseq();
    assert(!NL_summseq_get_consume(obj));

    DBG("- get/set\n");
    NL_summseq_set_consume(obj, 1);
    assert(NL_summseq_get_consume(obj));

    NL_summseq_del(obj);

    return 0;
}

#define GET_FIELD(F,L) do {\
	int i, r, n=5;\
	NL_rec_t *rec;\
	unsigned *fields, fields_n;\
	NL_summseq_T obj;\
	double v = 1.0;\
	\
	DBG("- create sequence\n");\
	obj =  NL_summseq();\
	assert(obj);	\
	for (i=0; i < n; i++) {\
		char s[5];\
		sprintf(s,"foo%d",i);\
	    r = NL_summseq_add_selector(obj, "event", s, 4);\
		assert(0==r);\
	}\
	NL_summseq_add_##F##_field(obj, 0, "my."#F );\
	NL_summseq_add_##F##_field(obj, n-1, "my." #F );\
	NL_summseq_add_##F##_field(obj, n-1, "your." #F);\
	\
	DBG("- create record\n");\
	rec = NL_rec(4);\
	NL_rec_add(rec, NL_fld("ts", 2, &v, sizeof(double), 'd'));\
	NL_rec_add(rec, NL_fld("event", 5, "xyz", 4, 's'));\
	NL_rec_add(rec, NL_fld("my." #F , 3+L, "1234", 4, 's'));\
	NL_rec_add(rec, NL_fld("your." #F , 5+L, &i, sizeof(int),\
						   'i'));\
						   \
	/* check record against sequence */\
	DBG("- NULL record\n");\
	r = NL_summseq_get_##F##s(obj, NULL, 0, &fields, &fields_n);\
	assert(-1 == r);\
\
	DBG("- i=0\n");\
	r = NL_summseq_get_##F##s(obj, rec, 0, &fields, &fields_n);\
	assert(0 == r);\
	assert(fields_n == 1);\
	assert(fields[0] == 2);\
\
	DBG("- i=1 (none)\n");\
	r = NL_summseq_get_##F##s(obj, rec, 1, &fields, &fields_n);\
	assert(0 == r);\
	assert(fields_n == 0);\
\
	DBG("- i=n-1\n");\
	r = NL_summseq_get_##F##s(obj, rec, n-1, &fields, &fields_n);\
	assert(0 == r);\
	assert(fields_n == 2);\
	assert(fields[0] == 2);\
	assert(fields[1] == 3);\
\
	DBG("- i=n (fail)\n");\
	r = NL_summseq_get_##F##s(obj, rec, n, &fields, &fields_n);\
	assert(-1 == r);\
	\
	DBG("- delete obj\n");\
	NL_summseq_del(obj);\
	\
	return 0;\
} while(0)

TEST_PROTO(getIds)
{
    GET_FIELD(id, 2);
}


TEST_PROTO(getValues)
{
    GET_FIELD(value, 5);
}


/* no-op callbacks */

void *nop_istate(NL_params_T params)
{
    return &g_processed;
}

int nop_process(NL_summstate_T state)
{
    return 0;
}

void nop_flush(NL_summstate_T state)
{
    return;
}

void nop_free(void *obj)
{
    return;
}

TEST_PROTO(getParams)
{
    NL_summseq_T obj;
    NL_params_T params = NL_params();
    int r;

    obj = NL_summseq();
    assert(obj);
    r = NL_summseq_set_info(obj, params,
                            nop_istate, nop_process, nop_flush, nop_free);
    assert(0 == r);
    assert(params == NL_summseq_get_params(obj));

    return 0;
}

TEST_PROTO(getState)
{
    NL_summseq_T obj;
    NL_summstate_T state;
    char *data[] = { "foo", "bar" };
    char *id[] = { "match this", "or this" };
    unsigned idlen[] = { 10, 7 }, is_new;
    int i;

    obj = NL_summseq();
    for (i = 0; i < 2; i++) {
        state = NL_summseq_get_state(obj, id[i], idlen[i], &is_new);
        assert(state != NULL);
        assert(state->data == NULL && is_new);
        state->data = data[i];
    }
    for (i = 0; i < 2; i++) {
        state = NL_summseq_get_state(obj, id[i], idlen[i], &is_new);
        assert(state != NULL);
        assert(!is_new);
        assert(state->data == data[i]);
    }

    return 0;
}

TEST_PROTO(matchRecord)
{
    NL_summseq_T obj;
    NL_rec_t **rec_arr;
    int i, r, num_events, num_records;
    char val;

    obj = NL_summseq();
    num_events = 26;                   /* now I know my ABC's */
    num_records = num_events + 1;
    DBG("- add selectors\n");
    for (i = 0; i < num_events; i++) {
        val = 'A' + i;
        r = NL_summseq_add_selector(obj, "event", &val, 1);
        assert(0 == r);
    }
    DBG("- create records\n");
    rec_arr = malloc(num_records * sizeof(NL_rec_t *));
    for (i = 0; i < num_records; i++) {
        val = 'A' + i;
        rec_arr[i] = NL_rec(2);
        NL_rec_add(rec_arr[i], NL_fld("ts", 2, "getawatch", 9, 's'));
        NL_rec_add(rec_arr[i], NL_fld("event", 5, &val, 1, 's'));
    }
    DBG("- match records\n");
    for (i = 0; i < num_records; i++) {
        int idx;

        idx = NL_summseq_match_record(obj, rec_arr[i]);
        if (i < num_events) {
            assert(idx == i);
        }
        else {
            assert(idx == -1);
        }
    }
    DBG("- match NULL record\n");
    assert(-1 == NL_summseq_match_record(obj, NULL));

    /* next time won't you sing with me? */
    return 0;
}

TEST_PROTO(setInfo)
{
    NL_summseq_T obj;
    NL_params_T params;
    int r;

    DBG("- all NULL\n");
    obj = NL_summseq();
    r = NL_summseq_set_info(obj, NULL, NULL, NULL, NULL, NULL);
    assert(0 != r);
    NL_summseq_del(obj);

    DBG("- incrementally more real\n");
    obj = NL_summseq();
    params = NL_params();
    r = NL_summseq_set_info(obj, NULL, NULL, NULL, NULL, NULL);
    assert(0 != r);
    r = NL_summseq_set_info(obj, params, NULL, NULL, NULL, NULL);
    assert(0 != r);
    r = NL_summseq_set_info(obj, params, x_getstate, NULL, NULL, NULL);
    assert(0 != r);
    r = NL_summseq_set_info(obj, params, x_getstate, x_process, NULL,
                            NULL);
    assert(0 != r);
    r = NL_summseq_set_info(obj, params, x_getstate, x_process, x_flush,
                            NULL);
    assert(0 != r);
    r = NL_summseq_set_info(obj, params, x_getstate, x_process, x_flush,
                            x_free);
    assert(0 == r);
    NL_summseq_del(obj);

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_create();
    test_delete();
    test_accept();
    test_addSelector();
    test_addIdField();
    test_addValueField();
    test_consume();
    test_getIds();
    test_getParams();
    test_getState();
    test_getValues();
    test_matchRecord();
    test_setInfo();
    //test_summarize();

    return g_num_failed;
}
