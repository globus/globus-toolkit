/* Tests for summ/nlobserver.c */

#include <unistd.h>

#include "nlobserver.h"
#include "util.h"

const char *g_err[] = {
    "Not implemented",
    NULL
};

int add_one(void *ctxt, void *x)
{
    int y;

    if (x) {
        y = *((int *) x);
        y++;
        *((int *) x) = y;
    }
    return 0;
}

TEST_PROTO(createDelete)
{
    NL_subject_T s = NL_subject();
    NL_observer_T o = NL_observer((NL_observer_cb) add_one, NULL);

    assert(o);
    assert(s);

    NL_observer_del(o);
    NL_subject_del(s);

    return 0;
}

TEST_PROTO(correctness)
{
    NL_subject_T s = NL_subject();
    NL_observer_T o = NL_observer(add_one, NULL);

    int i, j, v;
    const int N1 = 100, N2 = 77;

    DBG("- notify empty with NULL\n");
    NL_subject_notify(s, NULL);

    DBG("- notify with real observer\n");
    for (j = 0; j < N2; j++) {
        v = 0;
        for (i = 0; i < N1; i++) {
            NL_subject_register(s, o);
            NL_subject_notify(s, &v);
        }
        if (j == N2 - 1) {
            DBG("- notify non-empty with NULL\n");
            NL_subject_notify(s, NULL);
        }
        assert(v == N1 * (N1 + 1) / 2);
        for (i = 0; i < N1; i++) {
            NL_subject_unregister(s, o);
        }
    }

    DBG("- delete observer\n");
    NL_observer_del(o);
    DBG("- delete subject\n");
    NL_subject_del(s);

    return 0;
}

TEST_PROTO(manyToOne)
{
    const int N = 7;
    NL_subject_T s[N];
    NL_observer_T o[N];
    int i, j;

    DBG2("- check %d subjects and %d observer\n", N, 1);
    for (i = 0; i < N; i++) {
        s[i] = NL_subject();
        o[i] = NL_observer(add_one, NULL);
    }
    NL_subject_register(s[0], o[0]);
    NL_subject_register(s[1], o[0]);
    for (i = 0; i < N; i++) {
        NL_subject_del(s[i]);
        NL_observer_del(o[i]);
    }

    return 0;
}

TEST_PROTO(manyToMany)
{
    const int N = 7;
    NL_subject_T s[N];
    NL_observer_T o[N];
    int i, j;

    DBG2("- check %d subjects and %d observers\n", N, N);
    for (i = 0; i < N; i++) {
        s[i] = NL_subject();
        o[i] = NL_observer(add_one, NULL);
    }
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            NL_subject_register(s[i], o[j]);
        }
    }
    for (i = 0; i < N; i++) {
        NL_subject_del(s[i]);
        NL_observer_del(o[i]);
    }

    return 0;
}


int main(int argc, char **argv)
{
    nl_test_init(argc, argv);

    test_createDelete();
    test_correctness();
    test_manyToOne();
    test_manyToMany();

    return g_num_failed;
}
