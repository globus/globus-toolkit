static const volatile char rcsid[] =
    "$Id: test_wvar.c 130 2007-08-22 14:09:32Z dang $";
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
 * Unit tests for summ/nlwvar.c
 *
 * Usage: test_wvar
 */

#include "nlwvar.h"
#include "nldbg.h"
#include "util.h"

/* List of error messages */
const char *g_err[] = {
    "Not implemented",
    NULL                               /* sentinel */
};

TEST_PROTO(correctness)
{
    int i, N = 10000;
    double variance, w_variance;
    NL_wvar_T w;

    DBG("\nCreate wvar obj\n");
    w = NL_wvar_new(1);
    DBG1("add %d numbers\n", N);
    for (i = 0; i < N; i++) {
        NL_wvar_add(w, (double) i);
    }
    variance = 8334166 + (2.0 / 3.0);
    w_variance = NL_wvar_variance(w);
    DBG2("theor. variance=%lf wvar variance=%lf\n", variance, w_variance);
    assert(EQ_EPS(variance, w_variance, 0.000001));

    return 0;
}

TEST_PROTO(baseline)
{
    NL_wvar_T w;

    w = NL_wvar_new(3);
    assert(NL_wvar_variance(w) == NL_NOT_ENOUGH_DATA);
    assert(NL_wvar_sd(w) == NL_NOT_ENOUGH_DATA);
    NL_wvar_add(w, 1.0);
    NL_wvar_add(w, 2.0);
    assert(NL_wvar_variance(w) == NL_NOT_ENOUGH_DATA);
    assert(NL_wvar_sd(w) == NL_NOT_ENOUGH_DATA);
    NL_wvar_add(w, 2.0);
    assert(NL_wvar_variance(w) != NL_NOT_ENOUGH_DATA);
    assert(NL_wvar_sd(w) != NL_NOT_ENOUGH_DATA);

    return 0;
}

TEST_PROTO(clear)
{
    NL_wvar_T w;

    w = NL_wvar_new(3);
    assert(w);
    NL_wvar_add(w, 1.0);
    NL_wvar_add(w, 2.0);
    NL_wvar_add(w, 3.0);
    assert(EQ_EPS(NL_wvar_variance(w), 1.0, 0.000001));
    NL_wvar_clear(w);
    assert(NL_wvar_variance(w) == NL_NOT_ENOUGH_DATA);

    return 0;
}

int main(int argc, char **argv)
{
    nl_test_init(argc, argv);
    test_correctness();
    test_baseline();
    test_clear();

    return g_num_failed;
}
