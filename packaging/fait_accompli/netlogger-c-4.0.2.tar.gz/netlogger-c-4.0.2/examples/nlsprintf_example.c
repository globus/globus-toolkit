#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include "nl.h"

int main(int argc, char **argv)
{
    int len;
    char buf[65536];
    struct timeval start_t, end_t;
    gettimeofday(&start_t, 0);
    gettimeofday(&end_t, 0);
    len = NL_sprintf(buf, "gridftp.FTP_INFO", NL_LVL_INFO,
                     "HOST=s PROG=s "
                     "START.TM=d END.TM=d "
                     "USER=s FILE=s "
                     "BUFFER=l BLOCK=l NBYTES=l VOLUME=d "
                     "STREAMS=i STRIPES=i "
                     "DEST=s TYPE=s CODE=i",
                     "131.243.2.1", "GridFTP",
                     start_t.tv_sec + start_t.tv_usec / 1e6,
                     end_t.tv_sec + end_t.tv_usec / 1e6,
                     "Elmo", "SesameStreet.txt",
                     1LL, 2LL, 32767LL, 1e9,
                     8, 12, "123.456.3.2", "what", 1);
    write(STDOUT_FILENO, buf, len);
}
