/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";
/** @file nltransfer_example.c
 *  @ingroup nlsumm examples
 */
/*@{*/

/**
 * Example usage of the NetLogger "transfer" API.
 * See usage() function for program arguments.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "nltransfer.h"

/** In reality, blocks would probably be O(100K) */
#define BLOCK_SIZE 8 

/* Pretend to read some data */
int read_bytes(void)
{
    usleep(1);
    return BLOCK_SIZE;
}

/* Pretend to write some data */
int write_bytes(void)
{
    usleep(20);
    return BLOCK_SIZE;
}

/* With apologies to Mark Harris */
int bang_the_drum_slowly(void)
{
    usleep(500000);
    return BLOCK_SIZE;
}

/* Prototype for run function */
typedef int (*run_fn_t)(const char *, int);

/*
 * Get GUID from NetLogger
 */
void get_my_guid(char **guid)
{
    if (!NL_get_guid(guid) && !NL_get_someid(guid)) {
        *guid = strdup("00000000-0000-0000-0000-000000000000");
    }
}

/**
 * Log everything to the same place.
 */
int run1(const char *logfile, long summ_usec )
{    
    
    char err_why[1024]; /* for error reporting */
    char *guid;
    NL_summ_T summ;
    NL_log_T log;
    const char *stdout_logfile = "-";
    char *result_str;
    
    /* Get a GUID */
    get_my_guid(&guid);
    /* Set log file to stdout if NULL */
    if (!logfile)
        logfile = stdout_logfile;
        
    /* 
        (1) Create NetLogger log instance 
    */
    /* Open log, return on error */
    log = NL_open(logfile);
    if (!log) {
        sprintf(err_why,"opening '%s'", logfile);
        goto error;
    }
    /* Set log to DEBUG level */
    NL_set_level(log, NL_LVL_DEBUG);    

    /* 
        (2) Create summarizer
    */
    summ = NL_summ();
    /* Make summarizer output go to log, too */
    NL_summ_set_shared_output(summ, log);
    /* Add NL_transfer events to summarizer.
       Set interval to -1 to mean "until NL_finalize()".
     */
    NL_transfer_init(summ, summ_usec,  NL_LVL_DEBUG);
    /* Don't let summarizer 'consume' the events,
     * we want them to "pass through" and get logged
     * in their full detail.
     */
    NL_transfer_set_passthrough(summ);
    /* Add this summarizer to log instance */
    NL_summ_add_log(summ, log);
    
    /*
        (3) Log some activity
     */
    NL_write(log, NL_LVL_INFO, "nltransfer_example.activity.start", "");
    {
        NL_transfer_blockid_t block_id;
        NL_transfer_streamid_t stream_id;
        NL_transfer_op_t op;
        double nbytes;
        
        for (block_id = 0; block_id < 2; block_id++) {
            for (stream_id = 11; stream_id < 13; stream_id++) {
                for (op=NL_TRANSFER_DISK_READ; op < NL_TRANSFER_NOEVENT; op++) {
                    NL_transfer_start(log, NL_LVL_DEBUG, op, 
                                      guid, stream_id, block_id);
                    nbytes = bang_the_drum_slowly();
                    NL_transfer_end(log, NL_LVL_DEBUG, op,
                                    guid, stream_id, block_id, nbytes);
                }
            }
        }
    }
    NL_write(log, NL_LVL_INFO, "nltransfer_example.activity.end", "");
    
    /*
        (4) Finalize handles and get result string.
            Then close everything up
     */
    NL_transfer_finalize(summ);
    result_str = NL_transfer_get_result_string(summ, guid);
    printf("RESULT STRING:\n%s", result_str);
    NL_summ_del(summ);
    NL_close(log);
    
    return 0;
    
error:
    fprintf(stderr,"Error:%s:%s\n", err_why, NL_err_str());
    return -1;
}

/**
 * Print usage message and exit
 */
void usage(void)
{
    printf("Program usage: nltransfer_example [-o logfile] [-i usec]\n");
    exit(0);           
}

/**
 * Program entry point
 */
int main(int argc, char **argv)
{
    long usec;
    int i, result = 0;
    char *logfile, *endptr;
    
    logfile = NULL;
    usec = -1;
    if (argc >= 2) {
        for (i=1; i < argc-1; i++) {
            if (argv[i][0] != '-')
                usage();
            switch (argv[i][1]) {                    
                case 'i':
                    usec = strtol(argv[i +1], &endptr, 10);
                    if (endptr == NULL)
                        usage();                        
                    break;
                case 'o':
                    logfile = strdup(argv[i+1]);
                    break;
                default:
                    usage();
            }
        }
    }
    
    if (usec < 0)
        usec = 1000000;
    if (!logfile)
        logfile = strdup("-");
        
    printf("--------------------------------------------------\n");
    result = run1(logfile, usec);
    
    free(logfile); /* keep valgrind happy */
    
    return result;
}

/*@}*/
