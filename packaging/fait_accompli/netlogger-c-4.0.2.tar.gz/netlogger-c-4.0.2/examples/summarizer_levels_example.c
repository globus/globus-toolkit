/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";
/** @file
 * @ingroup examples
 *
 * @brief Example usage of various levels of the NetLogger summarizer.
 *
 * Run with one or more of the provided levels to see the expected type
 * of output (to stdout).
 * For example:
 * @verbatim
 # default logging only
   summarize_levels_example -1
   
 # default logging and 1-second interval logging
   summarize_levels_example -1 -3 1.0
   
 # all logging except interval logging
   summarize_levels_example -1 -2 -4 @endverbatim
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "nltransfer.h"

#define eprnt(fmt, args...) fprintf(stderr, fmt, ##args)

/**
 * Print usage message and exit
 */
void usage(const char *why)
{
    if (why)
        eprnt("Error: %s\n", why);
    eprnt("usage: summarizer_levels_example [options]\n"
          "[options] are one or more of:\n"          "-1      default log level\n"          "-2      'bottleneck' logging\n"          "-3 SEC  interval logging (summary every SEC seconds)\n"          "-4      full logging (all IO operations logged)\n"
          "Note: Level -4 also includes default logging\n"          
          "\n"
          "AND at most one of:\n"
          "-r      disk/read bottleneck\n"
          "-w      disk/write bottleneck\n"
          "-n      network bottleneck\n"
          "Note: by default they all go about the same speed\n"
           );
    exit(0);           
}

/* Structure containing parsed args */
struct parsed_args {
    int64_t interval_usec;
    unsigned int options;
    NL_transfer_op_t bottleneck;
};

/* Names for the 4 level bitmasks, for code readability */
#define DEFAULT_LOGGING    (1)
#define BOTTLENECK_LOGGING (2)
#define INTERVAL_LOGGING   (4)
#define FULL_LOGGING       (8)

/* Argument parsing */
int parse_args(int argc, char **argv, struct parsed_args *argp)
{
    int i;

    if (argc < 2)
        return -1;

    argp->options = 0;
    argp->bottleneck = NL_TRANSFER_NOEVENT;
    for (i=1; i < argc; i++) {
        /* all args must start with '-' */
        if (argv[i][0] != '-')
            usage("argument must start with a '-'");
        if (argv[i][1] >= '1' && argv[i][1] <= '4') {
            argp->options |= 1 << (argv[i][1] - '1');
            if (argv[i][1] == '3') {            
                /* parse next arg. as seconds */
                char *endptr;
                double sec;
                if (i == argc-1)
                    usage("missing SEC"); 
                sec = strtod(argv[i+1], &endptr);
                if (!endptr || sec <= 0.)
                    usage("invalid SEC, must be a number >= 0");
                 argp->interval_usec = (int64_t)(sec * 1e6);
                 i++; /* skip value we just parsed */
            }
        }
        else {
            switch (argv[i][1]) {
                case 'r': argp->bottleneck = NL_TRANSFER_DISK_READ; break;
                case 'w': argp->bottleneck = NL_TRANSFER_DISK_WRITE; break;
                case 'n': argp->bottleneck = NL_TRANSFER_NET_READ; break;
                default:
                    usage("unrecognized argument");
            }                 
        }
    }
    
    return 0;
}
        
/* Pretend to do I/O */
int slow_io(void) { usleep(2500); return 131024; }
int fast_io(void) { usleep(1000); return 131024; }

/* Get GUID from NetLogger */
void get_my_guid(char **guid)
{
    if (!NL_get_guid(guid) && !NL_get_someid(guid))
        *guid = strdup("00000000-0000-0000-0000-000000000000");
}



/**
 * Run the example
 */
int run(struct parsed_args *argp)
{    
    
    char err_why[1024]; /* for error reporting */
    char *guid;
    NL_summ_T summ;
    NL_log_T log;
    int i, j, k;
    double nbytes;
    NL_level_t dflt_lvl = NL_LVL_INFO;
    NL_level_t detl_lvl = NL_LVL_DEBUG;
        
    get_my_guid(&guid);
    /* 
        Create NetLogger log instance 
    */
    if (!(log = NL_open("-" /* stdout */)))
        goto error;

    if (argp->options == DEFAULT_LOGGING) {
        /* Default logging only: INFO level */
        NL_set_level(log, NL_LVL_INFO);
        summ = NULL;
    }
    else if (argp->options == FULL_LOGGING) {
        NL_set_level(log, NL_LVL_DEBUG2);
        summ = NULL;
    }
    else {
        if (argp->options & FULL_LOGGING)
            /* Full logging: set log to DEBUG + 2 level */
            NL_set_level(log, NL_LVL_DEBUG2);
        else {
            /* Summarization: set log to DEBUG level */
            NL_set_level(log, NL_LVL_DEBUG);
            /* Raise level of detailed logging so it doesn't show up */
            detl_lvl = NL_LVL_USER;
            /* If no default logging, also raise its level */
            if (!(argp->options & DEFAULT_LOGGING))
                dflt_lvl = NL_LVL_USER;
        }
        
        /* 
            Create summarizer
        */
        summ = NL_summ();
        /* Make summarizer output go to log, too */
        NL_summ_set_shared_output(summ, log);
        /* Set time-interval to 'forever' if no interval logging */
        if (!(argp->options & INTERVAL_LOGGING))
            argp->interval_usec = -1;
        /* Init for transfer events */
        NL_transfer_init(summ, argp->interval_usec, NL_LVL_DEBUG);
        /* Determine whether or not to let summarizer 'consume' the events,
         * which depends on whether full logging is desired.
         */
        if (argp->options & FULL_LOGGING)
            NL_transfer_set_passthrough(summ);
        /* Add this summarizer to log instance */
        NL_summ_add_log(summ, log);
    }    

    /*
        Log some activity
     */
    NL_write(log, dflt_lvl, "activity.start", "guid=s", guid);
    
    /* Outer loop */
    for (i=0; i < 2; i++) {
        /* Example of more detailed program logging. */
        NL_write(log, detl_lvl, "loop.start", "guid=s num=i", guid, i);
        /* Inner loop */
        for (j=0; j < 5; j++) {
            for (k=0; k < NL_TRANSFER_NOEVENT; k++) {
                NL_transfer_start(log, NL_LVL_DEBUG, k, guid, 0, 0);
                nbytes = (k == argp->bottleneck) ? slow_io() : fast_io();
                NL_transfer_end(log, NL_LVL_DEBUG, k, guid, 0, 0, nbytes);
            }
        }
        NL_write(log, detl_lvl, "loop.end", "guid=s num=i status=i",
                 guid, i, 0);
    }
    NL_write(log, dflt_lvl, "activity.end", "guid=s status=i", guid, 0);
    
    /*
        Finalize handles and optionally print bottleneck
     */
     if (summ) {        
        NL_transfer_finalize(summ);
        if (argp->options & BOTTLENECK_LOGGING) {
            NL_transfer_btl_t bottleneck;
            char *rstr = NL_transfer_get_result_string(summ, guid);
            eprnt("\nBottleneck determination: ");
            NL_transfer_get_bottleneck(rstr, NULL, &bottleneck);
            switch (bottleneck.result) {
                case NL_BTL_KNOWN:
                    eprnt("Bottleneck is ");
                    switch (bottleneck.location) {
                        case NL_BTL_DISK_READ: eprnt("disk read\n"); break;
                        case NL_BTL_DISK_WRITE: eprnt("disk write\n"); break;
                        case NL_BTL_DISK_WRITE_MAYBE: 
                            eprnt("disk write, maybe\n"); break;
                        case NL_BTL_NET: eprnt("network\n"); break;
                    }
                    break;
                case NL_BTL_UNKNOWN: eprnt("Unknown\n"); break;
                case NL_BTL_MISSING_DATA: eprnt("Not enough data\n"); break;
                case NL_BTL_BAD_DATA: eprnt("Bad data\n"); break;
                case NL_BTL_SYSERR: eprnt("System error\n"); break;
            }
        }
        NL_summ_del(summ);
    }
    NL_close(log);
    
    return 0;
    
error:
    eprnt("Error:%s:%s\n", err_why, NL_err_str());
    return -1;
}


/**
 * Program entry point
 */
int main(int argc, char **argv)
{
    struct parsed_args arg;
    int r;
    
    if (parse_args(argc, argv, &arg))
        usage("missing arguments");
    r = run(&arg);

    return r;
}

/*@}*/
