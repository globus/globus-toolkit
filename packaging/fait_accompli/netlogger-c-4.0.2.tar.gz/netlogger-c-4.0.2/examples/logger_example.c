/* 
Copyright (c) 2004, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/** @file 
 * @ingroup examples */

/**
 * Sample high-level C API usage. This is the API that most people
 * would be expected to use.
 */
#include <stdio.h>
#include "nl.h"
 
 /**
  * Pretend to do something. Actually a no-op.
  */
void do_something(void)
{
    return;
}


/**
 * MAIN
 */
int main(int argc, char **argv)
{
    NL_log_T environment, screen, debug;
    int i;

    /* If the destination is NULL, setting
     * the environment variable 'NL_DEST' will redirect it, e.g.:
     *    % export NL_DEST=/tmp/myData.log
     */
    environment = NL_open(NULL);

    /* Set destination to stderr, output level to 'info', and
     * add a string constant to every message
     */
    screen = NL_open("&");
    NL_set_level(screen, NL_LVL_INFO);
    NL_set_const(screen, "constant:s", "constant value");

    /* Debugging handle */
    debug = NL_open("&");
    NL_set_level(debug, NL_LVL_DEBUG1);

    /* Write an empty 'program.start' event to the 'screen' log. */
    NL_write(screen, NL_LVL_INFO, "program.start", "");

    /* 
     * log a 'loop.start' event with two values to the 'debug' log.
     * since we know the values are constant, we can use a ':'
     * instead of an '=' as the keyword:datatype separator.
     *
     * By default, these will not be logged, but could be
     * "turned on" by using the dynamic levels feature.
     * e.g., if you execute the (bash) shell commands
     *    % export NL_CFG=/tmp/levels.cfg
     *    % echo 5 > /tmp/levels.cfg
     * before running this program, you will see the messages.     
     */
    NL_write(debug, NL_LVL_DEBUG, "loop.start", "start:i stop:i", 0, 10);
    for (i = 0; i < 10; i++) {
        /* 
         * Wrap do_something() with an eponymous event at
         * a higher (more fine-grained) debugging level.
         *
         * To turn on these messages, you will need to set the
         * logging level to '6' (see comment above).
         */
        NL_write(debug, NL_LVL_DEBUG1, "do.something.start", "index=i", i);
        do_something();
        NL_write(debug, NL_LVL_DEBUG1, "do.something.end", "index=i", i);
    }
    /*
     * these are just mirror images of the loop.start/program.start
     * messages
     */
    NL_write(debug, NL_LVL_DEBUG, "loop.end", "start=i stop=i", 0, 10);
    NL_write(screen, NL_LVL_INFO, "program.end", "", 1.0);

    /* close logs */
    NL_close(environment);
    NL_close(debug);
    NL_close(screen);

    return 0;
}