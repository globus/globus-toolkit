#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "nl.h"

const char *prog = NULL;

void error()
{
    fprintf(stderr, "Error: %s\n", NL_err_str());
    NL_err_clear();
}

void usage()
{
    fprintf(stderr, "usage: %s "
            "[#messages=1] [per-msg sleep(us)=0]\n", prog);
}

/**
 * Usage: {prog} [#messages=1] [per-msg sleep(us)=0]
 */
int main(int argc, char **argv)
{
    uint32_t mask[2];
    int x, n = 1, us = 0;
    NL_log_T log1, log2;
    NL_result_t r;

    prog = argv[0];

    if (argc > 2) {
        n = atoi(argv[1]);
        if (n < 1) {
            usage();
            return (-1);
        }
        if (argc > 2) {
            us = atoi(argv[2]);
        }
    }

    log1 = NL_open("x-syslog://localhost");
    if (!log1)
        error();
    NL_set_level(log1, NL_LVL_INFO);
    log2 = NL_open("&");
    if (!log2)
        error();
    NL_set_level(log2, NL_LVL_INFO);

    for (x = 0; x < n; x++) {
        /* log only first/last 10 messages to console */
        if (x < 10)
            NL_write(log2, NL_LVL_INFO, "test-event",
                     "sample string:s sample int:i", "hello", x);
        r = NL_write(log1, NL_LVL_INFO, "test-event",
                     "sample string:s sample int:i", "hello", x);
        if (r)
            error();
        if (us)
            usleep(us);
    }

    NL_close(log1);
    NL_close(log2);

    return 0;
}
