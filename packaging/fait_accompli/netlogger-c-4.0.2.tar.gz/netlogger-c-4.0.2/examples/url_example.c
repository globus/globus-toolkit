/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#include "nl.h"

int main(int argc, char **argv)
{
    NL_log_T log;

    if (argc != 2) {
        fprintf(stderr, "usage: %s URL\n", argv[0]);
        exit(1);
    }

    log = NL_open(argv[1]);
    NL_write(log, NL_LVL_INFO, "event", "prog=s url=s", argv[0], argv[1]);
    NL_close(log);

    exit(0);
}
