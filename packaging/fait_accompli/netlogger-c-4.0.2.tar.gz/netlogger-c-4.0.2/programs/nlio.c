/* NL threaded IO, for testing logging */

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>
/* time headers */
#if TIME_WITH_SYS_TIME
#    include <sys/time.h>
#    include <time.h>
#else
#    if HAVE_SYS_TIME_H
#        include <sys/time.h>
#    else
#        include <time.h>
#    endif
#endif
#include "nl.h"
#include "nlerr.h"
#include "nlsumm.h"
#include "nltransfer.h"
#include "nlio.h"

/*
 * Global log
 */
NL_log_T g_log = NULL;

/*
 * Global GUIDs
 */
char * g_guid = NULL;
char * g_xguid = NULL; /* transfer GUID */
guid_mode_t g_guid_mode = NLIO_NOGUID;

/* ------------------------------------------------------------------------ */
/* Master thread object                                                     */
/* ------------------------------------------------------------------------ */

#define T nlio_master_T
struct T {
    int read_fds_len;
    int *read_fds;
    int write_fds_len;
    int *write_fds;
    mode_t file_mode;           /* mode for newly created files */
    uint32_t peer_addr, local_addr;
    char *peer_host, *local_host;
    unsigned short peer_port, local_port;
    char *filename;
    size_t tcp_buf;
    int at_eof, is_sender;
    int64_t ttl_bytes;          /* total #bytes so far */
    int64_t max_bytes;          /* max #bytes to transfer, -1=until EOF */
    pthread_mutex_t mutex;
    uint32_t block_id;
    void *free_args;
    unsigned int op_usleep[4];  /* time to usleep for a given operation */
    NL_log_T log;               /**< performance log */
    NL_summ_T summ;        /**< summarize entire  run + intervals */
    NL_transfer_btl_t *bottleneck;    
};

struct nlio_master_arg_t {
    T master;
    nlio_device_t read, write;
    int is_server;
};
typedef struct nlio_master_arg_t nlio_master_arg_t;

T nlio_master_new(void)
{
    T self = malloc(sizeof(struct T));

    self->free_args = NULL;
    self->write_fds_len = self->read_fds_len = 0;
    self->write_fds = self->read_fds = NULL;
    self->peer_host = self->local_host = NULL;
    self->peer_port = self->local_port = -1;
    self->filename = NULL;
    self->tcp_buf = (size_t)0;
    self->at_eof = 0;
    self->log = NULL;
    self->summ = NULL;
    pthread_mutex_init(&self->mutex, NULL);
    self->file_mode = 0600;
    self->max_bytes = -1;
    self->ttl_bytes = 0LL;
    self->block_id = 0U;
    /* set initial sleep times to 0 */
    memset(self->op_usleep, 0, sizeof(self->op_usleep));
    self->bottleneck = NULL;
    return self;
}

/*
 * Lock master mutex
 */
static inline void nlio_master_lock(T self)
{
    pthread_mutex_lock(&self->mutex);
}

/*
 * Unlock master mutex
 */
static inline void nlio_master_unlock(T self)
{
    pthread_mutex_unlock(&self->mutex);
}

/*
 * Initialize performance log
 */
int
nlio_master_init_log(T self, NL_log_T log,
                    int modes, float summ_interval)
{
    int result = 0;
    long long interval_usec = -1LL;
    
    self->log = log;
    if (NULL == self->log)
        goto bottom;
        
    if (modes == NLIO_LOG_NONE)
        goto bottom;
   
    if (modes & NLIO_LOG_INT)
        interval_usec = summ_interval * 1000000;
        
    if (modes & (NLIO_LOG_PROG | NLIO_LOG_INT)) {
        self->summ = NL_summ();
        result = NL_transfer_init(self->summ, interval_usec, NL_LVL_INFO);
        if (result < 0)
            goto error;
        NL_summ_set_shared_output(self->summ, self->log);
        NL_summ_add_log(self->summ, self->log);
    }
 
    if ((modes & NLIO_LOG_FULL) && self->summ)
        NL_transfer_set_passthrough(self->summ);     

bottom:
    return 0;
    
error:
    return -1;
}

/*
 * Get results of performance log
 */
NL_summ_T nlio_master_get_summ(T self)
{
    return self->summ;
}

NL_transfer_btl_t *nlio_master_get_btl(T self)
{
    return self->bottleneck;
}

/* Functions for read/write file descriptors */
/* ----------------------------------------- */

/*
 * Get total number of bytes so far
 */
extern int64_t nlio_master_get_bytes(T self)
{
    int64_t r;
    pthread_mutex_lock(&self->mutex);
    r = self->ttl_bytes;
    pthread_mutex_unlock(&self->mutex);
    return r;
}

/*
 * Add to total #bytes so far
 */
extern void nlio_master_add_bytes(T self, int64_t n)
{
    pthread_mutex_lock(&self->mutex);
    self->ttl_bytes += n;
    pthread_mutex_unlock(&self->mutex);
}



/*
 * Allocate file descriptors for reading, and initialize to -1
 */
void nlio_master_init_read_fds(T self, int n)
{
    int i;

    self->read_fds_len = n;
    self->read_fds = malloc(sizeof(int) * self->read_fds_len);
    for (i = 0; i < self->read_fds_len; i++) {
        self->read_fds[i] = -1;
    }
}

/*
 * Get i-th reading file descriptor
 */
int nlio_master_get_read_fd(T self, int i)
{
    return (i >= 0 && i < self->read_fds_len) ? self->read_fds[i] : -1;
}

/*
 * Are we at EOF (for reading)?
 */
int nlio_master_get_read_eof(T self)
{
    int at_eof;

    nlio_master_lock(self);
    at_eof = self->at_eof;
    nlio_master_unlock(self);
    return at_eof;
}

/*
 * Set max #bytes to process
 */
void nlio_master_set_max_bytes(T self, int64_t n)
{
    self->max_bytes = n;
}

/*
 * Set flag for being at EOF to true
 */
void nlio_master_set_read_eof(T self)
{
    nlio_master_lock(self);
    self->at_eof = 1;
    nlio_master_unlock(self);
}

/*
 * Set i-th read descriptor value.
 */
void nlio_master_set_read_fd(T self, int i, int fd)
{
    if (i >= 0 && i < self->read_fds_len) {
        self->read_fds[i] = fd;
    }
}

/*
 * Allocate file descriptors for writing, and initialize to -1
 */
void nlio_master_init_write_fds(T self, int n)
{
    int i;

    self->write_fds_len = n;
    self->write_fds = malloc(sizeof(int) * self->write_fds_len);
    for (i = 0; i < self->write_fds_len; i++) {
        self->write_fds[i] = -1;
    }
}

/*
 * Get i-th writing file descriptor
 */
int nlio_master_get_write_fd(T self, int i)
{
    return (i >= 0 && i < self->write_fds_len) ? self->write_fds[i] : -1;
}

/*
 * Set i-th write descriptor value
 */
void nlio_master_set_write_fd(T self, int i, int fd)
{
    if (i >= 0 && i < self->write_fds_len) {
        self->write_fds[i] = fd;
    }
}

/* Functions for socket and file I/O */
/* --------------------------------- */

/*
 * Get next block id
 */
static inline uint32_t nlio_master_get_next_block(T self)
{
    uint32_t r;
    pthread_mutex_lock(&self->mutex);
    r = self->block_id++;
    pthread_mutex_unlock(&self->mutex);
    return r;
}

/*
 * Set host/port
 */
int nlio_master_set_host(T self, const char *host, short port, int is_remote)
{
    if (is_remote) {
        if (-1 == nlio_get_host_addr(host, &self->peer_addr))
            goto error;
        self->peer_host = strdup(host);
        self->peer_port = port;
    }
    else {
        if (-1 == nlio_get_host_addr(host, &self->local_addr))
            goto error;
        self->local_host = strdup(host);
        self->local_port = port;
    }
    return 0;
error:
    return -1;
}

/*
 * Get address of the host.
 */
int nlio_get_host_addr(const char *host, unsigned *addr)
{
    struct hostent *hent = NULL;

    if (!host)
        goto error;
    hent = gethostbyname(host);
    if (!hent)
        goto error;
    *addr = ((struct in_addr *) (hent->h_addr))->s_addr;
    return 0;
    
error:
    return -1;
}

/*
 * Get other end of socket host/port
 */
char *nlio_get_peer_name(int sock)
{
    struct sockaddr_in inaddr;
    socklen_t len;
    struct hostent *hent;
    
    if (0 < getpeername(sock, (struct sockaddr*)&inaddr, &len))
        goto error;
    if (NULL == (hent = gethostbyaddr(&inaddr, len, AF_INET)))
        goto error;
    return strdup(hent->h_name);
    
error:
    return NULL;
}

/*
 * Set read/write file
 */
void nlio_master_set_file(T self, const char *filename)
{
    self->filename = strdup(filename);
}

/*
 * Set is_sender flag
 */
void nlio_master_set_sender(T self, int flag)
{
    self->is_sender = flag;
}

/*
 * Set buffer size to apply to sockets
 */
void nlio_master_set_tcpbuf(T self, size_t bytes)
{
    self->tcp_buf = bytes;
}

/*
 * Set microsecond sleep time on each iteration
 */
int nlio_master_set_usleep(T self, NL_transfer_op_t op, unsigned int us)
{
    if (op < 0 || op >= NL_TRANSFER_NOEVENT)
        return -1;
    self->op_usleep[op] = us;
    return 0;
}

/*
 * Connect to remote peer
 */
int nlio_master_connect(T self)
{
#define CONN_ERROR(e) \
        NLIO_ERROR("nlio.conn." e, "status=i", -1); \
        goto error
    int num_streams;
    struct sockaddr_in serv_addr, client_addr;
    socklen_t addr_len;
    int i;

    if (!self->peer_host) {
        goto error;
    }
    if (self->is_sender) {
        num_streams = self->write_fds_len;
        nlio_master_init_write_fds(self, num_streams);
    }
    else {
        num_streams = self->read_fds_len;
        nlio_master_init_read_fds(self, num_streams);
    }
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = self->peer_addr;
    serv_addr.sin_port = htons(self->peer_port);
    /* connect each stream */
    for (i = 0; i < num_streams; i++) {
        int sockfd;
        size_t result;

        sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd < 0) {
            CONN_ERROR("socket");
            goto error;
        }
        /* socket buffer option */
        if (self->tcp_buf > 0) {
            result = setsockbuf(sockfd, self->tcp_buf, self->is_sender);
        }
        /* connect */
        addr_len = sizeof(struct sockaddr_in);
        if (connect(sockfd, (struct sockaddr *) &serv_addr,
                    sizeof(serv_addr)) < 0) {
            CONN_ERROR("connect");
            goto error;
        }
        /* verify socket buffer here since some OS's don't show results
         * until after connect()
         */
        if (self->tcp_buf > 0)
            result =
                (size_t) getsockbuf(sockfd, self->tcp_buf,
                                    self->is_sender);
        else
            self->tcp_buf = getsockbuf(sockfd, 0, self->is_sender);
        if (0 > getsockname(sockfd,
                            (struct sockaddr *) &client_addr, &addr_len)) {
            CONN_ERROR("getsockname");
            goto error;
        }

        if (self->is_sender)
            nlio_master_set_write_fd(self, i, sockfd);
        else
            nlio_master_set_read_fd(self, i, sockfd);
        if (0 == i) {
            nlio_master_set_host(self, "localhost",
                             ((struct sockaddr_in)client_addr).sin_port, 0);
        }
    }
    /* add global for this? if (!quiet_mode)  */
    /* just do this once for the last socket: should be the same for all sockets */
    fprintf(stderr, "TCP Socket buffer size set to %d bytes\n", (int)self->tcp_buf);
    return 0;

  error:
    return -1;
}

/*
 * Accept connection from remote peer
 */
int nlio_master_accept(T self)
{
/* report error and jump to return statement */
#define ACCEPT_ERROR(e) \
           NLIO_ERROR("nlio.accept." e, "status=i", -1); \
	   perror("accept error"); \
           goto error

    int num_streams;
    int i, sockfd, yes = 1;
    struct sockaddr_in serv_addr, cli_addr;
    size_t result;

    if (!self->local_host) {
        ACCEPT_ERROR("localhost_not_given");
    }
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    if (self->local_addr) {
        serv_addr.sin_addr.s_addr = self->local_addr;
    }
    else {
        serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    }
    serv_addr.sin_port = htons(self->local_port);

    /* open listen socket */
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        ACCEPT_ERROR("socket.error");
    }
    /* set re-use option */
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes)) <
        0) {
        ACCEPT_ERROR("setsockopt");
    }
    /* socket buffer option */
    if (self->tcp_buf > 0) {
        result = setsockbuf(sockfd, self->tcp_buf, self->is_sender);
    }
    /* bind to addr */
    if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) <
        0) {
        ACCEPT_ERROR("bind");
    }
    /* listen */
    listen(sockfd, 5);
    /* verify socket buffer here since some OS's don't show results
     * until after listen()
     */
    if (self->tcp_buf > 0)
        result =
            (size_t) getsockbuf(sockfd, self->tcp_buf, self->is_sender);
    else
        self->tcp_buf = getsockbuf(sockfd, 0, self->is_sender);

    /* accept num_streams connections */
    num_streams =
        self->is_sender ? self->write_fds_len : self->read_fds_len;
    for (i = 0; i < num_streams; i++) {
        unsigned cliaddr_len;
        int fd;

        cliaddr_len = sizeof(cli_addr);
        fd = accept(sockfd, (struct sockaddr *) &cli_addr, &cliaddr_len);
        if (fd < 0) {
            ACCEPT_ERROR("accept");
            goto error;
        }
        if (self->is_sender)
            nlio_master_set_write_fd(self, i, fd);
        else
            nlio_master_set_read_fd(self, i, fd);
        if (0 == i) {
            nlio_master_set_host(self, nlio_get_peer_name(sockfd), 
                                 ((struct sockaddr_in)cli_addr).sin_port, 1);
        }
    }
    
    close(sockfd);
    
    return 0;

  error:
    return -1;
#undef ACCEPT_ERROR
}

/*
 * Open file for read or write
 */
int nlio_master_open_file(T self, nlio_op_t op)
{
/* report error and jump to return statement */
#define OPEN_ERROR(e) \
           NLIO_ERROR("nlio.open." e, "status=i", -1); \
	   perror("open error"); \
           goto error

    if (self->filename == NULL) {
        goto error;
    }
    if (op == NLIO_READ) {
        if (self->read_fds_len < 1) {
            goto error;
        }
        self->read_fds[0] = open(self->filename, O_RDONLY);
        if (self->read_fds[0] < 0) {
            OPEN_ERROR("open_file.read");
        }
    }
    else {
        if (self->write_fds_len != 1) {
            goto error;
        }
        self->write_fds[0] = open(self->filename, O_WRONLY | O_CREAT,
                                  self->file_mode);
        if (self->write_fds[0] < 0) {
            OPEN_ERROR("open_file.write");
        }
    }

    return 0;

  error:
    return -1;
}
#undef OPEN_ERROR

/*
 * Logging helpers
 */
static inline void
log_transfer_start(T m, int is_server)
{
    int nstreams, disk_usleep;
    char role[16];
                     
    if (m->is_sender) {
        strcpy(role, "SND" );    
        nstreams =  m->write_fds_len;
        disk_usleep = m->op_usleep[NL_TRANSFER_DISK_READ];
    }        
    else { 
        strcpy(role, "RCV");    
        nstreams = m->read_fds_len;
        disk_usleep = m->op_usleep[NL_TRANSFER_DISK_WRITE];
    }
    if (is_server) {
        NLIO_INFO("nlioperf.server.transfer.start",
                  "role=s host=s port=i file=s "
                  "nstrm=i tcp.bufsz=l nbytes=l disk.us=i",
                role, m->local_host,
                (int)m->local_port, m->filename, nstreams, 
                (long long)m->tcp_buf, m->max_bytes,
                disk_usleep);  
    }
    else {
        NLIO_INFO("nlioperf.client.transfer.start",
                  "role=s host=s port=i file=s "
                  "nstrm=i tcp.bufsz=l nbytes=l disk.us=i",
                role, m->local_host,
                (int)m->local_port, m->filename, nstreams, 
                (long long)m->tcp_buf, m->max_bytes,
                disk_usleep);  
    }
    fprintf(stderr, "Transfer Started for %d streams \n", nstreams);
}

static inline void 
log_transfer_end(T m, int status, int is_server)
{
    char event[32], event_tmpl[32];

    if (0 <= status)
        strcpy(event_tmpl,"nlioperf.%s.end");
    else
        strcpy(event_tmpl,"nlioperf.%s.error");
    if (is_server) {
        sprintf(event, event_tmpl, "server.transfer");
        NLIO_INFO(event, "status=i", status);
    }
    else {
        sprintf(event, event_tmpl, "client.transfer");
        NLIO_INFO(event, "status=i", status);
    }
    fprintf(stderr, "Done.\n");
}

/*
 * Exchange (metadata) strings between endpoints
 */
static int send_string(int *fds, int nfds, char *s, int n)
{
    int i;
    uint32_t nn;
       
    nn = htonl(n);
    for (i=0; i < nfds; i++) {
        if (4 != writen(fds[i], (char*)&nn, 4))
            return -1;
        if (n != writen(fds[i], s, n))
            return -1;
    }
    return n;
}

static int receive_string(int *fds, int nfds, char **s)
{
    int i, n=0, b;
    char *p = NULL;
    uint32_t nn;
    
    for (i=0; i < nfds; i++) {
        b = readn(fds[i], (char*)&nn, 4);
        if (4 != b)
            return -1;
        if (!n) {
            n = ntohl(nn);
            p = malloc(n);
        }
        if (n != readn(fds[i], p, n))
            return -1;
    }
    *s = p;
    //printf("@@done receive\n");    
    return n;            
}

static void nlio_master_exchange_results(T self, int net_read)
{
    char *peer_result, *local_result, err[128];
    int local_len, result;
    NL_transfer_btl_t btl;
    
    NLIO_TRACE("nlio.exchange.transfer.summary.start", "");
    
    /* re-connect socket descriptors */
    self->read_fds_len = self->write_fds_len = 1;
    if (net_read) {
        NLIO_TRACE( "socket.accept.2.start", "");
        result = nlio_master_accept(self);
        NLIO_TRACE( "socket.accept.2.end", "status=i", result);
    }
    else {
        NL_level_t cur_lvl;
        NLIO_TRACE( "socket.connect.2.start", "");
        /* turn off logging of conn. errors */
        cur_lvl = NL_get_level(g_log);
        NL_set_level(g_log, NL_LVL_FATAL);
        for (;;) {
            result = nlio_master_connect(self);
            if (0 == result)
                break;
            usleep(10000);
        }
        NL_set_level(g_log, cur_lvl);
        NLIO_TRACE( "socket.connect.2.end", "status=i",
                 result);
    }
    if (result < 0) {
        NLIO_ERROR("nlio.socket.error", "status=i msg=s", result,
                   "socket operation failed in master thread");
        strcpy(err, "could not re-connect client and server");
        goto error;
    }
    
    /* get local result to send */
    local_result = NL_transfer_get_result_string(self->summ, g_xguid);
    if (!local_result || 0 == strlen(local_result)) {
        strcpy(err, "no local result");
        goto error;
    }
    local_len = strlen(local_result) + 1;
    //printf("\n@@ local result %d <%s>\n\n", local_len, local_result);
 
    if (net_read) {
        result = receive_string(self->read_fds, self->read_fds_len, 
                                &peer_result);
        if (result > 0)
            result = send_string(self->read_fds, self->read_fds_len,
                                 local_result, local_len);
    }
    else {
        result = send_string(self->write_fds, self->write_fds_len, 
                                         local_result, local_len);
        if (result > 0)
            result = receive_string(self->write_fds, self->write_fds_len,
                                    &peer_result);
    }
    if (result < 0) {
        strcpy(err, "exchange protocol failed");
        goto error;
    }
    /* process results */
    //printf("@@ peer result <%s>\n", peer_result);
    result = NL_transfer_get_bottleneck(local_result, peer_result, &btl);
    if (result < 0) {
        strcpy(err, "results garbled or incomplete");
        goto error;
    }
    /* copy into master */
    self->bottleneck = malloc(sizeof(NL_transfer_btl_t));
    memcpy(self->bottleneck, &btl, sizeof(NL_transfer_btl_t));
    
    NLIO_TRACE("nlio.exchange.transfer.summary.end","status=i msg=s", 0, "OK");

   if (net_read)
       close(self->read_fds[0]);
   else
       close(self->write_fds[0]);
   return;

error:
   if (net_read)
       close(self->read_fds[0]);
   else
       close(self->write_fds[0]);
   NLIO_ERROR("nlio.exchange.transfer.summary.end","status=i msg=s", -1, err); 
}


/*
 * Master thread
 */
void *run_master_thr(void *arg)
{
    nlio_master_arg_t *args = (nlio_master_arg_t *)arg;
    T self;
    nlio_device_t read_device, write_device;
    nlio_worker_T *workers = NULL;
    nlio_buf_T nbuf;
    pthread_t *threads;
    int i, j, srv, wn;          /* total # of workers */
    int result = 0;
    char result_msg[1024];

    strcpy(result_msg, "none");

    NLIO_INFO( "master.run.start", "");

    /* unpack args */
    read_device = args->read;
    write_device = args->write;
    srv = args->is_server;
    self = args->master;

    /* check that there is at least one source and sink */
    if (self->read_fds_len < 1) {
        result = -1;
        sprintf(result_msg, "%d read descriptors", self->read_fds_len);
        goto bottom;
    }
    if (self->write_fds_len < 1) {
        result = -1;
        strcpy(result_msg, "no write descriptors");
        goto bottom;
    }

    wn = self->read_fds_len + self->write_fds_len;

    /* create shared buffer */
    nbuf = nlio_buf_new(wn);
    /* connect socket descriptors */
    if (srv) {
        NLIO_TRACE( "socket.accept.start", "");
        result = nlio_master_accept(self);
        NLIO_TRACE( "socket.accept", "status=i bufsz=i", result, 
                    (int)self->tcp_buf);
        fprintf(stderr, "TCP Socket buffer size set to %d bytes\n",
                    (int)self->tcp_buf);
    }
    else {        
        NLIO_TRACE( "socket.connect.start", "");
        result = nlio_master_connect(self);
        NLIO_TRACE( "socket.connect.end", "status=i",
                 result);
    }
    if (result < 0) {
        NLIO_ERROR("nlio.socket.error", "status=i msg=s", result,
                   "socket operation failed in master thread");
        goto bottom;
    }
    /* exchange transfer GUID and log start of transfer */
    NLIO_TRACE("nlio.exchange.transfer.guid.start", "");
    if (read_device == NLIO_NETWORK) {
        result = receive_string(self->read_fds, self->read_fds_len, &g_xguid);
    }
    else {
        g_xguid = g_guid;
        result = send_string(self->write_fds, self->write_fds_len, g_xguid, 37);
    }
    if (result < 0) {
        NLIO_ERROR("nlio.exchange.transfer.guid.end","status=i", -1);
        goto bottom;
    }
    g_guid_mode = NLIO_BOTHGUID;
    NLIO_TRACE("nlio.exchange.transfer.guid.end","status=i", 0);

    log_transfer_start(self, srv);
    g_guid_mode = NLIO_XGUID;
    /* create worker objects */
    workers = (nlio_worker_T *) malloc(wn * sizeof(nlio_worker_T));
    for (i = 0; i < self->read_fds_len; i++) {
        workers[i] = nlio_worker_new(self, self->read_fds[i], i, NLIO_READ,
                                     read_device, nbuf);
    }
    for (i = self->read_fds_len, j = 0; i < wn; i++, j++) {
        workers[i] = nlio_worker_new(self, self->write_fds[j], j,
                                     NLIO_WRITE, write_device, nbuf);
    }
    /* start threads for the writers */
    threads = (pthread_t *) malloc(wn * sizeof(pthread_t));
    for (i = self->read_fds_len; i < wn; i++) {
        if ((result = pthread_create(&threads[i], NULL, nlio_worker_run,
                                     workers[i])) < 0) {
            NLIO_ERROR("nlio.pthread_create.error", "status=i", result);
            perror("error creating write thread");
        }
    }
    /* start thread for the readers */
    for (i = 0; i < self->read_fds_len; i++) {
        if ((result = pthread_create(&threads[i], NULL, nlio_worker_run,
                                     workers[i]) > 0)) {
            NLIO_ERROR("pthread_create.error", "status=i", result);
            perror("error creating read thread");
            goto bottom;
        }
    }

    /* join the readers */
    for (i = 0; i < self->read_fds_len; i++) {
        NLIO_TRACE( "reader.join.start", "t.id=i", i);
        if ((result = pthread_join(threads[i], NULL)) < 0) {
            NLIO_WARN("pthread_join.error", "t.id=i status=i", i, result);
            perror("error with pthread join");
        }
        NLIO_TRACE( "reader.join.end", "t.id=i status=i", i, 0);
    }
    /* set eof-flag */
    nlio_master_set_read_eof(self);
    /* join the writers */
    for (i = self->read_fds_len; i < wn; i++) {
        NLIO_TRACE( "writer.join.start", "t.id=i", i);
        if ((result = pthread_join(threads[i], NULL)) < 0) {
            NLIO_WARN("pthread_join.error", "status=i", result);
        }
        NLIO_TRACE( "writer.join.end", "t.id=i status=i", i, 0);
    }

    /* log end of transfer */
    log_transfer_end(self, result, srv);
    /* clean up */
    NLIO_TRACE( "log.cleanup.start", "");
    if (self->summ) {
        NL_transfer_finalize(self->summ);
    }
    NLIO_TRACE( "log.cleanup.end", "");

    NLIO_TRACE( "cleanup1.start", "");
    nlio_buf_del(nbuf);
    free(threads);
    for (i = 0; i < wn; i++) {
        NLIO_TRACE( "worker.del.start", "worker=i", i);
        nlio_worker_del(workers[i]);
        NLIO_TRACE( "worker.del.end", "worker=i", i);
    }
    NLIO_TRACE( "cleanup1.end", "status=i", 0);

    /* exchange results */
    nlio_master_exchange_results(self, srv);
 
  bottom:
    NLIO_TRACE( "cleanup2.start", "");
    if (workers)
        free(workers);
    NLIO_TRACE( "cleanup2.end", "status=i", 0);
    NLIO_TRACE( "master.run.end", "status=i msg=s",
             result, result_msg);
    return (void *) result;
}

/* 
 * Copy from disk to network, or network to disk.
 *
 * Precondition: all connections are made, files opened, etc.
 */
int
nlio_master_run(T self, nlio_device_t read_device,
                nlio_device_t write_device, int is_server,
                pthread_t * thrp)
{
    int result = 0;
    nlio_master_arg_t *args = malloc(sizeof(nlio_master_arg_t));

    args->read = read_device;
    args->write = write_device;
    args->is_server = is_server;
    args->master = self;

    if (NULL == thrp) {
        result = (int) run_master_thr((void *) args);
    }
    else {
        result = (int) pthread_create(thrp, NULL,
                                      run_master_thr, (void *) args);
    }

    self->free_args = args;

    return result;
}

/*
 * Delete master thread
 * which in turn deletes worker threads
 */
void nlio_master_del(T self)
{
    if (self) {
        /* Free descriptors.
         * Close of descriptors is done by worker. */
        if (self->read_fds)
            free(self->read_fds);
        if (self->write_fds)
            free(self->write_fds);

        if (self->filename)
            free(self->filename);
        if (self->peer_host)
            free(self->peer_host);
        if (self->local_host)
            free(self->local_host);

        /* Close/free log */
        if (self->summ) {
            NLIO_TRACE("summ.del.start", "");
            NL_summ_del(self->summ);
            NLIO_TRACE( "summ.del.end", "");
        }       
        if (self->log) {
            NL_close(self->log);
        }      
        if (self->free_args)
            free(self->free_args);

        if (self->bottleneck)
            free(self->bottleneck);
            
        free(self);
    }
}

#undef T

/* ------------------------------------------------------------------------ */
/* Shared buffer object                                                     */
/* ------------------------------------------------------------------------ */

/* buffer-choosing algorithm */
#define NLIO_BUF_RANDOM 0
#define NLIO_BUF_FIFO 1

#define T nlio_buf_T
struct T {
    char *buf;                  /* shared buffer */
    unsigned n;                 /* number of blocks, rounded up to next power of 2 */
    unsigned char *states;      /* one per block */
#if NLIO_BUF_FIFO
    int64_t *times;              /* one per block */
    int64_t cur_time;            /* counter */
#endif
    pthread_mutex_t *mutex;     /* locks reads/writes to states */
    pthread_cond_t *cond_full, *cond_empty;     /* signal on state-change */
};

T nlio_buf_new(unsigned nblocks)
{
    T self = (T) malloc(sizeof(struct T));
    int i;

    /* oh so cleverly round up to next pow. of 2 */
    self->n = nblocks - 1;
    for (i = 1; i < 32; i <<= 1)
        self->n |= self->n >> i;
    self->n++;

    self->buf = (char *) malloc(self->n * NLIO_BLOCKSZ);
    self->states = (unsigned char *) malloc(self->n * sizeof(char));
#if NLIO_BUF_FIFO
    self->times = (int64_t *)calloc(sizeof(int64_t), self->n);
    self->cur_time = 0;
#endif    
    for (i = 0; i < self->n; i++)
        self->states[i] = NLIO_EMPTY;
    self->mutex = malloc(sizeof(pthread_mutex_t));
    pthread_mutex_init(self->mutex, NULL);
    self->cond_full = malloc(sizeof(pthread_cond_t));
    pthread_cond_init(self->cond_full, NULL);
    self->cond_empty = malloc(sizeof(pthread_cond_t));
    pthread_cond_init(self->cond_empty, NULL);

    return self;
}

inline void nlio_buf_lock(T self)
{
    pthread_mutex_lock(self->mutex);
}

inline void nlio_buf_unlock(T self)
{
    pthread_mutex_unlock(self->mutex);
}

char *nlio_buf_claim(T self, nlio_state_t cur_state)
{
    int i, j, mask = self->n - 1;
#if NLIO_BUF_FIFO
    int first_idx;
    int64_t first_time;
#endif
    char *p = NULL;

    nlio_buf_lock(self);
    /* check to see if we can claim a buffer */
#if NLIO_BUF_RANDOM
    j = random() & mask;               /* start looking at random spot */
    for (i = 0; i < self->n; i++) {
        if (self->states[j] == cur_state) {
            p = self->buf + NLIO_BLOCKSZ * j;
            self->states[j] = NLIO_WORKING;
            break;
        }
        j = (j + 1) & mask;
    }
#endif
#if NLIO_BUF_FIFO
    j = 0;
    first_idx = -1;
    first_time = 0.;
    for (i = 0; i < self->n; i++) {
        if (self->states[j] == cur_state) {
            if (first_idx < 0 || self->times[j] < first_time) {
                first_idx = j;
                first_time = self->times[j];
            }
        }
        j = (j + 1) & mask;
    }
    if (first_idx >= 0) {
        p = self->buf + NLIO_BLOCKSZ * first_idx;
        self->states[first_idx] = NLIO_WORKING;        
    }
#endif
    nlio_buf_unlock(self);

    return p;
}

void nlio_buf_release(T self, char *offs, nlio_state_t new_state)
{
    nlio_buf_lock(self);
    if (offs >= self->buf && offs < self->buf + self->n * NLIO_BLOCKSZ) {
        int idx = (offs - self->buf) / NLIO_BLOCKSZ;
        self->states[idx] = new_state;
#if NLIO_BUF_FIFO
        /* set unique time for this buffer state */
        self->times[idx] = ++self->cur_time;         
#endif
    }
    switch (new_state) {
    case NLIO_EMPTY:
        pthread_cond_signal(self->cond_empty);
        break;
    case NLIO_FULL:
        pthread_cond_signal(self->cond_full);
        break;
    case NLIO_WORKING:                /* ignore */
        break;
    }
    nlio_buf_unlock(self);
}

/* debugging only */
void nlio_buf_dump(T self, char *buf)
{
    int i;

    for (i = 0; i < self->n; i++) {
        if (self->states[i] == NLIO_EMPTY)
            buf[i] = '_';
        else if (self->states[i] == NLIO_FULL)
            buf[i] = 'F';
        else
            buf[i] = 'W';
    }
    buf[self->n] = '\0';
}

void nlio_buf_del(T self)
{
    if (self) {
        free(self->buf);
        free(self->states);
        pthread_mutex_destroy(self->mutex);
        pthread_cond_destroy(self->cond_full);
        pthread_cond_destroy(self->cond_empty);
        free(self);
    }
}

#undef T

/* ------------------------------------------------------------------------ */
/* Worker thread object                                                     */
/* ------------------------------------------------------------------------ */

#define T nlio_worker_T
struct T {
    int fd, stream_id;
    nlio_op_t op;
    nlio_device_t device;
    nlio_buf_T buf;
    struct timespec sleep_time;
    nlio_master_T master;       /* pointer to parent */
};

/*
 * Create new worker
 */
T
nlio_worker_new(nlio_master_T master, int fd, int strm, nlio_op_t op,
                nlio_device_t device, nlio_buf_T buf)
{
    T self;

    if (master == NULL)
        return NULL;

    self = malloc(sizeof(struct T));
    self->master = master;
    self->fd = fd;
    self->stream_id = strm + 1;
    self->op = op;
    self->device = device;
    self->buf = buf;

    return self;
}

/*
 * Main function for worker thread
 */
void *nlio_worker_run(void *arg)
{
    T self = (T) arg;
    unsigned has_max_bytes, is_writer;
    int nbytes, hdr_len;
    uint32_t block_id = 0;
    char *p = NULL;
    /*const char *guid;*/
    nlio_state_t before, after;
    nlio_iofn_t io_func;
    NL_log_T log;
    NL_transfer_op_t x_op;
    int64_t max_bytes = 0LL;
    pthread_mutex_t *mtx = self->buf->mutex;
    pthread_cond_t *cnd;
    unsigned int op_usleep;

    log = self->master->log;
    /*guid = self->master->transfer_guid;*/
    has_max_bytes = self->master->max_bytes > 0;
    if (has_max_bytes) {
        max_bytes = self->master->max_bytes;
    }
    /* choose I/O operation, target buffer state */
    if (self->op == NLIO_READ) {
        is_writer = 0;
        io_func = readn;
        before = NLIO_EMPTY;
        after = NLIO_FULL;
        x_op = (self->device == NLIO_DISK) ? NL_TRANSFER_DISK_READ :
            NL_TRANSFER_NET_READ;
        cnd = self->buf->cond_empty;
    }
    else {
        is_writer = 1;
        io_func = writen;
        before = NLIO_FULL;
        after = NLIO_EMPTY;
        x_op = (self->device == NLIO_DISK) ? NL_TRANSFER_DISK_WRITE :
            NL_TRANSFER_NET_WRITE;
        cnd = self->buf->cond_full;
    }
    /* set usleep depending on operation */
    op_usleep = self->master->op_usleep[x_op];
    /* read 4 less bytes for net.read to compensate for header */
    hdr_len = (x_op == NL_TRANSFER_NET_READ) ? 4 : 0;
    /* read or write until EOF/error */
    for (;;) {
        /* wait for data to be available */
        for (;;) {
            struct timeval tv0;
            double t1;
            struct timespec cnd_tmout;

            if (has_max_bytes &&
                nlio_master_get_bytes(self->master) > max_bytes) {
                nlio_buf_release(self->buf, p, before);
                goto bottom;
            }
            p = nlio_buf_claim(self->buf, before);
            if (p)
                break;
            if (is_writer && nlio_master_get_read_eof(self->master)) {
                goto bottom;
            }
            gettimeofday(&tv0, NULL);
            t1 = tv0.tv_sec + tv0.tv_usec / 1e6 + 0.2;
            cnd_tmout.tv_sec = (time_t) t1;
            cnd_tmout.tv_nsec = (t1 - (double) cnd_tmout.tv_sec) * 1e9;
            pthread_mutex_lock(mtx);
            pthread_cond_timedwait(cnd, mtx, &cnd_tmout);
            pthread_mutex_unlock(mtx);
        }
        /* read/write data */
        if (log) {
            /* assign block id */
            if (x_op == NL_TRANSFER_DISK_READ) {
                block_id = nlio_master_get_next_block(self->master);
            }
            /* get block id from first 4 bytes of 'message' */
            else {
                /* for network.read, read header first */
                if (x_op == NL_TRANSFER_NET_READ) {
                    nbytes = readn(self->fd, p, hdr_len);
                    if (nbytes != hdr_len) {
                        if (nbytes < 0) {
                            char buf[1024];
                            strerror_r(nbytes, buf, sizeof(buf));
                            NLIO_ERROR("nlio.io.error",
                                      "status=i msg=s", nbytes, buf);
                            nlio_buf_release(self->buf, p, before);
                        }
                        nlio_buf_release(self->buf, p, before);
                        break;
                    }
                 }
                /* copy into block_id with correct endianness */
                block_id = ntohl(*((uint32_t *) p));
            }
            /* log start of transfer */
            NL_transfer_start(log, NL_LVL_DEBUG, x_op,
                              g_xguid, self->stream_id,
                              (unsigned long long) block_id);
            /* perform I/O */
            nbytes = io_func(self->fd, p + hdr_len,
                             NLIO_BLOCKSZ - hdr_len);
            /* optionally, sleep for a bit to simulate a lower
               throughput
             */
            if (op_usleep > 0)
                usleep(op_usleep);
            /* log end of transfer */
            NL_transfer_end(log, NL_LVL_DEBUG, x_op,
                            g_xguid, self->stream_id,
                            (unsigned long long) block_id,
                            (double) nbytes);
            /* put block id into the "message" */
            if (x_op == NL_TRANSFER_DISK_READ && nbytes > 0) {
                *((uint32_t *) p) = htonl(block_id);
            }
        }
        else {
            nbytes = io_func(self->fd, p, NLIO_BLOCKSZ);
        }
        /* deal with result */
        if (nbytes < 0) {
            char buf[1024];
            strerror_r(nbytes, buf, sizeof(buf));
            NLIO_ERROR("nlio.io.error", "status=i msg=s", nbytes, buf);
            nlio_buf_release(self->buf, p, before);
            break;
        }
        else if (nbytes == 0) {
            break;
        }
        else if (nbytes < NLIO_BLOCKSZ - hdr_len) {
            nlio_buf_release(self->buf, p, after);
            if (is_writer)
                nlio_master_add_bytes(self->master, nbytes);
            break;
        }
        else {
            nlio_buf_release(self->buf, p, after);
            if (is_writer)
                nlio_master_add_bytes(self->master, nbytes);
        }
    }

  bottom:
    return self;
}

void nlio_worker_del(T self)
{
    if (self) {
        if (self->fd >= 0)
            close(self->fd);
        free(self);
    }
}

#undef T

/* ------------------------------------------------------------------------ */
/* I/O helper functions                                                     */
/* ------------------------------------------------------------------------ */

/*
 * Read 'nbytes' from descriptor fd, copying into space
 * pointed to by 'ptr'.
 * Return the number of bytes read until EOF or 'nbytes', whichever
 * comes first; or the (negative) error code on a read error.
 */
int readn(int fd, char *ptr, int nbytes)
{
    int nleft, nread;

    nleft = nbytes;
    while (nleft > 0) {
        nread = read(fd, ptr, nleft);
        if (nread < 0) {
            NLIO_ERROR("readn.error", "status=i", nread);
            perror("network read error");
            return nread;              /* error, return < 0 */
        }
        else if (nread == 0)
            break;                     /* EOF */
        nleft -= nread;
        ptr += nread;
    }
    return (nbytes - nleft);           /* return >= 0 */
}

/*
 * Write 'nbytes' to descriptor fd, copying from space
 * pointed to by 'ptr'.
 * Return 'nbytes', or the (negative) error code on a write error.
 */
int writen(int fd, char *ptr, int nbytes)
{
    int nleft, nwritten;

    nleft = nbytes;
    while (nleft > 0) {
        nwritten = write(fd, ptr, nleft);
        if (nwritten <= 0) {
            NLIO_ERROR("writen.error", "status=i", nwritten);
            perror("network write error");
            return (nwritten);         /* error */
        }
        nleft -= nwritten;
        ptr += nwritten;
    }
    return (nbytes - nleft);
}

/*
 * Helper functions for logging in {get,set}sockbuf()
 */
static inline char **create_sockbuf_events(unsigned char send, char gs)
{
    char **e;
    int i;
    const char *send_str = send ? "SND" : "RCV";

    e = (char **) malloc(3 * sizeof(char *));
    /* create start/end/err events */
    for (i = 0; i < 3; i++) {
        e[i] = (char *) malloc(64);
        sprintf(e[i], "%cet.SO_%sBUF.", gs, send_str);
    }
    strcat(e[0], "start");
    strcat(e[1], "end");
    strcat(e[2], "error");

    return e;
}

static inline void free_sockbuf_events(char **e)
{
    int i;

    for (i = 0; i < 3; i++)
        free(e[i]);
    free(e);
}

/*
 * Set send/receive socket buffer.
 */
size_t setsockbuf(int skt, size_t size, unsigned char send)
{
    size_t result;
    socklen_t ssize;
    int flag;
    char **e;

    e = create_sockbuf_events(send, 's');
    flag = send ? SO_SNDBUF : SO_RCVBUF;
    ssize = size;
    /* log start */
    NLIO_TRACE( e[0], "fd=i size=l", skt,
             (long long) ssize);
    /* perform the call */
    result =
        setsockopt(skt, SOL_SOCKET, flag, (char *) &ssize, sizeof(ssize));
    /* log end */
    if (0 == result)
        NLIO_TRACE( e[1], "fd=i size=l status=i",
                 skt, (long long) ssize, 0);
    else
        NLIO_WARN(e[2], "fd=i size=l status=i",skt,(long long) ssize, result);

    free_sockbuf_events(e);

    return result;
}

/*
 * Get send/receive socket buffer.
 */
socklen_t getsockbuf(int skt, socklen_t expected, unsigned char send)
{
    size_t result;
    int bufsize=0;
    socklen_t len = sizeof(bufsize);
    int flag;
    char **e;

    flag = send ? SO_SNDBUF : SO_RCVBUF;
    e = create_sockbuf_events(send, 'g');
    /* log start */
    NLIO_TRACE( e[0], "sockfd=i expected=i", skt, expected);
    /* perform call */
    result = getsockopt(skt, SOL_SOCKET, flag, (char *) &bufsize, &len);
    /* log end */
    if (0 == result)
        NLIO_TRACE( e[1], "fd=i size=l status=i", skt, (long long) bufsize, 0);
    else
        NLIO_WARN(e[2], "fd=i size=l status=i", skt, (long long) bufsize,
                  result);

    free_sockbuf_events(e);

    return bufsize;
}
