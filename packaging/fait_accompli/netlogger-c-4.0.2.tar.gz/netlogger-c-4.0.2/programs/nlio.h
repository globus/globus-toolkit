/* 
   Copyright (c) 2007, The Regents of the University of California, through 
   Lawrence Berkeley National Laboratory (subject to receipt of any required 
   approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#ifndef NLIO_H_INCLUDED
#    define NLIO_H_INCLUDED

/*
 * NL threaded IO, for testing logging 
 *
 */

#    ifdef __cplusplus
extern "C" {
#    endif
#    include <pthread.h>
#    include <sys/socket.h>
#    include <sys/types.h>
#    include "nltransfer.h"

/* Global log */
extern NL_log_T g_log;
extern char * g_guid;
extern char * g_xguid; /* transfer GUID */
typedef enum { NLIO_GUID, NLIO_XGUID, NLIO_BOTHGUID, NLIO_NOGUID } guid_mode_t;
extern guid_mode_t  g_guid_mode;

/*
 * Logging macros
 */
 

#define NLIO_BASE(L, E, F, args...) do {\
    switch(g_guid_mode) {\
        case NLIO_GUID:\
            NL_write(g_log, (L), (E), "prog.guid=s " F, g_guid, ##args);\
            break;\
        case NLIO_XGUID:\
            NL_write(g_log, (L), (E), "guid=s " F, g_xguid, ##args);\
            break;\
        case NLIO_BOTHGUID:\
            NL_write(g_log, (L), (E), "prog.guid=s guid=s " F,\
                     g_guid, g_xguid, ##args);\
            break;\
        case NLIO_NOGUID:\
            NL_write(g_log, (L), (E), "" F, ##args);\
            break;\
    }\
} while(0)

#define NLIO_ERROR(E, F, args...) NLIO_BASE(NL_LVL_ERROR, E, F, ##args)
#define NLIO_WARN(E, F, args...) NLIO_BASE(NL_LVL_WARN, E, F, ##args)
#define NLIO_INFO(E, F, args...) NLIO_BASE(NL_LVL_INFO, E, F, ##args)
#define NLIO_DBG(E, F, args...) NLIO_BASE(NL_LVL_DEBUG, E, F, ##args)
#define NLIO_TRACE(E, F, args...) NLIO_BASE(NL_LVL_DEBUG1, E, F, ##args)

/** state of block */
    typedef enum { NLIO_EMPTY = 0, NLIO_FULL = 1, NLIO_WORKING = 2
    } nlio_state_t;

/** I/O operation */
    typedef enum { NLIO_READ, NLIO_WRITE } nlio_op_t;

/** device used in I/O operation */
    typedef enum { NLIO_DISK, NLIO_NETWORK } nlio_device_t;

#    define NLIO_BLOCKSZ 262144         /**< transfer block size */
#    define NLIO_DEFAULT_PORT 55566     /**< default server port */

/** type of statistics to return */
    typedef enum { NLIO_STATS_ALL, } nlio_stats_type_t;

/** logging modes */
    typedef enum { 
        NLIO_LOG_NONE=0, /**< no logging at all */
        NLIO_LOG_FULL=1, /**< full debug logging */
        NLIO_LOG_INT=2, /**< interval logging */
        NLIO_LOG_PROG=4 /**< whole-program logging */
    } nlio_logmode_t ;
                        
/* Forward declarations so datatypes
 * can be defined in any order.
 */
    struct nlio_master_T;
    typedef struct nlio_master_T *nlio_master_T;

    struct nlio_worker_T;
    typedef struct nlio_worker_T *nlio_worker_T;

    struct nlio_buf_T;
    typedef struct nlio_buf_T *nlio_buf_T;

/**
 * Util
 */
extern int nlio_get_host_addr(const char *host, unsigned *addr);
extern char *nlio_get_peer_name(int sock);

/**
 * Thread master
 */
#    define T nlio_master_T

    extern T nlio_master_new(void);

    extern int nlio_master_accept(T self);
    
    extern NL_transfer_btl_t *nlio_master_get_btl(T self);

    extern int nlio_master_connect(T self);
    
    extern const char *nlio_master_get_guid(T self);

    extern void nlio_master_set_guid(T self, const char *guid);

    extern const char *nlio_master_get_transfer_guid(T self);

    extern void nlio_master_set_transfer_guid(T self, const char *guid);

    extern int nlio_master_get_read_eof(T self);

    extern int nlio_master_get_read_fd(T self, int i);

    extern NL_summ_T nlio_master_get_summ(T self);

    extern int nlio_master_get_write_fd(T self, int i);

    extern int nlio_master_init_log(T self, NL_log_T log,
                                    int log_modes, float summ_interval);

    extern void nlio_master_init_read_fds(T self, int n);

    extern void nlio_master_init_write_fds(T self, int n);

    extern int nlio_master_open_file(T self, nlio_op_t op);

    extern int nlio_master_run(T self, nlio_device_t read_device,
                               nlio_device_t write_device, int server,
                               pthread_t * thr);

    extern void nlio_master_set_file(T self, const char *filename);
    
    extern int nlio_master_set_host(T self, const char *host, short port,
                                     int is_remote);

    extern void nlio_master_set_sender(T self, int flag);

/**
 * Set max #bytes to process
 */
    extern void nlio_master_set_max_bytes(T self, int64_t n);

/**
 * Get total number of bytes so far
 */
    extern int64_t nlio_master_get_bytes(T self);

/**
 * Add to total #bytes so far
 */
    extern void nlio_master_add_bytes(T self, int64_t n);

    extern void nlio_master_set_read_eof(T self);

    extern void nlio_master_set_read_fd(T self, int i, int fd);

/**
 * Set TCP send/receive buffer size
 *
 * @param self Obj
 * @param bytes New size
 */
    extern void nlio_master_set_tcpbuf(T self, size_t bytes);

    extern void nlio_master_set_write_fd(T self, int i, int fd);

/**
 * Set microsecond sleep time on each iteration
 *
 * @param self Master object
 * @param op Transfer operation
 * @param us Microseconds to sleep on each iteration
 * @return 0 on success, -1 on failure (bad op)
 */
    int nlio_master_set_usleep(T self, NL_transfer_op_t op,
                               unsigned int us);

    extern void nlio_master_del(T self);

#    undef T

/**
 * Thread worker
 */
#    define T nlio_worker_T

    extern T nlio_worker_new(nlio_master_T master, int fd, int strm,
                             nlio_op_t op, nlio_device_t device,
                             nlio_buf_T buf);

    extern void *nlio_worker_run(void *arg);

    extern void nlio_worker_del(T self);

#    undef T

/* ------------------------------------------------------------------------ */
/* Thread-safe shared buffer                                                */
/* ------------------------------------------------------------------------ */
/* 
 * Function to tell buffer when to give up on a blocking
 * wait for a slot 
 */
    typedef int (*nlio_buf_giveup_fn) (void *data);


#    define T nlio_buf_T

    extern T nlio_buf_new(unsigned nblocks);

    extern char *nlio_buf_claim(T self, nlio_state_t cur_state);

    extern void nlio_buf_dump(T self, char *buf);

    extern void nlio_buf_release(T self, char *offs,
                                 nlio_state_t new_state);

    extern void nlio_buf_del(T self);

#    undef T


/**
 * Declaration of IO helper functions
 */
 /** Shared prototype for readn() and writen() */
    typedef int (*nlio_iofn_t) (int, char *, int);

/**
 * Read N bytes from a descriptor.
 *
 * @param fd Open file descriptor.
 * @param ptr Pointer to memory buffer with at least nbytes of space
 * @param nbytes Number of bytes to read
 * @return -1=error, 0=eof, else nbytes for success
 */
    extern int readn(int fd, char *ptr, int nbytes);

/**
 * Write N bytes to a descriptor.
 *
 * @param fd Open file descriptor.
 * @param ptr Pointer to memory buffer with at least nbytes of data
 * @param nbytes Number of bytes to write
 * @return -1=error, else nbytes for success
 */
    extern int writen(int fd, char *ptr, int nbytes);

/**
 * Get send/receive buffer on a socket
 *
 * @param skt Socket descriptor
 * @param size Size of expected window, in bytes
 * @param send If 1, get send buffer else set receive buffer
 * @return Size of buffer
 */
    extern socklen_t getsockbuf(int skt, socklen_t size,
                                unsigned char send);

/**
 * Set send/receive buffer on a socket
 *
 * @param skt Socket descriptor
 * @param size Size of desired window, in bytes
 * @param send If 1, set send buffer else set receive buffer
 * @return -1=error, else new size
 */
    size_t setsockbuf(int skt, size_t size, unsigned char send);

#    ifdef __cplusplus
}
#    endif
#endif                          /* _INCLUDED */
