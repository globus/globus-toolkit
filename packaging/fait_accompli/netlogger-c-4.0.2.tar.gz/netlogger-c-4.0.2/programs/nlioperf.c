/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

/*
 * NetLogger I/O performance client and server command-line program.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>		
#include "nlio.h"
#include "nltransfer.h"

/*
 * Data structures and global variables
 * ------------------------------------
 */

#define MbS(x) ((x)/131072.)
#define MB(x) ((x)/1048576.)

#ifndef MAX
#    define MAX(x,y) ((x) >= (y) ? (x) : (y))
#endif
#ifndef MIN
#    define MIN(x,y) ((x) <= (y) ? (x) : (y))
#endif

 /* Program run mode */
typedef enum { CLIENT_MODE, SERVER_MODE } nlioperf_mode_t;

/* Reporting output format */
typedef enum {
    FULL_TEXT_REPORT,
    BRIEF_TEXT_REPORT,
    CSV_REPORT,
    NO_REPORT,
} nlioperf_rptfmt_t;

#define MAX_REPORTS 16
/*
 * End-of-run reports
 */

 /* Initialize state for reporting */
typedef void *(*nlioperf_rpt_new_fn) (void);
 /* Report a result of an operation+stream (out of nstreams) */
typedef void (*nlioperf_rpt_result_fn) (void *obj, FILE * output,
                                        NL_transfer_op_t operation,
                                        unsigned nstreams,
                                        unsigned stream_num,
                                        NL_transfer_result_t * resultp);
 /* CSV report state */
typedef struct {
    unsigned char wrote_hdr;
    int nstreams[4];
} nlioperf_rpt_csv_t;

/* Text report state */
typedef struct {
    unsigned char wrote_hdr;
    int nstreams[4];
} nlioperf_rpt_txt_t;

/* Reporting part of parsed args, below */
typedef struct {
    nlioperf_rptfmt_t fmt;      /* canonical format */
    FILE *ofile;                /* output stream for report */
    nlioperf_rpt_new_fn initfn; /* function to init. report state */
    nlioperf_rpt_result_fn resultfn;    /* function to report a result */
} nlioperf_rptarg_t;

/* Parsed argument values */
typedef struct {
    char *why;                  /* why parsing args failed, if it did */
    nlioperf_mode_t mode;
    unsigned char quiet, verbose;
    long long nbytes;
    int nstreams;
    size_t sockbuf;             /* TCP rcv/send buf size */
    char *filename;
    unsigned short port;
    char *host;
    int reverse;
    nlioperf_rptarg_t rpt[MAX_REPORTS];
    unsigned int rpt_n;         /* number of reports to produce */
    unsigned int disk_usleep;   /* How long to sleep on disk */
    /* logging */
    double log_interval;
    const char *log_file;
    int log_modes;
} nlioperf_args_t;

/* operations, ordered by sender/receiver, then read/write */
NL_transfer_op_t g_ops[2][2] = {
    {NL_TRANSFER_NET_READ, NL_TRANSFER_DISK_WRITE},
    {NL_TRANSFER_DISK_READ, NL_TRANSFER_NET_WRITE},
};

/* text-report names of operations */
const char *const g_text_op_names[] = {
    "read from disk",
    "write to disk",
    "read from network",
    "write to network",
};

/* csv-report names of operations */
const char *const g_csv_op_names[] = {
    "diskRead",
    "diskWrite",
    "networkRead",
    "networkWrite",
};

/*
 * Function declarations
 * ----------------------
 */
static void usage(const char *why);
static int parse_args(int argc, char *const argv[],
                      nlioperf_args_t * args);
static int parse_rptarg(char *arg, nlioperf_rptarg_t * ra, char **errmsg);
static void open_sender(nlio_master_T m, nlioperf_args_t * args);
static void open_receiver(nlio_master_T m, nlioperf_args_t * args);
static void report_results(nlio_master_T m, nlioperf_args_t * args);
/* reporting functions */
static void *nlioperf_rpt_csv(void);
static void nlioperf_rpt_csv_result(void *obj, FILE * output,
                                    NL_transfer_op_t operation,
                                    unsigned nstreams, unsigned stream_num,
                                    NL_transfer_result_t * resultp);
static void *nlioperf_rpt_txtfull(void);
static void nlioperf_rpt_txtfull_result(void *obj, FILE * output,
                                        NL_transfer_op_t operation,
                                        unsigned nstreams,
                                        unsigned stream_num,
                                        NL_transfer_result_t * resultp);
static void *nlioperf_rpt_txtbrief(void);
static void nlioperf_rpt_txtbrief_result(void *obj, FILE * output,
                                         NL_transfer_op_t operation,
                                         unsigned nstreams,
                                         unsigned stream_num,
                                         NL_transfer_result_t * resultp);
static void *nlioperf_rpt_nop(void);
static void nlioperf_rpt_nop_result(void *obj, FILE * output,
                                    NL_transfer_op_t operation,
                                    unsigned nstreams, unsigned stream_num,
                                    NL_transfer_result_t * resultp);

#define NONESTR(s) ((s)?(s):"None")

/*
 * Program entry point
 */
int main(int argc, char *const argv[])
{
    nlioperf_args_t args;
    nlio_master_T master;
    int r = -1, is_sender, is_server;
    NL_level_t prog_level;
    struct timeval start_t, end_t;
    int total_usecs, fsize;
    float total_secs, tput;
    
    /* parse arguments */
    if (-1 == parse_args(argc, argv, &args))
        usage(args.why);

    NL_env_override = 0;  /* dont have NL_DEST override command line arg */
    g_log = NL_open(args.log_file);
    if(!NL_is_active(g_log)) {
        if (!args.quiet) {
            fprintf(stderr,"Log open of '%s' failed\n", args.log_file);
        }
        goto error;
    }
    if (args.verbose)
        prog_level = NL_LVL_DEBUG1;
    else if (args.quiet || args.log_modes == NLIO_LOG_NONE)
        prog_level = NL_LVL_ERROR;
    else
        prog_level = NL_LVL_DEBUG;
    NL_set_level(g_log, prog_level);
    /* grab a GUID */
    if (!NL_get_guid(&g_guid) && !NL_get_someid(&g_guid))
        g_guid = strdup("00000000-0000-0000-0000-000000000000");
    g_guid_mode = NLIO_GUID;

    /* write program start event */
    {
        int i, argslen;
        char *strargs;
        
        for (i=0, argslen=0; i < argc; i++)
            argslen += strlen(argv[i]);
        argslen += argc + 1;
        strargs = calloc(1, argslen);
        for (i=0; i < argc; i++) {
            strcat(strargs, argv[i]);
            if (i != argc-1)
                strcat(strargs, " ");
        }
        NLIO_INFO( "nlioperf.start", "args=s", strargs);
        free(strargs);
    }
    
    master = nlio_master_new();
    if (0 != nlio_master_init_log(master, g_log, args.log_modes,
                                  args.log_interval)) {
        NL_set_level(g_log, NL_LVL_ERROR);
        NL_write(g_log, NL_LVL_ERROR, "nlioperf.nlio_master_init_log.error",
                 "status=i", -1);
        goto error;
    }
    /* tell master desired send/recv bufsize */
    nlio_master_set_tcpbuf(master, (size_t)args.sockbuf);
    /* init for sender/receiver x client/server  */
    if (args.mode == SERVER_MODE) {
        if (-1 == nlio_master_set_host(master, args.host, args.port, 0))
            goto error;
        is_server = 1;
        is_sender = args.reverse;
    }
    else {
        if (-1 ==nlio_master_set_host(master, args.host, args.port, 1))
            goto error;
        is_server = 0;
        is_sender = !args.reverse;
    }
    if (args.nbytes > 0) {
        nlio_master_set_max_bytes(master, args.nbytes);
    }
    /* run */
    if (is_sender) {
        gettimeofday(&start_t, 0);

        open_sender(master, &args);
        r = nlio_master_run(master, NLIO_DISK, NLIO_NETWORK, is_server,
                            NULL);

	/* for the sender, compute the average throughput */
        gettimeofday(&end_t, 0);
        total_usecs = (end_t.tv_sec-start_t.tv_sec) * 1000000 +
                     (end_t.tv_usec-start_t.tv_usec);
        total_secs = total_usecs / 1000000.0;
        /* get number of bytes sent: nlio_master_run does not return 
        this value (maybe it should?), so use -b option value or filesize */
        if (args.nbytes > 0) {
           fsize = args.nbytes;
        }
        else {
           struct stat stat_p;	
           if (stat (args.filename, &stat_p) < 0)
	        printf(" Error attempting to stat %s\n", args.filename);
           fsize = stat_p.st_size;
        }
        tput = (float) fsize / total_secs / 1000000. ;
        if (!args.quiet) 
            fprintf(stderr, "Mean throughput for test  = %.1f Mbps (%.1f MBps) \n", 
	    		tput * 8, tput);
    }
    else {       
        open_receiver(master, &args);
        r = nlio_master_run(master, NLIO_NETWORK, NLIO_DISK, is_server,
                            NULL);
    } 
    if (r)
        goto error;

    if (!args.quiet) {
        report_results(master, &args);
    }
    NLIO_INFO( "nlioperf.end", "status=i", 0);
    NL_close(g_log);
    return 0;

  error:
    NL_write(g_log, NL_LVL_ERROR, "nlioperf.error", "status=i", -1);
    NL_close(g_log);
    return -1;
}

/*
 * Open file and network connections for the data sender.
 */
void open_sender(nlio_master_T m, nlioperf_args_t * args)
{
    int r;

    nlio_master_set_file(m, args->filename);
    nlio_master_init_read_fds(m, 1);
    r = nlio_master_open_file(m, NLIO_READ);
    if (0 != r) {
        usage("cannot open input file");
    }
    nlio_master_init_write_fds(m, args->nstreams);
    nlio_master_set_sender(m, 1);
    if (args->disk_usleep > 0)
        nlio_master_set_usleep(m, NL_TRANSFER_DISK_READ,
                               args->disk_usleep);
}

/*
 * Open file and network connections for the data receiver.
 */
void open_receiver(nlio_master_T m, nlioperf_args_t * args)
{
    int r;

    nlio_master_set_file(m, args->filename);
    nlio_master_init_write_fds(m, 1);
    r = nlio_master_open_file(m, NLIO_WRITE);
    if (0 != r) {
        usage("cannot open output file");
    }
    nlio_master_init_read_fds(m, args->nstreams);
    nlio_master_set_sender(m, 0);
    if (args->disk_usleep > 0)
        nlio_master_set_usleep(m, NL_TRANSFER_DISK_WRITE,
                               args->disk_usleep);
}

/* Return state to pass around with report functions */
void *nlioperf_rpt_txtbrief(void)
{
    return NULL;
}

/* Report, in text format, the fullresults for a stream+operation */
void
nlioperf_rpt_txtbrief_result(void *state, FILE * fp,
                             NL_transfer_op_t op, unsigned nstrm,
                             unsigned strm, NL_transfer_result_t * x)
{
    if (strm == 0) {
        fprintf(fp, "Mean throughput for %-17s = %lf Mb/s\n",
                g_text_op_names[op], MbS(x->value_sum / x->duration));
    }
}

/* Return state to pass around with report functions */
void *nlioperf_rpt_txtfull(void)
{
    return NULL;
}

/* Report, in text format, the fullresults for a stream+operation */
void
nlioperf_rpt_txtfull_result(void *state, FILE * fp,
                            NL_transfer_op_t op, unsigned nstrm,
                            unsigned strm, NL_transfer_result_t * resultp)
{
    char snum[4];
    double sd[2];
    char hdrc = ':';
    if (strm == 0 && nstrm == 1)
        return;
    if (strm == 1) {
        fprintf(fp, "%c %s streams=%d\n", hdrc, g_text_op_names[op],
                nstrm);
    }
    if (strm == 0) {
        strcpy(snum, "totals");
    }
    else {
        sprintf(snum, "%-3d", strm);
    }
    fprintf(fp, "%c  stream %s\n", hdrc, snum);
    /* -- ratios -- */
    /* don't report negative stdev */
    sd[0] = resultp->ratio_mean - 2 * resultp->ratio_sd;
    sd[1] = resultp->ratio_mean + 2 * resultp->ratio_sd;
    sd[0] = MAX(sd[0], 0);
    fprintf(fp, "%c    %-5lld ratios: %lf .. %lf ((%lf))  %lf .. %lf\n",
            hdrc,
            (long long) resultp->value_count,
            MbS(resultp->ratio_min),
            MbS(sd[0]),
            MbS(resultp->ratio_mean), MbS(sd[1]), MbS(resultp->ratio_max));
    /* -- times -- */
    /* don't report +/- stdev below or above min/max */
    sd[0] = resultp->time_mean - 2 * resultp->time_sd;
    sd[1] = resultp->time_mean + 2 * resultp->time_sd;
    sd[0] = MAX(sd[0], 0);
    fprintf(fp, "%c    %-5lld times : %lf .. %lf ((%lf))  %lf .. %lf\n",
            hdrc,
            (long long) resultp->count,
            resultp->time_min,
            sd[0], resultp->time_mean, sd[1], resultp->time_max);
/*                
    fprintf(fp, "%c    %-5lld values: %lf .. %lf ((%lf))  %lf .. %lf\n", 
                hdrc,
                resultp->value_count,
                resultp->value_min, 
                resultp->value_mean - 2*resultp->value_sd,
                resultp->value_mean, 
                resultp->value_mean + 2*resultp->value_sd,
                resultp->value_max);
                */
}

/* Get new state for CSV reporting */
void *nlioperf_rpt_csv()
{
    nlioperf_rpt_csv_t *state;

    state = malloc(sizeof(nlioperf_rpt_csv_t));
    state->wrote_hdr = 0;

    return state;
}

/* Report, in CSV format, the results for a stream+operation */
void
nlioperf_rpt_csv_result(void *state, FILE * fp,
                        NL_transfer_op_t op,
                        unsigned nstrm, unsigned strm,
                        NL_transfer_result_t * resultp)
{
    nlioperf_rpt_csv_t *self = (nlioperf_rpt_csv_t *) state;

    if (!self->wrote_hdr) {
        fprintf(fp, "nstreams,stream,min,max,mean,sd\n");
        self->wrote_hdr = 1;
    }
    fprintf(fp, "%d,%d,%lf,%lf,%lf,%lf\n", nstrm, strm,
            MbS(resultp->ratio_min), MbS(resultp->ratio_max),
            MbS(resultp->ratio_mean), MbS(resultp->ratio_sd));
}

/* Null-obj report state fn */
void *nlioperf_rpt_nop(void)
{
    return NULL;
}

/* Null-obj report fn */
void
nlioperf_rpt_nop_result(void *state, FILE * fp,
                        NL_transfer_op_t op,
                        unsigned nstrm, unsigned strm,
                        NL_transfer_result_t * resultp)
{
    return;
}

/*
 * Report results of run
 */
void report_results(nlio_master_T m, nlioperf_args_t * args)
{
    NL_transfer_btl_t *btlp;
    
    if (args->quiet)
        return;
        
    /* print out stats / bottleneck to stderr */
    btlp = nlio_master_get_btl(m);
    if (btlp) {
        char *s;
        NL_transfer_op_t op;
        
        for (op=0; op < NL_TRANSFER_NOEVENT; op++) {
            double mbs = (btlp->inst_thru[op] / 1e6) * 8;
            fprintf(stderr, "Avg instantaneous tput for %-10s = %9.1lf Mb/s\n",
                    NL_transfer_op_name(op), mbs);
            NL_write(g_log, NL_LVL_INFO, "nlio.tput", "op=s mbs=d",
                     NL_transfer_op_name(op), mbs);
            s = NL_transfer_bottleneck_str(nlio_master_get_btl(m));
        }
        if (s) {
            fprintf(stderr, "Bottleneck: %s\n", s);
            NL_write(g_log, NL_LVL_INFO, "nlio.bottleneck", "loc=s", s);
            free(s);
        }
    }
    /* backup method if result exchange failed */
    else {
        NL_summ_T summ;
        int rpti, i, j, nstreams, is_sender, is_server;
        void *state;
        NL_transfer_result_t result;
    
        summ = nlio_master_get_summ(m);
        if (NULL == summ)
            goto bottom;
        is_server = args->mode == SERVER_MODE;
        is_sender = !(is_server ^ args->reverse);
        for (rpti = 0; rpti < args->rpt_n; rpti++) {
            nlioperf_rptarg_t *rpt = &args->rpt[rpti];
            state = rpt->initfn();
            for (i = 0; i < 2; i++) {
                NL_transfer_op_t op = g_ops[is_sender][i];
                nstreams = NL_transfer_get_num_streams(summ, op, NULL);
                for (j = 1; j <= nstreams; j++) {
                    if (1 <=
                        NL_transfer_get_result(summ, op, NULL, -1, j,
                                               &result)) {
                        rpt->resultfn(state, rpt->ofile, op, nstreams, j,
                                      &result);
                    }
                }
                /* ALL streams */
                NL_transfer_get_result(summ, op, NULL, -1, 0, &result);
                rpt->resultfn(state, rpt->ofile, op, nstreams, 0, &result);
            }
        }
    }
    
  bottom:
    return;
}

/*
 * Show usage message and exit.
 */
void usage(const char *why)
{
    if (why) {
        fprintf(stderr, "nlioperf: %s\n", why);
    }
    fprintf(stderr, "\n"
            "Usage: nlioperf (-c HOST|-s HOST) -f FILE {options}\n"
            "client/server options:\n"
            "        -b BYTES       Number of bytes [until EOF]\n"
            "        -c HOST        Remote host (required)\n"
            "        -f FILE        Local file (required)\n"
            "        -h             Print this message\n"
            "        -n NUM         Number of parallel streams [1]\n"
            "        -p PORT        Local/remote port [%d]\n"
            "        -R             Server sends data to client, instead\n"
            "                       of client sending to server [NO]\n"
            "        -s HOST        Local listen host/interface [IPADDR_ANY]\n"
            "        -u USEC        Sleep USEC microseconds after every \n"
            "                       disk operation [0]\n"
            "        -w BYTES       TCP send/receive buffer [0]\n"
            "logging options:\n"
            "        -i SEC         Interval in seconds for summary logs.\n"
            "                       Ignored if 'i' not given for -t option\n"
            "        -o FILE        Write logs to FILE [& = stderr]\n"
            "        -q             No program logging\n"
            "        -r FMT[:FILE]  Report results to file [stdout].\n"
            "                       FMT: full, brief, csv, off. Repeatable\n"
            "        -t CODES..     Type of logging to perform, using\n"
            "                       one or more of these characters:\n"
            "                          f = Full logs of every read/write\n"
            "                          i = Interval summaries\n"
            "                          n = No logging\n"
            "                          s = Summary event for transfer\n"
            "                       [Default is 's']\n"
            "        -v             Verbose program logging\n"
            "", NLIO_DEFAULT_PORT);
    exit(1);
}

/*
 * Parse arguments into a structure
 */
int parse_args(int argc, char *const argv[], nlioperf_args_t * args)
{
    const char *optstring = "b:c:f:hi:n:o:p:qr:Rs:t:u:vw:";
    char optc;
    char *endptr;               /* for strtod, strtoll */
    int got_mode;

    /* initialize args to defaults */
    args->quiet = args->verbose = 0;
    args->why = NULL;
    args->filename = NULL;
    args->host = NULL;
    args->port = NLIO_DEFAULT_PORT;
    args->nstreams = 1;
    args->nbytes = 0LL;
    args->reverse = 0;
    args->rpt_n = 0;
    args->sockbuf = (size_t)0;
    args->disk_usleep = 0;
    args->log_file = NULL;
    args->log_interval = 0.;
    args->log_modes = NLIO_LOG_PROG;
    
    got_mode = 0;
    /* Main option parsing loop */
    while (-1 != (optc = getopt(argc, argv, optstring))) {
        long tmp_long;
        switch (optc) {
        case '?':
        case 'h':
            goto error;
        case 'b':
            args->nbytes = strtoll(optarg, &endptr, 10);
            if (endptr == optarg || args->nbytes < 1) {
                args->why = strdup("-b value must be a positive integer");
                goto error;
            }
            break;
        case 'c':
            got_mode = 1;
            args->host = strdup(optarg);
            args->mode = CLIENT_MODE;
            break;
        case 'f':
            args->filename = strdup(optarg);
            break;
        case 'i':
            args->log_interval = strtod(optarg, &endptr);
            if (args->log_interval == 0 && endptr == optarg) {
                args->why = strdup("-i interval must be a number");
                goto error;
            }
            break;
        case 'o':
            args->log_file = strdup(optarg);
            break;
        case 'n':
            args->nstreams = strtol(optarg, &endptr, 10);
            if (endptr == optarg || args->nstreams < 1) {
                args->why = strdup("-n value must be a positive integer");
                goto error;
            }
            break;
        case 'p':
            tmp_long = strtol(optarg, &endptr, 10);
            if (endptr == optarg || tmp_long < 1 || tmp_long > 65535) {
                args->why = strdup("-p value must be in range 1-65535");
                goto error;
            }
            args->port = (unsigned short) tmp_long;
            break;
        case 'q':
            if (args->verbose) {
                args->why = strdup("-v and -q options conflict");
                goto error;
            }
            args->quiet = 1;
            break;
        case 'r':
            if (-1 ==
                parse_rptarg(optarg, &args->rpt[args->rpt_n],
                             &args->why)) {
                goto error;
            }
            args->rpt_n++;
            break;
        case 'R':
            args->reverse = 1;
            break;
        case 's':
            got_mode = 1;
            args->mode = SERVER_MODE;
            if (optarg && *optarg) {
                if (optarg[0] == '-') {
                    /* next option, back up! */
                    optind--;
                    args->host = strdup("localhost");
                }
                else {
                    args->host = strdup(optarg);
                }
            }
            break;
        case 't':
            {
                int i;
                for (i=0; i>=0 && optarg[i]; i++) {
                    switch(optarg[i]) {
                        case 'f':
                        case 'F':
                            args->log_modes |= NLIO_LOG_FULL;
                            break;
                        case 'i':
                        case 'I':
                            args->log_modes |= NLIO_LOG_INT;
                            break;
                        case 's':
                        case 'S':
                            args->log_modes |= NLIO_LOG_PROG;
                            break;
                        case 'n':
                        case 'N':
                            args->log_modes = NLIO_LOG_NONE;
                            i = -99; /* stop now */
                            break;
                        default:
                            args->why = strdup("unknown mode character for -t");
                            goto error;
                    }
                }
            }
            break;
        case 'u':
            tmp_long = strtol(optarg, &endptr, 10);
            if (endptr == optarg || tmp_long < 1) {
                args->why = strdup("-u value must be greater than 0");
                goto error;
            }
            args->disk_usleep = (unsigned int) tmp_long;
            break;
        case 'v':
            if (args->quiet) {
                args->why = strdup("-v and -q options conflict");
                goto error;
            }
            args->verbose = 1;
            break;
        case 'w':
            tmp_long = strtol(optarg, &endptr, 10);
            if (endptr == optarg || tmp_long < 1) {
                args->why = strdup("-w value must be a positive integer");
                goto error;
            }
            args->sockbuf = (size_t)tmp_long;
            break;
        }
    }
    /* stop if no mode */
    if (!got_mode) {
        args->why = strdup("-c or -s is required\n");
        goto error;
    }
    /* set default report if none was given */
    if (args->rpt_n == 0 && args->log_modes != NLIO_LOG_NONE) {
        if (-1 == parse_rptarg("brief", &args->rpt[0], &args->why)) {
            /* hopefully never get here! */
            char *tmp = malloc(strlen(args->why) + 80);
            sprintf(tmp, "Internal error at %s:%d :: %s", __FILE__,
                    __LINE__, args->why);
            free(args->why);
            args->why = tmp;
            goto error;
        }
        args->rpt_n = 1;
    }
    /* check that required arguments were provided */
    if (args->filename == NULL) {
        args->why = strdup("required argument -f is missing");
        goto error;
    }
    /* set default log file */
    if (NULL == args->log_file) {
        args->log_file = strdup("&");
    }

    return 0;

error:
    return -1;
}

/*
 * Parse -r FMT[:FILE]
 */
int parse_rptarg(char *arg, nlioperf_rptarg_t * ra, char **whyp)
{
    char *fmt, *filename, *p;

    p = strchr(arg, ':');
    if (p)
        *p = '\0';
    fmt = arg;
    if (!strcasecmp(fmt, "full")) {
        ra->fmt = FULL_TEXT_REPORT;
    }
    else if (!strcasecmp(fmt, "brief")) {
        ra->fmt = BRIEF_TEXT_REPORT;
    }
    else if (!strcasecmp(fmt, "csv")) {
        ra->fmt = CSV_REPORT;
    }
    else if (!strcasecmp(fmt, "off")) {
        ra->fmt = NO_REPORT;
    }
    else {
        if (p)
            *p = ':';
        *whyp = strdup("unknown report format");
        goto error;
    }
    /* open file */
    if (p) {
        *p = ':';
        filename = p + 1;
        if (*filename == '\0') {
            *whyp = strdup("report output filename is empty");
            goto error;
        }
        ra->ofile = fopen(filename, "w");
        if (!ra->ofile) {
            *whyp = strdup("cannot open report output file");
            goto error;
        }
    }
    else {
        ra->ofile = stdout;
    }
    /* set func. ptrs */
    switch (ra->fmt) {
    case CSV_REPORT:
        ra->initfn = nlioperf_rpt_csv;
        ra->resultfn = nlioperf_rpt_csv_result;
        break;
    case FULL_TEXT_REPORT:
        ra->initfn = nlioperf_rpt_txtfull;
        ra->resultfn = nlioperf_rpt_txtfull_result;
        break;
    case BRIEF_TEXT_REPORT:
        ra->initfn = nlioperf_rpt_txtbrief;
        ra->resultfn = nlioperf_rpt_txtbrief_result;
        break;
    case NO_REPORT:
        ra->initfn = nlioperf_rpt_nop;
        ra->resultfn = nlioperf_rpt_nop_result;
        break;
    default:
        *whyp = malloc(1024);
        sprintf(*whyp, "Internal error at %s:%d", __FILE__, __LINE__);
    }

    return 0;

  error:
    return -1;

}
