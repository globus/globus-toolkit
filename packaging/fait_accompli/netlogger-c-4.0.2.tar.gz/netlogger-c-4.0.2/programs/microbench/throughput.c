/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

#include <assert.h>                    /* assert */
#include <stdio.h>                     /* printf, etc. */
#include <stdlib.h>                    /* exit */
#include <string.h>                    /* strcasecmp */
#include <unistd.h>                    /* unlink */
#include "nlint.h"
#include "nlsummint.h"
#include "nltsummint.h"
#include "common.h"

int g_verbose = 1;
int g_debug = 0;
#define INFO(...) do { if (g_verbose) fprintf (stderr, __VA_ARGS__); } while(0)
#define DBG(...) do { if (g_debug) fprintf (stderr, __VA_ARGS__); } while(0)

/* print usage msg & exit */
static void usage(const char *why)
{
    if (why)
        fprintf(stderr, "error: %s\n", why);
    fprintf(stderr, "usage: throughput summ-type num-runs [sample-rate]\n"
                    "  inst-type must be 'none', 'summ', or 'all'\n"
                    "  sample-rate = sample rate percentage 0..100\n");
    exit(1);
}

/* print fatal error and exit */
static void fatal(const char *why)
{
    fprintf(stderr, "fatal error: %s\n", why);
    exit(-1);
}

/* initialize logging */
NL_log_T init_logging(nlinst_t inst_type, char **logfile,
                      char **summ_logfile)
{
    NL_log_T log;

    if (inst_type == INST_NONE) {
        return NULL;
    }
    else if (inst_type == INST_ALL) {
        *logfile = strdup("/dev/null");
    }
    else {
        *logfile = tempnam(".", NULL);
    }
    log = NL_open(*logfile);
    if (NULL == log) {
        fatal("cannot open log to temporary file");
    }
    NL_set_level(log, NL_LVL_DEBUG);
    if (inst_type == INST_SUMM) {
        NL_summ_T summ = NL_summ();
        NL_params_T params = NL_params();
        NL_summseq_T sequence = NL_summseq();
        char event[32];
        NL_log_T slog;
        int r;

        /* set up summarization for the .start/.end events & */
        sprintf(event, "noop.start");
        r = NL_summseq_add_selector(sequence, "event", event,
                                    strlen(event));
        assert(0 == r);
        r = NL_summseq_add_id_field(sequence, 0, "id");
        assert(0 == r);
        sprintf(event, "noop.end");
        r = NL_summseq_add_selector(sequence, "event", event,
                                    strlen(event));
        assert(0 == r);
        r = NL_summseq_add_id_field(sequence, 1, "id");
        assert(0 == r);
        r = NL_summseq_add_value_field(sequence, 1, "value");
        assert(0 == r);
        {
            int64_t intr = 1000000;
            NL_params_append(params, NLTSUMM_P_INTERVAL, &intr, sizeof(intr));
        }
        NL_params_append(params, NLTSUMM_P_LVL, "INFO", 4);     /* output level */
        NL_params_append(params, NLTSUMM_P_EVENT, "thrput", 6);
        r = NL_summseq_set_info(sequence, params, NL_tsumm_init,
                                NL_tsumm_process, NL_tsumm_flush,
                                NL_tsumm_free_data);
        assert(0 == r);                       
        NL_summseq_set_consume(sequence, 1);
        assert(0 == NL_summ_add_sequence(summ, sequence));
        /* connect summarizer to log */
        NL_summ_add_log(summ, log);
        /* set summarizer output */
        *summ_logfile = tempnam(".", NULL);
        slog = NL_open(*summ_logfile);
        if (NULL == slog) {
            fatal("cannot open log to temporary file");
        }
        NL_set_level(slog, NL_LVL_INFO);        /* match output level param */
        NL_summ_set_output(summ, slog);
    }

    return log;
}

/* perform num_runs runs */
double measure_throughput(int num_runs, NL_log_T log)
{
    struct timeval t;
    double time = 0.0;
    int i;
    int64_t usec;

    for (i = 0; i < num_runs; i++) {
        int j;
        fprintf(stderr, "RUN %d\n", i + 1);
        TIMER_START(t);
        /* one million pairs */
        for (j = 0; j < 1000000; j++) {
            if (log) {
                NL_write(log, NL_LVL_DEBUG, "noop.start", "id=i", i);
                NL_write(log, NL_LVL_DEBUG, "noop.end", "id=i value=d",
                         i, 1.0 * j);
            }
        }
        TIMER_ELAPSED(t, usec);
        time += (double) usec / 1e6;
        if (log) {
            NL_flush(log);
        }
    }

    return time;
}

/* perform num_runs runs */
double measure_throughput_smpl(int num_runs, NL_log_T log)
{
    struct timeval t;
    double time = 0.0;
    int i;
    int64_t usec;
    NL_smpl_t smpl = NL_get_smpl(log);
    
    for (i = 0; i < num_runs; i++) {
        int j;
        fprintf(stderr, "RUN %d\n", i + 1);
        TIMER_START(t);
        /* one million pairs */
        for (j = 0; j < 1000000; j++) {
            if (log) {
                NL_write_begin(0, log, smpl, NL_LVL_DEBUG, "noop.start", "id=i", i);
                NL_write_end(0, log, smpl, NL_LVL_DEBUG, "noop.end", "id=i value=d",
                             i, 1.0 * j);
            }
        }
        TIMER_ELAPSED(t, usec);
        time += (double) usec / 1e6;
        if (log) {
            NL_flush(log);
        }
    }

    return time;
}

/**
 * Main
 */
int main(int argc, char **argv)
{
    char *endptr, *logfile, *summ_logfile;
    int i, num_runs, sample_rate;
    nlinst_t inst_type;
    double time, avg_time;
    NL_log_T log;

    /* --- parse arguments --- */
    if (argc < 3 || argc > 4) {
        usage(NULL);
    }
    i = 1;
    /* inst-type */
    for (inst_type = 0; g_inst_name[inst_type]; inst_type++) {
        if (!strcasecmp(argv[i], g_inst_name[inst_type])) {
            break;
        }
    }
    if (!g_inst_name[inst_type]) {
        usage("unrecognized instrumentation type");
    }
    i++;
    /* num-runs */
    num_runs = strtol(argv[i], &endptr, 10);
    if (num_runs <= 0) {
        usage("num-runs must be a positive integer");
    }
    i++;
    /* sample rate */
    if (argc < 4) {
        sample_rate = 100;
    }
    else {
        sample_rate = strtol(argv[i], &endptr, 10);
        if (sample_rate < 1 || sample_rate > 100) {
            usage("sample rate must be in range 1..100");
        }
    }
    /* set up logging/summarization */
    logfile = summ_logfile = NULL;
    log = init_logging(inst_type, &logfile, &summ_logfile);
    if (sample_rate == 100) {
        time = measure_throughput(num_runs, log);
    }
    else {
        NL_set_smpl_rate(log, (double)sample_rate / 100.0);
        time = measure_throughput_smpl(num_runs, log);
    }
    /* report results */
    avg_time = time / (double) num_runs;
    printf("%s: %lf microseconds/event pair\n",
           g_inst_name[inst_type], avg_time);
    /* cleanup */
    if (log) {
        NL_close(log);
        if (logfile) {
            INFO("unlinking log file %s\n", logfile);
            unlink(logfile);
        }
        if (summ_logfile) {
            INFO("unlinking log summary file %s\n", summ_logfile);
            unlink(summ_logfile);
        }
    }

    return 0;
}
