/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "common.h"
#include "nlparams.h"
#include "nlsummint.h"

/*
 * Simple summarizer benchmark that shows how the number of
 * (distinct) event-pairs and guids-per-pair affect the performance
 */

#define MAX_PAIRS 64
#define MAX_GUIDS 16

char *g_event_start[MAX_PAIRS], *g_event_end[MAX_PAIRS];
char *g_guid[MAX_GUIDS];
char *g_filename;

int make_temp_file(char **filename)
{
    *filename = strdup("/tmp/nlbench.XXXXXX");
    return mkstemp(*filename); 
}

void init_summ(NL_summ_T *summ_p, NL_log_T log, int n)
{
    NL_params_T params; 
    NL_summseq_T sequence; 
    char event[32];
    int i, len;
    int64_t usec;
    
    *summ_p = NL_summ();
    usec = 500000;
    for (i=0; i < n; i++) {        
        len = sprintf(event, "event%d.start", i+1);        
        sequence = NL_summseq();
        NL_summseq_add_selector(sequence, "event", event, len);
        NL_summseq_add_id_field(sequence, 0, "guid");
        g_event_start[i] = strdup(event);
        len = sprintf(event, "event%d.end", i+1);
        NL_summseq_add_selector(sequence, "event", event, len);
        NL_summseq_add_id_field(sequence, 1, "guid");
        NL_summseq_add_value_field(sequence, 1, "value");
        g_event_end[i] = strdup(event);
        params = NL_params();
        NL_params_append(params, NLTSUMM_P_INTERVAL, &usec, sizeof(usec));
        NL_params_append(params, NLTSUMM_P_LVL, "INFO", 4);
        NL_params_append(params, NLTSUMM_P_EVENT, "event.summ", 10);
        NL_summseq_set_info(sequence, params, NL_tsumm_init,
                                NL_tsumm_process, NL_tsumm_flush,
                                NL_tsumm_free_data);
        NL_summseq_set_consume(sequence, 1);                                
        NL_summ_add_sequence(*summ_p, sequence);
    }
    NL_summ_add_log(*summ_p, log);
    NL_summ_set_shared_output(*summ_p, log);
}

void init_log(NL_log_T *log_p)
{
    make_temp_file(&g_filename);
    *log_p = NL_open(g_filename);    
}

void destroy_log(NL_log_T log)
{
    NL_close(log);
    unlink(g_filename);
}

void init_guids(void)
{
    int i;
    char *guid;
    
    for (i=0; i < MAX_GUIDS; i++) {
        NL_get_guid(&guid);
        g_guid[i] = guid;
    }    
}

int log_events(NL_log_T log, int num, int num_each)
{
    int i, j, k, inner_loops;
    
    inner_loops = 100000 / num / num_each;
    for (i=0; i < num; i++) {
        for (j=0; j < num_each; j++) {
            for (k=0; k < inner_loops; k++) {
                NL_write(log, NL_LVL_INFO, g_event_start[i], "guid=s",
                         g_guid[j]);
                NL_write(log, NL_LVL_INFO, g_event_end[i], "guid=s value=d",
                         g_guid[j], (double)k);
            }
        }
    }
    return inner_loops * num * num_each;
}

int main(int argc, char **argv)
{
    NL_log_T log;
    NL_summ_T summarizer;
    const int NUM_ITER = 5;
    int i, j, g, nguid, num_iter, iter, pairs;
    struct timeval tv;
    int64_t usec;
    double usec_arr[MAX_PAIRS][MAX_GUIDS];
    
    if (argc > 1 && !strncmp(argv[1],"-h",2)) {
        fprintf(stderr,"\nSimple summarizer benchmark that shows how\n"
        "the number of (distinct) event-pairs and guids-per-pair\n"
        "affect the summarizer's performance.\n"
        "\nusage: nl_multievent [iter(%d)]\n"
        "progress is logged to stderr, results to stdout\n",
        NUM_ITER);
        return 1;
    }
    if (argc > 1)
        num_iter = atoi(argv[1]);
    else
        num_iter = NUM_ITER;
        
    memset(usec_arr, 0, sizeof(usec_arr));
    init_log(&log);
    init_summ(&summarizer, log, MAX_PAIRS);
    init_guids();
    
    for (iter=0; iter < num_iter; iter++) {
        fprintf(stderr, "\n%d/%d: ", iter+1, num_iter);
        for (nguid=1, g=0; nguid <= MAX_GUIDS; nguid *= 2, g++) {
            for (i=1, j=0; i <= MAX_PAIRS; i = i*2, j++) {
                fprintf(stderr, "%d*%d ", i, nguid); fflush(stderr);
                TIMER_START(tv);
                pairs = log_events(log, i, nguid);
                TIMER_ELAPSED(tv, usec);
                usec_arr[j][g] += 1.0 * usec / pairs;
            }
        }
    }

    destroy_log(log);
    
    printf("\nnpairs\tnnguids\tavg usec\n");
    for (i=0; 1<<i <= MAX_PAIRS; i++) {
        for (j=0; 1<<j <= MAX_GUIDS; j++) {
            printf("%d\t%d\t%lf\n", 1<<i, 1<<j, usec_arr[i][j] / num_iter);
        }
    }

    return 0;
}