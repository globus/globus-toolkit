/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

#include <limits.h>                    /* strtol */
#include <stdio.h>                     /* printf */
#include <stdlib.h>                    /* malloc */
#include <string.h>                    /* memset */
#include "common.h"

void usage(char *why)
{
    if (why) {
        fprintf(stderr, "error: %s\n", why);
    }
    fprintf(stderr, "usage: calibrate MIN_US MAX_US STEP_US\n"
            "  Run and report tests from MIN_US to MAX_US by STEP\n"
            "  US = microseconds.\n");
    exit(1);
}

/* Run until all types of tests take at least min_ms, 
 * reporting as we finish each test.
 */
void run(int64_t min_us, int64_t max_us, int64_t step)
{
    unsigned char test_done[NUM_TIMINGS];
    int64_t test_iter[NUM_TIMINGS];
    unsigned num_done;
    int64_t iter, usec;
    struct timeval t;
    int fd;
    char *tmpfile_name;

    /* init */
    memset(test_done, 0, sizeof(char) * NUM_TIMINGS);
    num_done = 0;
    open_tmpfile(&tmpfile_name, &fd);
    /* keep increasing the number of iterations */
    for (iter = step; num_done < NUM_TIMINGS; iter += step) {
        int i, j;
        /* loop over each type of test */
        for (i = 0; i < NUM_TIMINGS; i++) {
            /* only look at tests that didn't already pass min_ms */
            if (!test_done[i]) {
                /* repeat to avoid fluke timings */
                usec = LONG_MAX;
                for (j = 0; j < 5; j++) {
                    int64_t usec_j;
                    TIMER_START(t);
                    switch (i) {
                    case IO_TIMING:
                        do_io(fd, iter, NULL);
                        break;
                    case COMPUTE_TIMING:
                        do_compute(iter, NULL);
                        break;
                    }
                    TIMER_ELAPSED(t, usec_j);
                    usec = MIN(usec, usec_j);
                }
                /* if we passed min_usec, print result and mark as done */
                if (usec >= min_us) {
                    char *buf;
                    test_done[i] = 1;
                    test_iter[i] = iter + step;
                    num_done++;
                    buf = format_timing(i, iter, usec);
                    printf(buf);
                    free(buf);
                }
            }
        }
    }
    /* reset for max_ms */
    memset(test_done, 0, sizeof(char) * NUM_TIMINGS);
    num_done = 0;
    /* keep increasing the number of iterations */
    while (num_done < NUM_TIMINGS) {
        int i, j;
        /* loop over each type of test */
        for (i = 0; i < NUM_TIMINGS; i++) {
            /* only look at tests that didn't already pass max_ms */
            if (!test_done[i]) {
                iter = test_iter[i];
                /* loop to avoid fluke timings */
                usec = LONG_MAX;
                for (j = 0; j < 5; j++) {
                    int64_t usec_j;
                    TIMER_START(t);
                    switch (i) {
                    case IO_TIMING:
                        do_io(fd, iter, NULL);
                        break;
                    case COMPUTE_TIMING:
                        do_compute(iter, NULL);
                        break;
                    }
                    TIMER_ELAPSED(t, usec_j);
                    usec = MIN(usec, usec_j);
                }
                /* if we passed max_ms, mark as done */
                if (usec > max_us) {
                    test_done[i] = 1;
                    num_done++;
                }
                /* otherwise, add to #iters */
                else {
                    test_iter[i] += step;
                }
                /* either way, report the result */
                {
                    char *buf;
                    buf = format_timing(i, iter, usec);
                    printf(buf);
                    free(buf);
                }
            }
        }
    }
    /* cleanup */
    close_tmpfile(tmpfile_name, fd);
}

int main(int argc, char **argv)
{
    int64_t min_us, max_us, step;
    char *endptr;

    if (argc != 4)
        usage(NULL);
    min_us = strtoll(argv[1], &endptr, 10);
    if (min_us < 1)
        usage("MIN_US must be between 1 and 2**63\n");
    max_us = strtoll(argv[2], &endptr, 10);
    if (max_us < min_us)
        usage("MAX_US must be between MIN_US and 2**63\n");
    step = strtoll(argv[3], &endptr, 10);
    if (step < 1)
        usage("STEP must be positive\n");

    run(min_us, max_us, step);

    return 0;
}
