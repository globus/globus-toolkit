#ifndef NL_MICROBENCH_COMMON_H_INCLUDED
#define NL_MICROBENCH_COMMON_H_INCLUDED
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* 
 * Sequence of events to summarize
 */

#ifdef HAVE_CONFIG_H
#include "nlconfig.h"
#endif
#include "nlstdint.h"
/* time headers */
#if TIME_WITH_SYS_TIME
# include <sys/time.h>
# include <time.h>
#else
# if HAVE_SYS_TIME_H
#  include <sys/time.h>
# else
#  include <time.h>
# endif
#endif
#include "nl.h"

#ifdef __cplusplus
extern "C" {
#endif
# if 0
}
#endif
/* types of timings, and their string equivalents */
    typedef enum { IO_TIMING = 0, COMPUTE_TIMING = 1, NUM_TIMINGS =
2 } timing_t;
typedef enum { INST_NONE = 0, INST_SUMM = 1, INST_ALL = 2, NUM_INST =
        3 } nlinst_t;
extern char *g_timing_name[], *g_inst_name[];

/* start the timer stored in struct timeval arg. */
#define TIMER_START(t) do { gettimeofday(&(t),0); } while(0)

/* get current time elapsed since time in input arg, store as usec in output */
#define TIMER_ELAPSED(t,u) do { \
    struct timeval t1; \
    gettimeofday(&t1,0); \
    (u) = (t1.tv_sec - (t).tv_sec) * 1000000LL + t1.tv_usec - (t).tv_usec; \
} while(0)

#ifndef MAX
#define MAX(X,Y) ((X) >= (Y) ? (X) : (Y))
#endif
#ifndef MIN
#define MIN(X,Y) ((X) <= (Y) ? (X) : (Y))
#endif

/* run a computation for some number of iterations,
 * logging to given log if non-NULL */
extern double do_compute(int64_t iter, NL_log_T log);

/* perform I/O to a file descriptor for some number of iterations,
 * logging to given log if non-NULL */
extern void do_io(int fd, int64_t iter, NL_log_T log);

/* format a timing as a string.
 * caller should free returned string when done. */
extern char *format_timing(timing_t type, int64_t iter, int64_t usec);

/* parse a timing string back to an internal representation.
 * return 0 if ok, -1 on error. */
extern int parse_timing(const char *str, timing_t * typep, int64_t * iterp,
                        int64_t * usecp);

/* open a temporary file (for writing), returning the name and descriptor.
 * these should be de-allocated by a call to close_tmpfile() */
extern void open_tmpfile(char **tmpfile_name, int *fd);

/* de-allocate, etc. the temporary file returned by open_tmpfile() */
extern void close_tmpfile(char *tmpfile_name, int fd);

#ifdef __cplusplus
}
#endif
#endif                          /* ..._INCLUDED */
