/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

#include <fcntl.h>                     /* open */
#include <stdio.h>                     /* printf, tmpnam */
#include <stdlib.h>                    /* malloc */
#include <string.h>                    /* strcpy */
#include <unistd.h>                    /* lseek */

#include "nl.h"
#include "common.h"

char *g_timing_name[] = { "io", "compute", NULL /* sentinel */  };
char *g_inst_name[] = { "none", "summ", "all", NULL /* sentinel */  };

#define ARR_SZ 1024
double g_arr[ARR_SZ];

/* run a computation for some number of iterations */
double do_compute(int64_t iter, NL_log_T log)
{
    double result;
    int64_t i;
    int j;

    if (log)
        NL_write(log, NL_LVL_DEBUG, "compute.start", "id=s", "1");

    for (i = 0; i < ARR_SZ; i++) {
        g_arr[i] = i;
    }
    for (i = 0; i < iter; i++) {
        for (j = 0; j < 10; j++) {
            g_arr[i % ARR_SZ] += g_arr[(i + j) % ARR_SZ] -
                g_arr[(i - j) % ARR_SZ];
        }
    }
    result = g_arr[0];

    if (log)
        NL_write(log, NL_LVL_DEBUG, "compute.end", "id=s value=d",
                 "1", g_arr[0]);
    return result;
}

/* perform I/O to a file descriptor for some number of iterations */
void do_io(int fd, int64_t iter, NL_log_T log)
{
    int64_t i, nbytes = 0LL;
    char buf[8];

    if (log)
        NL_write(log, NL_LVL_DEBUG, "io.start", "id=i", fd);

    lseek(fd, 0, SEEK_SET);
    strcpy(buf, "hello!!");
    for (i = 0; i < iter; i++) {
        nbytes += write(fd, buf, sizeof(buf));
    }
    if (log)
        NL_write(log, NL_LVL_DEBUG, "io.end", "id=i value=d", fd,
                 (double) nbytes);
}

/* format a timing as a string */
char *format_timing(timing_t type, int64_t iter, int64_t usec)
{
    char *buf = malloc(1024);

    sprintf(buf, "%s %lld %lld\n", g_timing_name[type], iter, usec);

    return buf;
}

/* parse a timing string back to an internal representation.
 * return 0 if ok, -1 on error. */
int parse_timing(const char *str, timing_t * typep, int64_t * iterp,
                 int64_t * usecp)
{
    char timing_name[32];
    int result = 0, num_items;

    num_items = sscanf(str, "%s %lld %lld", timing_name, iterp, usecp);
    if (num_items == 3) {
        int i, got_it;
        for (i = 0, got_it = 0; g_timing_name[i]; i++) {
            if (!strcmp(timing_name, g_timing_name[i])) {
                *typep = (timing_t) i;
                got_it = 1;
                break;
            }
        }
        result = got_it ? 0 : -1;
    }
    else {
        result = -1;
    }

    return result;
}

/* open a temporary file (for writing), returning the name and descriptor */
void open_tmpfile(char **tmpfile_name, int *fd)
{
    *tmpfile_name = tmpnam(NULL);
    *fd = open(*tmpfile_name, O_RDWR | O_CREAT | O_NONBLOCK, 0644);
}

/* de-allocate, etc. the temporary file returned by open_tmpfile() */
void close_tmpfile(char *tmpfile_name, int fd)
{
    close(fd);
}
