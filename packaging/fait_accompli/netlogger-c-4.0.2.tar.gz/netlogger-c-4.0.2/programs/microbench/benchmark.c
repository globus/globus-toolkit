/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

#include <assert.h>                    /* assert */
#include <stdio.h>                     /* printf, etc. */
#include <stdlib.h>                    /* exit */
#include <string.h>                    /* strcasecmp */
#include <unistd.h>                    /* unlink */
#include "nl.h"
#include "nlint.h"
#include "nlsummint.h"
#include "nltsummint.h"
#include "common.h"

int g_verbose = 1;
int g_debug = 0;
#define INFO(...) do { if (g_verbose) fprintf (stderr, __VA_ARGS__); } while(0)
#define DBG(...) do { if (g_debug) fprintf (stderr, __VA_ARGS__); } while(0)

/* print usage msg & exit */
static void usage(const char *why)
{
    if (why)
        fprintf(stderr, "error: %s\n", why);
    fprintf(stderr, "usage: benchmark timing-type summ-type calib-file "
            "target-usec/iter num-runs\n");
    exit(1);
}

/* print fatal error and exit */
static void fatal(const char *why)
{
    fprintf(stderr, "fatal error: %s\n", why);
    exit(-1);
}

/* read calibration file, and figure out how many inner loops
 * of the given type of timing we should be doing to hit the target
 * number of microseconds (in tgt_usec).
 */
int64_t read_calibration_file(FILE * fp, timing_t ttype, int64_t tgt_usec)
{
    char str[1024];
    timing_t ttype_in;
    int64_t iter[2], usec[2], result;
    unsigned char done;

    iter[0] = iter[1] = 0LL;
    usec[0] = usec[1] = 0LL;
    result = -1LL;
    done = 0;
    while (!done && fgets(str, sizeof(str), fp)) {
        if (0 != parse_timing(str, &ttype_in, iter + 1, usec + 1)) {
            fatal("bad line in calibration file");
        }
        if (ttype == ttype_in) {
            if (usec[1] == tgt_usec) {
                result = iter[1];
                done = 1;
            }
            else if (usec[1] > tgt_usec) {
                /* simple linear interpolation */
                result = (double) (tgt_usec - usec[0]) /
                    (double) (usec[1] - usec[0]) *
                    (double) (iter[1] - iter[0]) + iter[0];
                done = 1;
            }
            else {
                iter[0] = iter[1];
                usec[0] = usec[1];
            }
        }
    }
    /* simply interpolate out a diagonal line if 
     * tgt_usec is greater than any available value */
    if (!done) {
        if (usec[1] > 0) {
            result = (tgt_usec / usec[1]) * iter[1];
        }
    }
    return result;
}

NL_log_T init_logging(nlinst_t inst_type, timing_t timing_type,
                      char **logfile, char **summ_logfile)
{
    NL_log_T log;

    if (inst_type == INST_NONE) {
        return NULL;
    }
    *logfile = tempnam(".", NULL);
    log = NL_open(*logfile);
    if (NULL == log) {
        fatal("cannot open log to temporary file");
    }
    NL_set_level(log, NL_LVL_DEBUG);
    if (inst_type == INST_SUMM) {
        NL_summ_T summ = NL_summ();
        NL_params_T params = NL_params();
        NL_summseq_T sequence = NL_summseq();
        char event[32];
        NL_log_T slog;
        int r;

        /* set up summarization for the .start/.end events & */
        sprintf(event, "%s.start", g_timing_name[timing_type]);
        r = NL_summseq_add_selector(sequence, "event", event,
                                    strlen(event));
        assert(0 == r);
        r = NL_summseq_add_id_field(sequence, 0, "id");
        assert(0 == r);
        sprintf(event, "%s.end", g_timing_name[timing_type]);
        r = NL_summseq_add_selector(sequence, "event", event,
                                    strlen(event));
        assert(0 == r);
        r = NL_summseq_add_id_field(sequence, 1, "id");
        assert(0 == r);
        r = NL_summseq_add_value_field(sequence, 1, "value");
        assert(0 == r);
        {
            int64_t intr = 1000000;
            NL_params_append(params, NLTSUMM_P_INTERVAL, &intr, sizeof(intr));
        }
        NL_params_append(params, NLTSUMM_P_LVL, "INFO", 4);  /* output level */
        NL_params_append(params, NLTSUMM_P_EVENT, "thrput", 6);
        r = NL_summseq_set_info(sequence, params, NL_tsumm_init,
                                NL_tsumm_process, NL_tsumm_flush,
                                NL_tsumm_free_data);
        assert(0 == r);                                
        NL_summseq_set_consume(sequence, 1);
        assert(0 == NL_summ_add_sequence(summ, sequence));
        /* connect summarizer to log */
        NL_summ_add_log(summ, log);
        /* set summarizer output */
        *summ_logfile = tempnam(".", NULL);
        slog = NL_open(*summ_logfile);
        if (NULL == slog) {
            fatal("cannot open log to temporary file");
        }
        NL_set_level(slog, NL_LVL_INFO);        /* match output level param */
        NL_summ_set_output(summ, slog);
    }

    return log;
}

/**
 * Main
 */
int main(int argc, char **argv)
{
    char *endptr, *tmpfile, *logfile, *summ_logfile;
    int i, num_runs, fd;
    int64_t num_loops, usec;
    FILE *calib_file;
    timing_t timing_type;
    nlinst_t inst_type;
    long tgt_usec;
    double time, avg_time;
    struct timeval t;
    NL_log_T log;


    /* --- parse arguments --- */
    if (argc != 6) {
        usage(NULL);
    }
    i = 1;
    /* timing-type */
    for (timing_type = 0; g_timing_name[timing_type]; timing_type++) {
        if (!strcasecmp(argv[i], g_timing_name[timing_type])) {
            break;
        }
    }
    if (!g_timing_name[timing_type]) {
        usage("timing-type must be 'io' or 'compute'");
    }
    i++;
    /* inst-type */
    for (inst_type = 0; g_inst_name[inst_type]; inst_type++) {
        if (!strcasecmp(argv[i], g_inst_name[inst_type])) {
            break;
        }
    }
    if (!g_inst_name[inst_type]) {
        usage("inst-type must be 'none', 'summ', or 'all'");
    }
    i++;
    /* calibration file */
    calib_file = fopen(argv[i], "r");
    if (NULL == calib_file) {
        usage("failed to open calibration file");
    }
    i++;
    /* target-usec per iter */
    tgt_usec = strtol(argv[i], &endptr, 10);
    if (tgt_usec <= 0) {
        usage("tgt-usec must be a positive integer");
    }
    i++;
    /* num-runs */
    num_runs = strtol(argv[i], &endptr, 10);
    if (num_runs <= 0) {
        usage("num-runs must be a positive integer");
    }
    i++;
    /* read calibration file */
    num_loops = read_calibration_file(calib_file, timing_type, tgt_usec);
    if (num_loops < 0) {
        usage("calibration file format error");
    }
    /* set up logging/summarization */
    logfile = summ_logfile = NULL;
    log = init_logging(inst_type, timing_type, &logfile, &summ_logfile);
    /* set up file for IO */
    if (timing_type == IO_TIMING) {
        open_tmpfile(&tmpfile, &fd);
    }
    /* perform num_runs runs */
    /* printf("runs=%d loops/run=%lld\n", num_runs, num_loops); */
    time = 0.0;
    for (i = 0; i < num_runs; i++) {
        double v = 1.0;

        TIMER_START(t);
        switch (timing_type) {
        case IO_TIMING:
            do_io(fd, num_loops, log);
            break;
        case COMPUTE_TIMING:
            v = do_compute(num_loops, log);
            break;
        default:
            fatal("bad timing type");
        }
        TIMER_ELAPSED(t, usec);
        fprintf(stderr, "result=%lf\n", v);
        time += (double) usec / 1e6;
        if (log) {
            NL_flush(log);
        }
    }
    /* report results:
       timing-type,inst-type,num-runs,tgt-sec,avg-sec,loops/sec
     */
    avg_time = time / (double) num_runs;
    printf("%s,%s,%d,%lf,%lf,%lf\n", g_timing_name[timing_type],
           g_inst_name[inst_type], num_runs, tgt_usec / 1e6, avg_time,
           1.0 / avg_time);
    /* cleanup */
    close_tmpfile(tmpfile, fd);
    unlink(tmpfile);
    if (log) {
        NL_close(log);
        if (logfile) {
            INFO("unlinking log file %s\n", logfile);
            unlink(logfile);
        }
        if (summ_logfile) {
            INFO("unlinking log summary file %s\n", summ_logfile);
            unlink(summ_logfile);
        }
    }

    return 0;
}
