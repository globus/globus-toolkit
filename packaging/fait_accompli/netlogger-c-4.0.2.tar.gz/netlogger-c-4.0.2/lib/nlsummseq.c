/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* 
 * Sequence of (field,expected value),
 * associated summarizer, and per-instance summarizer state.
 */
#ifndef lint
static const volatile char rcsid[] =
    "$Id: nlsummseq.c 127 2007-08-21 18:18:00Z dang $";
#endif

#include <stdlib.h>

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "nlsummseq.h"
#include "nlint.h"
#include "nlparams.h"
#include "nlhash.h"
#include "nllist.h"
#include "nlsummvisitor.h"
#include "nlsummstate.h"

#define BOOL unsigned char
enum { FALSE = 0, TRUE = 1 };

static int process_record_noop(NL_summstate_T state)
{
    return -1;
}

static void free_state_noop(void *state)
{
    return;
}

static void *get_initial_state_noop(NL_params_T params)
{
    return NULL;
}

#define T NL_summseq_T
struct T {
    NL_hash_T /* NL_summstate_T */ states;
    //unsigned states_n, states_sz;
    NL_list_T /* fieldvec_t */ id_fields, value_fields, aux_fields;
    NL_list_T /* fvaluevec_t */ selectors;
    NL_subject_T output_rec_subject;
    int consume;
    struct {
        NL_params_T params;
        NL_summseq_init_state_fn get_initial_state;
        NL_summseq_process_fn process_record;
        NL_summseq_flush_fn flush_state;
        NL_free_fn free_state;
    } summ;
};

/* one vector of fields */
struct fieldvec_t {
    const char **fields;
    unsigned n, size;
};

void fieldvec_free(void *f)
{
    struct fieldvec_t *fv = (struct fieldvec_t *) f;
    if (fv) {
        if (fv->fields) {
            int i;
            for (i = 0; i < fv->n; i++) {
                free((char *) fv->fields[i]);
            }
            free((char **) fv->fields);
        }
        free(f);
    }
}

/* field and expected value */
struct fieldval_t {
    char *name;
    unsigned name_len;
    void *value;
    unsigned value_len;
};

void fieldval_free(void *f)
{
    struct fieldval_t *fv = (struct fieldval_t *) f;
    if (f) {
        free((char *) fv->name);
        free((char *) fv->value);
        free(f);
    }
}

/**
 * Constructor
 */
T NL_summseq(void)
{
    T self = (T) malloc(sizeof(struct T));

    self->states = NL_hash(128);
    self->id_fields = NL_list();
    self->value_fields = NL_list();
    self->aux_fields = NL_list();
    self->selectors = NL_list();
    self->output_rec_subject = NL_subject();
    self->consume = 0;
    self->summ.params = NL_params();
    self->summ.get_initial_state = get_initial_state_noop;
    self->summ.process_record = process_record_noop;
    self->summ.free_state = free_state_noop;

    return self;
}

/* Accept a visitor */
void NL_summseq_accept(T self, NL_summvisitor_T visitor)
{
    if (visitor) {
        NL_summvisitor_visit_summseq(visitor, self);
    }
}

/* Add a new item to the sequence */
int
NL_summseq_add_selector(T self, const char *name, void *value,
                        unsigned size)
{
    int result = 0, is_dup;
    void *p;
    struct fieldval_t *fp;

    /* check for duplicate */
    for (is_dup = 0, p = NL_list_iter(self->selectors);
         !is_dup && p; p = NL_list_next_node(self->selectors, p)) {
        fp = (struct fieldval_t *) NL_list_node_data(p);
        is_dup = (0 == strcmp(name, fp->name) &&
                  fp->value_len == size
                  && 0 == memcmp(value, fp->value, size));
    }
    /* add, if not duplicate */
    if (is_dup) {
        /* printf("@@ dup\n"); */
        result = -1;
    }
    else {
        fp = malloc(sizeof(struct fieldval_t));
        fp->name = strdup(name);
        fp->name_len = strlen(name);
        fp->value = malloc(size);
        memcpy(fp->value, value, size);
        fp->value_len = size;
        NL_list_append(self->selectors, fp);
        /* add empty id/value entries */
        NL_list_append(self->id_fields, NULL);
        NL_list_append(self->value_fields, NULL);
        NL_list_append(self->aux_fields, NULL);
    }
    return result;
}

/*
 * Add a new id or value field
 */
inline int
add_field(T self, unsigned idx, const char *field_name, NL_list_T flist)
{
    int result = 0;

    if (idx >= NL_list_len(flist) || NULL == field_name) {
        /* printf("@@ idx=%d len=%d field_name=%p\n", idx, NL_list_len(flist),
           field_name);
         */
        result = -1;
    }
    else {
        struct fieldvec_t *f;
        int i, duplicate = 0;

        f = (struct fieldvec_t *) NL_list_get(flist, idx);
        if (NULL == f) {
            f = malloc(sizeof(struct fieldvec_t));
            f->n = 0;
            f->size = 4;
            f->fields = malloc(f->size * sizeof(char *));
            NL_list_replace(flist, idx, f, NULL);
        }
        else {
            /* check for duplicate */
            for (i = 0; i < f->n; i++) {
                if (0 == strcmp(f->fields[i], field_name)) {
                    duplicate = 1;
                    break;
                }
            }
        }
        if (duplicate) {
            result = -1;
        }
        else {
            if (f->n >= f->size) {
                f->size *= 2;
                f->fields = realloc(f->fields, f->size * sizeof(char *));
            }
            f->fields[f->n] = strdup(field_name);
            f->n++;
        }
    }

    return result;
}

/*
 * Add 'id' field to selector #idx
 */
int NL_summseq_add_id_field(T self, unsigned idx, const char *field_name)
{
    return add_field(self, idx, field_name, self->id_fields);
}

/*
 * Add auxiliary field to selector #idx
 */
int NL_summseq_add_aux_field(T self, unsigned idx, const char *field_name)
{
    return add_field(self, idx, field_name, self->aux_fields);
}

/*
 * Add  'value' field to selector #idx
 */
int
NL_summseq_add_value_field(T self, unsigned idx, const char *field_name)
{
    return add_field(self, idx, field_name, self->value_fields);
}

/*
 * Copy over indices from the NL_list_t to a simple array
 */
static inline void
copy_indices(NL_list_T x, unsigned **indices, unsigned *n)
{
    void *node;
    int i;

    *n = NL_list_len(x);
    *indices = (unsigned *) malloc((*n) * sizeof(unsigned));
    for (i = 0, node = NL_list_iter(x); node;
         node = NL_list_next_node(x, node), i++) {
        (*indices)[i] = *((unsigned *) NL_list_node_data(node));
    }
}

/* 
 * Match up fields in record with those expected by
 * the fieldvec_t
 */
inline NL_list_T match_fields(NL_rec_t * record, struct fieldvec_t *f)
{
    unsigned i, j, match;
    int flen;
    NL_fld_t *fld;
    NL_list_T idlist;

    idlist = NL_list();

    for (i = 0, match = 1; match && (i < f->n); i++) {
        flen = strlen(f->fields[i]);
        for (j = 0, match = 0; !match && j < record->len; j++) {
            fld = record->fields[j];
            if (fld->klen == flen
                && 0 == memcmp(fld->key, f->fields[i], flen)) {
                unsigned *idxp = malloc(sizeof(unsigned));
                *idxp = j;
                NL_list_append(idlist, idxp);
                match = 1;
            }
        }
    }

    return idlist;
}

static inline int
get_fields(NL_list_T fields_to_match, NL_rec_t * record,
           int idx, unsigned **fields, unsigned *fields_n)
{
    int result = 0;
    struct fieldvec_t *fvec;

    fvec = (struct fieldvec_t *) NL_list_get(fields_to_match, idx);
    if (NULL == fvec) {
        *fields_n = 0;
        *fields = NULL;
        if (idx < 0 || idx >= NL_list_len(fields_to_match)) {
            result = -1;
        }
    }
    else {
        NL_list_T matched;

        matched = match_fields(record, fvec);
        if (NL_list_len(matched) < fvec->n) {
            result = -1;
        }
        else {
            copy_indices(matched, fields, fields_n);
        }
        NL_list_del(matched, free);
    }

    return result;
}

/*
 * Match i-th selector value
 */
int
NL_summseq_selector_equals(T self, unsigned idx,
                           const void *value, unsigned value_n)
{
    int is_equal;

    if (idx < NL_list_len(self->selectors)) {
        struct fieldval_t *fvp = NL_list_get(self->selectors, idx);
        is_equal = (value_n == fvp->value_len) &&
            !memcmp(value, fvp->value, value_n);
    }
    else {
        is_equal = 0;
    }

    return is_equal;
}

void flush_state(NL_hash_T tbl, NL_hash_node_t node, void *vfunc)
{
    ((NL_summseq_flush_fn) vfunc) (node->data);
}


/**
 * Flush
 */
void NL_summseq_flush(T self)
{
    /*
       int i;   
       for (i=0; i < self->states_n; i++) {
       NL_hash_visit(self->states[i], flush_state,
       self->summ.flush_state);
       }
     */
    NL_hash_visit(self->states, flush_state, self->summ.flush_state);
}

 /**
  * Access 'records should not be written' flag
  */
int NL_summseq_get_consume(T self)
{
    return self->consume;
}

/**
 * Return positions for identifiers for selector #pos_in_seq
 * as found in the input record.
 */
int
NL_summseq_get_ids(T self, NL_rec_t * record, int pos_in_seq,
                   unsigned **ids, unsigned *ids_n)
{
    int result;

    if (record == NULL) {
        result = -1;
    }
    else {
        result =
            get_fields(self->id_fields, record, pos_in_seq, ids, ids_n);
    }

    return result;
}

/*
 * Accessor for length of sequence
 */
unsigned NL_summseq_get_len(T self)
{
    return NL_list_len(self->selectors);
}

/*
 * Accessor for Observer-pattern subject for the output record
 */
NL_subject_T NL_summseq_get_output_rec_subject(T self)
{
    return self->output_rec_subject;
}

/*
 * Accessor for parameters
 */
NL_params_T NL_summseq_get_params(T self)
{
    return self->summ.params;
}

/*
 * Get the whole darn state table
 */
struct NL_hash_T *NL_summseq_get_states(T self)
{
    return self->states;
}

/** Accessor for summary function. */
NL_summseq_process_fn NL_summseq_get_summary_fn(T self)
{
    return self->summ.process_record;
}


/*
 * Get summarizer state for instance matching 'identifier'.
 * Pre: NL_summseq_set_summ_info() has been called.
 */
NL_summstate_T
NL_summseq_get_state(T self,
                     const char *identifier,
                     unsigned identifier_len, unsigned *is_new)
{
    NL_summstate_T result;

    *is_new = 0;

    if (NULL == identifier || 0 == identifier_len) {
        result = NULL;        
    }
    else {
        NL_HASH_GET(self->states, identifier, identifier_len, result);
        if (NULL == result) {
            void *istate = self->summ.get_initial_state(self->summ.params);
            result = NL_summstate(self, istate, self->summ.free_state);
            NL_hash_put(self->states, identifier, identifier_len, result,
                        0);
            *is_new = 1;
        }
    }

    return result;
}

/*
 * Return positions for value fields for selector #pos_in_seq
 * as found in the input record.
 */
int
NL_summseq_get_values(T self, NL_rec_t * record, int pos_in_seq,
                      unsigned **values, unsigned *values_n)
{
    int result;

    if (record == NULL) {
        result = -1;
    }
    else {
        result = get_fields(self->value_fields, record, pos_in_seq,
                            values, values_n);
        /* printf("@@ [%d]: %d == get_values, values_n=%d\n", pos_in_seq,
           result, *values_n); */
    }

    return result;
}

/**
 * Return index of (first) selector matching record, or -1 if no match.
 */
int NL_summseq_match_record(T self, NL_rec_t * rec)
{
    void *p;
    struct fieldval_t *fp;
    int i, j, match_idx;

    match_idx = -1;
    if (NULL != rec) {
        /* for each selector field.. */
        for (i = 0, p = NL_list_iter(self->selectors); p;
             i++, p = NL_list_next_node(self->selectors, p)) {
            fp = (struct fieldval_t *) NL_list_node_data(p);
            /* search record for this field and value */
            for (j = 0; j < rec->len; j++) {
                NL_fld_t *fld = rec->fields[j];
                if (fp->name_len == fld->klen &&
                    !memcmp(fld->key, fp->name, fp->name_len) &&
                    fp->value_len == fld->vlen &&
                    !memcmp(fld->value, fp->value, fp->value_len)) {
                    match_idx = i;
                    break;
                }
            }
            if (-1 != match_idx) {
                break;
            }
        }
    }
    return match_idx;
}

/*
 * Set consume/no-consume flag.
 * If not set, default is 0 (no).
 */
void NL_summseq_set_consume(T self, int c)
{
    self->consume = c;
}

/*
 * Set information used to create new summarizer instances.
 */
int
NL_summseq_set_info(T self,
                    NL_params_T params,
                    NL_summseq_init_state_fn init_state,
                    NL_summseq_process_fn process_record,
                    NL_summseq_flush_fn flush_state, NL_free_fn free_state)
{
    int result = 0;

    if (NULL == params || NULL == process_record || NULL == free_state ||
        NULL == init_state) {
        NL_err_add("NULL argument to NL_summseq_set_info");
        result = -1;
    }
    else {
        /* see if init_state with those params returns a non-NULL obj. */
        void *dummy = init_state(params);
        if (NULL == dummy) {
            NL_err_add("init_state failed");
            result = -1;
        }
        else {
            free_state(dummy);         /* free state created above */
            NL_params_del(self->summ.params);
            self->summ.params = params;
            self->summ.get_initial_state = init_state;
            self->summ.free_state = free_state;
            self->summ.process_record = process_record;
            self->summ.flush_state = flush_state;
        }
    } 

    return result;
}

/*
 * Delete everything
 */
void NL_summseq_del(T self)
{
    if (self) {
        NL_hash_del(self->states, (NL_hash_freefn) NL_summstate_del);
        NL_list_del(self->id_fields, fieldvec_free);
        NL_list_del(self->value_fields, fieldvec_free);
        NL_list_del(self->selectors, fieldval_free);
        NL_params_del(self->summ.params);
        free(self);
    }
}

#undef T
