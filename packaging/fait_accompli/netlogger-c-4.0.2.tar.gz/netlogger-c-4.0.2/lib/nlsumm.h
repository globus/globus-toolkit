#ifndef NL_SUMM_H_INCLUDED
#    define NL_SUMM_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/**
 * @file nlsumm.h
 * @brief NetLogger summarization API.
 *
 * NetLogger summarization is a flexible and powerful way to extract the
 * essential information from thousands of logged events per second 
 * without overloading the application or filling up disks.
 *
 * @ingroup nlsumm
 */

#    include "nl.h"

#    ifdef __cplusplus
extern "C" {
#    endif
/*
 * Opaque types
 */ struct nl_ksum_var;
    struct NL_wvar_T;
#    define NL_wvar_T struct NL_wvar_T *
    struct NL_alist_T;
#    define NL_alist_T struct NL_alist_T *
    struct NL_summvisitor_T;
#    define NL_summvisitor_T struct NL_summvisitor_T *
    struct NL_summseq_T;
#    define NL_summseq_T struct NL_summseq_T *

#    define T NL_summ_T
    typedef struct T *T;

/**
 * Constructor.
 *
 * @return NL_summ_T object
 */
    extern T NL_summ(void);

/**
 * Visitor pattern to look at every sequence in the summarizer.
 */
    extern void NL_summ_accept(T self, NL_summvisitor_T visitor);

/**
 * Add a NetLogger log object to be summarized.
 *
 * @pre Log object is initialized.
 * @param self Summarizer object.
 * @param log Log object.
 */
    extern int NL_summ_add_log(T self, NL_log_T log);

/**
 * Add a sequence of events (and associated algorithm) to
 * be summarized.
 *
 * @param self Summarizer object.
 * @param seq Initialized event sequence object.
 */
    extern int NL_summ_add_sequence(T self, NL_summseq_T seq);

/** 
 * Flush all contained summarized event sequences.
 *
 * This is called by the observer of the subject associated
 * with NL_flush(). Therefore, flushing any one of the
 * logs added with NL_summ_add_log() will also flush all
 * the sequences contained in this summarizer.
 *
 * @param self Summarizer object
 * @param ignored The second argument is part of the observer pattern,
 *                but is not needed here. Its value is ignored.
 */
    extern int NL_summ_flush(void *self, void *ignored);

/* this function exists, but should not be called directly:
extern NL_list_T NL_summ_match_record(T self, NL_rec_t *record);
*/

/**
 * Remove log previously added with NL_summ_add_log().
 *
 * @param self Summarizer object
 * @param log Log to remove, which is matched by address
 * @return Success (0), or failure/not-found (-1)
 */
    extern int NL_summ_remove_log(T self, NL_log_T log);

/**
 * Set output destination for summarizer.
 *
 * @pre The NetLogger log is initialized
 * @param self Summarizer object
 * @param log NetLogger output destination
 * @post On NL_summ_del(), this log will be automatically closed.
 */
    extern int NL_summ_set_output(T self, NL_log_T log);

/**
 * Set shared output destination for summarizer.
 *
 * @pre The NetLogger log is initialized
 * @param self Summarizer object
 * @param log NetLogger output destination
 * @post On NL_summ_del(), this log will NOT be automatically closed.
 */
    extern int NL_summ_set_shared_output(T self, NL_log_T log);

/**
 * Destructor.
 *
 * @pre The NetLogger log(s) given to NL_summ_add_log() are still valid
 * @post The NetLogger log(s) given to NL_summ_add_log() are still valid.
 * @post the NetLogger log, if any, given to NL_summ_set_output() is closed.
 * @param self Summarizer object.
 */
    extern void NL_summ_del(T self);

/** @} */

/** @addtogroup nlsummint  NetLogger summarizer internal functions
 * @{ 
 */

/** 
 * Inform summarizer of a new NL_rec_t record.
 *
 * This is called by the observer of the subject associated with
 * new records that are detected during NL_write().
 *
 * @param self Summarizer object
 * @param record Pointer to initialized NetLogger record (NL_rec_t*)
 * @return Success (0) or failure (-1). If failure, this record
 *         will not be summarized in this or subsequent calls to
 *         NL_write().
 */
    extern int NL_summ_new_record(void *self, void *record);

/**
 * Write record to output.
 *
 * This will be called whenever one of the summarizer routines
 * associated with the sequences added by NL_summ_add_sequence()
 * performs output. They all share the same output log.
 *
 * @param self Summarizer object
 * @param rl Pointer to a structure combining a NetLogger record and the logging
 *           level at which it should be written to the output log.
 * @pre The 'rl' parameter contains a valid and non-NULL record
 * @post memory pointed to by rl is freed
 */
    extern int NL_summ_write_record(void *self, void *rl);

#    undef T

#    undef NL_summvisitor_T
#    undef NL_summseq_T
#    undef NL_wvar_T
#    undef NL_alist_T

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
