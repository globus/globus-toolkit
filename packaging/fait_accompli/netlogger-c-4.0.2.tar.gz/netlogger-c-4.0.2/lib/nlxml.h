#ifndef NL_XML_H_INCLUDED
#    define NL_XML_H_INCLUDED
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* 
 * Simple XML library
 */

#    ifdef __cplusplus
extern "C" {
#    endif

#    define T NL_xml_T
    typedef struct T *T;

    T NL_xml();
    const char *NL_xml_get_data(T self);
    const char *NL_xml_get_attr(T self, const char *name);
    int NL_xml_goto(T self, const char *path);
    const char *NL_xml_idx(T self, const char *tag, unsigned i);
    int NL_xml_parse(T self, FILE * infile);
    FILE *NL_xml_set_err(T self, FILE * errfile);
    void NL_xml_del(T self);

#    undef T

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
