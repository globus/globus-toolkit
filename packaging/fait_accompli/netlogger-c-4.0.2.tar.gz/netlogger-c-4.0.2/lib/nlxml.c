/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

/* Tiny XML config file parser */

#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "nlxml.h"

/* extremely sophisticated debugging :-) */
#ifdef DEBUG
#    define DBG(s) fprintf(stderr,"DEBUG: %s\n",s)
#else
#    define DBG(s)
#endif

/* Size limits. Parser should return an error if exceeded. */
#define MAX_TAG  1024                  /* max size of tag name */
#define MAX_TEXT  4096                 /* max size of data */
#define MAX_ATTR_NAME  128             /* max size of attr name */
#define MAX_ATTR_TEXT  1024            /* max size of attr data */
#define MAX_ATTR  16                   /* max # of attrs */
#define MAX_CHILD  128                 /* max # of children */
#define MAX_DEPTH   16                 /* max depth of tree */

/* status codes */
enum status { OK = 0, FILE_EOF = -1, OUT_OF_SPACE = -2, BAD_ATTR = -3,
    TOO_MANY_CHILDREN = -4,
    START_TAG_OPEN = 1, END_TAG_OPEN = 2, COMMENT_OPEN = 3,
    START_END_TAG = 4, END_TAG_CLOSED = 5
};

/* Tree of nodes */
struct node_t;
struct node_t {
    char tag[MAX_TAG];
    char attr[MAX_ATTR][MAX_ATTR_NAME];
    char attr_text[MAX_ATTR][MAX_ATTR_TEXT];
    unsigned attr_n;
    char data[MAX_TEXT];
    struct node_t *children[MAX_CHILD];
    unsigned children_n;
};

/* Location in file */
struct pos_t {
    unsigned char_num, line_num;
    int depth;
};

/* Get next character and update location at the same time */
#define NEXT_CHAR(S,C,PP) do { \
    C = getc_unlocked(S); \
    if (C == '\n') { (PP)->line_num++; (PP)->char_num=1; } \
    else { (PP)->char_num++; } \
} while(0)

/* Internal function declarations */
static int start_tag_open(FILE * f, struct pos_t *pos, char *cp);
static int start_tag_close(FILE * f, char *buf, unsigned sz,
                           struct pos_t *pos);
static int end_tag_close(FILE * f, struct pos_t *pos);
static int comment_close(FILE * f, struct pos_t *pos);
static int end_or_start_tag_open(FILE * f, char *buf, unsigned sz,
                                 struct pos_t *pos);
static char *strip_ws(char *s);
static int set_tag(struct node_t *node, char *s);
static int set_data(struct node_t *node, char *s);
static void report_error(FILE * stream, struct pos_t *pos, int code);
static struct node_t *parse_file(FILE * stream, struct pos_t *pos, char c);
static void print_tree(FILE * stream, struct node_t *node, int indent);

/* -- External API -- */

#define T NL_xml_T

struct T {
    struct node_t *doc;
    struct node_t *path[MAX_DEPTH];
    unsigned path_n;
    char tmp_tag[MAX_TAG + 8];
    FILE *errf;
};

T NL_xml()
{
    T self = (T) malloc(sizeof(struct T));

    self->doc = NULL;
    self->path_n = 0;
    self->errf = NULL;

    return self;
}

static inline struct node_t *cur_node(T self)
{
    return self->path[self->path_n - 1];
}

const char *NL_xml_get_data(T self)
{
    char *result = NULL;

    if (self->path_n > 1) {
        result = cur_node(self)->data;
    }
    return result;
}

const char *NL_xml_get_attr(T self, const char *name)
{
    char *result = NULL;

    if (self->path_n > 1) {
        int i;
        struct node_t *cur = cur_node(self);
        for (i = 0; i < cur->attr_n; i++) {
            if (!strcmp(cur->attr[i], name)) {
                result = cur->attr_text[i];
                break;
            }
        }
    }

    return result;
}

static int navigate(T self, struct node_t *p, const char *path)
{
    unsigned result, i, j, match, eol;
    char *s;

    //printf("@@ navigate: path='%s'\n", path);
    result = 0;
    for (s = (char *) path; *s != '\0' && *s != '/'; s++);
    eol = (*s == '\0');
    *s = '\0';
    if (!strcmp(path, "..")) {
        if (self->path_n > 1) {
            self->path_n--;
            result = navigate(self, cur_node(self), s + 1);
        }
    }
    else {
        int which = 0;          /* default value equiv. to 'first' */
        /* check for [1..N] suffix, assign to 'which' */
        if (*(s - 1) == ']') {
            char *wb, *endptr;
            for (wb = s - 2; wb > path; wb--) {
                if (*wb == '[')
                    break;
            }
            if (*wb == '[') {
                /* parse integer */
                which = strtol(wb + 1, &endptr, 10);
                if (endptr != (s - 1) || which < 1 || which > MAX_CHILD) {
                    goto error;
                }
                *wb = '\0';
            }
        }
        /* look for matching child tag */
        match = -1;
        for (i = 0, j = 0; i < p->children_n; i++) {
            //printf("@@ match '%s' == '%s' #=%d?\n",
            //        path, p->children[i]->tag, which); 
            if (0 == strcmp(p->children[i]->tag, path)) {
                j++;
                if (j >= which) {
                    match = i;
                    break;
                }
            }
        }
        if (-1 == match) {
            goto error;
        }
        /* add child node to path */
        self->path[self->path_n++] = p->children[match];
        /* recurse if more of search string remains */
        if (!eol) {
            result = navigate(self, p->children[match], s + 1);
        }
    }

    return result;

  error:
    return -1;
}

static inline void reset_path(T self)
{
    self->path_n = 1;
    self->path[0] = self->doc;
}

/**
 * Navigate using Xpath subset
 */
int NL_xml_goto(T self, const char *path)
{
    int result = 0;
    char *xpath, *s;

    xpath = s = strdup(path);
    if (path[0] == '/') {
        reset_path(self);
        s++;
    }
    result = navigate(self, cur_node(self), s);
    free(xpath);

    return result;
}

const char *NL_xml_idx(T self, const char *tag, unsigned i)
{
    sprintf(self->tmp_tag, "%s[%u]", tag, i);
    return self->tmp_tag;
}

int NL_xml_parse(T self, FILE * infile)
{
    int result;
    char c;
    struct pos_t pos;
    struct node_t *root;

    pos.char_num = 0;
    pos.line_num = 0;
    pos.depth = 0;

    if (OK != start_tag_open(infile, &pos, &c)) {
        result = -1;
    }
    else {
        root = parse_file(infile, &pos, c);
        if (NULL == root) {
            result = -1;
        }
        else {
            self->doc = malloc(sizeof(struct node_t));
            self->doc->children_n = 1;
            self->doc->children[0] = root;
            reset_path(self);
            result = 0;
        }
    }
    return result;
}

FILE *NL_xml_set_err(T self, FILE * errfile)
{
    FILE *result = self->errf;
    self->errf = errfile;
    return result;
}

void del_subtree(struct node_t *p)
{
    int i;
    for (i = 0; i < p->children_n; i++) {
        del_subtree(p->children[i]);
    }
    free(p);
}

void NL_xml_del(T self)
{
    if (self) {
        if (self->doc) {
            del_subtree(self->doc);
        }
        free(self);
    }
}

#undef T

/* -- Internal function definitions -- */

/**
 * Find open of start tag (skip comments)
 */
static int start_tag_open(FILE * f, struct pos_t *pos, char *cp)
{
    int c, r, done;

    DBG("start_tag_open");
    done = 0;
    do {
        do {
            NEXT_CHAR(f, c, pos);
        }
        while (c != '<' && c != EOF);
        if (c == EOF) {
            r = FILE_EOF;
        }
        else {
            NEXT_CHAR(f, c, pos);
            if (c == '!') {
                r = comment_close(f, pos);

            }
            else {
                *cp = c;
                r = OK;
                done = 1;
            }
        }
    } while (OK == r && !done);

    return r;
}

/**
 * Find close of start tag
 */
static int
start_tag_close(FILE * f, char *buf, unsigned sz, struct pos_t *pos)
{
    int c, r;
    char *p = buf;

    DBG("start_tag_close");
    do {
        NEXT_CHAR(f, c, pos);
        *p++ = c;
        if (p - buf == sz)
            goto out_of_space;
    }
    while (c != '>' && c != EOF);
    if (c == EOF) {
        r = FILE_EOF;
    }
    else {
        if (*(p - 2) == '/') {
            r = START_END_TAG;
            *(p - 2) = '\0';
        }
        else {
            r = OK;
            *(p - 1) = '\0';
        }
    }

    DBG("x start_tag_close");

    return r;

  out_of_space:
    *p = '\0';
    return OUT_OF_SPACE;
}

/**
 * Find close of end tag
 */
static int end_tag_close(FILE * f, struct pos_t *pos)
{
    int c;

    do {
        NEXT_CHAR(f, c, pos);
    }
    while (c != '>' && c != EOF);

    return (c == EOF ? FILE_EOF : OK);
}

/**
 * Find close of comment
 */
static int comment_close(FILE * f, struct pos_t *pos)
{
    int c, done = 0;

    DBG("comment_close");
    do {
        do {
            NEXT_CHAR(f, c, pos);
        }
        while (c != '-' && c != EOF);
        NEXT_CHAR(f, c, pos);
        if (c == '-') {
            NEXT_CHAR(f, c, pos);
            if (c == '>')
                done = 1;
        }
    }
    while (!done && c != EOF);
    DBG("x comment_close");

    return (c == EOF ? FILE_EOF : OK);
}

/**
 * Find end tag or start of child
 */
static int
end_or_start_tag_open(FILE * f, char *buf, unsigned sz, struct pos_t *pos)
{
    int c, r;
    char *p = buf;

    DBG("end_or_start_tag_open");
    do {
        NEXT_CHAR(f, c, pos);
        *p++ = c;
        if (p - buf == sz)
            goto out_of_space;
    }
    while (c != '<' && c != EOF);
    if (c == EOF) {
        r = FILE_EOF;
    }
    else {
        NEXT_CHAR(f, c, pos);
        *p++ = c;
        if (p - buf == sz)
            goto out_of_space;
        switch (c) {
        case '/':
            r = END_TAG_OPEN;
            *(p - 2) = '\0';
            break;
        case '!':
            r = COMMENT_OPEN;
            break;
        default:
            r = START_TAG_OPEN;
            *p = '\0';
        }
    }
    DBG("x end_or_start");

    return r;

  out_of_space:
    *p = '\0';
    return OUT_OF_SPACE;
}

/**
 * Strip leading / trailing whitespace
 */
static char *strip_ws(char *s)
{
    char *p;

    for (p = s + strlen(s) - 1; p >= s && isspace(*p); p--);
    if (p < s) {
        *s = '\0';
        p = s;
    }
    else {
        *(p + 1) = '\0';
        for (p = s; *p && isspace(*p); p++);
    }

    return p;
}

/**
 * Set tag contents in node
 */
static int set_tag(struct node_t *node, char *s)
{
    char *p, *t, *a, c;
    int r;

    r = OK;
    p = strip_ws(s);
    /* tag name */
    for (t = p; *t && !isspace(*t); t++);
    if (!*t) {
        /* done! */
        strcpy(node->tag, p);
    }
    else {
        /* continue on to parse attributes */
        *t = '\0';
        strcpy(node->tag, p);
        p = t + 1;
        /* attributes */
        while (*p) {
            if (isspace(*p)) {
                p++;
            }
            else {
                /* attribute key */
                for (a = p; *a && !isspace(*a) && !(*a == '='); a++);
                if (*a == '\0') {
                    r = BAD_ATTR;
                    goto error;
                }
                c = *a;
                *a = '\0';
                strcpy(node->attr[node->attr_n], p);
                *a = c;
                while ((*a != '=') && *a)
                    a++;
                if (*a == '\0') {
                    r = BAD_ATTR;
                    goto error;
                }
                a++;
                while (*a && isspace(*a))
                    a++;
                if (*a == '\0') {
                    r = BAD_ATTR;
                    goto error;
                }
                /* attribute value */
                if (*a == '"' || *a == '\'') {
                    for (p = a + 1; *p && (*p != *a); p++);
                    if (!*p) {
                        r = BAD_ATTR;
                        goto error;
                    }
                    *p++ = '\0';
                    strcpy(node->attr_text[node->attr_n], a + 1);
                }
                else {
                    for (p = a; *p && !isspace(*p); p++);
                    *p = '\0';
                    strcpy(node->attr_text[node->attr_n], a);
                }
                node->attr_n++;
            }
        }
    }

    return r;
  error:
    return r;
}

/**
 * Set data in node
 */
static int set_data(struct node_t *node, char *s)
{
    char *p;

    p = strip_ws(s);
    DBG("set data from:");
    DBG(p);
    strcpy(node->data, p);

    return OK;
}

/**
 * Report errors
 */
static void report_error(FILE * stream, struct pos_t *pos, int code)
{
    char err_name[40];

    switch (code) {
    case FILE_EOF:
        strcpy(err_name, "end of file");
        break;
    case OUT_OF_SPACE:
        strcpy(err_name, "out of buffer space");
        break;
    case BAD_ATTR:
        strcpy(err_name, "bad attribute");
        break;
    case TOO_MANY_CHILDREN:
        sprintf(err_name, "too many children (%d max)", MAX_CHILD);
        break;
    default:
        sprintf(err_name, "code %d", code);
    }

    fprintf(stream, "Error at (line %u, char %u, depth %d): %s\n",
            pos->line_num, pos->char_num, pos->depth, err_name);
}

/**
 * Parse file
 */
struct node_t *parse_file(FILE * stream, struct pos_t *pos, char c)
{
    const int tag_sz =
        MAX_TAG + MAX_ATTR * (MAX_ATTR_NAME + MAX_ATTR_TEXT);
    char tag_buf[tag_sz + 1];
    const int data_sz = MAX_TEXT;
    char data_buf[data_sz + 1];
    struct node_t *node;
    int r;

    node = NULL;

    if (c) {
        tag_buf[0] = c;
        r = start_tag_close(stream, tag_buf + 1, tag_sz - 1, pos);
    }
    else {
        r = start_tag_close(stream, tag_buf, tag_sz, pos);
    }
    if (r < OK)
        goto error;
    node = calloc(1, sizeof(struct node_t));
    if (OK != set_tag(node, tag_buf))
        goto error;
    if (START_END_TAG != r) {
        do {
            r = end_or_start_tag_open(stream, data_buf, data_sz, pos);
            switch (r) {
            case END_TAG_OPEN:
                if (node->children_n == 0) {
                    r = set_data(node, data_buf);
                    if (OK != r)
                        goto error;
                }
                r = end_tag_close(stream, pos);
                if (OK != r)
                    goto error;
                r = END_TAG_CLOSED;
                break;
            case START_TAG_OPEN:
                if (node->children_n == MAX_CHILD) {
                    r = TOO_MANY_CHILDREN;
                    goto error;
                }
                pos->depth++;
                node->children[node->children_n++] =
                    parse_file(stream, pos,
                               data_buf[strlen(data_buf) - 1]);
                r = OK;
                break;
            case COMMENT_OPEN:
                r = comment_close(stream, pos);
                if (OK != r)
                    goto error;
                break;
            default:
                goto error;
            }
        }
        while (OK == r);
    }
    pos->depth--;

    return node;

  error:
    report_error(stderr, pos, r);
    return NULL;
}

/**
 * Print tree for debugging
 */
void print_tree(FILE * stream, struct node_t *node, int indent)
{
    int i;

    if (indent > 0) {
        for (i = 0; i < indent; i++)
            fprintf(stream, "  ");
    }
    fprintf(stream, "<%s", node->tag);
    for (i = 0; i < node->attr_n; i++) {
        fprintf(stream, " %s='%s'", node->attr[i], node->attr_text[i]);
    }
    fprintf(stream, ">%s", node->data);
    for (i = 0; i < node->children_n; i++) {
        print_tree(stream, node->children[i],
                   indent != -1 ? indent + 1 : -1);
    }
    if (indent > 0 && (node->data[0] || node->children_n > 0)) {
        for (i = 0; i < indent; i++)
            fprintf(stream, "  ");
    }
    fprintf(stream, "</%s>\n", node->tag);
}
