#ifndef NL_TSUMMINT_H_INCLUDED
#    define NL_TSUMMINT_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/

/* Internal summarizer definitions */

#    include "nltsumm.h"
#    include "nlalist.h"
#    include "nlhash.h"
#    include "nlsummrec.h"
#    include "nlsummseq.h"
#    include "nlsummstate.h"
#    include "nlsummvisitor.h"

#endif
