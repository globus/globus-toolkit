/* Doxygen definitions */
/**
 * @defgroup nlapi Logging API
 * @defgroup nlsumm NetLogger summarization API
 * @defgroup nlutil Utility functions
 * @defgroup examples Example files
 */

