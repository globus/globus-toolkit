#ifndef NL_KAHAN_H_INCLUDED
#    define NL_KAHAN_H_INCLUDED
/*
 * Calculate Kahan sum, which is more accurate
 * for long summations particularly of large numbers.
 *
 * Reference: D. Goldberg, 
 *           "What Every Computer Scientist Should Know About Floating-Point Arithmetic
 * available from http://www.validlab.com/goldberg/paper.pdf
 *
 * Usage:
 *   struct nl_ksum_var kv;
 *   nl_ksum_init( &kv, <first value> );
 *   NL_KSUM_ADD( kv, <other values> );
 *   ... many more calls to NL_KSUM_ADD() ...
 *   double result = kv.s;
 */
struct nl_ksum_var {
    double s, c, y, t;
};

extern void nl_ksum_init(struct nl_ksum_var *kvp, double x0);

#    define NL_KSUM_ADD( V, X )           \
    (V).y = X - (V).c;                \
    (V).t = (V).s + (V).y;            \
    (V).c = ( (V).t - (V).s ) - (V).y;\
    (V).s = (V).t;

#endif
