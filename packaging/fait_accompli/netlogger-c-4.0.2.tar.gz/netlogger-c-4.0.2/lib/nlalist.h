#ifndef NL_ALIST_H_INCLUDED
#define NL_ALIST_H_INCLUDED
/* 
   Copyright (c) 2007, The Regents of the University of California, through 
   Lawrence Berkeley National Laboratory (subject to receipt of any required 
   approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#include "nl.h"

/**@file nlalist.h List of items that can be accessed by index or key
 * @ingroup nlutil
 */
/*@{*/

#    ifdef __cplusplus
extern "C" {
#    endif

/**
 * Data with a length
 */
#   define T NL_adata_T
    typedef struct T *T;

/**
 * Constructor
 *
 * @param data Pointer to the data
 * @param len Length of the data
 * @param do_copy 0=no, <other>=yes
 * @return New NL_adata_T object
 */
    extern T NL_adata(void *data, unsigned len, int do_copy);

/**
 * Convenience macro to construct with NUL-terminated string
 */
#define NL_ADATA_STR(S, C) NL_adata((S), strlen(S), (C))


/**
 * Convert to string
 *
 * @param self Data object to convert
 * @param nul_subst Character to substitute for embedded '\0'
 * @return String with same length = length(data) + 1, for trailing '\0',
 *         caller should free when done.
 */
    extern char *NL_adata_as_str(T self, char nul_subst);

/**
 * Compare two data items.
 *
 * @param self First item
 * @param self Second item
 * @return Same semantics as memcmp()
 */
    extern int NL_adata_cmp(T self, T other);

/**
 * Copy a data item
 *
 * @param self Item to copy
 * @return Deep copy of input
 */
    extern T NL_adata_copy(T self);

/**
 * Get a pointer to the value
 *
 * @param self Data object
 * @return Pointer to value; use at own risk
 */
    extern void *NL_adata_get_value(T self);
    
/**
 * Destructor
 *
 * @param self Data object to destroy
 * @post If copy flag to constructor was true, data is also freed
 */
    void NL_adata_del(T self);

#undef T

/**
 * Linked list node with a key and value
 */
#define T NL_anode_T
    typedef struct T *T;

/**
 * Constructor
 *
 * @param key Node's key
 * @param value Node's value
 * @return New node
 */
    extern T NL_anode(NL_adata_T key, NL_adata_T value);

/**
 * Compare two nodes by key
 *
 * @param self Node object
 * @param other Node object
 * @return Same semantics as NL_adata_cmp()
 */
    extern int NL_anode_cmp(T self, T other);

/**
 * Get pointer to key
 *
 * @param self Node object
 * @return Node's key
 */
    extern NL_adata_T NL_anode_get_key(T self);

/**
 * Get pointer to value
 *
 * @param self Node object
 * @return Node's value
 */
    NL_adata_T NL_anode_get_value(T self);

/**
 * Destructor
 *
 * @param self Node object 
 */
    extern void NL_anode_del(T self);

#undef T

/**
 * List that can be accessed by key or index.
 * The indices start at 0.
 */
#define T NL_alist_T
    typedef struct T *T;

/**
 * Constructor
 *
 * @return Empty list object
 */
    extern T NL_alist(void);

/**
 * Append to list
 *
 * @param self List object
 * @param node Node to append
 * @post Node is at end of list
 */
    extern void NL_alist_append(T self, NL_anode_T node);

/**
 * Copy list
 *
 * @param self List object
 * @return Deep copy of input
 */
    extern T NL_alist_copy(T self);

/**
 * Get node at index
 *
 * @param self List object
 * @param index Index of desired node
 * @return Node, or NULL if index is out of range
 */
    extern NL_anode_T NL_alist_get_by_index(T self, uint32_t index);

/**
 * Get node by key
 *
 * @param self List object
 * @param key Key of desired node
 * @return Node, or NULL if no match
 */
    extern NL_anode_T NL_alist_get_by_key(T self, NL_adata_T key);

/**
 * Insert node before index
 * Index can be in the range 0 .. NL_alist_len(), inclusive.
 *
 * @param self List object
 * @param index Index of node to insert before (starting at 0)
 * @param node What to insert
 * @return 0 if OK, -1 on failure  
 */
    extern int NL_alist_insert(T self, uint32_t index, NL_anode_T node);

/**
 * Get list length
 * @param self List object
 * @return Length of list
 */
    extern uint32_t NL_alist_len(T self);

/**
 * Remove a node from the list
 * Node is matched by address, so it should have been returned
 * by NL_alist_get_by_key() or NL_alist_get_by_index(), not be constructed
 * by the user.
 *
 * @param self List object
 * @param node Node to remove
 * @return On success, the same as input, else NULL
 */
    extern NL_anode_T NL_alist_remove(T self, NL_anode_T node);

/**
 * Set list's read-only flag.
 * If true, NL_alist_insert(), NL_alist_append(), NL_alist_remove()
 * will do nothing and return an error.
 *
 * @param self List object
 * @param read_only Flag, 0=false, otherwise true
 */
    extern void NL_alist_set_read_only(T self, unsigned int read_only);

/**
 * Destructor
 *
 * @param self List object
 * @post Every node in list is freed, thus every data item in those
 *       nodes is freed (if its copy flag was true).
 */
    extern void NL_alist_del(T self);

#undef T

/*@}*/

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
