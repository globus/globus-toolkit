#ifndef NL_SUMMVISITOR_H_INCLUDED
#    define NL_SUMMVISITOR_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* 
 * Visitor to a summarizer
 */

#    include "nl.h"

#    ifdef __cplusplus
extern "C" {
#    endif

/* Opaque types */
    struct NL_summseq_T;
#    define NL_summseq_T struct NL_summseq_T *
    struct NL_summstate_T;
#    define NL_summstate_T struct NL_summstate_T *
    struct NL_hash_T;
#    define NL_hash_T struct NL_hash_T *

#    define T NL_summvisitor_T

    struct T;
    typedef struct T *T;

    typedef void (*NL_summvisitor_fn) (T, void *);

    struct T {
        void *data;
        NL_summvisitor_fn visit_summstate;
        NL_summvisitor_fn visit_summseq;
        void (*free_fn) (void *);
    };


/**
 * Constructor
 *
 * @return Summary visitor object
 */
    extern T NL_summvisitor(void);

/**
 * Visit NL_summseq_T, if there is a visit function defined.
 * If no function is defined, nothing is done.
 *
 * @param self Summary visitor object
 * @param data Summary sequence to visit
 */
    extern void NL_summvisitor_visit_summseq(T self, NL_summseq_T data);

/**
 * Visit NL_summstate_T, if there is a visit function defined.
 * If no function is defined, nothing is done.
 *
 * @param self Summary visitor object
 * @param data Summary state to visit
 */
    extern void NL_summvisitor_visit_summstate(T self,
                                               NL_summstate_T data);

/**
 * Walk all the summstate-s in the hash table,
 * calling NL_visit_summstate() for each.
 *
 * @param self Summary visitor object
 * @param table Table to walk
 */
    extern void NL_summvisitor_walk_table(T self, NL_hash_T table);

/**
 * Destructor.
 *
 * If/only-if a 'free-fn' has been provided, delete associated state.
 *
 * @param self Summary visitor object
 */
    extern void NL_summvisitor_del(T self);

#    undef T

#    undef NL_summseq_T
#    undef NL_summstate_T
#    undef NL_hash_T

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
