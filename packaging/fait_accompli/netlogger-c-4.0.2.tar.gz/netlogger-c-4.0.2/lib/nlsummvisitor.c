/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

#include <stdlib.h>                    /* malloc/free */
#include <string.h>                    /* memset */
#include "nlsummvisitor.h"
#include "nlhash.h"
#include "nlsummseq.h"
#include "nlsummstate.h"


#define T NL_summvisitor_T

/*
 * Constructor
 */
T NL_summvisitor(void)
{
    T self = malloc(sizeof(struct T));
    memset(self, 0, sizeof(struct T));
    return self;
}

/*
 * Visit NL_summseq_T (with data)
 */
void NL_summvisitor_visit_summseq(T self, NL_summseq_T data)
{
    if (self->visit_summseq) {
        self->visit_summseq(self, data);
    }
}

/*
 * Visit NL_summstate_T (with data)
 */
void NL_summvisitor_visit_summstate(T self, NL_summstate_T data)
{
    if (self->visit_summstate) {
        self->visit_summstate(self, data);
    }
}

/*
 * Walk through all hash nodes
 */

/* adapter between hash table's iterator and visitor pattern */
static void visit_hash_node(NL_hash_T tbl, NL_hash_node_t node, void *x)
{
    NL_summvisitor_visit_summstate((NL_summvisitor_T) x,
                                   (NL_summstate_T) node->data);
}

/* Called to walk the table */
void NL_summvisitor_walk_table(T self, NL_hash_T table)
{
    NL_hash_visit(table, visit_hash_node, self);
}


/*
 * Destructor.
 *
 * If/only-if a 'free-fn' has been provided, delete associated state.
 */
void NL_summvisitor_del(T self)
{
    if (self) {
        if (self->free_fn) {
            self->free_fn(self->data);
        }
        free(self);
    }
}


#undef T
