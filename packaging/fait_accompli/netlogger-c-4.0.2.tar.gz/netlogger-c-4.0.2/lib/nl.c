/*********************************************************
 * NetLogger 'lite' API, implementation file.
 *********************************************************
 *
 * $Author: dang $
 * $Date: 2007/03/15 23:55:19 $
 */
#ifndef lint
static const volatile char rcsid[] =
    "$Id: nl.c 125 2007-08-21 06:24:25Z dang $";
#endif

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include <ctype.h>
#include <fcntl.h>
#include <limits.h>
#include <math.h>
#include <netdb.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <syslog.h>
#include <unistd.h>
/* BSD net header */
#if HAVE_NETINET_IN_H
#    include <netinet/in.h>
#endif
/* UUID header */
#if HAVE_UUID_UUID_H
#    include <uuid/uuid.h>
#endif
/* time headers */
#if TIME_WITH_SYS_TIME
#    include <sys/time.h>
#    include <time.h>
#else
#    if HAVE_SYS_TIME_H
#        include <sys/time.h>
#    else
#        include <time.h>
#    endif
#endif
/* x-platform fsync w/FreeBSD '-1' test */
#if defined(_POSIX_SYNCHRONIZED_IO) && _POSIX_SYNCHRONIZED_IO != -1
#    define FSYNC(fd) fdatasync(fd)
#else
#    define FSYNC(fd) fsync(fd)
#endif

/* debugging */
/* #define DEBUG 1 */
#include "nldbg.h"
/* #undef DEBUG */
#include "nlstdint.h"
#include "nl.h"
#include "nlint.h"
#include "nlobserver.h"
#include "nlsumm.h"

/*-----------------------------------------------------------
 * Top-level data structure
 */

struct NL_log_T {
    int status;
    NL_level_t level;
    FILE *lvl_fp;
    const char *lvl_file;
    struct timeval lvl_tm;
    struct NL_outp_t *output;
    struct NL_fstrm_t *stream;
    struct NL_rec_t *const_rec;
    char *user_data;
    int user_data_len;
    NL_subject_T flush_subj, newrec_subj;
    NL_smpl_t smpl;
#if NL_THREADED
    pthread_mutex_t mtx;
#endif
};

NL_result_t setconst_ap(NL_log_T, const char *fmt, va_list ap);
typedef void (*NL_setlevel_fn_t) (NL_log_T, NL_level_t);
NL_result_t parse_level(NL_log_T, FILE * fp, NL_setlevel_fn_t);
static int log_should_write(NL_log_T, struct timeval *tv_p,
                            NL_level_t level);
static NL_rec_t *log_build_rec(NL_log_T, struct timeval *tv_p,
                               NL_level_t level, const char *event,
                               const char *fmt, va_list ap);

/*-----------------------------------------------------------
 * Macros/constants
 */

/* File open mode */

#define NL_STATUS_CHECK(S)				\
  if ((S)->status == NL_STATUS_OFF) { return(NL_OK); }
#define NL_STATUS_CHECK_VOID(S)				\
  if ((S)->status == NL_STATUS_OFF) { return; }

/*
 * Convert NL_level_t to standard syslog levels
 */
const int NL_SYSLOG_LEVEL[] =
    { 0, LOG_EMERG, LOG_ERR, LOG_WARNING, LOG_INFO,
    LOG_DEBUG, LOG_DEBUG, LOG_DEBUG, LOG_DEBUG, LOG_DEBUG
};

#define NL_STARTS_WITH(s,x) (strstr(s,x) == s)

/*-----------------------------------------------------------
 * Globals
 */

int NL_flush_on = 0;
mode_t NL_file_mode = 0664;
int NL_file_append = 1;
const char *NL_level_names[] = { NL_STD_LVL_NAMES };
int NL_level_lengths[] = { NL_STD_LVL_LENS };
int NL_env_override = 1;

/*-----------------------------------------------------------
 * Internal (inline) functions
 */

inline int is_file(const char *f)
{
    int fd;

    if (NULL == f)
        return 0;
    fd = open(f, O_RDONLY);
    if (fd > -1) {
        close(fd);
        return 1;
    }
    return 0;
}

/*
 * Return 1 if level allows write, 0 otherwise
 */
inline int
log_should_write(NL_log_T self, struct timeval *tv_p, NL_level_t level)
{
    /* periodically update levels, may affect result */
    if (self->lvl_fp) {
        if ((tv_p->tv_sec - self->lvl_tm.tv_sec +
             (tv_p->tv_usec - self->lvl_tm.tv_usec) / 1e6) > NL_LVL_TM) {
            parse_level(self, self->lvl_fp, NL_set_level);
            self->lvl_tm.tv_sec = tv_p->tv_sec;
            self->lvl_tm.tv_usec = tv_p->tv_usec;
        }
    }
    return (level <= self->level);
}



/*-----------------------------------------------------------
 * High-level Logging API
 */
#define T NL_log_T

/*
 * Create/open logging handle.
 */
T NL_open(const char *url)
{
    T self = NULL;

    if (NULL == (self = calloc(1, sizeof(struct NL_log_T)))) {
        NL_err_add("calloc() failed in NL_log constructor");
        goto error;
    }
    self->level = NL_LVL_INFO;
    /* look for level-config file */
    self->lvl_file = getenv(NL_CFG_ENV);
    if (!is_file(self->lvl_file)) {
        /* no config file; assign default level */
        self->lvl_file = NL_CFG_LVL;
    }
    self->lvl_fp = fopen(self->lvl_file, "r");
    memset(&self->lvl_tm, 0, sizeof(self->lvl_tm));
    self->stream = NL_fstrm();
    self->const_rec = NULL;
    /*
     Use environment variable for output destination,
     if g_nl_env_override is set, or if filename is NULL
    */
    if (NL_env_override || NULL == url) {
        char *env_url;
        if ((env_url = getenv(NL_DEST_ENV)) && env_url[0])
            url = env_url;
        else if ((env_url = getenv(NL_DEST2_ENV)) && env_url[0])
            url = env_url;
    }
    self->output = open_url(url);
    self->status = (self->output == NULL) ? NL_STATUS_OFF : NL_STATUS_ON;
    /* extra user-supplied text to put at the end of a log line  */
    {
        char *s = getenv(NL_EXTRA_ENV);
        if (s) {
            int slen = strlen(s);
            self->user_data_len = slen + NL_FLD_SEP_LEN;
            self->user_data = malloc(self->user_data_len);
            memcpy(self->user_data, NL_FLD_SEP, NL_FLD_SEP_LEN);
            memcpy(self->user_data + NL_FLD_SEP_LEN, s, slen);
        }
    }
    /* observer-pattern subjects for summarizing */
    self->flush_subj = NL_subject();
    self->newrec_subj = NL_subject();
    self->stream->newrec_subj = self->newrec_subj;
    /* sub-sampling vars */
    self->smpl = calloc(1, sizeof(struct NL_smpl_t));
#if NL_THREADED
    pthread_mutex_init(&self->mtx, NULL);
#endif

    return self;

  error:
    NL_err_add("Failed to create handle");
    return NULL;
}

/*
 * Try opening again
 */
int NL_reopen(T self, const char *url)
{
    if (NULL == self) {
        NL_err_add("Attempt to open an invalid handle");
        return -1;
    }
    self->output = open_url(url);
    self->status = (self->output == NULL) ? NL_STATUS_OFF : NL_STATUS_ON; 

    return self->status == NL_STATUS_ON ? 0 : -1;
}
 
/*
 * Check whether handle is valid and open.
 */
int NL_is_active(T self)
{
    return (self && self->status == NL_STATUS_ON);
}

/* 
 * Create 'constant' record for a module.
 */
NL_result_t NL_set_const(T self, const char *fmt, ...)
{
    int err;
    va_list ap;

    va_start(ap, fmt);
    err = setconst_ap(self, fmt, ap);
    va_end(ap);

    return err;
}

/*
 * Set log level
 */
void NL_set_level(T self, NL_level_t level)
{
    self->level = level;
}

NL_level_t NL_get_level(T self)
{
    return self->level;
}

/*
 * Set sampling rate
 */
void NL_set_smpl_rate(T self, double prob_true)
{
    if (prob_true < 0 || prob_true > 1)
        return;
    self->smpl->rate = ((long)((1UL << 31UL) - 1UL)) * prob_true;
}

/*
 * Get whole sampling obj
 */
NL_smpl_t NL_get_smpl(T self)
{
    return self->smpl;
}

/*
 * Shared code block betw. NL_write() and NL_write_ts(), below.
 * Implemented as a macro to not mess with varargs
 */
#define NL_WRITE_TS(tv_p) do {                                          \
    if (!log_should_write(self, (tv_p), level)) goto bottom;            \
    va_start(ap, fmt);                                                  \
    NL_rec_t *rec = log_build_rec(self, (tv_p), level, event, fmt, ap); \
    if (NULL == rec) {                                                  \
        r = NL_ERROR;                                                   \
    }                                                                   \
    else if (0 == rec->consumed) {                                      \
        r = NL_write_rec(self, rec, level);                             \
    }                                                                   \
    else {                                                              \
        r = NL_OK;                                                      \
    }                                                                   \
    va_end(ap);                                                         \
} while(0)

/*
 * Write one log entry
 */
NL_result_t
NL_write(T self, NL_level_t level, const char *event, const char *fmt, ...)
{
    NL_result_t r = NL_OK;
    va_list ap;
    struct timeval tv;

    if (!self || self->level == NL_LVL_NOLOG)
        return r;

    gettimeofday(&tv, NULL);
#if NL_THREADED
    pthread_mutex_lock(&self->mtx);
#endif
    NL_WRITE_TS(&tv);

  bottom:
#if NL_THREADED
    pthread_mutex_unlock(&self->mtx);
#endif
    return r;
}

/*
 * Write one event with user-supplied timestamp
 */
NL_result_t
NL_write_ts(T self, struct timeval * ts,
            NL_level_t level, const char *event, const char *fmt, ...)
{
    NL_result_t r = NL_OK;
    va_list ap;

    if (!self || self->level == NL_LVL_NOLOG)
        goto bottom;

    NL_WRITE_TS(ts);

  bottom:
    return r;
}

/*
 * Flush log
 */
void NL_flush(T self)
{
    NL_subject_notify(self->flush_subj, NULL);
    return;
}

/*
 * Close/delete log
 */
void NL_close(T self)
{
    if (!self)
        return;
    NL_outp_del(self->output);
    NL_fstrm_del(self->stream);
    if (self->lvl_fp)
        fclose(self->lvl_fp);
    NL_subject_del(self->newrec_subj);
    NL_subject_del(self->flush_subj);
    free(self);
}

/*
 * A sprintf-like utility function.
 */
int NL_sprintf(char *buf, const char *event, int level, char *fmt, ...)
{
    NL_fstrm_t *fs_p;
    int len;
    va_list ap;
    NL_rec_t *rec;
    struct timeval tv;

    gettimeofday(&tv, NULL);
    va_start(ap, fmt);
    fs_p = NL_fstrm();
    rec = make_rec(fs_p, &tv, event, level, fmt, ap);
    if (!rec) {
        return -1;
    }
    len = NL_fstrm_fmtrec(fs_p, rec);
    va_end(ap);

    if (len > 0) {
        memcpy(buf, fs_p->buf, len);
		buf[len] = '\0';
    }

    NL_fstrm_del(fs_p);

    return len;
}

NL_rec_t *log_build_rec(T self, struct timeval * tv_p, NL_level_t level,
                        const char *event, const char *fmt, va_list ap)
{
    NL_rec_t *rec;

    rec = make_rec(self->stream, tv_p, event, level, fmt, ap);
    if (!rec)
        NL_err_add("Error creating record");
    return rec;
}


NL_result_t NL_write_rec(T self, NL_rec_t * rec, NL_level_t level)
{
    int nbytes, r;
    struct NL_fstrm_t *fsm = self->stream;
    if (NULL == self->output)
        goto bottom;

    nbytes = NL_fstrm_fmtrec(fsm, rec);
    if (nbytes <= 0) {
        NL_err_add("Error formatting record");
        goto error;
    }
    if (self->user_data) {
        /* insert user_data between the buffer and
         * the record separator
         */
        NL_outp_WRITE(self->output, level, fsm->buf,
                      nbytes - NL_REC_SEP_LEN, r);
        if (r == -1) {
            NL_err_add("Error writing formatted record");
            goto error;
        }
        NL_outp_WRITE(self->output, level,
                      self->user_data, self->user_data_len, r);
        if (r == -1) {
            NL_err_add("Error writing user data");
            goto error;
        }
        NL_outp_WRITE(self->output, level,
                      fsm->buf + nbytes - NL_REC_SEP_LEN, NL_REC_SEP_LEN,
                      r);
        if (r == -1) {
            NL_err_add("Error writing record separator");
            goto error;
        }
    }
    else {
        NL_outp_WRITE(self->output, level, self->stream->buf, nbytes, r);
    }
    if (r == -1) {
        NL_err_add("Error writing formatted record");
        goto error;
    }
  bottom:
    return NL_OK;
  error:
    return NL_ERROR;
}

/*
 * Set constant record.
 */
NL_result_t setconst_ap(T self, const char *fmt, va_list ap)
{
    int i;
    int ival;
    char *sval;
    NL_rec_t *recp;

    if (NULL == (recp = parse_fmt(fmt, NL_rec(NL_MAX_FLD)))) {
        NL_err_add("Creating log constant record failed");
        goto error;
    }

    for (i = 0; i < recp->len; i++) {
        NL_fld_t *fldp = (recp->fields)[i];
        /* Program */
        if (!memcmp(fldp->key, NL_FLD_PROG, NL_FLD_PROG_LEN)) {
            sval = va_arg(ap, char *);
            fldp->vlen = strlen(sval);
            memcpy(fldp->value, sval, fldp->vlen);
        }
        /* Host */
        else if (!memcmp(fldp->key, NL_FLD_HOST, NL_FLD_HOST_LEN)) {
            sval = va_arg(ap, char *);
            if (strlen(sval) == 0)
                sval = NL_get_ipaddr();
            fldp->vlen = strlen(sval);
            memcpy(fldp->value, sval, fldp->vlen);
        }
        /* PID */
        else if (!memcmp(fldp->key, NL_FLD_PID, NL_FLD_PID_LEN)) {
            ival = va_arg(ap, int);
            if (ival < 1)
                ival = getpid();
            memcpy(fldp->value, &ival, sizeof(ival));
        }
        else {
            NL_FLD_SET(fldp, ap);
        }
    }
    if (self->const_rec)
        NL_rec_del(self->const_rec);
    self->const_rec = self->stream->const_rec = recp;

    return NL_OK;

  error:
    if (recp)
        NL_rec_del(recp);
    return NL_ERROR;
}

/*
 * Parse log level from a file, call provided function
 */
NL_result_t parse_level(T self, FILE * fp, NL_setlevel_fn_t set_fn)
{
    char buf[80];
    int len;
    char *p, *endptr;
    NL_level_t level;
    long int tmpval;

    rewind(fp);
    while (fgets(buf, sizeof(buf), fp)) {
        len = strlen(buf);
        if (buf[len - 1] == '\n')
            buf[len - 1] = '\0';
        p = strchr(buf, ' ');
        if (p)
            *p = '\0';
        /* first, the numeric level */
        tmpval = strtol(buf, &endptr, 10);
        if (endptr == buf || tmpval < NL_LVL_NOLOG || tmpval > 127) {
            NL_err_add
                ("Bad level value %d in file '%s'. Must be (int) 0 .. 127",
                 tmpval, self->lvl_file);
            goto error;
        }
        level = (unsigned long) tmpval;
        set_fn(self, level);
    }
    return NL_OK;

  error:
    return NL_ERROR;
}

/*
 * Return subject for observers of new records.
 */
NL_subject_T NL_get_new_record_subject(T self)
{
    return self->newrec_subj;
}

/*
 * Return subject for observers of "flush" events.
 */
NL_subject_T NL_get_flush_subject(T self)
{
    return self->flush_subj;
}


#undef T

/*-----------------------------------------------------------
 * Field 
 */

/* 
 * Constructor 
 *
 * Post: 'key', 'value' may be freed by caller
 */
NL_fld_t *NL_fld(const char *key, int klen, void *value, int vlen,
                 char type)
{
    NL_fld_t *self = NULL;

    /* check the type */
    switch (type) {
    case 'd':
    case 'i':
    case 's':
    case 'l':
    case 't':
    case 'u':
        break;
    default:
        NL_err_add("Bad type code");
        goto error;
    }

    if (NULL == (self = calloc(1, sizeof(NL_fld_t))))
        goto error;

    if (NULL == (self->key = malloc(klen)))
        goto error;
    memcpy(self->key, key, klen);
    self->klen = klen;

    if (NULL == (self->value = malloc(vlen)))
        goto error;
    memcpy(self->value, value, vlen);
    self->vlen = vlen;

    self->type = type;

    return self;

  error:
    NL_fld_del(self);
    return NULL;
}

/*
 * Copy constructor.
 */
NL_fld_t *NL_fld_clone(NL_fld_t * orig)
{
    return NL_fld(orig->key, orig->klen, orig->value, orig->vlen,
                  orig->type);
}

/*
 * Fill in new values for field.
 * Key and value are copied.
 */
void
NL_fld_fill(NL_fld_t * self, const char *key, int klen, void *value,
            int vlen, char type)
{
    memcpy(self->key, key, klen);
    self->klen = klen;
    memcpy(self->value, value, vlen);
    self->vlen = vlen;
    self->type = type;
}

/* 
 * Destructor 
 */
void NL_fld_del(NL_fld_t * self)
{
    if (NULL == self)
        return;

    if (self->key)
        free(self->key);
    if (self->value)
        free(self->value);
    free(self);

    return;
}

/*-----------------------------------------------------------
 * Record 
 */

/* 
 * Constructor 
 *
 * Pre: 'size' is >= 1
 */
NL_rec_t *NL_rec(int size)
{
    NL_rec_t *self = NULL;
    struct timeval tv;

    gettimeofday(&tv, 0);

    if (size < 1)
        goto error;
    if (NULL == (self = calloc(1, sizeof(NL_rec_t))))
        goto error;
    if (NULL == (self->fields = malloc(size * sizeof(NL_fld_t *))))
        goto error;
    if (NULL == (self->is_meta = malloc(size * sizeof(int))))
        goto error;
    self->len = 0;
	self->empty_len = 0;
    self->size = size;
    self->create_tm = tv.tv_sec + tv.tv_usec / 1e6;
    self->hash_index = -1;
    self->update_subj = NL_subject();

    return self;

  error:
    NL_rec_del(self);
    return NULL;
}

/*
 * Allocate all memory for a record.
 * Only put in dummy fields though.
 */
NL_rec_t *NL_rec_empty(int size)
{
    NL_rec_t *rec_p;

    rec_p = NL_rec(size);
    if (rec_p) {
        int i;
        char buf[NL_MAX_STR];

        for (i = 0; i < rec_p->size; i++) {
            rec_p->fields[i] =
                NL_fld(buf, NL_MAX_STR, buf, NL_MAX_STR, NL_string);
        }
		rec_p->empty_len = rec_p->size;
    }
    return rec_p;
}


/* 
 * Add field 
 *
 * Pre: 'fldp' is initialized
 * Post: On success (0), memory of 'fldp' is not owned by caller
 * Return: 0=OK/added, -1=no more space
 */
int NL_rec_add(NL_rec_t * self, NL_fld_t * fldp)
{
    if (self->len == self->size || NULL == fldp) {
        NL_err_add("No more space, or NULL field");
        goto error;
    }
    self->fields[self->len] = fldp;
    self->is_meta[self->len] = 0;
    self->len++;

    return 0;

  error:
    return -1;
}

/* 
 * Add metadata field 
 *
 * Pre: 'fldp' is initialized
 * Post: On success (0), memory of 'fldp' is not owned by caller
 * Return: 0=OK/added, -1=no more space
 */
int NL_rec_add_meta(NL_rec_t * self, NL_fld_t * fldp)
{
    if (self->len == self->size || NULL == fldp) {
        NL_err_add("No more space, or NULL field");
        goto error;
    }
    self->fields[self->len] = fldp;
    self->is_meta[self->len] = 1;
    self->len++;

    return 0;

  error:
    return -1;
}

/*
 * Linear search for a field by name.
 */
NL_fld_t *NL_rec_find_field(NL_rec_t * rec_p, const char *key, int keylen)
{
    NL_fld_t *fp;
    register int i;

    for (i = 0; i < rec_p->len; i++) {
        fp = rec_p->fields[i];
        if (fp->klen == keylen && !memcmp(fp->key, key, keylen)) {
            return fp;
        }
    }
    return NULL;
}

int NL_rec_field_idx(NL_rec_t * rec_p, const char *key, int keylen)
{
    NL_fld_t *fp;
    int i;
    for (i = 0; i < rec_p->len; i++) {
        fp = rec_p->fields[i];
        if (fp->klen == keylen && !memcmp(fp->key, key, keylen)) {
            return i;
        }
    }
    return -1;
}

/* 
 * Destructor 
 */
void NL_rec_del(NL_rec_t * self)
{
    if (NULL == self)
        return;

    if (self->fields) {
        int i;

        for (i = 0; i < MAX(self->len, self->empty_len); i++)
            NL_fld_del(self->fields[i]);
        free(self->fields);
    }
    if (self->is_meta)
        free(self->is_meta);
    free(self);

    return;
}

/*-----------------------------------------------------------
 * Formatting
 */

/* 
 * Constructor 
 */
NL_rfmt_t *NL_rfmt(void)
{
    NL_rfmt_t *self = NULL;

    if (NULL == (self = calloc(1, sizeof(NL_rfmt_t))))
        goto error;

    /* Fill in 'fmt' function ptrs */
    self->fmt['i'] = (void *) NL_fmt_int32;
    self->fmt['l'] = (void *) NL_fmt_longlong;
    self->fmt['d'] = (void *) NL_fmt_double;
    self->fmt['s'] = (void *) NL_fmt_string;
    self->fmt['t'] = (void *) NL_fmt_iso8601;
    self->fmtkey = (void *) NL_fmt_key;
    self->pad_bytes = NL_REC_SEP_LEN;

    /* Optimize date formatting */
    self->dbuf = strdup("2001-01-01T12:01:01.");
    self->fbuf = strdup("123456");
    self->prev_sec = 0;

    return self;

  error:
    NL_rfmt_del(self);
    return NULL;
}


/* 
 * Format a record.
 *
 * Params:
 *    recp - Record to format (or "serialize")
 *    buf, maxlen - Buffer/length to serialize into
 * Pre: 'buf' has >= 'maxlen' bytes
 * Return: 1+=len, 0=out of space, -1=bad input
 */
int
NL_rfmt_format(NL_rfmt_t * self, NL_rec_t * recp, char *buf, size_t maxlen)
{
    int i;
    int offs = 0;
    NL_fld_t *fldp;
    NL_ffmt_fn fn;
    int len;

    /* loop through all fields */
    for (i = 0; i < recp->len; i++) {

        fldp = (recp->fields)[i];

        /* first check that value can be formatted */
        if (NULL == (fn = self->fmt[(int) fldp->type])) {
            NL_err_add("No format function defined for type code");
            goto error;
        }

        /* format the key */
        len = ((NL_ffmt_fn) self->fmtkey) (self, fldp, buf + offs,
                                           maxlen - offs);
        if (len == 0) {
            NL_err_add("Not enough space for key");
            goto error;
        }
        if (len == -1) {
            NL_err_add("Key formatting failed");
            goto error;
        }
        offs += len;

        /* add key/value separator */
        memcpy(buf + offs, NL_KEYVAL_SEP, NL_KEYVAL_SEP_LEN);
        offs += NL_KEYVAL_SEP_LEN;

        /* check for adequate space */
        if ((maxlen - offs) < self->pad_bytes) {
            NL_err_add("Not enough space left for any value");
            goto error;
        }

        /* format value */
        len = ((NL_ffmt_fn) fn) (self, fldp, buf + offs, maxlen - offs);
        if (len < 0) {
            if (len == -2) {
                NL_err_add("Value formatting failed");
                goto error;
            }
            else {
                NL_err_add("%s: offs=%d maxlen=%d idx=%d type=%c",
                           "Not enough space for value", offs, maxlen,
                           i, fldp->type);
                goto error;
            }
        }
        offs += len;

        /* add field separator, except at last field */
        if (i < (recp->len - 1)) {
            memcpy(buf + offs, NL_FLD_SEP, NL_FLD_SEP_LEN);
            offs += NL_FLD_SEP_LEN;
        }

        /* check for adequate space */
        if ((maxlen - offs) < self->pad_bytes) {
            NL_err_add("Not enough space left for any value");
            goto error;
        }
    }
    /* end-of-record marker */
    memcpy(buf + offs, NL_REC_SEP, NL_REC_SEP_LEN);
    offs += NL_REC_SEP_LEN;

    /* return length ( >= 1 ) */
    return offs;

  error:
    /* something very bad happened */
    return -1;
}

/* 
 * Destructor 
 */
void NL_rfmt_del(NL_rfmt_t * self)
{
    if (NULL == self)
        return;

    free(self);

    return;
}

/*
 * Field formatting functions, of type NL_ffmt_fn
 *
 * Naming convention: NL_fmt_<type>
 */

/*
 * Format field's key and datatype
 */
int NL_fmt_key(NL_rfmt_t * self, NL_fld_t * fldp, char *buf, int maxlen)
{
    register int offs = 0;

    if (maxlen < NL_TYPE_PPLEN + fldp->klen)
        return 0;

    switch (NL_TYPE_FIRST) {
    case 1:                           /* type, then key */
        /* datatype */
        if (NL_TYPE_PRE)
            buf[offs++] = NL_TYPE_PRE;
        buf[offs++] = fldp->type;
        if (NL_TYPE_POST)
            buf[offs++] = NL_TYPE_POST;
        /* key */
        memcpy(buf + offs, fldp->key, fldp->klen);
        offs += fldp->klen;
        break;
    case 0:                           /* key, then type */
        /* key */
        memcpy(buf + offs, fldp->key, fldp->klen);
        offs += fldp->klen;
        /* datatype */
        if (NL_TYPE_PRE)
            buf[offs++] = NL_TYPE_PRE;
        buf[offs++] = fldp->type;
        if (NL_TYPE_POST)
            buf[offs++] = NL_TYPE_POST;
    case -1:                          /* just key, no type */
        /* key */
        memcpy(buf + offs, fldp->key, fldp->klen);
        offs += fldp->klen;
        break;
    default:
        NL_err_add("Bad value for NL_TYPE_FIRST");
        offs = 0;
    }
    return offs;
}

/* all possible powers of 10 for 32 bit ints */
int32_t POW10_32[] =
    { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000,
    1000000000
};

/* all possible powers of 10 for 64 bit ints */
int64_t POW10_64[] =
    { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000,
    1000000000, 10000000000LL, 100000000000LL,
    1000000000000LL, 10000000000000LL, 100000000000000LL,
    1000000000000000LL, 10000000000000000LL,
    100000000000000000LL, 1000000000000000000LL,
};

/*
 * Format a 32-bit integer
 */
int NL_fmt_int32(NL_rfmt_t * self, NL_fld_t * fldp, char *buf, int maxlen)
{
    register int val = *((int *) fldp->value);
    register int neg;
    register int ndigits;
    register int p;

    if (maxlen < 2) {
        NL_err_add("Cannot put int into buffer of size < 2");
        goto out_of_space;
    }

    /* special case for '0' */
    if (val == 0) {
        buf[0] = '0';
        buf[1] = '\0';
        return 1;
    }
    /* use abs(val), remember if negative */
    if (val < 0) {
        val = -val;
        neg = 1;
    }
    else
        neg = 0;
    /* count digits */
    for (ndigits = 1; (ndigits < 10) && (val >= POW10_32[ndigits]);
         ndigits++);
    if (ndigits + 1 + neg > maxlen) {
        NL_err_add("Not enough space for integer digits");
        goto out_of_space;
    }
    buf[ndigits + neg] = '\0';
    /* place digits */
    for (p = ndigits + neg; p > neg; val /= 10, p--)
        buf[p - 1] = '0' + (val % 10);
    /* if negative, show it */
    if (neg)
        buf[0] = '-';

    return ndigits + neg;

  out_of_space:
    return -1;
}

/*
 * Format a long long (64-bit?) integer
 */
int
NL_fmt_longlong(NL_rfmt_t * self, NL_fld_t * fldp, char *buf, int maxlen)
{
    register int neg;
    register int ndigits;
    register int p;
    long long val = *((long long *) fldp->value);

    if (maxlen < 2) {
        NL_err_add("Cannot put long long into buffer of size < 2");
        goto out_of_space;
    }

    /* special case for '0' */
    if (val == 0) {
        buf[0] = '0';
        buf[1] = '\0';
        return 1;
    }
    /* use abs(val), remember if negative */
    if (val < 0) {
        val = -val;
        neg = 1;
    }
    else {
        neg = 0;
    }
    /* count digits */
    for (ndigits = 1; (ndigits < 20) && (val >= POW10_64[ndigits]);
         ndigits++);
    if (ndigits + 1 + neg > maxlen) {
        NL_err_add("Not enough space for long long digits");
        goto out_of_space;
    }
    buf[ndigits + neg] = '\0';
    /* place digits */
    for (p = ndigits + neg; p > neg; val /= 10L, p--)
        buf[p - 1] = '0' + (val % 10L);
    /* if negative, show it */
    if (neg) {
        buf[0] = '-';
    }

    return ndigits + neg;

  out_of_space:
    return -1;
}

/*
 * Format a double.
 */
int NL_fmt_double(NL_rfmt_t * self, NL_fld_t * fldp, char *buf, int maxlen)
{
    return snprintf(buf, maxlen, "%lf", *((double *) fldp->value));
}

/*
 * Format a string of bytes (NUL-terminated?)
 */
int NL_fmt_string(NL_rfmt_t * self, NL_fld_t * fldp, char *buf, int maxlen)
{
    int result = 0;
    /* stored value len <==> formatted length */
    if (maxlen < fldp->vlen)
        return -1;
#if NL_QUOTE_SPC
    {
        int i, has_spc;
        /* look for embedded whitespace */
        for (i = 0, has_spc = 0; i < fldp->vlen; i++) {
            char c = ((char *) fldp->value)[i];
            if (c == ' ' || c == '\t') {
                has_spc = 1;
                break;
            }
        }
        /* if found, quote the string */
        if (has_spc) {
            /* first re-check space limits */
            if (maxlen < fldp->vlen + 2)
                return -1;
            buf[0] = NL_QUOTE_CHAR;
            memcpy(buf + 1, fldp->value, fldp->vlen);
            buf[fldp->vlen + 1] = NL_QUOTE_CHAR;
            result = fldp->vlen + 2;
        }
        else {
            /* otherwise, just copy as before */
            memcpy(buf, fldp->value, fldp->vlen);
            result = fldp->vlen;
        }
    }
#else
    memcpy(buf, fldp->value, fldp->vlen);
    result = fldp->vlen;
#endif
    return result;
}

/*
 * Format a date per ISO 8601
 *
 * Input: struct timeval
 * Output: YYYY-MM-DDThh:mm:ss.<fractional>
 */
int
NL_fmt_iso8601(NL_rfmt_t * self, NL_fld_t * fldp, char *buf, int maxlen)
{
    time_t sec;
#ifdef NL_SUSECONDS
    suseconds_t usec;
#else                           /* Non-POSIX (ie FreeBSD & Mac OS/X) hack */
    long usec;
#endif
    int i;

    if (maxlen < 27) {
        goto out_of_space;
    }

    /* copy & rename the date */
    sec = ((struct timeval *) fldp->value)->tv_sec;
    usec = ((struct timeval *) fldp->value)->tv_usec;

    /* use previous date string if seconds are the same */
    if (sec != self->prev_sec) {
        struct tm *tm_p;

        if (NULL == (tm_p = gmtime((time_t *) & sec)))
            goto error;
        if (0 == strftime(self->dbuf, 21, "%Y-%m-%dT%H:%M:%S.", tm_p))
            goto error;
        self->prev_sec = sec;
    }

    /* copy into return buffer */
    memcpy(buf, self->dbuf, 20);

    /* add in microseconds */
    for (i = 0; i < 6; i++) {
        buf[25 - i] = '0' + (usec % 10);
        usec /= 10;
    }

    /* add 'Z' */
    buf[26] = 'Z';

    return 27;

  out_of_space:
    return -1;
  error:
    return -2;
}

/*-----------------------------------------------------------
 * Generic output
 */

/*
 * Constructor
 */
NL_outp_t *NL_outp(void)
{
    NL_outp_t *self = calloc(1, sizeof(NL_outp_t));
    return self;
}

/*
 * Delete output object
 */
void NL_outp_del(NL_outp_t * self)
{
    if (NULL == self)
        return;
    if (self->statep)
        self->close(self->statep);
    free(self);
}

/*-----------------------------------------------------------
 * Concrete output factories / functions
 */

/*
 * File descriptor write 
 */
size_t NL_fd_write(void *statep, int level, const char *buf, size_t len)
{
    NL_fd_state *fdp = (NL_fd_state *) statep;
    size_t r, rtot;

    for (rtot = 0; rtot < len; rtot += r) {
        r = write(fdp->fd, buf + rtot, len - rtot);
        if (r < 0) {
            rtot = r;
            break;
        }
    }
    if (rtot == len && NL_flush_on)
        FSYNC(fdp->fd);
    return rtot;
}

/*
 * File descriptor close
 */
void NL_fd_close(void *statep)
{
    NL_fd_state *fdp = (NL_fd_state *) statep;

    if (fdp->fd != STDOUT_FILENO && fdp->fd != STDERR_FILENO) {
        close(fdp->fd);
    }
    free(fdp->name);
    free(fdp);
}

/*
 * Make new file output
 */
NL_outp_t *NL_ofile(const char *filename)
{
    NL_outp_t *outp;
    NL_fd_state *statep;
    int fd;

    if (NULL == (outp = NL_outp())) {
        NL_err_add("Creating ofile failed");
        return NULL;
    }

    /* open output -> 'fd' */
    if (!strcmp(filename, "&"))
        fd = STDERR_FILENO;
    else if (!strcmp(filename, "-"))
        fd = STDOUT_FILENO;
    else {
        int oflags = O_WRONLY | O_CREAT;
        if (NL_file_append)
            oflags |= O_APPEND;
        if (-1 == (fd = open(filename, oflags, NL_file_mode))) {
            NL_err_add("File open failed: %s", strerror(errno));
            return NULL;
        }
    }

    statep = malloc(sizeof(NL_fd_state));
    statep->fd = fd;
    statep->name = strdup(filename);

    outp->statep = statep;
    outp->write = NL_fd_write;
    outp->close = NL_fd_close;

    return outp;
}

/*
 * Make new socket output
 *
 * Params:
 *    rhost - Remote host name
 *    port - Remote port
 *    udp - Flag, 1=UDP and 0=TCP
 */
NL_outp_t *NL_osock(const char *rhost, unsigned short port, char udp)
{
    NL_outp_t *outp = NULL;
    NL_fd_state *statep;
    int fd;
    struct hostent *hp = NULL;
    struct sockaddr_in address;

    if (NULL == (outp = NL_outp())) {
        NL_err_add("Creating output failed");
        goto error;
    }
    /* create a socket */
    if (udp) {
        fd = socket(AF_INET, SOCK_DGRAM, 0);
    }
    else {
        fd = socket(AF_INET, SOCK_STREAM, 0);
    }
    if (fd < 0) {
        NL_err_add("Error creating socket: %s", strerror(errno));
        goto error;
    }

    /* init address structure */
    memset((void *) &address, 0, sizeof(address));
    hp = gethostbyname(rhost);
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = ((struct in_addr *) (hp->h_addr))->s_addr;
    address.sin_port = htons(port);
    /* connect to host */
    if (connect(fd, (struct sockaddr *) &address, sizeof(address)) == -1) {
        NL_err_add("Error connecting to remote host: %s", strerror(errno));
        goto error;
    }
    /* store stuff in state */
    statep = malloc(sizeof(NL_fd_state));
    statep->name = strdup(rhost);
    statep->fd = fd;
    /* finish output obj */
    outp->statep = statep;
    outp->write = NL_fd_write;
    outp->close = NL_fd_close;

    return outp;

  error:
    NL_outp_del(outp);
    return NULL;
}


/* Syslog state */
struct syslog_state {
    int facility;
};


/*
 * Go from
 *
 * t DATE: 2006-12-16T00:21:19.114142
 * s LVL: INFO
 * s EVNT: nlwrite.event
 * d val: 100.0
 * s why: I said so
 *
 * to
 *
 * date=2006-12-16T00:21:19.114142Z level=INFO event=nlwrite.event \
 * val=100.0 why="I said so"
 *
 */
int NL_reformat_for_syslog(const char *buf, int n, char **s_p)
{
#define FINDCHAR(S,C,P) for((P)=(S);*(P) != (C);(P)++);
#define FINDCHAR_SPC(S,C,P,A) for((P)=(S);*(P) != (C);(P)++) { \
    (A) = (A) || (*(P) == ' '); }
    char *p1;                   /* position in input */
    char *p2;                   /* position in outpu */
    char *q;                    /* temporary variable */
    const char *p1e;
    unsigned char date = 0, event = 0, level = 0;
    char typecode;
    int x;

    p1 = (char *) buf;
    p1e = buf + n;
    p2 = *s_p = calloc(2 * n, 1);
    while (*p1 != '\n') {
        typecode = *p1;
        p1 += 2;                       /* skip space after typecode, too */
        /* DATE 
         * For string dates, append a 'Z'
         * For doubles, just copy. 
         */
        if (!date && ((p1e - p1) > 5) && *p1 == 'D'
            && !memcmp(p1, "DATE:", 5)) {
            p1 += 6;
            memcpy(p2, "ts=", 3);
            p2 += 5;
            FINDCHAR(p1, '\n', q);
            x = q - p1;
            memcpy(p2, p1, x);
            p1 += x + 1;               /* 1 more for newline */
            p2 += x;
            /* append explicit Zulu timezone for string dates */
            if (typecode == 't' || typecode == 'T')
                *p2++ = 'Z';
            date = 1;
        }
        /* EVNT */
        else if (!event && (p1e - p1) > 5 && *(p1) == 'E' &&
                 !memcmp(p1, "EVNT:", 5)) {
            p1 += 6;
            memcpy(p2, "event=", 6);
            p2 += 6;
            FINDCHAR(p1, '\n', q);
            x = q - p1;
            memcpy(p2, p1, x);
            p1 += x + 1;               /* 1 more for newline */
            p2 += x;
            event = 1;
        }
        /* LVL */
        else if (!level && (p1e - p1) > 4 && *(p1) == 'L' &&
                 !memcmp(p1, "LVL:", 4)) {
            p1 += 5;
            memcpy(p2, "level=", 6);
            p2 += 6;
            FINDCHAR(p1, '\n', q);
            x = q - p1;
            memcpy(p2, p1, x);
            p1 += x + 1;               /* 1 more for newline */
            p2 += x;
            level = 1;
        }
        /* all other fields */
        else {
            unsigned char spc = 0;
            /* copy name */
            FINDCHAR(p1, ':', q);
            x = q - p1;
            memcpy(p2, p1, x);
            p2 += x;
            p1 = q + 2;                /* skip ':' and space */
            *p2++ = '=';
            /* copy value */
            if (typecode == 's') {
                FINDCHAR_SPC(p1, '\n', q, spc)
            }
            else {
                FINDCHAR(p1, '\n', q);
            }
            if (spc)
                *p2++ = '"';
            x = q - p1;
            memcpy(p2, p1, x);
            p1 += x + 1;               /* 1 more for newline */
            p2 += x;
            if (spc)
                *p2++ = '"';
        }
        *p2++ = ' ';                   /* space before next field */
    }
    *(p2 - 1) = 0;

    return (p2 - *s_p);
}

/*
 * Syslog write 
 */
size_t
NL_syslog_write(void *statep, int level, const char *buf, size_t len)
{
    struct syslog_state *sp = (struct syslog_state *) statep;
    int new_len = len;

    if (len < 1)
        return 0;

/* only bother with this if we're using multi-line netlogger fmt */
#if NL_FMT_PARAM == 1
    if ((new_len = NL_reformat_for_syslog(buf, len, &str)) > 0) {
        syslog(sp->facility | NL_SYSLOG_LEVEL[level], str);
        free(str);
    }
#else
    syslog(sp->facility | NL_SYSLOG_LEVEL[level], buf);
#endif
    return new_len;
}

/*
 * Syslog close
 */
void NL_syslog_close(void *statep)
{
    closelog();
}

/*
 * Make new syslog output
 *
 * Params:
 *    facility - Syslog facility
 */
NL_outp_t *NL_osyslog(char *prog, int facility)
{
    NL_outp_t *outp = NULL;
    struct syslog_state *statep = NULL;

    if (NULL == (outp = NL_outp())) {
        NL_err_add("Creating output failed");
        goto error;
    }
    openlog(prog, 0, facility);
    statep = malloc(sizeof(struct syslog_state));
    statep->facility = facility;
    outp->statep = statep;
    outp->write = NL_syslog_write;
    outp->close = NL_syslog_close;

    return outp;

  error:
    NL_outp_del(outp);
    return NULL;
}

/*-----------------------------------------------------------
 * Formatting stream
 */

/*
 * Constructor
 */
NL_fstrm_t *NL_fstrm(void)
{
    NL_fstrm_t *self = NULL;

    if (NULL == (self = calloc(1, sizeof(NL_fstrm_t))))
        goto error;
    /*self->rectbl = nl_rectbl_new(NULL);*/
	self->rectbl = nl_rectbl_new((NL_free_fn)NL_rec_del);
    self->fmtp = NL_rfmt();
    self->buflen = 64 * 1024 - 1;
    if (NULL == (self->buf = (char *) malloc(self->buflen + 1)))
        goto error;
    if (NULL == (self->const_rec = NL_rec(NL_MAX_FLD / 2)))
        goto error;
    self->newrec_subj = NULL;
    return self;

  error:
    NL_fstrm_del(self);
    return NULL;
}

/*
 * Build and return template record with
 * constant values filled in
 */
NL_rec_t *NL_fstrm_constrec(NL_fstrm_t * self, const char *event)
{
    int result;
    NL_rec_t *recp = NULL;
    int i;
    char sval[NL_MAX_STR];

    recp = NL_rec(NL_MAX_FLD - (self->const_rec->len + NL_numfld));
    if (NULL == recp) {
        NL_err_add("Failed to create new record");
        goto error;
    }

    /* add standard fields, in whatever order */
    for (i = 0; i < NL_numfld; i++) {
        if (NL_dtfld == i)
            NL_rec_add(recp, NL_fld(NL_FLD_DATE, NL_FLD_DATE_LEN, sval,
                                    sizeof(struct timeval), NL_time));
        else if (NL_lvlfld == i)
            NL_rec_add(recp, NL_fld(NL_FLD_LVL, NL_FLD_LVL_LEN, sval,
                                    NL_MAX_STR, NL_string));
        else if (NL_evfld == i)
            NL_rec_add_meta(recp, NL_fld(NL_FLD_EVENT, NL_FLD_EVENT_LEN,
                                         (void *) event, strlen(event),
                                         NL_string));
    }
    /* add 'constant' fields */
    for (i = 0; i < self->const_rec->len; i++) {
        result = NL_rec_add_meta(recp,
                                 NL_fld_clone(self->const_rec->fields[i]));
        if (-1 == result) {
            NL_err_add("Failed to add constant field");
            goto error;
        }
    }

    return recp;

  error:
    NL_rec_del(recp);
    return NULL;
}

/*
 * Create record from varargs input.
 */
NL_rec_t *make_rec(NL_fstrm_t * self,
                   struct timeval * tv_p,
                   const char *event, int level, const char *fmt,
                   va_list ap)
{
    NL_rec_t *recp;
    const char *lname;
    int llen;

    if (NULL == (recp = NL_fstrm_getrec(self, tv_p, event, fmt))) {
        NL_err_add("Could not get cached record from table");
        goto error;
    }
    /* put in level */
    if (level < NL_LVL_USER) {
        lname = NL_level_names[level];
        llen = NL_level_lengths[level];
    }
    else {
        lname = NL_STD_LVL_NAME_USER;
        llen = 4;
    }
    memcpy(recp->fields[NL_lvlfld]->value, lname, llen);
    recp->fields[NL_lvlfld]->vlen = llen;

    /* put real values into record */
    set_values(recp, ap, NL_numfld + self->const_rec->len);

    /* tell observers about new value */
    recp->consumed = 0;
    NL_subject_notify(recp->update_subj, recp);

    return recp;

  error:
    return NULL;
}

/*
 * Format a completed record
 */
int NL_fstrm_fmtrec(NL_fstrm_t * self, NL_rec_t * recp)
{
    int len;

    if (0 >=
        (len =
         NL_rfmt_format(self->fmtp, recp, self->buf, self->buflen))) {
        NL_err_add("Formatting record failed");
        return len;
    }

    self->buf[len] = '\0';

    return len;
}

/*
 * Get record for event, or create it according to 'fmt'
 */
NL_rec_t *NL_fstrm_getrec(NL_fstrm_t * self, struct timeval * tv_p,
                          const char *event, const char *fmt)
{
    NL_rec_t *recp;
    register int elen = strlen(event);

    recp = nl_rectbl_get(self->rectbl, event, elen);
    /* XXX: Note: add 'safe mode' here 

       if (  recp && nl_safe_mode ) {
       if ( ! same_format( fmt, recp ) ) {
       remove-recp-from table
       delete recp
       recp = NULL
       ..now next clause will create new record..
       }
       }
     */
    if (NULL == recp) {
        recp = NL_fstrm_constrec(self, event);
        if (NULL == recp) {
            NL_err_add("Failed to build constant part of record");
            goto error;
        }
        recp = parse_fmt(fmt, recp);
        if (NULL == recp) {
            NL_err_add("Failed to parse format string");
            goto error;
        }
        nl_rectbl_put(self->rectbl, event, elen, recp,
                      &(recp->hash_index));
        recp->create_tm = tv_p->tv_sec + tv_p->tv_usec / 1e6;
        if (self->newrec_subj) {
            NL_subject_notify(self->newrec_subj, recp);
        }
    }

    /* put in time */
    memcpy(recp->fields[NL_dtfld]->value, tv_p, sizeof(struct timeval));

    return recp;

  error:
    return NULL;
}

/*
 * Destructor
 */
void NL_fstrm_del(NL_fstrm_t * self)
{
    if (!self)
        return;

    nl_rectbl_del(self->rectbl);
    NL_rfmt_del(self->fmtp);
    if (self->buf)
        free(self->buf);
	if (self->const_rec)
		NL_rec_del(self->const_rec);
    free(self);

    return;
}

/*
 * Internal functions for NL_fstrm
 */

/*
 * Parse format string, create new record
 */
NL_rec_t *parse_fmt(const char *fmt, NL_rec_t * recp)
{
    const char *p = NULL;
    int pstate;
    const char *kstart = NULL;
    int klen = 0;
    char type;
    int result;
    NL_fld_t *fldp = NULL;
    /* vararg fake val */
    char sval[NL_MAX_STR];

    if (!fmt)
        return recp;

    for (p = fmt, pstate = 0; *p;) {
        /* whitespace */
        if (pstate == 0) {
            if (!isspace(*p)) {
                kstart = p;
                pstate = 1;
            }
            p++;
        }
        /* key */
        else if (pstate == 1) {
            if (*p == ':' || *p == '=') {
                klen = p - kstart;
                pstate = 2;
            }
            p++;
        }
        /* everything else */
        else {
            int meta = 0;

            /* grab type code */
            type = *p++;
            /* ignore up to next whitespace */
            while (*p && isspace(*p))
                p++;
            /* put key, dummy value, type into field */
            switch (type) {
            case NL_double_meta:
                meta = 1;
            case NL_double:
                fldp = NL_fld(kstart, klen, sval, sizeof(double), 'd');
                break;
            case NL_int_meta:
                meta = 1;
            case NL_int:
                fldp = NL_fld(kstart, klen, sval, sizeof(int), 'i');
                break;
            case NL_long_meta:
                meta = 1;
            case NL_long:
                fldp = NL_fld(kstart, klen, sval, sizeof(long long), 'l');
                break;
            case NL_string_meta:
                meta = 1;
            case NL_string:
                fldp = NL_fld(kstart, klen, sval, NL_MAX_STR, 's');
                break;
            }
            /* add field to record */
            if (meta)
                result = NL_rec_add_meta(recp, fldp);
            else
                result = NL_rec_add(recp, fldp);
            if (result == -1)
                goto error;
            /* reset to parse next pair */
            pstate = 0;
        }
    }

    return recp;

  error:
    return NULL;
}

/*
 * Set (non-metadata) values in record from varargs values.
 */
void set_values(NL_rec_t * recp, va_list ap, int offs)
{
    int i;

    for (i = offs; i < recp->len; i++) {
        NL_FLD_SET(recp->fields[i], ap);
    }
}

/*-----------------------------------------------------------
 * Utility functions
 */

#if HAVE_UUID_UUID_H
/*
 * Get a GUID.
 */
int NL_get_guid(char **rbuf)
{
    const int len = 36;
    uuid_t uu;

    if (NULL == (*rbuf = malloc(len + 1)))
        return -1;

    uuid_generate(uu);
    uuid_unparse(uu, *rbuf);

    return len;
}
#else
/*
 * Get a GUID.
 */
int NL_get_guid(char **rbuf)
{
    const int len = 36;
    FILE *pipe;

    if (0 == system(NULL))
        return -1;
    pipe = popen("uuidgen", "r");
    if (pipe == NULL)
        return -1;
    *rbuf = malloc(len + 1);
    fflush(pipe);
    if (NULL == fgets(*rbuf, len + 1, pipe)) {
        free(*rbuf);
        return -1;
    }
    if (pclose(pipe) < 0) {
        free(*rbuf);
        return -1;
    }
    return strlen(*rbuf);
}
#endif

/*
 * Get a pale imitation of a GUID
 */
int NL_get_someid(char **buf)
{
    struct timeval tv;
    int pid;
    struct hostent *he_p = NULL;
    char local_name[1024];
    unsigned char addr[4] = { 0, 0, 0, 0 };

    /* get the local host name (probably does not include the domain) */
    if (gethostname(local_name, sizeof(local_name)) < 0)
        strcpy(local_name, "localhost");
    /* look up the IP address from the name server */
    if ((he_p = gethostbyname(local_name)) == NULL)
        addr[0] = (unsigned char) 127;
    else
        memcpy(addr, he_p->h_addr, 4);
    /* more entropy with pid and time of day */
    gettimeofday(&tv, 0);
    pid = getpid();
    /* stuff into buffer */
    *buf = malloc(36);
    return
        sprintf(*buf, "%.8lX-%.8lX-%.8lX-%.8lX", (long unsigned int) addr,
                (long unsigned int) pid, (long unsigned int) tv.tv_sec,
                (long unsigned int) tv.tv_usec);
}

/* Level name <=> code */

const char *NL_get_level_name(NL_level_t level)
{
    return NL_level_names[level];
}

NL_level_t NL_get_level_code(const char *name)
{
    int i, result;

    for (result = -1, i = NL_LVL_NOLOG; i < NL_LVL_USER; i++) {
        if (!strcasecmp(name, NL_level_names[i])) {
            result = i;
            break;
        }
    }

    return result;
}

/*
 * Lookup dotted-decimal IP addr of this host.
 */
char *NL_get_ipaddr(void)
{
    struct hostent *he_p = NULL;
    char local_name[1024];
    char *buf = NULL;

    buf = (char *) calloc(1, sizeof(local_name));

    /* get the local host name (probably does not include the domain) */
    if (gethostname(local_name, sizeof(local_name)) < 0) {
        strcpy(local_name, "localhost");
    }

    /* now lookup the IP address from the name server */
    if ((he_p = gethostbyname(local_name)) == NULL) {
        strcpy(buf, "127.0.0.1");
    }
    else {
        /* copy primary interface IP into return val */
        sprintf(buf, "%u.%u.%u.%u",
                (unsigned char) he_p->h_addr[0],
                (unsigned char) he_p->h_addr[1],
                (unsigned char) he_p->h_addr[2],
                (unsigned char) he_p->h_addr[3]);
    }

    return buf;
}


/* Open a netlogger URL */
NL_outp_t *open_url(const char *url)
{
    NL_outp_t *output = NULL;
    char *urlc = NULL, *p = NULL;

    if (!url)
        return NULL;

    /* copy url so we can modify it */
    urlc = strdup(url);
    /* strip potential crap off end */
    if ((p = strrchr(urlc, '?'))) {
        *p = '\0';
    }
    /* TCP or UDP */
    if (NL_STARTS_WITH(urlc, "x-netlog://") ||
        NL_STARTS_WITH(urlc, "x-netlog-udp://")) {
        char *host, *endptr;
        unsigned short port;
        char udp;
        int offs;

        udp = NL_STARTS_WITH(urlc, "x-netlog-udp://");
        offs = (udp ? 15 : 11);
        if ((p = strchr(urlc + offs, ':'))) {
            *p = '\0';
            host = urlc + offs;
            port = strtol(p + 1, &endptr, 10);
            if (endptr == p + 1) {
                NL_err_add("Socket port %d is not a number", port);
                goto error;
            }
        }
        else {
            host = urlc + offs;
            port = NL_DEFAULT_PORT;
        }
        if (NULL == (output = NL_osock(host, port, udp))) {
            NL_err_add("Could not open %s socket to host '%s' port %u",
                       (udp ? "UDP" : "TCP"), host, port);
            goto error;
        }
    }
    else if (NL_STARTS_WITH(urlc, "x-syslog://")) {
        char *program = NULL;
        int facility;
        split_syslog_url(urlc, &program, &facility);
        if (NULL == (output = NL_osyslog(program, facility))) {
            NL_err_add("Could not open syslog (LOG_USER) for output");
            goto error;
        }
    }
    else {
        if (NULL == (output = NL_ofile(urlc))) {
            NL_err_add("Could not open file '%s' for output", urlc);
            goto error;
        }
    }
    return output;

  error:
    if (urlc)
        free(urlc);
    return NULL;
}

/*
 * Extract program and facility from URL.
 *
 * INPUT: "x-syslog://[FACILITY:]PROGRAM"
 *
 * Where FACILITY is one of the standard syslog macro
 * names, case-insensitive and without the LOG_ prefix.
 * For example "FTP", "Local0", and "syslog" are all valid.
 * The default facility is USER (LOG_USER).
 *
 * OUTPUT: prog points to the program name, facility is set.
 */
void split_syslog_url(char *url, char **prog, int *facility)
{
    const char sep = ':';
    const char *extra;
    char *p;

    *facility = LOG_USER;
    extra = url + 11;
    /* look for separator */
    for (p = (char *) extra; *p && *p != sep; p++);
    /* no separator, then it's all program name. we're done. */
    if (!*p) {
        *prog = (char *) extra;
    }
    /* set the separator to '\0' and parse the facility name */
    else {
        *prog = p + 1;
        *p = '\0';                     /* for strcmp */
        /* parse facility, fail quietly */
        /* Note: Python code to generate the following::
           a = ['AUTH', 'AUTHPRIV', 'CRON', 'DAEMON', 'FTP', 'LOCAL0', 'LOCAL1', 'LOCAL2', 'LOCAL3', 'LOCAL4', 'LOCAL5', 'LOCAL6', 'LOCAL7', 'LPR', 'MAIL', 'NEWS', 'SYSLOG', 'USER', 'UUCP'] ; print '\n'.join(['else if (!strcasecmp(extra,"%s"))\n    *facility = LOG_%s;' % (s,s) for s in a])
         */
        if (!strcasecmp(extra, "AUTH"))
            *facility = LOG_AUTH;
        else if (!strcasecmp(extra, "AUTHPRIV"))
            *facility = LOG_AUTHPRIV;
        else if (!strcasecmp(extra, "CRON"))
            *facility = LOG_CRON;
        else if (!strcasecmp(extra, "DAEMON"))
            *facility = LOG_DAEMON;
        else if (!strcasecmp(extra, "FTP"))
            *facility = LOG_FTP;
        else if (!strcasecmp(extra, "LOCAL0"))
            *facility = LOG_LOCAL0;
        else if (!strcasecmp(extra, "LOCAL1"))
            *facility = LOG_LOCAL1;
        else if (!strcasecmp(extra, "LOCAL2"))
            *facility = LOG_LOCAL2;
        else if (!strcasecmp(extra, "LOCAL3"))
            *facility = LOG_LOCAL3;
        else if (!strcasecmp(extra, "LOCAL4"))
            *facility = LOG_LOCAL4;
        else if (!strcasecmp(extra, "LOCAL5"))
            *facility = LOG_LOCAL5;
        else if (!strcasecmp(extra, "LOCAL6"))
            *facility = LOG_LOCAL6;
        else if (!strcasecmp(extra, "LOCAL7"))
            *facility = LOG_LOCAL7;
        else if (!strcasecmp(extra, "LPR"))
            *facility = LOG_LPR;
        else if (!strcasecmp(extra, "MAIL"))
            *facility = LOG_MAIL;
        else if (!strcasecmp(extra, "NEWS"))
            *facility = LOG_NEWS;
        else if (!strcasecmp(extra, "SYSLOG"))
            *facility = LOG_SYSLOG;
        else if (!strcasecmp(extra, "USER"))
            *facility = LOG_USER;
        else if (!strcasecmp(extra, "UUCP"))
            *facility = LOG_UUCP;
        /* put back separator where NUL was */
        *p = sep;
    }
}

#undef NL_STARTS_WITH
