#ifndef NL_TRANSFER_H_INCLUDED
#    define NL_TRANSFER_H_INCLUDED
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/**
 * @file nltransfer.h Facade for file-transfer tasks using summarizer API
 * @defgroup nltransfer NetLogger 'transfer' API
 */
/*@{*/

#include <math.h> /* NAN */
#    include "nlsumm.h"

#    ifdef __cplusplus
extern "C" {
#    endif

/**
 * Different types of operations.
 * These are passed to NL_transfer_start() and NL_transfer_end().
 */
    typedef enum {
        NL_TRANSFER_DISK_READ = 0,
        NL_TRANSFER_DISK_WRITE = 1,
        NL_TRANSFER_NET_READ = 2,
        NL_TRANSFER_NET_WRITE = 3,
        NL_TRANSFER_NOEVENT = 4        /* sentinel */
    } NL_transfer_op_t;

/**
 * Due to some portability issues, this simpler way to define
 * a non-number is used. Its primary use is in NL_transfer_result_t,
 * where ratios and values in the result are set to NAN if there
 * were no actual bytes read for that stream+operation.
 */
#    ifndef NAN
#        define NAN (-1e307)
#    endif

/** Type of a stream identifier */
    typedef unsigned long long NL_transfer_streamid_t;

/** Type of a block identifier */
    typedef unsigned long long NL_transfer_blockid_t;

/**
 * Summary result of a given operation for a given stream.
 * 
 * - time_ : statistics for time between start and end of an operation.
 *   This is "instantaneous" time, i.e. not including the gap
 *   between the end of one operation and the start of the next. 
 *
 * - value_ : statistics for value of end event, i.e. number of bytes.
 *   These will be NAN if value_count is 0.
 *
 * - ratio_ : statistics for ratio of value/time for each event.
 *   In general, ratio_<foo> is NOT the same as (value_<foo> / time_<foo>).
 *   These will be NAN if value_count is 0.
 *
 * - counts: How many start/end pairs are being summarized, and of those
 *  how many had a valid value, above 0 (bytes).
 */
    typedef struct {
        double time_min,
                     /**< minimum time */
         time_max,   /**< maximum time */
         time_sum,   /**< total of all times (not incl. gap) */
         time_mean,   /**< time_sum / count */
         time_sd,   /**< one standard deviation; mean for multiple streams */
         time_sd_sum,   /**< for multiple streams, total of stdev for each */
         time_var,   /**< variance; mean for multiple streams */
         time_var_sum;   /**< for multiple streams, total variance */
        double value_min,
                      /**< minimum value */
         value_max,   /**< maximum value */
         value_sum,   /**< total of all values */
         value_mean,   /**< value_sum / value_count */
         value_sd,   /**< one standard deviation; mean for multiple streams */
         value_sd_sum,   /**< for multiple streams, total of stdev for each */
         value_var,   /**< variance; mean for multiple streams */
         value_var_sum;   /**< for multiple streams, total variance */
        double ratio_min,
                      /**< minimum ratio */
         ratio_max,   /**< maximum ratio */
         ratio_sum,   /**< sum of all ratios */
         ratio_mean,   /**< sum / value_count */
         ratio_sd,   /**< stdev; mean for multiple */
         ratio_sd_sum,   /**< stdev sum across all streams */
         ratio_var,   /**< variance; mean for multiple streams */
         ratio_var_sum;   /**< for multiple streams, total variance */
        int64_t count,
                   /**< Number of start/end intervals being summarized */
         value_count;     /**< Number of intervals that had a non-zero value */
        double duration;
                     /**< Time between first start and last end */
         NL_transfer_streamid_t stream_id; /**< Numeric 'stream' identifier */
    } NL_transfer_result_t;

/**
 * Possible locations for a bottleneck
 */
    typedef enum {
        NL_BTL_DISK_READ,       /**< disk read */
        NL_BTL_DISK_WRITE,      /**< disk write */
        NL_BTL_DISK_WRITE_MAYBE,/**< maybe disk write */
        NL_BTL_NET,             /**< the friggin' network */
        
    } NL_transfer_btloc_t;

/**
 * Whether a bottleneck was determined and, if not, why.
 * Note that zero is 'yes', non-zero is 'no'.
 */
    typedef enum {
        NL_BTL_KNOWN = 0,       /**< yes, got it! */
        NL_BTL_UNKNOWN,         /**< can't figure it out */
        NL_BTL_MISSING_DATA,    /**< missing one or more results */
        NL_BTL_BAD_DATA,        /**< results don't make sense */
        NL_BTL_SYSERR,          /**< system error (e.g. malloc failed) */
    } NL_transfer_btresult_t;

/**
 * Bottleneck detection result
 */
    typedef struct {
        NL_transfer_btresult_t result;  /**< whether bottleneck was found */
        NL_transfer_btloc_t location;   /**< where bottleneck is */
		double *inst_thru; /**< instantaneous throuhgput for each operation */
    } NL_transfer_btl_t;
    
/**
 * Initialize summarizer.
 *
 * Specifically, set up summarizer to handle the NL_TRANSFER events.
 * Global summarizer parameters, like the summary log output level and
 * destination, are the caller's responsibility.
 * 
 * @param summ Summarizer object
 * @param interval Summarization interval in microseconds, where
 *                 less than or equal to zero means indefinitely
 * @param level NetLogger log level for summarization events
 * @return 0=success, -1=failure
 */
    int NL_transfer_init(NL_summ_T summ, int64_t interval,
                         NL_level_t level);

/**
 * Allow transfer events to 'pass through' to the
 * log object, so that at the proper log level they will get
 * logged in all their gory detail.
 *
 * @param summ Summarizer object
 */
    void NL_transfer_set_passthrough(NL_summ_T summ);

/**
 * Indicate start of operation for a given stream.
 *
 * @param log Log object
 * @param level Loglevel for transfer event
 * @param operation Code indicating read/write from disk or network
 * @param guid Globally Unique Identifier, such as a DCE UUID.
 * @param stream_id Stream number, starting at 1. Stream id's of 0 are a noop.
 * @param block_id Data block identifier, whose meaning is user-defined
 */
    void NL_transfer_start(NL_log_T log,
                           NL_level_t level,
                           NL_transfer_op_t operation,
                           const char *guid,
                           NL_transfer_streamid_t stream_id,
                           NL_transfer_blockid_t block_id);
/**
 * Indicate start of operation for a given stream,
 * with a user-supplied timestamp.
 *
 * @param log Log object
 * @param ts User-supplied timestamp
 * @param level Loglevel for transfer event
 * @param operation Code indicating read/write from disk or network
 * @param guid Globally Unique Identifier, such as a DCE UUID.
 * @param stream_id Stream number, starting at 1. Stream id's of 0 are a noop.
 * @param block_id Data block identifier, whose meaning is user-defined
 */
    void NL_transfer_start_ts(NL_log_T log,
                              struct timeval *ts,
                              NL_level_t level,
                              NL_transfer_op_t operation,
                              const char *guid,
                              NL_transfer_streamid_t stream_id,
                              NL_transfer_blockid_t block_id);

/**
 * Indicate end of operation for a given stream.
 *
 * @param log Log object
 * @param level Loglevel for transfer event
 * @param operation Code indicating read/write from disk or network
 * @param guid Globally Unique Identifier, such as a DCE UUID.
 * @param stream_id Stream number, starting at 1. Stream id's of 0 are a noop.
 * @param block_id Data block identifier, whose meaning is user-defined
 * @param bytes Number of bytes read or written. Negative values mean failure
 */
    void NL_transfer_end(NL_log_T log,
                         NL_level_t level,
                         NL_transfer_op_t operation,
                         const char *guid,
                         NL_transfer_streamid_t stream_id,
                         NL_transfer_blockid_t block_id, double bytes);

/**
 * Finalize summarizer.
 * This is important to do before NL_transfer_get_results(),
 * especially for interval == 0.
 *
 * @param summ Summarizer object
 */
    void NL_transfer_finalize(NL_summ_T summ);

/**
 * Get number of distinct streams for a given operation.
 *
 * @param summ Summarizer object
 * @param operation Code indicating read/write from disk or network
 * @param guid GUID value to match, or NULL for 'any'
 * @return Number of streams, 0 means "none yet".
 */
    unsigned NL_transfer_get_num_streams(NL_summ_T summ,
                                         NL_transfer_op_t operation,
                                         const char *guid);

/**
 * Get result for given stream and operation. 
 *
 * For stream matching, if stream_pos >= 0, it is used to
 * pull out the i-th matching stream. Otherwise, stream_id is
 * used to match the stream identifier exactly, except if
 * stream_id is 0 (and stream_pos < 0) then all streams are aggregated.
 *
 * @param summ Summarizer object
 * @param operation Code indicating read/write from disk or network
 * @param guid GUID value to match, or NULL for 'any'
 * @param stream_pos Stream position, starting at 0
 * @param stream_id Stream identifier
 * @param resultp Pointer to space for results; allocated and owned by caller.
 * @return num_streams (1 or many if stream_id==0) on succcess, -1 on failure 
 */
    int NL_transfer_get_result(NL_summ_T summ,
                               NL_transfer_op_t operation,
                               const char *guid,
                               int stream_pos,
                               NL_transfer_streamid_t stream_id,
                               NL_transfer_result_t * resultp);

/**
 * Get result for all operations, all streams as a string.
 *                                                 
 * @param summ Summarizer object
 * @param guid GUID value to match, or NULL for 'any'
 * @return String value or NULL on error.
 */
    char *NL_transfer_get_result_string(NL_summ_T summ,
                                        const char *guid);

/**
 * Deduce bottleneck from combined result strings.
 * The result strings should come from NL_transfer_get_result_string().
 * Successful return from this function does not mean that
 * a bottleneck was determined; the caller must check that, first, the
 * bottleneck.result is NL_BTL_FOUND. If it is, then the 
 * location will be one of disk read, disk write or network as enumerated
 * in bottleneck.location. Otherwise, whether the bottleneck could not be
 * determined, or whether data was missing or in error will be indicated
 * by the enumeration in bottleneck.result.
 *
 * For convenience, parameters for two result strings (one from each
 * endpoint) are provided. Either one of these may be incomplete, empty,
 * or NULL -- they are just concatenated.
 * 
 * @param result1 Result string from one endpoint
 * @param result2 Result string from the other endpoint
 * @param bottleneck Returned bottleneck
 * @return 0 for success understanding the results, -1 for failure
 */
    int NL_transfer_get_bottleneck(const char *result1,
                                   const char *result2,
                                   NL_transfer_btl_t *bottleneck);

/**
 * Convenience function to stringify bottleneck.
 *
 * @param bp Bottleneck determined by NL_transfer_get_bottleneck()
 * @return Heap-allocated string describing where bottleneck is.
 */
    char * NL_transfer_bottleneck_str(NL_transfer_btl_t *bp);

/**
 * Convenience function to name an operation.
 *
 * @param op Operation code
 * @return Name of operation, as plain readable English
 */
	const char *NL_transfer_op_name(NL_transfer_op_t op);
/*@}*/

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
