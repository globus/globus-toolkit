/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] =
    "$Id: nltsumm.c 130 2007-08-22 14:09:32Z dang $";

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include "nldbg.h"
#include "nlerr.h"
#include "nlint.h"
#include "nlparams.h"
#include "nlsummseq.h"
#include "nlsummstate.h"
#include "nltsumm.h"
#include "nltsummint.h"

#define NOTIME ((int64_t)-1)

#ifndef NAN
#    define NAN (-1e307)
#endif

/* -- Internal functions -- */

static inline void clear_stats(struct tsumm_stats *statsp)
{
    /* counters */
    statsp->n = 0;
    statsp->nv = 0;
    statsp->dur = 0.;
    /* sums */
    nl_ksum_init(&statsp->t_s, 0.0);
    nl_ksum_init(&statsp->v_s, 0.0);
    nl_ksum_init(&statsp->r_s, 0.0);
    /* min/max */
    statsp->v_m = DBL_MAX;
    statsp->t_m = DBL_MAX;
    statsp->r_m = DBL_MAX;
    statsp->v_x = DBL_MIN;
    statsp->t_x = DBL_MIN;
    statsp->r_x = DBL_MIN;
    /* variance */
    NL_wvar_clear(statsp->t_v);
    NL_wvar_clear(statsp->v_v);
    NL_wvar_clear(statsp->r_v);
}

static inline void create_rec(struct tsumm_data *d, NL_summstate_T state)
{
    NL_rec_t *rec;
    double dd = 0.;
    long long ll = 0LL;
    struct timeval tt;
    int i;

    rec = NL_rec(15 + NL_numfld + state->id_fields_n);
    /* add standard fields, in whatever order */
    for (i = 0; i < NL_numfld; i++) {
        if (NL_dtfld == i) {
            NL_rec_add(rec, NL_fld(NL_FLD_DATE, NL_FLD_DATE_LEN, &tt,
                                   sizeof(struct timeval), NL_time));
        }
        else if (NL_lvlfld == i) {
            const char *level = NL_level_names[d->output_level];
            NL_rec_add(rec, NL_fld(NL_FLD_LVL, NL_FLD_LVL_LEN,
                                   (void *) level, strlen(level),
                                   NL_string));
        }
        else if (NL_evfld == i) {
            const char *event = d->output_event;
            NL_rec_add_meta(rec, NL_fld(NL_FLD_EVENT, NL_FLD_EVENT_LEN,
                                        (void *) event, strlen(event),
                                        NL_string));
        }
    }
    /* add id's as metadata fields (since they don't change) */
    for (i = 0; i < state->id_fields_n; i++) {
        NL_rec_add_meta(rec, NL_fld_clone(state->id_fields[i]));
    }
    /* counts */
    NL_rec_add(rec, NL_fld("n", 1, &ll, sizeof(long long), NL_long));
    NL_rec_add(rec, NL_fld("nv", 2, &ll, sizeof(long long), NL_long));
    NL_rec_add(rec, NL_fld("dur", 3, &dd, sizeof(double), NL_double));
    /* time */
    NL_rec_add(rec, NL_fld("t.m", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("t.x", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("t.s", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("t.sd", 4, &dd, sizeof(double), NL_double));
    /* value */
    NL_rec_add(rec, NL_fld("v.m", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("v.x", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("v.s", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("v.sd", 4, &dd, sizeof(double), NL_double));
    /* ratio */
    NL_rec_add(rec, NL_fld("r.m", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("r.x", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("r.s", 3, &dd, sizeof(double), NL_double));
    NL_rec_add(rec, NL_fld("r.sd", 4, &dd, sizeof(double), NL_double));

    d->rec = rec;
}

static inline void fill_rec(struct tsumm_data *d, 
                            struct tsumm_stats *statsp,
                            NL_summstate_T state)
{
    struct timeval tv;
    NL_rec_t *rec;
    double time_sd, value_sd, ratio_sd;
    register int i;

    if (NULL == d->rec) {
        create_rec(d, state);
        /* printf("@@ created -> record(%p)\n", d->rec); */
    }
    rec = d->rec;
    /* timestamp */
    if (statsp->summ_usec == NOTIME) {
        /* no actual information in this summary event! */
        tv.tv_sec = 0;
        tv.tv_usec = 0;
    }
    else {
        tv.tv_sec = (int) (statsp->summ_usec / 1000000.0);
        tv.tv_usec = statsp->summ_usec - tv.tv_sec * 1000000;
    }
    memcpy(rec->fields[NL_dtfld]->value, &tv, sizeof(struct timeval));

    /* get standard deviations */
    time_sd = NL_wvar_sd(statsp->t_v);
    value_sd = NL_wvar_sd(statsp->v_v);
    ratio_sd = NL_wvar_sd(statsp->r_v);
    /* counts + duration */
    i = state->id_fields_n + NL_numfld;
    memcpy(rec->fields[i++]->value, &statsp->n, sizeof(long long));
    memcpy(rec->fields[i++]->value, &statsp->nv, sizeof(long long));
    memcpy(rec->fields[i++]->value, &statsp->dur, sizeof(double));
    /* time */
    memcpy(rec->fields[i++]->value, &statsp->t_m, sizeof(double));
    memcpy(rec->fields[i++]->value, &statsp->t_x, sizeof(double));
    memcpy(rec->fields[i++]->value, &statsp->t_s.s, sizeof(double));
    memcpy(rec->fields[i++]->value, &time_sd, sizeof(double));
    /* value */
    if (statsp->v_m == DBL_MAX)
        statsp->v_m = NAN;
    if (statsp->v_x == DBL_MIN)
        statsp->v_x = NAN;
    memcpy(rec->fields[i++]->value, &statsp->v_m, sizeof(double));
    memcpy(rec->fields[i++]->value, &statsp->v_x, sizeof(double));
    memcpy(rec->fields[i++]->value, &statsp->v_s.s, sizeof(double));
    memcpy(rec->fields[i++]->value, &value_sd, sizeof(double));
    /* ratio */
    if (statsp->r_m == DBL_MAX)
        statsp->r_m = NAN;
    if (statsp->r_x == DBL_MIN)
        statsp->r_x = NAN;
    memcpy(rec->fields[i++]->value, &statsp->r_m, sizeof(double));
    memcpy(rec->fields[i++]->value, &statsp->r_x, sizeof(double));
    memcpy(rec->fields[i++]->value, &statsp->r_s.s, sizeof(double));
    memcpy(rec->fields[i++]->value, &ratio_sd, sizeof(double));
}

/*
 * If new data has been registered since last call,
 * calculate stats and output a record. Otherwise, do nothing.
 */
static inline int do_summarize(struct tsumm_data *d,
                               struct tsumm_stats *statsp,
                               NL_summstate_T state)
{
    int result;

    if (statsp->dur > 0) {
        /* already summarized, no new data */
        result = 0;
        goto bottom;
    }

    if (statsp->nv == 0) {
        /* no values, set value-stats to NAN */
        statsp->v_s.s = NAN;
        statsp->v_m = NAN;
        statsp->v_x = NAN;
        /* also set ratio-stats to NAN */
        statsp->r_s.s = statsp->r_m = statsp->r_x = NAN;
    }
    if (statsp->t_s.s < DBL_EPSILON) {
        /* no time passed, set these stats to NAN */
        statsp->t_s.s = NAN;
        statsp->t_m = NAN;
        statsp->t_x = NAN;
        /* also set ratio-stats to NAN */
        statsp->r_s.s = statsp->r_m = statsp->r_x = NAN;
    }
    statsp->dur = (double) (state->ts_usec - statsp->summ_usec) / 1e6;
    /* printf("@@ record(%p) cur_usec=%lld - summ_usec=%lld / 1e6 = %lf\n",
       d->rec, state->ts_usec, statsp->summ_usec, statsp->dur); */
    /* Fill in values */
    fill_rec(d, statsp, state);
    /* Write record */
    result = NL_summstate_write_record(state, d->rec, d->output_level);
    /* Update summarization time */
    statsp->summ_usec = NOTIME; /*NO! state->ts_usec*/;

  bottom:
    return result;
}


/* -- External functions -- */

/* 
 * Initialize state
 */
void *NL_tsumm_init(NL_params_T params)
{
    struct tsumm_data *data = NULL;
    char *e, *lvl;
    int i;

    if (NULL == params)
        goto error;

    data = (struct tsumm_data *) calloc(1, sizeof(struct tsumm_data));
    
    /*
     * init parameters
     */
    if (-1 == NL_params_get_int64(params, NLTSUMM_P_INTERVAL, 
                &data->interval_usec)) {
        NL_err_add("Missing parameter " NLTSUMM_P_INTERVAL);
        goto error;
    }
    if (-1 == NL_params_get_double(params, NLTSUMM_P_MIN, &data->min_val)) {
        data->min_val = 0;
    }
    if (-1 == NL_params_get_double(params, NLTSUMM_P_MAX, &data->max_val)) {
        data->max_val = 0;
    }
    if (data->max_val < data->min_val) {
        NL_err_add("Maximum value < minimum value");
        goto error;
    }
    data->filter_value = !(data->min_val == data->max_val);
    NL_params_get_int32(params, NLTSUMM_P_VARBASE,
                        &data->variance_baseline);
    if (data->variance_baseline < 0) {
        NL_err_add("Negative variance baseline");
        goto error;
    }
    if (-1 == NL_params_get_string(params, NLTSUMM_P_EVENT, &e)) {
        NL_err_add("Missing output event");
        goto error;
    }
    data->output_event = (const char *)e;
    data->output_event_len = strlen(e);
    if (-1 == NL_params_get_string(params, NLTSUMM_P_LVL, &lvl))
        lvl = NLTSUMM_D_LVL;
    data->output_level = NL_get_level_code(lvl);
    if (data->output_level == (NL_level_t) - 1) {
        NL_err_add("Invalid output log level");
        goto error;
    }

    /* 
     * init statistics
    */
    /* timekeeping */
    data->start_usec = NOTIME;
    data->prev_usec = NOTIME;
    /* reset all values */
    for (i=0; i < 2; i++) {
        struct tsumm_stats *statsp = data->stats + i;
        /* allocate variance structs */
        statsp->t_v = NL_wvar_new(data->variance_baseline);
        statsp->v_v = NL_wvar_new(data->variance_baseline);
        statsp->r_v = NL_wvar_new(data->variance_baseline);
        statsp->summ_usec = NOTIME;
        clear_stats(statsp);
    }
    /* output record will be created on first use */
    data->rec = NULL;

    return data;

  error:
    if (data)
        free(data);
    return NULL;
}

/*
 * Process a record. 
 */
int NL_tsumm_process(NL_summstate_T state)
{
    int i, result = 0;
    struct tsumm_data *d = (struct tsumm_data *) state->data;

    if (d->stats[0].dur > 0 /* summarized */ ) {
        clear_stats(&d->stats[0]);
    }
    if (NOTIME == d->start_usec) {
        /* waiting for first event in sequence */
        if (0 == state->pos) {
            /* got first event in sequence */
            d->start_usec = state->ts_usec;
            /* if not set, initialize summarized-since to this time */
            for (i=0; i < 2; i++) {
                if (NOTIME == d->stats[i].summ_usec)
                    d->stats[i].summ_usec = state->ts_usec;
            }
        }
    }
    /* waiting for last event in sequence */
    else if (state->pos == state->sequence_len - 1) {
        /* got last event in sequence */
        register double ddt;    /* (double) delta time */
        ddt = (state->ts_usec - d->start_usec) / 1e6;
        for (i=0; i < 2; i++) {
            struct tsumm_stats *statsp = d->stats + i;
            NL_KSUM_ADD(statsp->t_s, ddt);
            statsp->t_m = MIN(statsp->t_m, ddt);
            statsp->t_x = MAX(statsp->t_x, ddt);
            NL_wvar_add(statsp->t_v, ddt);
            statsp->n++;
            if (state->values_n > 0) {
                /* ignore all values but first */
                register double val, ratio;
                val = state->values[0];
                if (!d->filter_value
                    || (val >= d->min_val && val <= d->max_val)) {
                    /* update value statistics */
                    NL_KSUM_ADD(statsp->v_s, val);
                    statsp->v_m = MIN(statsp->v_m, val);
                    statsp->v_x = MAX(statsp->v_x, val);
                    NL_wvar_add(statsp->v_v, val);
                    /* update ratio statistics */
                    ratio = val / ddt;
                    NL_KSUM_ADD(statsp->r_s, ratio);
                    statsp->r_m = MIN(statsp->r_m, ratio);
                    statsp->r_x = MAX(statsp->r_x, ratio);
                    NL_wvar_add(statsp->r_v, ratio);
                    /* incr. number of values */
                    statsp->nv++;
                }
            }
        }
        d->prev_usec = state->ts_usec;
        /* check (for stats[0], the interval one) if should summarize */
        if (d->interval_usec > 0 &&
            state->ts_usec - d->stats[0].summ_usec >= d->interval_usec) {
            result = do_summarize(d, &d->stats[0], state);
        }
        d->start_usec = NOTIME;        /* start waiting for 1st again */
    }

    return result;
}

/*
 * Flush current state. 
 */
void NL_tsumm_flush(NL_summstate_T state)
{
    struct tsumm_data *d = (struct tsumm_data *)state->data;
    
    if (d->interval_usec > 0) {
        do_summarize(d, &d->stats[0], state);
    }
    do_summarize(d, &d->stats[1], state);
}

/*
 * Free the 'data', i.e. struct tsumm_data.
 */
void NL_tsumm_free_data(void *data)
{
    int i;
    struct tsumm_data *d = (struct tsumm_data *) data;

    if (d) {
        free((char *) d->output_event);
        for (i=0; i < 2; i++) {
            NL_wvar_del(d->stats[i].t_v);
            NL_wvar_del(d->stats[i].v_v);
            NL_wvar_del(d->stats[i].r_v);
        }
        if (d->rec)
            NL_rec_del(d->rec);
        free(d);
    }
}

#undef NOTIME
