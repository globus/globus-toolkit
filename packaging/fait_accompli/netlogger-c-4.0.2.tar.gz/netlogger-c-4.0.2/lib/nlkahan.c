/*
 * Calculate Kahan sum, which is more accurate
 * for long summations particularly of large numbers.
 * See header file for details.
 */
static const char rcsid[] =
    "$Id: nlkahan.c 121 2007-08-19 23:19:37Z dang $";

#include "nlkahan.h"

void nl_ksum_init(struct nl_ksum_var *kvp, double x0)
{
    kvp->s = x0;
    kvp->c = 0;
}
