/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
  Container for summarized event sequences.
  This is in a sense the root object for the summarizer functions.
 */
static const volatile char rcsid[] =
    "$Id: nlsumm.c 128 2007-08-21 21:49:45Z dang $";

#include <stdlib.h>

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "nlsumm.h"
#include "nlint.h"
#include "nlobserver.h"
#include "nlsummseq.h"
#include "nlsummrec.h"
#include "nlsummstate.h"
#include "nlsummvisitor.h"
#include "nllist.h"

#define T NL_summ_T
struct T {
    NL_list_T /* NL_summseq_T */ sequences;
    NL_list_T /* NL_log_T */ logs;
    NL_log_T output;
    int output_shared;
    NL_observer_T newrec_obs, flush_obs, writerec_obs;
};

extern NL_list_T NL_summ_match_record(T self, NL_rec_t * record);

T NL_summ(void)
{
    T self = (T) malloc(sizeof(struct T));

    self->sequences = NL_list();
    self->logs = NL_list();
    self->output = NULL;
    self->output_shared = 0;
    /* create observers once, so they can be removed (by address) later */
    self->newrec_obs = NL_observer(NL_summ_new_record, self);
    self->flush_obs = NL_observer(NL_summ_flush, self);
    self->writerec_obs = NL_observer(NL_summ_write_record, self);
    return self;
}

/*
 * Visitor pattern to look at every sequence in the summarizer.
 */
void NL_summ_accept(T self, NL_summvisitor_T visitor)
{
    void *node;

    for (node = NL_list_iter(self->sequences); node;
         node = NL_list_next_node(self->sequences, node)) {
        NL_summseq_accept((NL_summseq_T) NL_list_node_data(node), visitor);
    }
}

int NL_summ_add_log(T self, NL_log_T log)
{
    NL_list_append(self->logs, log);
    NL_subject_register(NL_get_new_record_subject(log), self->newrec_obs);
    NL_subject_register(NL_get_flush_subject(log), self->flush_obs);
    return 0;
}

int NL_summ_add_sequence(T self, NL_summseq_T seq)
{
    int result = 0;

    if (NULL == seq) {
        result = -1;
    }
    else {
        NL_subject_T subj = NULL;

        NL_list_append(self->sequences, seq);
        subj = NL_summseq_get_output_rec_subject(seq);
        NL_subject_register(subj, self->writerec_obs);
    }

    if (self->output) {
        NL_flush(self->output);
    }

    return result;
}

int NL_summ_flush(void *vself, void *ignored)
{
    T self = (T) vself;
    NL_list_T seq = self->sequences;
    void *n;

    for (n = NL_list_iter(seq); n; n = NL_list_next_node(seq, n)) {
        NL_summseq_flush((NL_summseq_T) NL_list_node_data(n));
    }

    return 0;
}

int NL_summ_new_record(void *vself, void *vrec)
{
    T self = (T) vself;
    NL_list_T m;
    NL_rec_t *rec = (NL_rec_t *) vrec;
    void *n;
    int result = 0;

    m = NL_summ_match_record(self, rec);   /* returns list of observers */
    if (NULL == m) {
        result = -1;
    }
    else {
        /* add each observer to the record's subject */
        for (n = NL_list_iter(m); n; n = NL_list_next_node(m, n)) {
            NL_observer_T obs = (NL_observer_T) NL_list_node_data(n);
            NL_subject_register(rec->update_subj, obs);
        }
    }

    return result;
}


int NL_summ_remove_log(T self, NL_log_T log)
{
    int result;
    if (!log) {
        result = -1;
    }
    else {
        NL_subject_unregister(NL_get_new_record_subject(log),
                              self->flush_obs);
        NL_subject_unregister(NL_get_flush_subject(log), self->newrec_obs);
        result = NL_list_remove(self->logs, log);
    }
    return result;
}

inline void close_output(T self)
{
    if (self->output && !self->output_shared)
        NL_close(self->output);
 }

int NL_summ_set_output(T self, NL_log_T log)
{
    close_output(self);
    self->output = log;
    self->output_shared = 0;
    return 0;
}

int NL_summ_set_shared_output(T self, NL_log_T log)
{
    close_output(self);
    self->output = log;
    self->output_shared = 1;
    return 0;
}

int NL_summ_write_record(void *vself, void *vrl)
{
    int result;
    T self = (T) vself;

    if (NULL == vrl) {
        result = -1;
    }
    else {
        NL_summstate_reclevel_T rl = (NL_summstate_reclevel_T) vrl;

        if (NULL == self->output) {
            result = -1;
        }
        else {
            result = NL_write_rec(self->output, rl->record, rl->level);
        }
        NL_summstate_reclevel_del(rl);
    }
    return result;
}

NL_list_T NL_summ_match_record(T self, NL_rec_t * record)
{
    void *node;
    int pos;
    NL_list_T result;

    result = NL_list();

    for (node = NL_list_iter(self->sequences); node;
         node = NL_list_next_node(self->sequences, node)) {
        NL_summseq_T seq;
        seq = NL_list_node_data(node);
        pos = NL_summseq_match_record(seq, record);
        if (pos >= 0) {
            NL_summrec_T sr;
            NL_observer_T obs;

            /* Create new summarized record, and an observer
             * that will invoke its main action method.
             * Add this observer to the returned list.
             */
            sr = NL_summrec(record, pos, seq);
            if (NULL != sr) {
                obs = NL_observer(NL_summrec_get_action(sr), sr);
                NL_list_append(result, obs);
            }
        }
    }

    return result;
}

void NL_summ_del(T self)
{
    if (self) {
        void *n;
        /* sequences: just delete */
        NL_list_del(self->sequences, (NL_list_free_data) NL_summseq_del);
        /* logs: unregister new_rec/flush observers first, since
         * the logs may continue afterwards */
        for (n = NL_list_iter(self->logs); n;
             n = NL_list_next_node(self->logs, n)) {
            NL_log_T log;
            NL_subject_T subj;

            log = (NL_log_T) NL_list_node_data(n);
            subj = NL_get_new_record_subject(log);
            NL_subject_unregister(subj, self->newrec_obs);
            subj = NL_get_flush_subject(log);
            NL_subject_unregister(subj, self->flush_obs);
        }
        NL_list_del(self->logs, NULL);
        /* delete the observers themselves */
        NL_observer_del(self->flush_obs);
        NL_observer_del(self->newrec_obs);
        NL_observer_del(self->writerec_obs);

        close_output(self);

        free(self);
    }
}

#undef T
