/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#ifndef lint
static const volatile char rcsid[] =
    "$Id: nlsummstate.c 128 2007-08-21 21:49:45Z dang $";
#endif
/* Summarizer state */

#include <stdlib.h>

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "nlint.h"
#include "nlsummstate.h"
#include "nlsummseq.h"

#ifdef __cplusplus
extern "C" {
#endif
#if 0
}
#endif
#define T NL_summstate_reclevel_T
T NL_summstate_reclevel(NL_rec_t * record, NL_level_t level)
{
    T self = (T) malloc(sizeof(struct T));
    self->record = record;
    self->level = level;
    return self;
}

void NL_summstate_reclevel_del(T self)
{
    /* god, no!! records are usually
     * reused for many invocations.
     * free(self->record); */
    free(self);
}

#undef T

#define T NL_summstate_T
/* struct is exposed in interface file */

T
NL_summstate(NL_summseq_T parent, void *initial_data, NL_free_fn free_data)
{
    T self = (T) malloc(sizeof(struct T));

    self->values_n = 0;
    self->values_sz = 2;
    self->values = malloc(self->values_sz * sizeof(double));
    self->data = initial_data;
    self->free_data = free_data;
    self->seq = parent;
    self->first_access_n = 4;
    self->first_access = malloc(self->first_access_n);
    memset(self->first_access, 1, self->first_access_n);
    self->id_fields = NULL;
    self->id_fields_n = 0;
    return self;
}

unsigned NL_summstate_first_access(T self, unsigned pos)
{
    unsigned result;

    if (pos > self->first_access_n) {
        unsigned char *tmp = realloc(self->first_access, sizeof(unsigned) *
                                     self->first_access_n * 2);
        assert(tmp);
        memset(tmp + self->first_access_n, 1, self->first_access_n);
        self->first_access_n *= 2;
        self->first_access = tmp;
    }
    result = self->first_access[pos];
    self->first_access[pos] = 0;

    return result;
}

int NL_summstate_set_num_values(T self, unsigned n)
{
    int result = 0;

    if (n > self->values_sz) {
        void *tmp = realloc(self->values, n * sizeof(double));
        if (NULL == tmp) {
            result = -1;
        }
        else {
            self->values = (double *) tmp;
            self->values_sz = n;
        }
    }

    return result;
}

int NL_summstate_write_record(T self, void *vrec, NL_level_t level)
{
    NL_rec_t *rec = (NL_rec_t *) vrec;
    int result = 0;
    NL_subject_T subj;

    subj = self->seq ? NL_summseq_get_output_rec_subject(self->seq) : NULL;
    if (subj) {
        NL_summstate_reclevel_T rl = NL_summstate_reclevel(rec, level);
        result = NL_subject_notify(subj, rl);
    }

    return result;
}

void NL_summstate_del(T self)
{
    if (self) {
        if (self->data && self->free_data) {
            self->free_data(self->data);
        }
        if (self->id_fields_n > 0) {
            int i;
            for (i = 0; i < self->id_fields_n; i++) {
                NL_fld_del(self->id_fields[i]);
            }
            free(self->id_fields);
        }
        free(self);
    }
}

#undef T
