#ifndef NL_SUMMSEQ_H_INCLUDED
#    define NL_SUMMSEQ_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* 
 * Sequence of events to summarize
 */

#    ifdef __cplusplus
extern "C" {
#    endif
#    include "nl.h"
/* Types we can keep opaque */ struct NL_summvisitor_T;
    struct NL_hash_T;
    struct NL_summstate_T;
#    define NL_summstate_T struct NL_summstate_T *
    struct NL_params_T;
#    define NL_params_T struct NL_params_T *
    struct NL_subject_T;
#    define NL_subject_T struct NL_subject_T *
#    define T NL_summseq_T
    typedef struct T *T;

/* Process a record. */
    typedef int (*NL_summseq_process_fn) (NL_summstate_T state);

/* Flush current state. */
    typedef void (*NL_summseq_flush_fn) (NL_summstate_T state);

/* Create initial state for a summarizer instance */
    typedef void *(*NL_summseq_init_state_fn) (NL_params_T params);

/**
 * Constructor
 */
    T NL_summseq(void);

/**
 * Use visitor pattern to look at summary state of all
 * instances of the sequence.
 */
    extern void NL_summseq_accept(T self,
                                  struct NL_summvisitor_T *visitor);

/**
 * Add an identifying field for selector #idx
 */
    extern int NL_summseq_add_id_field(T self, unsigned idx,
                                       const char *field_name);

/**
 * Add an auxiliary (non-value, non-id) field for selector #idx
 */
    extern int NL_summseq_add_aux_field(T self, unsigned idx,
                                        const char *field_name);

/**
 * Add next selector to the sequence
 */
    extern int NL_summseq_add_selector(T self, const char *name,
                                       void *value, unsigned value_size);

/**
 * Add a value field for selector #idx
 */
    extern int NL_summseq_add_value_field(T self, unsigned idx,
                                          const char *field_name);

/**
 * Flush current state (of all contained instances).
 */
    extern void NL_summseq_flush(T self);

 /**
  * Access 'records should not be written' flag
  */
    extern int NL_summseq_get_consume(T self);

/**
 * Return positions for identifiers for selector #pos_in_seq
 * as found in the input record.
 */
    extern int NL_summseq_get_ids(T self, NL_rec_T record, int pos_in_seq,
                                  unsigned **ids, unsigned *ids_n);

/**
 * Get length of sequence.
 */
    extern unsigned NL_summseq_get_len(T self);

/**
 * Get subject for output records.
 */
    extern NL_subject_T NL_summseq_get_output_rec_subject(T self);

/**
 * Get a ref. to the parameter list
 */
    extern NL_params_T NL_summseq_get_params(T self);

/**
 * Get the whole darn state table
 */
    extern struct NL_hash_T *NL_summseq_get_states(T self);

/**
 * Equality test for selector value.
 *
 * @param self Object
 * @param idx Index of selector in range 0 to (#selectors-1)
 * @param value Value to match
 * @param value_n Value length
 * @return 1 if value is equal to value for this selector, 0 else.
 */
    int NL_summseq_selector_equals(T self, unsigned idx,
                                   const void *value, unsigned value_n);


/**
 * Get a copy of the function pointer, which removes a
 * function call from the critical path.
 */
    extern NL_summseq_process_fn NL_summseq_get_summary_fn(T self);

/**
 * Get/create summarizer state for instance matching 'identifier'
 * at selector position 'pos'.
 * The out param 'is_new' indicates whether a new state was created.
 */
    extern NL_summstate_T NL_summseq_get_state(T self,
                                               const char *identifier,
                                               unsigned identifier_len,
                                               unsigned *is_new);

/**
 * Return positions for value fields for selector #pos_in_seq
 * as found in the input record.
 */
    extern int NL_summseq_get_values(T self, NL_rec_T record,
                                     int pos_in_seq, unsigned **values,
                                     unsigned *values_n);

/**
 * Return index of selector matching record, or -1 if no match.
 */
    extern int NL_summseq_match_record(T self, NL_rec_T record);

/**
 * Set consume/no-consume flag.
 * If not set, default is 0 (no).
 */
    extern void NL_summseq_set_consume(T self, int c);

/**
 * Set info needed for summarizer state creation.
 * If called more than once, the previous value is deleted.
 * Incoming arguments are checked to be non-NULL.
 * Returns -1 if something was NULL, 0 otherwise.
 */
    extern int NL_summseq_set_info(T self,
                                   NL_params_T params,
                                   NL_summseq_init_state_fn
                                   get_initial_state,
                                   NL_summseq_process_fn process_record,
                                   NL_summseq_flush_fn flush_state,
                                   NL_free_fn free_state);

    extern void NL_summseq_del(T self);

#    undef T

#    undef NL_summstate_T
#    undef NL_params_T
#    undef NL_subject_T

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
