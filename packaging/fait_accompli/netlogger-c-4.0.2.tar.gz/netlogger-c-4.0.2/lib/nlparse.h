#ifndef NL_PARSE_H_INCLUDED
#    define NL_PARSE_H_INCLUDED
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/

/** 
 * @ingroup nlapi 
 * Parse NetLogger Best Practices logs as strings
 */

#    ifdef __cplusplus
extern "C" {
#    endif

struct NL_alist_T;
#define NL_alist_T struct NL_alist_T *

/**
 * Parse a single log entry into an associative array of named values.
 *
 * @param str One log entry, optionally ending in a newline
 * @param nvp_out Name-value pairs stored in an NL_alist_T
 * @return 0 for success, -1 for error
 */
extern int
NL_parse_str(const char *str, NL_alist_T *nvp_out);

/**
 * Get vector of pointers to start of each newline-delimited log entry.
 *
 * @param buf Buffer with one or more log entries, separated by newlines
 * @param str_out Vector of pointers into buf. Should be freed by caller.
 * @param n_out Number of char*'s in str_out
 * @return 0 for success, -1 for error
 */
extern int 
NL_parse_split(const char *buf, char **str_out, unsigned *n_out);

#undef NL_alist_T

#    ifdef __cplusplus
}
#    endif

#endif              /* ...INCLUDED */