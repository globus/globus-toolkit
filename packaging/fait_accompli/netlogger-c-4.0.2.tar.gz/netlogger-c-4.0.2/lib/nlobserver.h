#ifndef NL_OBSERVER_H_INCLUDED
#    define NL_OBSERVER_H_INCLUDED

/* Observer pattern */

/* In nl.h: typedef int (*NL_observer_cb)(void *, void *); */
#    include "nl.h"

#    define T NL_observer_T
typedef struct T *T;

T NL_observer(NL_observer_cb callback, void *context);
void NL_observer_del(T self);

#    undef T

#    define T NL_subject_T
typedef struct T *T;

T NL_subject(void);
void NL_subject_register(T self, NL_observer_T obs);
int NL_subject_unregister(T self, NL_observer_T obs);
int NL_subject_notify(T self, void *arg);
void NL_subject_del(T self);

#    undef T

#endif
