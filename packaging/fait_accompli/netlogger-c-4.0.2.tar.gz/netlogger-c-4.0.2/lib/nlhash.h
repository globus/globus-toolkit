#ifndef NL_HASH_H_INCLUDED
#    define NL_HASH_H_INCLUDED
/*
 * Simple, fast hash table.
 * Optimized for smallish fixed table sizes, append-only.
 *
 * Basic usage::
 *    Create: NL_hash_t tbl = NL_hash(1000); [1]
 *    Add   : NL_hash_put(tbl, "hello", 5, (void*)value, 0); [2]
 *    Find  : void *value = NL_hash_get(tbl, "hello", 5);
 *    Visit : NL_hash_visit(tbl, visit_func, (void*)visit_data);
 *    Delete: NL_hash_del(tbl, free); [3]
 * Notes: 
 *       [1] hash table size will be rounded up to nearest power of 2
 *       [2] last parameter is 0 for 'do not replace' or 1 for 'replace'
 *       [3] use NL_hash_nofree as second parameter, to not free each value
 */

#    include <stdlib.h>
#    include <stdio.h>
#    include <string.h>

#    include "nlstdint.h"


/* ------------------------------------------ */

typedef void (*NL_hash_freefn) (void *);

/* Pass this to nl_hash_del when you don't want
 * to really free the values. */
void NL_hash_nofree(void *ignore);

/* Dumb, but fast, hash function */
#    define HASH(K,L,H) do {                                 \
        int ii;                                          \
        for( (H) = 1, ii = 0; ii < (L); ii++ )           \
            (H) = (  1001 * (H) + (K)[ii] );             \
    } while(0)

/* ------------------------------------------ */

#    define T NL_hash_list_t
struct T;
typedef struct T *T;

struct NL_hash_node_t;
typedef struct NL_hash_node_t {
    const char *key;
    uint32_t keylen;
    void *data;
    struct NL_hash_node_t *next;
} *NL_hash_node_t;

struct T {
    NL_hash_node_t *heads;
    uint32_t size;
};

/* Construct new list of a given size */
extern T NL_hash_list(uint32_t size);
/* Free list  and contents */
extern void NL_hash_list_del(T self, void (*free_func) (void *));
#    if 0
/* Find node & return its data (or NULL) */
static inline void *NL_hash_list_get(T self, uint32_t idx, const char *key,
                                     uint32_t keylen)
{
    NL_hash_node_t node;
    void *result;

    result = NULL;
    for (node = self->heads[idx]; node; node = node->next) {
        if (node->keylen == keylen
            && (0 == memcmp(node->key, key, keylen))) {
            result = node->data;
            break;
        }
    }
    return result;
}
#    endif
/* Add data for this key */
extern void NL_hash_list_add(T self, uint32_t idx, const char *key,
                             uint32_t keylen, void *data);
/* Get value matching key (NULL if none) */
extern void *NL_hash_list_get(T self, uint32_t idx, const char *key,
                              uint32_t keylen);


#    undef T

/* ------------------------------------------ */

#    define T NL_hash_T
struct T;
typedef struct T *T;

struct T {
    NL_hash_list_t list;
    uint32_t size;
    uint32_t length;
    uint32_t mask;
};

/* Construct new hash table of given size */
extern T NL_hash(uint32_t size);
/* Delete hashtable and contents */
extern void NL_hash_del(T self, void (*free_func) (void *));
/* Put a value for this key; replace existing if replace != 0 */
extern void *NL_hash_put(T self, const char *key, uint32_t keylen,
                         void *data, unsigned char replace);
/* Get node matching key (or NULL if none) */
#    define NL_HASH_GET(self, K, KL, R) \
do { \
    int idx; \
    uint32_t hash; \
    NL_hash_node_t node; \
    HASH(K, KL, hash);  \
    idx = hash & self->mask;  \
    R = NULL; \
    for (node=self->list->heads[idx]; node; node=node->next) { \
        if (node->keylen == KL && (0 == memcmp(node->key, K, KL))) {\
            R = node->data; \
            break; \
        } \
    } \
} while(0)

/* Type for function called when visiting nodes */
typedef void (*NL_hash_vfunc_t) (T self, NL_hash_node_t node, void *vdata);
/* Do something at every node */
extern void NL_hash_visit(T self, NL_hash_vfunc_t func, void *vdata);

#    undef T

#endif                          /* included */
