/* 
   Copyright (c) 2004, The Regents of the University of California, through 
   Lawrence Berkeley National Laboratory (subject to receipt of any required 
   approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#ifndef NL_INT_H_INCLUDED
#    define NL_INT_H_INCLUDED
/**
 * NetLogger internal header file
 */

#    include <errno.h>

#    ifdef NL_THREADED
#        include <pthread.h>
#    endif

#    include <fcntl.h>
#    include <stdarg.h>
#    include "nlstdint.h"
#    include <stdio.h>
#    include <syslog.h>
/* time headers */
#if TIME_WITH_SYS_TIME
#    include <sys/time.h>
#    include <time.h>
#else
#    if HAVE_SYS_TIME_H
#        include <sys/time.h>
#    else
#        include <time.h>
#    endif
#endif
#    include "doxygen.h"

#    include "nl.h"
#    include "nldbg.h"
#    include "nlerr.h"
#    include "nlparams.h"
#    include "nlrectbl.h"
#    include "nlobserver.h"

#    ifdef __cplusplus
extern "C" {
#    endif

/*-----------------------------------------------------------
 * Macros, enums, constants
         *//* Global logging status */
    enum log_status { NL_STATUS_ON = 1, NL_STATUS_OFF = 0 };

/* Default socket port */
#    define NL_DEFAULT_PORT 14380

/* Standard log-level names */
#    define NL_STD_LVL_NAMES						\
  "!", "FATAL", "ERROR", "WARN", "INFO", "DEBUG", "DEBUG1", "DEBUG2", "DEBUG3"
#    define NL_STD_LVL_LENS				\
  1, 5, 5, 4, 4, 5, 6, 6, 6
    extern const char *NL_level_names[];
    extern int NL_level_lengths[];

#    define NL_STD_LVL_NAME_USER "USER"

/** Default log level file */
#    define NL_CFG_LVL "/etc/netlogger/level"

/** Check log level file interval */
#    define NL_LVL_TM 2.0

/* Set/reset/test whether a given record (NL_rec_t *) is being
 * used as a 'flush summary data for this record' request.
 *
 * Parameters:
 *   NL_rec_t * R = the record
 *   double T     = temporary variable to hold create_time of record
 */
#    define NL_REC_SET_FLUSH(R,T) do {		\
    (T) = (R)->create_tm;			\
    ((R)->create_tm = -1.0);			\
  } while(0)
#    define NL_REC_RESET_FLUSH(R,T) do {		\
    (R)->create_tm = (T);			\
  } while(0)
#    define NL_REC_IS_FLUSH(R) ((R)->create_tm < 0.0)

/* for experimental sampling API */

/*-----------------------------------------------------------
 * Formatting constants
 */

/* Maximum number of record fields
 * Up to 1/2 of these can be constants
 */
#    define NL_MAX_FLD 128

/* Minimum serialized field length 
 * <type-char> <spc> <key> ':' <spc> '\n'
 * */
#    define NL_MIN_FLD_LEN 6

/* Maximum length of a string */
#    define NL_MAX_STR 4096

/* These parameters control the output format */
#    ifndef NL_FMT_PARAM
#        define NL_FMT_PARAM 1
#    endif
/* Parameter sets: */
#    if NL_FMT_PARAM == 1       /* --with-format=multi */
#        define NL_REC_SEP "\n\n"       /* separator between records */
#        define NL_REC_SEP_LEN 2
#        define NL_KEYVAL_SEP ": "      /* separator between key and value */
#        define NL_KEYVAL_SEP_LEN 2
#        define NL_FLD_SEP "\n" /* separator between fields */
#        define NL_FLD_SEP_LEN 1
#        define NL_TYPE_PRE '\0'        /* before the datatype char */
#        define NL_TYPE_POST ' '        /* after the datatype char */
#        define NL_TYPE_PPLEN 1 /* total len of pre + post */
#        define NL_TYPE_FIRST 1 /* whether it's type-key or key-type */
#        define NL_QUOTE_SPC 0  /* whether embedded spaces need quotes */
#        define NL_QUOTE_CHAR '\0'      /* quote character */
/**
 * Std field names
 */
#        define NL_FLD_DATE "DATE"
#        define NL_FLD_DATE_LEN 4
#        define NL_FLD_LVL "LVL"
#        define NL_FLD_LVL_LEN 3
#        define NL_FLD_EVENT "EVNT"
#        define NL_FLD_EVENT_LEN 4
#        define NL_FLD_PROG "PROG"
#        define NL_FLD_PROG_LEN 4
#        define NL_FLD_HOST "HOST"
#        define NL_FLD_HOST_LEN 4
#        define NL_FLD_PID "PID"
#        define NL_FLD_PID_LEN 3
#    elif NL_FMT_PARAM == 2     /* --with-format=bplog */
#        define NL_REC_SEP "\n" /* separator between records */
#        define NL_REC_SEP_LEN 1
#        define NL_KEYVAL_SEP "="       /* separator between key and value */
#        define NL_KEYVAL_SEP_LEN 1
#        define NL_FLD_SEP " "  /* separator between fields */
#        define NL_FLD_SEP_LEN 1
#        define NL_TYPE_PRE '\0'        /* before the datatype char */
#        define NL_TYPE_POST ' '        /* after the datatype char */
#        define NL_TYPE_PPLEN 1 /* total len of pre + post */
#        define NL_TYPE_FIRST -1        /* no type at all */
#        define NL_QUOTE_SPC 1  /* whether embedded spaces need quotes */
#        define NL_QUOTE_CHAR '"'       /* quote character */
/**
 * Std field names
 */
#        define NL_FLD_DATE "ts"
#        define NL_FLD_DATE_LEN 2
#        define NL_FLD_LVL "level"
#        define NL_FLD_LVL_LEN 5
#        define NL_FLD_EVENT "event"
#        define NL_FLD_EVENT_LEN 5
#        define NL_FLD_PROG "prog"
#        define NL_FLD_PROG_LEN 4
#        define NL_FLD_HOST "host"
#        define NL_FLD_HOST_LEN 4
#        define NL_FLD_PID "pid"
#        define NL_FLD_PID_LEN 3
#    else
     error !
#    endif
/* Standard field positions 
 * If you add to this enumeration, you also need to modify
 * the 'add standard fields' loop in NL_fstrm_constrec().
 */
    enum NL_stdfld { NL_dtfld = 0, NL_lvlfld = 2, NL_evfld =
            1, NL_numfld = 3
    };

/* Type codes */
    enum {
        NL_double = 'd',
        NL_string = 's',
        NL_int = 'i',
        NL_long = 'l',
        NL_time = 't',
        NL_double_meta = 'D',
        NL_string_meta = 'S',
        NL_int_meta = 'I',
        NL_long_meta = 'L',
        NL_time_meta = 'T',
    };

/*-----------------------------------------------------------
 * Field 
 */

    typedef struct NL_fld_t {
        char *key;
        int klen;
        void *value;
        int vlen;
        char type;
    } NL_fld_t;

    extern NL_fld_t *NL_fld(const char *key, int klen, void *value,
                            int vlen, char type);
    extern NL_fld_t *NL_fld_clone(NL_fld_t * orig);
    extern void NL_fld_fill(NL_fld_t * self, const char *key, int klen,
                            void *value, int vlen, char type);
    extern void NL_fld_del(NL_fld_t * self);

/**
 * Macro to set value of field
 */
#    define NL_FLD_SET(fldp, ap) do {			\
    double dval;					\
    int ival;						\
    long long lval;					\
    char *sval;						\
							\
    switch( (fldp)->type ) {				\
    case NL_double:                                     \
      dval = va_arg((ap),double);			\
      memcpy( (fldp)->value, &dval, (fldp)->vlen );	\
      break;						\
    case NL_int:                                        \
      ival = va_arg((ap),int);				\
      memcpy( (fldp)->value, &ival, (fldp)->vlen );	\
      break;						\
    case NL_long:                                       \
      lval = va_arg((ap),long long);			\
      memcpy( (fldp)->value, &lval, (fldp)->vlen );	\
      break;						\
    case NL_string:                                     \
      sval = va_arg((ap), char*);			\
      (fldp)->vlen = strlen(sval);			\
      memcpy( (fldp)->value, sval, (fldp)->vlen );	\
      break;						\
    default:                                            \
      NL_err_add("Unknown type for field");             \
    }							\
  } while(0)

/*-----------------------------------------------------------
 * Record 
 */

    typedef struct NL_rec_t {
        NL_fld_t **fields;
        int *is_meta;
        int len; /* filled fields */
		int empty_len; /* allocated but unfilled fields, may be 0 */
        int size; /* total number of field pointers */
        int hash_index;         /* cached hashcode */
        double create_tm;       /* record creation time */
        NL_subject_T update_subj;       /* notify observers when record is updated */
        int consumed;           /* way for observers to record whether record should
                                 * be written */
    } NL_rec_t;

    extern NL_rec_t *NL_rec(int size);
    extern NL_rec_t *NL_rec_empty(int size);
    extern int NL_rec_add(NL_rec_t * self, NL_fld_t * fldp);
    extern int NL_rec_add_meta(NL_rec_t * self, NL_fld_t * fldp);
    extern NL_fld_t *NL_rec_find_field(NL_rec_t * rec_p, const char *key,
                                       int klen);
    extern int NL_rec_field_idx(NL_rec_t * rec_p, const char *key,
                                int keylen);
    extern void NL_rec_del(NL_rec_t * self);

/*-----------------------------------------------------------
 * Formatting
 */

/* Record formatter */
    typedef struct NL_rfmt_t {
        void *fmtkey;           /* Function to format 'key' part */
        void *fmt[128];         /* sparse array indexed by field 'type' */
        int pad_bytes;          /* num bytes for header, footer, etc. (not per-field) */
        /* these next three optimize date formatting */
        char *dbuf;
        char *fbuf;
        int prev_sec;
    } NL_rfmt_t;

/* Field formatting function prototype */
    typedef int (*NL_ffmt_fn) (NL_rfmt_t *, NL_fld_t *, char *buf,
                               int maxlen);

    extern NL_rfmt_t *NL_rfmt(void);
    extern int NL_rfmt_format(NL_rfmt_t * self, NL_rec_t * recp,
                              char *buf, size_t maxlen);
    extern void NL_rfmt_del(NL_rfmt_t * self);

/* Field formatters (internal) */
    int NL_fmt_key(NL_rfmt_t * self, NL_fld_t * fldp, char *buf,
                   int maxlen);
    int NL_fmt_int32(NL_rfmt_t * self, NL_fld_t * fldp, char *buf,
                     int maxlen);
    int NL_fmt_longlong(NL_rfmt_t * self, NL_fld_t * fldp, char *buf,
                        int maxlen);
    int NL_fmt_double(NL_rfmt_t * self, NL_fld_t * fldp, char *buf,
                      int maxlen);
    int NL_fmt_string(NL_rfmt_t * self, NL_fld_t * fldp, char *buf,
                      int maxlen);
    int NL_fmt_iso8601(NL_rfmt_t * self, NL_fld_t * fldp, char *buf,
                       int maxlen);

/*-----------------------------------------------------------
 * Formatting stream
 */

    typedef struct NL_fstrm_t {
        nl_rectbl_t rectbl;     /* Hash table of records */
        NL_rfmt_t *fmtp;        /* Formatter */
        char *buf;              /* Buffer for formatted records */
        int buflen;             /* Max len of 'buf', allowing space for '\0' */
        NL_rec_t *const_rec;    /* Fields added to each record */
        NL_subject_T newrec_subj;       /* notify when a new record comes along */
    } NL_fstrm_t;

    extern NL_fstrm_t *NL_fstrm(void);
    extern NL_rec_t *NL_fstrm_constrec(NL_fstrm_t * self,
                                       const char *event);
    extern int NL_fstrm_fmtrec(NL_fstrm_t * self, NL_rec_t * recp);
    extern NL_rec_t *NL_fstrm_getrec(NL_fstrm_t * self,
                                     struct timeval *tv_p,
                                     const char *event, const char *fmt);
    extern void NL_fstrm_del(NL_fstrm_t * self);

/* internal */
    extern NL_rec_t *make_rec(NL_fstrm_t * self,
                              struct timeval *tv_p,
                              const char *event,
                              int level, const char *fmt, va_list ap);
    extern NL_rec_t *parse_fmt(const char *fmt, NL_rec_t * recp);
    extern void set_values(NL_rec_t * recp, va_list ap, int offs);

/*-----------------------------------------------------------
 * Generic output (interface)
 */

/*
 * File descriptor state (used by socket and file)
 */
    typedef struct NL_fd_state {
        int fd;
        char *name;
    } NL_fd_state;

/* Table of known output files && fd's, so
 * we can avoid opening the same file twice 
 */
    extern struct NL_tbl_s *g_opened_files;

/* Function prototypes */
    typedef size_t(*NL_write_fn) (void *, int, const char *, size_t);
    typedef void (*NL_close_fn) (void *);

    typedef struct NL_outp_t {
        void *statep;           /* specific outputs' state */
        /* Function pointers for output operations: */
        NL_write_fn write;
        NL_close_fn close;
        int level;
    } NL_outp_t;

    extern NL_outp_t *NL_outp(void);
    extern void NL_outp_del(NL_outp_t * self);

/* Copy level into handle and call 'write'.
 * The level is used if the handle is syslog.
 */
#    define NL_outp_WRITE(outp, LVL, buf, len, rval) do {                   \
        (outp)->level = (LVL);                                          \
        (rval) = (outp)->write((outp)->statep,                          \
                               (outp)->level, (buf), (len));            \
    } while(0)
#    define NL_outp_CLOSE(outp)			\
    (outp)->close()

/* internal */
    NL_outp_t *NL_ofile(const char *filename);
    NL_outp_t *NL_osock(const char *rhost, unsigned short port, char udp);
    NL_outp_t *NL_osyslog(char *program, int facility);
    NL_outp_t *open_url(const char *url);


#    ifdef __cplusplus
}
#    endif
#    undef NL_level_t
#endif
