/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#ifndef lint
static const volatile char rcsid[] =
    "$Id: nllist.c 121 2007-08-19 23:19:37Z dang $";
#endif
/**
 * Minimal list API.
 */
#include <stdlib.h>
#include "nllist.h"

#define T NL_list_T

struct node;
struct node {
    void *data;
    struct node *next;
};

struct T {
    struct node *head, *tail;
    unsigned len;
};

T NL_list(void)
{
    T self = malloc(sizeof(struct T));

    self->head = NULL;
    self->tail = NULL;
    self->len = 0;

    return self;
}

void *NL_list_node_data(void *node)
{
    return ((struct node *) node)->data;
}

/* Insert a node before idx.
 * Precondition: 0 <= idx < self->len
 */
static inline int insert_node(T self, unsigned idx, struct node *x)
{
    int result = 0;

    if (self->len == 0) {
        x->next = NULL;
        self->head = self->tail = x;
    }
    else {
        int i;
        struct node *cur = self->head, *prev = NULL;

        for (i = 0; i < idx; prev = cur, cur = cur->next, i++);

        if (prev == NULL) {
            x->next = self->head;
            if (self->len == 1) {
                self->tail = x->next;
            }
            self->head = x;
        }
        else {
            prev->next = x;
            x->next = cur;
            if (cur == NULL) {
                self->tail = x;
            }
        }
    }

    if (result == 0) {
        self->len++;
    }

    return result;
}

void NL_list_append(T self, void *data)
{
    struct node *new_node;

    new_node = malloc(sizeof(struct node));
    new_node->data = data;

    insert_node(self, self->len, new_node);
}

void NL_list_insert(T self, unsigned idx, void *data)
{
    struct node *new_node;

    if (idx <= self->len) {
        new_node = malloc(sizeof(struct node));
        new_node->data = data;
        insert_node(self, idx, new_node);
    }
}

unsigned NL_list_len(T self)
{
    return self->len;
}

/* return (opaque) node to be used in calls to NL_list_next */
void *NL_list_iter(T self)
{
    return self->head;
}

void *NL_list_next_node(T self, void *iter)
{
    struct node *cur = (struct node *) iter;

    if (cur) {
        cur = cur->next;
    }
    return cur;
}

void *NL_list_get(T self, unsigned idx)
{
    unsigned i;
    struct node *cur;
    void *result;

    if (idx >= self->len) {
        result = NULL;
    }
    else {
        for (i = 0, cur = self->head; i < idx; cur = cur->next, i++);
        result = cur->data;
    }

    return result;
}

int NL_list_remove(T self, void *data)
{
    int result = -1;
    struct node *cur, *prev;

    for (prev = NULL, cur = self->head; cur; prev = cur, cur = cur->next) {
        if (cur->data == data) {
            if (NULL == prev) {
                self->head = self->head->next;
            }
            else {
                prev->next = cur->next;
                if (NULL == prev->next) {
                    self->tail = prev;
                }
            }
            free(cur);
            self->len--;
            result = 0;
            break;
        }
    }

    return result;
}

int
NL_list_replace(T self, unsigned idx, void *data, NL_list_free_data freefn)
{
    int i, result = 0;
    struct node *cur;

    if (idx >= self->len) {
        result = -1;
    }
    else {
        for (i = 0, cur = self->head; i < idx; cur = cur->next, i++);
        if (cur->data && freefn) {
            freefn(cur->data);
        }
        cur->data = data;
    }

    return result;
}

void NL_list_del(T self, NL_list_free_data freefn)
{
    if (self) {
        if (freefn) {
            struct node *cur, *prev = NULL;
            for (cur = self->head; cur; prev = cur, cur = cur->next) {
                if (prev) {
                    free(prev);
                }
                if (cur->data) {
                    freefn(cur->data);
                }
            }
        }
        free(self);
    }
}
