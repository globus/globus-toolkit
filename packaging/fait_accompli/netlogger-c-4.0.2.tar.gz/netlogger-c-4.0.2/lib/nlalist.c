/* 
   Copyright (c) 2007, The Regents of the University of California, through 
   Lawrence Berkeley National Laboratory (subject to receipt of any required 
   approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/**
 * List of items that can be accessed by index or key    
 */

#include <stdlib.h>
#include <string.h>
#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "nl.h"
#include "nlalist.h"

/*--------------------
 * Data with a length
 *--------------------
 */

#define T NL_adata_T

struct T {
    unsigned len;
    void *data;
    int copied;
};

/*
 * Constructor 
 */
T NL_adata(void *data, unsigned len, int do_copy)
{
    T self = malloc(sizeof(struct T));

    if (!data) {
        self->data = NULL;
        self->len = 0;
        self->copied = 0;
        goto bottom;
    }

    if (do_copy) {
        self->data = malloc(len);
        memcpy(self->data, data, len);
    }
    else {
        self->data = data;
    }
    self->len = len;
    self->copied = do_copy;

  bottom:
    return self;
}

/*
 * Convert to string
 */
char *NL_adata_as_str(T self, char nul_subst)
{
    char *s, *d = (char*)self->data;
    int i;

    s = malloc(self->len + 1);
    for (i = 0; i < self->len; i++) {
        s[i] = d[i] == '\0' ? nul_subst : d[i];
    }
    s[self->len] = '\0';

    return s;
}

/*
 * Compare two data items
 */
int NL_adata_cmp(T self, T other)
{
    if (!self || !other || self->len != other->len)
        return -1;
    return memcmp((const void *) self->data,
                  (const void *) other->data, self->len);
}

/*
 * Copy a data item
 */
T NL_adata_copy(T self)
{
    if (!self)
        return NULL;
    return NL_adata(self->data, self->len, 1);
}

/*
 * Get value
 */
void *NL_adata_get_value(T self)
{
    return self->data;
}

/*
 * Destructor
 */
void NL_adata_del(T self)
{
    if (self) {
        if (self->copied)
            free(self->data);
        free(self);
    }
}

#undef T

/*----------------------------------------
 * Linked list node with a key and value
 *----------------------------------------
 */

#define T NL_anode_T
struct T;

struct T {
    NL_adata_T key;
    NL_adata_T value;
    T prev, next;
};

/*
 * Constructor
 */
T NL_anode(NL_adata_T key, NL_adata_T value)
{
    T self = malloc(sizeof(struct T));

    self->key = key;
    self->value = value;
    self->next = NULL;

    return self;
}

/*
 * Compare two nodes by key
 */
int NL_anode_cmp(T self, T other)
{
    if (!self || !other)
        return -1;
    return NL_adata_cmp(self->key, other->key);
}

/*
 * Get key
 */
NL_adata_T NL_anode_get_key(T self)
{
    return self->key;
}

/*
 * Get value
 */
NL_adata_T NL_anode_get_value(T self)
{
    return self->value;
}

/*
 * Destructor
 */
void NL_anode_del(T self)
{
    if (self) {
        NL_adata_del(self->key);
        NL_adata_del(self->value);
        free(self);
    }
}

#undef T

/*-------------------------
 * Associative linked list
 *-------------------------
 */
#define T NL_alist_T

struct T {
    NL_anode_T head, tail;
    uint32_t len;
    unsigned char read_only;
};

/*
 * Constructor
 */
T NL_alist(void)
{
    T self = (T) malloc(sizeof(struct T));
    self->read_only = 0;
    self->head = NULL;
    self->tail = NULL;
    self->len = 0;

    return self;
}

/*
 * Append after end
 */
void NL_alist_append(T self, NL_anode_T node)
{
    if (self->read_only)
        return;

    if (self->len == 0) {
        self->head = node;
        self->tail = node;
    }
    else {
        self->tail->next = node;
        self->tail = node;
    }
    node->next = NULL;
    self->len++;
}

/*
 * Copy list
 */
T NL_alist_copy(T self)
{
    T copy;
    NL_anode_T node, new_node;

    copy = NL_alist();
    for (node = self->head; node; node = node->next) {
        new_node = NL_anode(NL_adata_copy(node->key),
                            NL_adata_copy(node->value));
        NL_alist_append(copy, new_node);
    }

    return copy;
}

/*
 * Get node at index
 */
NL_anode_T NL_alist_get_by_index(T self, uint32_t index)
{
    NL_anode_T node;

    if (index >= self->len)
        return NULL;

    for (node = self->head; index > 0; index--, node = node->next);

    return node;
}

/*
 * Get node by key
 */
NL_anode_T NL_alist_get_by_key(T self, NL_adata_T key)
{
    NL_anode_T node;
    NL_anode_T tgt = NL_anode(key, NULL);

    for (node = self->head; node; node = node->next) {
        if (!NL_anode_cmp(node, tgt))
            break;
    }

    return node;
}


/*
 * Insert before index
 */
int NL_alist_insert(T self, uint32_t index, NL_anode_T node)
{
    if (self->read_only || index > self->len)
        goto error;

    /* append to tail */
    if (index == self->len) {
        /*printf("@@ to tail\n"); */
        NL_alist_append(self, node);
        goto bottom;
    }

    /* insert before head */
    if (index == 0) {
        /*printf("@@ before head\n");*/
        node->next = self->head;
        self->head = node;
    }
    /* insert between head and tail */
    else {
        NL_anode_T prev = NL_alist_get_by_index(self, index - 1);
        /*printf("@@ between\n");*/
        node->next = prev->next;
        prev->next = node;
    }
    self->len++;

  bottom:
    return 0;

  error:
    return -1;
}

/*
 * Get list length
 */
uint32_t NL_alist_len(T self)
{
    return self->len;
}

/*
 * Remove a node
 */
NL_anode_T NL_alist_remove(T self, NL_anode_T node)
{
    NL_anode_T prev;

    if (self->read_only || self->len == 0)
        goto error;

    if (node == self->head) {
        /* node is first in list */
        if (self->len == 1) {
            self->head = self->tail = NULL;
        }
        else {
            self->head = node->next;
        }
    }
    else {
        /* find previous node  ( O(N)! )  */
        for (prev = self->head; prev->next && prev->next != node;
             prev = prev->next);
        if (prev->next == NULL)
            goto error;                /* not in list */
        /* cut node out of list */
        prev->next = node->next;
        /* adjust tail if necessary */
        if (node == self->tail) {
            self->tail = prev;
        }
    }
    /* set new list length */
    self->len--;

    return node;

  error:
    return NULL;
}

/*
 * Set list to be read-only
 */
void NL_alist_set_read_only(T self, unsigned int read_only)
{
    self->read_only = read_only;
}

/*
 * Destructor
 */
void NL_alist_del(T self)
{
    NL_anode_T node, prev;

    if (!self)
        return;
        
    for (node = self->head; node;) {
        prev = node;
        node = prev->next;
        NL_anode_del(prev);
    }
    free(self);
}

#undef T
