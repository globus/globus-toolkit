/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

/*
 * Fast state-machine-based parser for best-practices logs.
 */
 

#ifdef HAVE_CONFIG_H
#include "nlconfig.h"
#endif
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#include "nlint.h"
#include "nlbpparse.h"
 
/* ----------------------------------------------------------------------- */

/* Some special chars */
#define FLDSEP '='
#define RECSEP '\n'
#define QUOTE  '"'
#define ESCAPE '\\'
 
/* States in machine */
typedef enum {
    NLBP_START,
    NLBP_START_NVP,
    NLBP_NAME,
    NLBP_VALUE,
    NLBP_UNQUOTED_VALUE,
    NLBP_QUOTED_VALUE,
    NLBP_ESCAPED,
    NLBP_ERROR,
    NLBP_DONE
} NL_bpstate_t;

/* ----------------------------------------------------------------------- */

#define T NL_bpparse_T
struct T {
    NL_rec_t *recp; /* record being built */
    char *buf; /* buffer of data being parsed */
    int buflen; /* buffer length */
    int bufsz; /* allocated buffer size */
    int pos; /* position in buffer */
    char err[1024]; /* error buffer */
};

/* internal parse routine */
static int parse_buf(T self);

/* error-setting macro */
#define PERR(fmt, args...) do {                 \
    sprintf(self->err, "error: " fmt "\n", ##args); \
} while(0)

T NL_bpparse(void)
{
    T self = (T)calloc(1, sizeof(struct T));
    
    self->recp = NL_rec_empty(NL_MAX_FLD);
    self->bufsz = 65536;
    self->buf = malloc(self->bufsz);
    self->pos = self->buflen = 0;
    self->err[0] = '\0';
    
    return self;
}

int NL_bpparse_add_buf(T self, const char *buf, int buflen)
{
    size_t n;
    
    /* move data to start of buffer */
    if (self->pos > 0) {
        if (self->buflen > 0)
            memcpy(self->buf, self->buf + self->pos, self->buflen);
        self->pos = 0;
    }
    /* make buffer bigger if necessary */
    n = self->bufsz - self->buflen;
    if (n < buflen) {
        char *tmp;
        self->bufsz = MAX(self->bufsz*2, n + buflen);
        if (NULL == (tmp = realloc(self->buf, self->bufsz))) {
            PERR("realloc failed");
            goto error;
        }
        self->buf = tmp;
    }
    /* copy new data into buffer */
    memcpy(self->buf + self->buflen, buf, buflen);
    self->buflen += buflen;
    return 0;
error:
    return -1;
}

int NL_bpparse_add_str(T self, const char *str)
{
    return NL_bpparse_add_buf(self, str, strlen((char*)str));
}

const char *NL_bpparse_get_err(T self)
{
    return self->err;
}

int NL_bpparse_next_rec(T self, NL_rec_t **recpp)
{
    if (!self->buf) {
        PERR("buffer is NULL");
        goto error;
    }
    if (self->pos + self->buflen > self->bufsz) {
        PERR("no more data in buffer");
        goto nomoredata;
    }
    switch(parse_buf(self)) {
        case 0:
            goto nomoredata;
        case -1:
            goto error;
        case 1:
            break;
        default:
            PERR("Internal error: unknown parse return value");
            goto error;
    }
    
    *recpp = self->recp;
    return 0;
    
nomoredata:
    *recpp = NULL;
    return 0;
error:
    *recpp = NULL;
    return -1;    
}

#if 0 /* save*/
NL_alist_T NL_bpparse_next_alist(T self)
{
    NL_alist_T next_alist;
    NL_rec_t *next_rec;
    int i;
    
    next_rec = NL_bpparse_next_rec(self, &next_rec);
    if (!next_rec)
        return NULL;
    next_alist = NL_alist();
    for (i=0 i < next_rec->len; i++) {
        NL_anode_T node;
        NL_fld_t *fldp;
        
        fldp = &next_rec->fields[i];
        node = NL_anode(NL_adata(fldp->key, fldp->keylen),
                        NL_adata(fldp->value, fldp->vlen), 0);
        NL_alist_append(next_alist, node);            
    }
    
    return next_alist;
}
#endif

void NL_bpparse_del(T self)
{
    if (self) {
        if (self->buf) 
            free(self->buf);
        NL_rec_del(self->recp);
    }
}

/* ----------------------------------------------------------------------- */

/* character class functions */

static inline int is_ws(char c)
{
    return (c == ' ' || c == '\t');
}

static inline int is_namechar(char c)
{
    return (isalnum(c) || c == '_' || c == '.' || c == '-');
}

static inline int is_valuechar(char c)
{
    return (isgraph(c) && !(c == ESCAPE || c == FLDSEP));
}

static inline int is_quoted_valuechar(char c)
{
    return ((isgraph(c) || is_ws(c)) && c != ESCAPE);
}

/*
 * Main parse function
 */
int parse_buf(T self)
{
    register int p = self->pos;
    register int n = self->pos + self->buflen;
    char *key=NULL, *value=NULL;
    int key_pos=0, value_pos=0;
    char *b = self->buf;
    register NL_bpstate_t state = NLBP_START;
        
 #  define PBERR(s) PERR("At column %d, char #%d: %s",\
                         (p-self->pos), b[p], (s))   

    strcpy(self->err, "No error");

    while (p < n) {
        switch(state) {
            case NLBP_START:
                /* make new record */
                self->recp->len = 0;
                state = NLBP_START_NVP;
                /* fall-through.. */
            case NLBP_START_NVP:
                if (b[p] == RECSEP)
                    state = NLBP_DONE;
                else if (is_ws(b[p]))
                    p++;
                else {
                    if (!is_namechar(b[p])) {
                        PBERR("bad name char");
                        goto error;
                    }                    
                    if (self->recp->len == self->recp->size) {
                        PBERR("too many name=value pairs");
                        goto error;
                    }
                    key = self->recp->fields[self->recp->len]->key;
                    value = self->recp->fields[self->recp->len]->value;
                    key_pos = value_pos = 0;
                    key[key_pos++] = b[p++];
                    state = NLBP_NAME;                   
                }
                break;
            case NLBP_NAME:
                if (is_namechar(b[p]))
                    key[key_pos++] = b[p++];
                else if (b[p] == FLDSEP) {
                    self->recp->fields[self->recp->len]->klen = key_pos;
                    p++;
                    state = NLBP_VALUE;
                }
                else {
                    PBERR("bad name char");
                    goto error;
                }
                break;
            case NLBP_VALUE:
                if (b[p] == QUOTE) {
                    p++;
                    state = NLBP_QUOTED_VALUE;
                }
                else if (is_valuechar(b[p])) {
                    state = NLBP_UNQUOTED_VALUE;
                }
                else {
                    PBERR("bad value char");
                    goto error;
                }
                break;
            case NLBP_UNQUOTED_VALUE:
                if (is_ws(b[p]) || b[p] == RECSEP) {
                    self->recp->fields[self->recp->len]->vlen = value_pos;
                    self->recp->len++;
                    state = NLBP_START_NVP;
                 }
                else if (is_valuechar(b[p]))
                    value[value_pos++] = b[p++];
                else {
                    PBERR("bad unquoted value char");
                    goto error;
                }
                break;
            case NLBP_QUOTED_VALUE:
                if (b[p] == ESCAPE) {                
                    p++;
                    state = NLBP_ESCAPED;
                }
                else if (QUOTE == b[p]) {
                    self->recp->fields[self->recp->len]->vlen = value_pos;
                    self->recp->len++;
                    p++;
                    state = NLBP_START_NVP;
                }
                else if (is_quoted_valuechar(b[p]))
                    value[value_pos++] = b[p++];
                else {
                    PBERR("bad quoted value char");
                    goto error;
                }
                break;
            case NLBP_ESCAPED:
                if (b[p] == '\\' || b[p] == '"' || is_valuechar(b[p])) {                    
                    value[value_pos++] = b[p++];
                    state = NLBP_QUOTED_VALUE;
                }
                else {
                    PBERR("bad escaped value char");
                    goto error;
                }
                break;
            case NLBP_DONE:
                goto bottom;
            default:
                PBERR("unknown state");
                goto error;
        }
    }

    PBERR("unterminated record");
    return 0;
        
bottom:
    p++;
    self->buflen -= (p - self->pos);
    self->pos = p;
    return 1;
    
error:
    return -1;
}

