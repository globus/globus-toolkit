#ifndef NL_PARAMS_H_INCLUDED
#define NL_PARAMS_H_INCLUDED
/* 
   Copyright (c) 2007, The Regents of the University of California, through 
   Lawrence Berkeley National Laboratory (subject to receipt of any required 
   approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#include "nl.h"

/**@file nlparams.h Set of name=value parameters
 * @ingroup nlutil
 */
/*@{*/

#    ifdef __cplusplus
extern "C" {
#    endif

/**
 * Parameters type
 */
#   define T NL_params_T
    typedef struct T *T;


/**
 * Constructor
 *
 * @return Params object
 */
extern T NL_params(void);


/**
 * Append a key=value pair.
 * Both key and value are copied.
 *
 * @param self Params object
 * @param key The key, as a NUL-terminated string
 * @param value The value, as raw bytes
 * @param vlen Length of the value
 * @post key/value are now in the parameter list, at the end
 */
extern void NL_params_append(T self, const char *key, void *value, int vlen);

/**
 * Make a deep copy of parameters
 *
 * @param self Params object to copy
 * @return Deep copy
 */
extern T NL_params_copy(T self);

/**
 * Find and return int64 value.
 *
 * @param self Params object
 * @param key The key, as a NUL-terminated string
 * @param v Value (OUT)
 * @return 0 for success, -1 for failure
 */
int NL_params_get_int64(T self, const char *key, int64_t *v);

/**
 * Find and return int32 value.
 *
 * @param self Params object
 * @param key The key, as a NUL-terminated string
 * @param v Value (OUT)
 * @return 0 for success, -1 for failure
 */
int NL_params_get_int32(T self, const char *key, int32_t *v);

/**
 * Find and return double value.
 *
 * @param self Params object
 * @param key The key, as a NUL-terminated string
 * @param v Value (OUT)
 * @return 0 for success, -1 for failure
 */
int NL_params_get_double(T self, const char *key, double *v);

/**
 * Find and return a string value.
 *
 * @param self Params object
 * @param key The key, as a NUL-terminated string
 * @param str Malloc-ed string (OUT). Should be freed by caller.
 * @return 0 for success, -1 for failure
 */
int NL_params_get_string(T self, const char *key, char **str);

/**
 * Destructor
 */
extern void NL_params_del(T self);

#undef T

/*@}*/

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
