#ifndef NL_TSUMM_INT_H_INCLUDED
#    define NL_TSUMN_INT_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* 
 * Internal header for time-summarization
 */

#    include "nlwvar.h"
#    include "nlkahan.h"

#    ifdef __cplusplus
extern "C" {
#    endif


struct tsumm_stats {
    /** Time and value statistics. 
     *
     * For summarizing a time-series of values,
     * each associated with a time interval for which
     * we have the start and end times.
     * Variable names have been kept short but consistent:
     *   prefixes: v=value, t=time, r=ratio (value/time), n=count
     *   suffixes: _s=(kahan) sum, _m=minimum, _x=maximum
     */
        struct nl_ksum_var v_s,
                            /**< values */
         t_s,               /**< interval times */
         r_s;               /**< value/time in one interval */
        NL_wvar_T t_v,
                   /**< interval time variance */
         v_v,       /**< value variance */
         r_v;      /**< ratio variance */
        int64_t n,
               /**< number of intervals */
         nv;    /**< number of intervals with any value */
        double t_m,
                /**< minimum time interval seen */
         t_x,   /**< maximum time interval seen */
         v_m,   /**< minimum value seen */
         v_x,   /**< maximum value seen */
         r_m,   /**< minimum ratio seen */
         r_x;   /**< maximum ratio seen */
        int64_t summ_usec;  /**< when last summarization of group occurred */
        double dur; /**< duration summarized (sec.) */
};

/**
 * Summary state kept for time-based summarization.
 * Includes extra information needed to write out summary records.
 */
    struct tsumm_data {
        /* -- parameters -- */
    /** Time interval to summarize on, in microseconds */
        int64_t interval_usec;
        double min_val;
                    /**< minimum value allowed */
        double max_val;
                    /**< maximum value allowed */
    /** Cached boolean whether to filter the value at all.
     *  If min_val == max_val (e.g. min_val = max_val = 0),
     *  then this is false (0), otherwise true (1).
     */
        unsigned filter_value;
    /** name of output (summary) event */
        const char *output_event;
        int output_event_len;
                          /**< output event length */
        NL_rec_T rec;
    /** logging level for output records */
        NL_level_t output_level;
    /** minimum number of values to give a variance */
        int variance_baseline;

    /** event times */
        int64_t start_usec, /**< when last event occurred */
         prev_usec;         /**< when last 'end' event occurred */

    /** Summary statistics 0=this time interval, 1=cumulative */
        struct tsumm_stats stats[2];
    };

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
