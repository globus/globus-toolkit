/* 
   Copyright (c) 2004, The Regents of the University of California, through 
   Lawrence Berkeley National Laboratory (subject to receipt of any required 
   approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#ifndef NL_LOG_H_INCLUDED
#    define NL_LOG_H_INCLUDED

/** @file
 *
 * @brief The basic NetLogger client logging API.
 *
 * NetLogger is designed to make debugging and performance analysis of complex
 * distributed applications easier. It is a methodology (summarized in our 
 * "Logging Best Practices" document) for analyzing distributed systems, and a 
 * set of tools to help implement the methodology.
 * 
 * @ingroup nlapi 
 */

#    include <errno.h>
#    if NL_THREADED
#        include <pthread.h>
#    endif
#    include <fcntl.h>
#    include <stdarg.h>
#    include "nlstdint.h"
#    include <stdio.h>
#    include <syslog.h>
#    include <sys/time.h>

#    ifdef __cplusplus
extern "C" {
#    endif

/*-----------------------------------------------------------
 * Macros
 */

#ifndef MIN
#    define MIN(a,b) ((a) <= (b) ? (a) : (b))
#endif

#ifndef MAX
#    define MAX(a,b) ((a) >= (b) ? (a) : (b))
#endif

#define NL_AS_LL(S, R, E) do {          \
    char *endptr;                       \
    (R) = strtoll((S), &endptr, 10);    \
    (E) = (endptr == (S));              \
} while(0)

#define NL_AS_LONG(S, R, E) do {        \
    char *endptr;                       \
    (R) = strtol((S), &endptr, 10);     \
    (E) = (endptr == (S));              \
} while(0)

#define NL_AS_DBL(S, R, E) do {         \
    char *endptr;                       \
    (R) = strtod((S), &endptr);         \
    (E) = (endptr == (S));              \
} while(0)


/*-----------------------------------------------------------
 * Types
 */ struct NL_summ_T;

/* Opaque types */
    struct NL_subject_T;
#    define NL_subject_T struct NL_subject_T *

    struct NL_rec_t;
    typedef struct NL_rec_t *NL_rec_T;

    struct NL_fld_t;
    typedef struct NL_fld_t *NL_fld_T;

/*
 * Callback functions
 */

/** Observer callback */
    typedef int (*NL_observer_cb) (void *, void *);
/** Function that frees memory */
    typedef void (*NL_free_fn) (void *);

/**
 * Log level enumeration
 */
    typedef enum {
        NL_LVL_NOLOG = 0,
        NL_LVL_FATAL = 1,
        NL_LVL_ERROR = 2,
        NL_LVL_WARN = 3,
        NL_LVL_INFO = 4,
        NL_LVL_DEBUG = 5,
        NL_LVL_DEBUG1 = 6,
        NL_LVL_DEBUG2 = 7,
        NL_LVL_DEBUG3 = 8,
        NL_LVL_USER = 9,
    } NL_level_t;

/**
 * Return value enumeration
 */
    typedef enum {
        NL_OK = 0,
        NL_ERROR = -1
    } NL_result_t;

/*-----------------------------------------------------------
 * Environment variable names
 */

/** Output URL (new). 
 *  Example: "x-netlog://remote.host:55555" 
 */
#    define NL_DEST_ENV "NL_DEST"
/** Output URL (old env var.) 
 */
#    define NL_DEST2_ENV "NETLOGGER_DEST"


/** Log level file. 
 *  Full path to file containing log level.
 *  See parse_level() for details. 
 */
#    define NL_CFG_ENV "NL_CFG"

/** Extra text to append to each log entry.
  The formatting for this text is not
  checked, so improper values here will corrupt
  the logs. However, this is a useful way
  to add arbitrary metadata without changing
  the program in any way.
  The data doesn't need any delimiters at the start
  or end.

  For example, if the 'gridbp' format is being used:
  prompt> export NL_EXTRA='experiment.name="test 1" p1=5 p2=14'
 */
#    define NL_EXTRA_ENV "NL_EXTRA"


/*-----------------------------------------------------------
 * Global variables
 */

/** Flush flag.
 *  User may set this to '1' to turn on flushing of
 *  all (file) output. Note that this will GREATLY reduce performance,
 *  and should only be used if each message is critical (and 
 *  infrequent, i.e. < 10 per second).
 */
    extern int NL_flush_on;


/** File permission bits.
   User may set this to change the permissions
   on log files.
 
   Default value is 0664.
 */
    extern mode_t NL_file_mode;

/** File append flag.
    If non-zero, open file URLs with
    O_APPEND in the open flags.
*/
    extern int NL_file_append;

/** Flag controlling whether the environment variable
    always overrides the value provided to NL_open().
    If set to 1, then it does. Otherwise, the environment
    is only checked if the filename given to NL_open() is
    NULL.
    
    Default value is 1.
 */
    extern int NL_env_override;
    
/**********************************************************
 * High-level Logging API
 */

/* Opaque type */
#    define T NL_log_T
    struct T;
    typedef struct T *T;

/**
 * Create and open log.
 *
 * @param url Output URL.
 * Accepted URL patterns:
 *   - path
 *   - file://path
 *   - x-netlog://host[:port]
 *   - x-netlog-udp://host[:port]
 *   - x-syslog://[facility_name:]program_name
 *    Where 'facility_name' is one of the standard syslog macro
 *    names, case-insensitive and without the LOG_ prefix.
 *    For example "FTP", "Local0", and "syslog" are all valid.
 *    The default facility is USER (LOG_USER).
 *
 * @return Log handle, NULL on error. Because NetLogger did once,
 *         and may someday do so again, allow
 *         for changing the URL during the program's lifetime,
 *         opening a file that does not exist or is not writable
 *         will not return NULL. To check if a returned handle is
 *         currently able to produce output, call NL_is_active().
 */
    extern T NL_open(const char *url);

/**
 * Try opening a handle again.
 *
 * @param self Log object (should be non-NULL for a chance of success)
 * @param url Output URL (see NL_open() for details).
 * @pre NL_is_active() is false (0) for this handle
 * @return 0=success, -1=failure
 * @post If return is 0 (success), then NL_is_active is true for this handle.
 * @see NL_open()
 * @see NL_is_active()
 */
    extern int NL_reopen(T self, const char *url);

/**
 * Check whether NetLogger handle is valid and open.
 * 
 * An 'active' handle is one which was created and, at some point
 * between creation time and now, opened an output destination
 * successfully. For now, this simply means that the destination given
 * to NL_open() was valid, but we are leaving the door open (yet again)
 * to the idea of periodic re-tries or dynamically changing output
 * destinations.
 *
 * @param self Log object (may be NULL)
 * @return 1=yes, 0=no.
 */
    extern int NL_is_active(T self);

/** 
 * Create 'constant' record.
 * Replace existing constant record, if any.
 *
 * @post This call does nothing if the log object is closed.
 *
 * @param self Log object.
 * @param fmt Format used to create log.
 * @return Success (NL_OK) or failure (NL_ERROR).
 */
    extern NL_result_t NL_set_const(T self, const char *fmt, ...);

/**
 * Set log level.
 *
 * @param self  Log object
 * @param level New logging level
 *
 * @return None
 */
    extern void NL_set_level(T self, NL_level_t level);

/**
 * Get log level.
 *
 * @param self  Log object
 * @return level Current logging level
 */
    extern NL_level_t NL_get_level(T self);

/**
 * Write one log event.
 *
 * @param self  Log object
 * @param level Logging level for this event
 * @param event Event name
 * @param fmt   Format for event attributes:
 *  "name1=type_code1 name2=type_code2 ..etc..".
 *   @par Recognized type_codes (all single characters):
 *     - 'd' Double (64 bits)
 *     - 's' String
 *     - 'i' Integer (32 bits)
 *     - 'l' Long integer (64 bits)
 *     - 't' Time; input as double seconds since UTC,1970    
 * @param ...        Event attributes
 * @return Status of write operation
 */
    extern NL_result_t NL_write(T self, NL_level_t level,
                                const char *event, const char *fmt, ...);

/**
 * Write one event with user-supplied timestamp.
 *
 * @param self  Log object
 * @param ts    Timestamp
 * @param level Logging level for this event
 * @param event Event name
 * @param fmt   Format for event attributes:
 *  "name1=type_code1 name2=type_code2 ..etc..".
 *   @par Recognized type_codes (all single characters):
 *     - 'd' Double (64 bits)
 *     - 's' String
 *     - 'i' Integer (32 bits)
 *     - 'l' Long integer (64 bits)
 *     - 't' Time; input as double seconds since UTC,1970    
 * @param ...        Event attributes
 * @return Status of write operation
 */
    extern NL_result_t NL_write_ts(T self, struct timeval *ts,
                                   NL_level_t level, const char *event,
                                   const char *fmt, ...);

/* write-record */
    extern NL_result_t NL_write_rec(T, NL_rec_T rec, NL_level_t level);

/**
 * Flush log.
 *
 * @param self Log object
 */
    extern void NL_flush(T self);

/**
 * Close and destroy log.
 *
 * @pre Parameter is NULL or valid log object.
 * @post Argument passed as 'self' is closed.
 * @param self Log object
 */
    extern void NL_close(T self);

/** @} */

/**
 * @addtogroup nlsummint
 *
  * @{
 */

/**
 * Return subject for observers of new records.
 *
 * The observer pattern is used to keep the summarizer and 'main'
 * NetLogger API decoupled. This function and NL_get_flush_subject()
 *  are used to get a subject to which summarizer observers are added.
 *
 * @param self Log object
 * @return Subject whose observers are notified when a new record
 *         is detected during execution of NL_write().
 */
    NL_subject_T NL_get_new_record_subject(T self);

/**
 * Return subject for observers of "flush" events.
 *
 * See NL_get_new_record_subject() for details.
 *
 * @param self Log object.
 * @return Subject whose observers are notified on NL_flush().
 */
    NL_subject_T NL_get_flush_subject(T self);

/** @} */

/**
 * @addtogroup subsmpl Experimental subsampling API
 *
 * This only works with pairs of events in the same
 * static scope (function).
 *
 * @{
 */

/** Maximum number of things to sample */
#    define NL_MAX_SMPL 16

    typedef struct NL_smpl_t {
        int32_t id_list[NL_MAX_SMPL];
        long rate;     /* 0 .. 2^31-1 */
    } *NL_smpl_t;

/**
 * Set sampling rate for (experimental) sub-sampling API
 *
 * @param prob_true Probability 0..1 of a given event being sampled
 */
    extern void NL_set_smpl_rate(T, double prob_true);

/**
 * Get current sampling obj.
 *
 * @param self Log object to sample
 */
    extern NL_smpl_t NL_get_smpl(T self);

/**
 * Begin of a sampled begin/end event pair.
 *
 * @param I An integer position for the pair 0.. NL_MAX_SMPL-1
 * @param L The NL_log_T object
 * @param S The result of NL_get_smpl(L)
 * @param V Log level
 * @param E Event name
 * @param F Format string
 * @param args.. Rest of arguments to function
 */
#    define NL_write_begin(I,L,S,V,E,F,args...) \
    if (random() <= (S)->rate) { \
        (S)->id_list[(I)] = 1;                  \
        NL_write((L),(V),(E),(F), ##args);      \
    }

/**
 * End of sampled begin/end event pair.
 *
 * @param I An integer position for the pair 0.. NL_MAX_SMPL-1
 * @param L The NL_log_T object
 * @param S The result of NL_get_smpl(L)
 * @param V Log level
 * @param E Event name
 * @param F Format string
 * @param args.. Rest of arguments to function
 */
#    define NL_write_end(I,L,S,V,E,F,args...) \
    if ( (S)->id_list[(I)] == 1 ) {         \
      NL_write((L),(V),(E),(F),##args);       \
      (S)->id_list[I] = 0;                    \
    } 
    
/**@}*/

#    undef T

/**
 * @addtogroup nlutil
 * @{ 
 */

/**
 * Look up dotted-decimal IP addr of this host.
 */
    extern char *NL_get_ipaddr(void);

/**
 * Get a GUID.
 * The result is placed in the buffer, NUL-terminated.
 *
 * This will use uuidlib if the headers uuid/uuid.h were
 * found by configure; otherwise it will try to execute
 * the command 'uuidgen' using popen().
 *
 * @param  buf Buffer to put it into, allocated by function.
 *         Caller should free this memory when done with it.
 * @return Length of data in buffer, not including trailing NUL.
 *         -1 is failure
 */
    extern int NL_get_guid(char **buf);

/**
 * Get some sort of unique-ish identifier, not necessarily
 * conforming to any sort of specification. You can use
 * this if NL_get_guid() fails.
 * 
 * @param buf Buffer to put it into, allocated by function.
 *            Caller should free this memory when done with it.
 * @return Length of data in buffer, not including trailing NUL
 *         -1 is failure
 */
    extern int NL_get_someid(char **buf);

/**
 * The equivalent of sprintf() for NetLogger.
 *
 * Example: see nlsprintf_example.c in examples/ dir
 *
 * @param buf Output buffer, make sure it is at least
 *         NL_MAX_FLD * NL_MAX_STR, or know what you are doing.
 * @param  event NL.EVNT field value
 * @param level NetLogger level, e.g. NL_LVL_INFO
 * @param fmt Format string as documented in NL_log_{write,print}
 * @param  ... Variables for format string
 * @return Number of bytes written to 'buf'. Like sprintf().
 *         If return val <= 0, there was an error.
 */
    int NL_sprintf(char *buf, const char *event, int level, char *fmt,
                   ...);

/**
 * Split a URL given to NL_open() for syslog into program and facility.
 * See NL_open() for the input URL format.
 * @param url NetLogger syslog output URL
 * @param prog (OUT) Syslog program name
 * @param facility (OUT) Syslog facility code
 */
    void split_syslog_url(char *url, char **prog, int *facility);

/**
 * Provide string name for a level code.
 *
 * @param level Level code
 * @return Name of code.
 */
    extern const char *NL_get_level_name(NL_level_t level);

/**
 * Provide level code for string name.
 *
 * @param name Level name
 * @return Level code
 */
    extern NL_level_t NL_get_level_code(const char *name);

/**
 * Clear error buffer.
 *
 * This should be done between successive calls to NL_err_str()
 * that want to get only the intervening errors.
 * Usually users will not need this function.
 */
    extern void
     NL_err_clear(void);

/**
 * Get last NetLogger error(s) as a string.
 *
 * Note: Does not clear the buffer. You
 * must do this explicitly with NL_err_clear().
 *
 * @return Pointer to global error buffer. Please use read-only and
 *         take care of any thread-safety issues your own self.
 */
    extern const char *NL_err_str(void);

/**
 * Simple macro to get time as a #sec since epoch.
 */
#define NL_GET_DBL_TIME(T) do {                 \
    struct timeval tv;                          \
    gettimeofday(&tv,0);                        \
    (T) = tv.tv_sec + tv.tv_usec / 1e6;         \
} while(0)

/** @} */


#    undef NL_subject_T

#    ifdef __cplusplus
}
#    endif
#endif
