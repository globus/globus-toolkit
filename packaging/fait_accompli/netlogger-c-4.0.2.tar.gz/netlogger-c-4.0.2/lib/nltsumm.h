#ifndef NL_TSUMM_H_INCLUDED
#    define NL_TSUMM_H_INCLUDED
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/** 
 * @file nltsumm.h Time-based summarization.
 * @addtogroup nlsumm
 * @{
 */

#    include "nl.h"
#    include "nlsumm.h"

/* Opaque types */
struct NL_summstate_T;
#    define NL_summstate_T struct NL_summstate_T *
struct NL_params_T;
#    define NL_params_T struct NL_params_T *

#    ifdef __cplusplus
extern "C" {
#    endif

/*
 * Time-summarization parameters.
 */

/** Summarization interval in microseconds */
#    define NLTSUMM_P_INTERVAL "interval"
/** Minimum value summarized. Events with a lower value are not counted. */
#    define NLTSUMM_P_MIN "min"
 /** Maximum value accepted. Events with a higher value are not counted. */
#    define NLTSUMM_P_MAX "max"
 /** Minimum number of values needed to calculate a variance. */
#    define NLTSUMM_P_VARBASE "variance-baseline"
 /** Output summary event name (e.g. if 'foo', then event=foo).*/
#    define NLTSUMM_P_EVENT "event"
 /** Output summary event logging level (e.g. if 'INFO' then level=INFO). */
#    define NLTSUMM_P_LVL "output-level"

/** Default min. number of items for variance calculation */
#    define NLTSUMM_D_VARBASE 10
/** Default event name */
#    define NLTSUMM_D_EVENT "summary"
/** Default output level */
#    define NLTSUMM_D_LVL "debug"

/* -------------------------------------------------
 * Functions
 */

/** 
 * Initialize state.
 *
 * @param params String name=value pairs. The names should match one
 *               of the NLTSUMM_P_<param> constants defined in this file.
 * @return Pointer to allocated and initialized state, or NULL on failure.
 */
    extern void *NL_tsumm_init(NL_params_T params);

/**
 * Process a record. 
 *
 * @param state Current summarized state of the record.
 * @return Success (0) or failure (-1).
 */
    extern int NL_tsumm_process(NL_summstate_T state);

/**
 * Flush current state. 
 *
 * @param state Current summarized state of the record.
 * @post A summary record is written to the output destination.
 */
    extern void NL_tsumm_flush(NL_summstate_T state);

/**
 * Free the internal summary data.
 *
 * @pre Input parameter points to allocated (struct tsumm).
 * @param data Pointer to data of (struct tsumm).
 * @post Memory for data is de-allocated.
 */
    extern void NL_tsumm_free_data(void *data);

/** @} */

#    undef NL_params_T
#    undef NL_summstate_T

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
