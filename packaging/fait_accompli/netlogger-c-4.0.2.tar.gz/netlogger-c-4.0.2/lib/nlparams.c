/* 
   Copyright (c) 2007, The Regents of the University of California, through 
   Lawrence Berkeley National Laboratory (subject to receipt of any required 
   approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#include <stdlib.h>
#include <string.h>
#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "nlalist.h"
#include "nlparams.h"
#include "nlstdint.h"

/*
 * Parameters type
 */
#define T NL_params_T
struct T {
    NL_alist_T plist;
};


/*
 * Constructor
 */
T NL_params(void)
{
    T self = malloc(sizeof(struct T));
    self->plist = NL_alist();
    return self;
}

/*
 * Append name=value
 */
void NL_params_append(T self, const char *key, void *value, int vlen)
{    
    NL_adata_T dkey, dvalue;

    dkey = NL_adata((void*)key, strlen(key), 1);
    dvalue = NL_adata(value, vlen, 1);
    NL_alist_append(self->plist, NL_anode(dkey, dvalue));
}

/*
 * Make a deep copy of parameters
 */
T NL_params_copy(T self) 
{
    T copy = malloc(sizeof(struct T));
    
    copy->plist = NL_alist_copy(self->plist);
    return copy;        
}

/*
 * Get, converting to datatype
 */
 
 /*
  * Common code for get-s below
  */
static inline NL_adata_T get_value(T self, const char *key)
{
    NL_anode_T node;                                
    NL_adata_T tgt;                         
    
    tgt = NL_adata((void*)key, strlen(key), 0);             
    node = NL_alist_get_by_key(self->plist, tgt);
    NL_adata_del(tgt);    
    return node ? NL_anode_get_value(node) : NULL;
}

/*
 * Get int64 value
 */
int NL_params_get_int64(T self, const char *key, int64_t *v)
{
    NL_adata_T vdata;
    
    if (!(vdata = get_value(self, key)))
        return -1;
    *v = *((int64_t*)NL_adata_get_value(vdata));
    return 0;
}

/*
 * Get int32 value
 */
int NL_params_get_int32(T self, const char *key, int32_t *v)
{
    NL_adata_T vdata;
    
    if (!(vdata = get_value(self, key)))
        return -1;
    *v = *((int32_t*)NL_adata_get_value(vdata));
    return 0;
}

/*
 * Get double value
 */
int NL_params_get_double(T self, const char *key, double *v)
{
    NL_adata_T vdata;
    
    if (!(vdata = get_value(self, key)))
        return -1;
    *v = *((double*)NL_adata_get_value(vdata));
    return 0;
}

/*
 * Get string value
 */
int NL_params_get_string(T self, const char *key, char **v)
{
    NL_adata_T vdata;
    
    if (!(vdata = get_value(self, key)))
        return -1;
    *v = NL_adata_as_str(vdata, ' ');
    return 0;
}

/*
 * Destructor
 */
void NL_params_del(T self)
{
    if (self) {
        NL_alist_del(self->plist);
        free(self);
    }
}

#undef T