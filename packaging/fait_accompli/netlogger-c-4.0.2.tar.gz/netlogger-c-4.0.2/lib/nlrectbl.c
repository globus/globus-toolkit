/**
 * Specialized hashtable
 */

#ifndef lint
static const volatile char rcsid[] =
    "$Id: nlrectbl.c 121 2007-08-19 23:19:37Z dang $";
#endif

#include <stdlib.h>
#include <string.h>
#include "nlrectbl.h"

/** Constructor */
nl_rectbl_t nl_rectbl_new(NL_free_fn free_fn)
{
    nl_rectbl_t self = malloc(sizeof(struct nl_rectbl_t));
    self->free_fn = free_fn;
    self->nodes = calloc(NLRECTBL_SZ, sizeof(struct nl_recnode_t));
    return self;
}

/**
 * Destructor
 */
void nl_rectbl_del(nl_rectbl_t self)
{
    int i;
    nl_recnode_t nodep, prevp;

    for (i = 0; i < NLRECTBL_SZ; i++) {
        nodep = self->nodes[i];
        while (nodep) {
            if (self->free_fn)
                self->free_fn(nodep->data);
            free(nodep->key);
            prevp = nodep;
            nodep = nodep->nextp;
            free(prevp);
        }
    }
    free(self->nodes);
    free(self);
}

/**
 * Get record
 */
void *nl_rectbl_get(nl_rectbl_t self, const char *key, int keylen)
{
    register int index, ii;
    nl_recnode_t nodep;

    NLRECTBL_HASH(key, keylen, index);
    for (nodep = self->nodes[index]; nodep; nodep = nodep->nextp) {
        if (nodep->keylen == keylen && !memcmp(nodep->key, key, keylen))
            break;
    }
    if (nodep)
        return nodep->data;
    else
        return NULL;
}

/**
 * Get record, known index
 */
void *nl_rectbl_geti(nl_rectbl_t self, int index, const char *key,
                     int keylen)
{
    nl_recnode_t nodep;

    for (nodep = self->nodes[index]; nodep; nodep = nodep->nextp) {
        if (nodep->keylen == keylen && !memcmp(nodep->key, key, keylen))
            break;
    }
    if (nodep)
        return nodep->data;
    else
        return NULL;
}

/**
 * Put record ( & set index )
 */
void
nl_rectbl_put(nl_rectbl_t self, const char *key, int keylen, void *data,
              int *hash_index)
{
    register int index, ii;
    nl_recnode_t nodep, prevp, newnodep;
    /*
       write(1,"@@ PUT:",7);
       write(1, key, keylen);
       write(1,"\n",1);
     */
    NLRECTBL_HASH(key, keylen, index);
    prevp = NULL;
    for (nodep = self->nodes[index]; nodep; nodep = nodep->nextp) {
        if (nodep->keylen == keylen && !memcmp(nodep->key, key, keylen))
            return;
        prevp = nodep;
    }
    newnodep = malloc(sizeof(struct nl_recnode_t));
    newnodep->key = malloc(keylen);
    memcpy(newnodep->key, key, keylen);
    newnodep->keylen = keylen;
    newnodep->data = data;
    newnodep->nextp = NULL;
    if (!prevp)
        self->nodes[index] = newnodep;
    else
        prevp->nextp = newnodep;
    *hash_index = index;
}

/**
 * Apply a generic function to each item in the table.
 */
void
nl_rectbl_apply(nl_rectbl_t self, nl_rectbl_visitfn_t func, void *data)
{
    int i;
    nl_recnode_t p;

    for (i = 0; i < NLRECTBL_SZ; i++) {
        for (p = self->nodes[i]; p; p = p->nextp) {
            func(self, p, data);
        }
    }
}
