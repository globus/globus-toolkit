#ifndef NL_BPPARSE_H_INCLUDED
#define NL_BPPARSE_H_INCLUDED
/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/** @file
 * Fast state-machine-based parser for best-practices logs.
 */

#include "nl.h"

#ifdef __cplusplus
extern "C" {
#endif
# if 0
}
#endif 

#define T NL_bpparse_T
typedef struct T *T;


/**
 * Constructor.
 *
 * @return Initialized parser instance
 */
T NL_bpparse(void);

/**
 * Add a buffer to be parsed.
 *
 * @param self Parser instance
 * @param buf Pointer to the data
 * @param buflen Length of data in buffer
 * @return 0 if there is space, else -1
 * @post Input buffer is copied into internal buffer, caller still owns
 *       its memory (i.e. may free 'buf' after this fn returns).
 * @post If return is -1, then realloc() failed and there
 * may be program-wide problems allocating memory.
 */
int NL_bpparse_add_buf(T self, const char *buf, int buflen);

/**
 * Add a NUL-terminated string of data to be parsed.
 *
 * @param self Parser instance
 * @param str NUL-terminated string
 * @return 0=OK, -1 otherwise
 * @post See NL_bpparse_add_buf()
 */
int NL_bpparse_add_str(T self, const char *str);

/**
 * Get a pointer to the current error message(s)
 *
 * @param self Parser instance
 * @return Pointer to a buffer, caller should NOT free it.
 */
 const char *NL_bpparse_get_err(T self);
 
/**
 * Parse and return the next record from the provided data.
 *
 * @param self Parser instance
 * @param rec_out  Address of a record (OUT)
 * @return 0=OK, -1 on parse or internal error. If there are no more records
 *         in the data, return is 0 but rec is set to NULL.
 * @post The memory of the returned record should NOT be freed by the caller.
 */
int NL_bpparse_next_rec(T self, NL_rec_T *rec_out);

/**
 * Destructor
 *
 * @param self Parser instance
 */
void NL_bpparse_del(T self);

#undef T

#ifdef __cplusplus
}
#endif
#endif /* ..._INCLUDED */
