/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
static const volatile char rcsid[] = "$Id$";

#include <ctype.h>
#include <stdlib.h>
#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "nlalist.h"

/*
 * Parse a string into an associative array of named values.
 */
int NL_parse_str(const char *str, NL_alist_T *nvp_out)
{
    NL_alist_T nvp = NULL;
    
    if (!str)
        goto error;

    nvp = NL_alist();
    
    /* XXX: Call yacc/bison here with (nvp) */
    
    *nvp_out = nvp;
    return 0;
    
error:
    if (nvp)
        NL_alist_del(nvp);
    return -1;
}

int NL_parse_split(const char *buf, char **str_out, unsigned *n_out)
{
    const char *p;
    unsigned i, n;
    
    if (!buf)
        goto error;
    /* pass 1: count newlines */
    for (p = buf, n=0; *p; p++) {
        if (*p == '\n')
            n++;
    }
    /* allocate */
    *n_out = n+1;
    *str_out = malloc(sizeof(char*) * (*n_out));
    if (NULL == *str_out)
        goto error;
    /* pass 2: assign pointers */
    (*str_out)[0] = buf;
    for (p = buf, i=1; *p && i < (*n_out); p++) {
        if (*p == '\n')
            (*str_out)[i++] = p;
    }

    return 0;
    
error:
    return -1;
}
