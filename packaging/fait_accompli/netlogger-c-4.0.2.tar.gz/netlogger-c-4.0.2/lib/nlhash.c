 /* 
    Copyright (c) 2007, The Regents of the University of California, through 
    Lawrence Berkeley National Laboratory (subject to receipt of any required 
    approvals from the U.S. Dept. of Energy).  All rights reserved.
  */
static const volatile char rcsid[] = "$Id$";

/**
 * Hash table
 */

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif

#include "nlhash.h"

void NL_hash_nofree(void *ignore)
{
}

/* ------------------------------------------ */

#define T NL_hash_list_t

T NL_hash_list(uint32_t size)
{
    T self = malloc(sizeof(struct T));
    self->heads = calloc(sizeof(NL_hash_node_t), size);
    self->size = size;
    return self;
}

void NL_hash_list_del(T self, void (*free_func) (void *))
{
    uint32_t i;
    for (i = 0; i < self->size; i++)
        if (self->heads[i])
            free_func(self->heads[i]->data);
    free(self->heads);
    free(self);
}

void
NL_hash_list_add(T self, uint32_t idx, const char *key, uint32_t keylen,
                 void *data)
{
    NL_hash_node_t node = malloc(sizeof(struct NL_hash_node_t));

    node->key = malloc(keylen * sizeof(char));
    memcpy((char *) node->key, key, keylen);
    node->keylen = keylen;
    node->data = data;
    node->next = self->heads[idx];
    self->heads[idx] = node;
}

/* Find node & return it */
inline NL_hash_node_t
NL_hash_list_get_node(T self, uint32_t idx, const char *key,
                      uint32_t keylen)
{
    NL_hash_node_t node;
    for (node = self->heads[idx]; node; node = node->next)
        if (node->keylen == keylen && !memcmp(node->key, key, keylen))
            return node;
    return NULL;
}

/* Do something at every node */
static void
NL_hash_list_visit(T self, NL_hash_T tbl, NL_hash_vfunc_t vfunc,
                   void *vdata)
{
    uint32_t i;
    NL_hash_node_t node;
    for (i = 0; i < self->size; i++) {
        for (node = self->heads[i]; node; node = node->next) {
            vfunc(tbl, node, vdata);
        }
    }
}

#undef T

/* ------------------------------------------ */

#define T NL_hash_T

T NL_hash(uint32_t size)
{
    T self = malloc(sizeof(struct T));
    for (self->mask = 1; self->mask < size; self->mask *= 2);
    self->size = self->mask--;         /* round up to next power of 2 */
    self->list = NL_hash_list(self->size);
    self->length = 0;
    return self;
}

void NL_hash_del(T self, void (*free_func) (void *))
{
    NL_hash_list_del(self->list, free_func);
    free(self);
}

void *NL_hash_put(T self, const char *key, uint32_t keylen, void *data,
                  unsigned char replace)
{
    int idx;
    NL_hash_node_t node;
    void *result;
    uint32_t hash;

    result = NULL;
    HASH(key, keylen, hash);
    idx = hash & self->mask;
    node = NL_hash_list_get_node(self->list, idx, key, keylen);
    if (node) {
        if (replace) {
            result = node->data;
            node->data = data;
        }
    }
    else {
        NL_hash_list_add(self->list, idx, key, keylen, data);
        self->length++;
    }
    return result;
}

void NL_hash_visit(T self, NL_hash_vfunc_t func, void *vdata)
{
    NL_hash_list_visit(self->list, self, func, vdata);
}


#undef T
