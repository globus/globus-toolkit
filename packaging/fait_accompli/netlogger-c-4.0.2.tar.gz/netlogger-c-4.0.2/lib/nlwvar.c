/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
#ifndef lint
static const volatile char rcsid[] =
    "$Id: nlwvar.c 130 2007-08-22 14:09:32Z dang $";
#endif

#include <stdlib.h>
#include <math.h>
#include "nlwvar.h"

#define T NL_wvar_T

struct T {
    double m, t;
    unsigned count, baseline;
};


static inline void wvar_clear(T self)
{
    self->m = self->t = 0.0;
    self->count = 0;
}


T NL_wvar_new(unsigned baseline)
{
    T self = malloc(sizeof(struct T));
    self->baseline = baseline;
    wvar_clear(self);

    return self;
}

void NL_wvar_add(T self, double x)
{
    double q, r;

    if (self->count == 0) {
        self->m = x;
        self->t = 0.0;
    }
    else {
        q = x - self->m;
        r = q / (self->count + 1);
        self->m = self->m + r;
        self->t = self->t + self->count * q * r;
    }
    self->count++;
}

void NL_wvar_clear(T self)
{
    wvar_clear(self);
}

double NL_wvar_variance(T self)
{
    if (self->count < self->baseline)
        return NL_NOT_ENOUGH_DATA;
    else
        return self->t / (self->count - 1);
}

double NL_wvar_sd(T self)
{
    if (self->count < self->baseline)
        return NL_NOT_ENOUGH_DATA;
    else
        return sqrt(NL_wvar_variance(self));
}

void NL_wvar_del(T self)
{
    if (self)
        free(self);
}



#undef T
