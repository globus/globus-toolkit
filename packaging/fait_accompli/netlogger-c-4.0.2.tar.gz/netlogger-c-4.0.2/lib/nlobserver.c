/** 
 * Observer pattern 
 */
#ifndef lint
static const volatile char rcsid[] =
    "$Id: nlobserver.c 128 2007-08-21 21:49:45Z dang $";
#endif

#include <stdlib.h>
#include "nlobserver.h"

#define T NL_observer_T
struct T {
    NL_observer_cb do_notify;
    void *context;
};

T NL_observer(NL_observer_cb callback, void *context)
{
    T self = malloc(sizeof(struct T));

    self->do_notify = callback;
    self->context = context;

    return self;
}

void NL_observer_del(T self)
{
    if (self) {
        free(self);
    }
}

#undef T

#define T NL_subject_T
struct T {
    void **obs;
    int obs_sz, obs_n;
};

#define OBS_CHUNK_N 32

T NL_subject(void)
{
    T self = malloc(sizeof(struct T));

    self->obs_sz = OBS_CHUNK_N;
    self->obs_n = 0;
    self->obs = (void **) malloc(sizeof(void *) * self->obs_sz);

    return self;
}

void NL_subject_register(T self, NL_observer_T obs)
{
    if (self->obs_n == self->obs_sz) {
        self->obs_sz += OBS_CHUNK_N;
        self->obs = realloc(self->obs, self->obs_sz * sizeof(void *));
    }
    self->obs[self->obs_n++] = obs;
}

int NL_subject_unregister(T self, NL_observer_T obs)
{
    int i, result;

    result = -1;
    for (i = 0; result == -1 && i < self->obs_n; i++) {
        if (self->obs[i] == obs) {
            int j;
            for (j = i + 1; j < self->obs_n; j++) {
                self->obs[j - 1] = self->obs[j];
            }
            self->obs_n--;
            result = 0;
        }
    }

    return result;
}

int NL_subject_notify(T self, void *arg)
{
    int i;

    for (i = 0; i < self->obs_n; i++) {
        NL_observer_T obs = (NL_observer_T) self->obs[i];
        obs->do_notify(obs->context, arg);
    }

    return self->obs_n;
}

void NL_subject_del(T self)
{
    if (self) {
        /* note: don't free observers since there is a 1-to-many
         * relationship of observers to subjects. 
         */
        /* BAD: if (self->obs_n) { NL_observer_del(self->obs[0]); } */
        free(self);
    }
}

#undef T
