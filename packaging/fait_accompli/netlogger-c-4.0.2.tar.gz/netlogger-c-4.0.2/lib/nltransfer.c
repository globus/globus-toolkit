/* 
Copyright (c) 2007, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
const volatile char rcsid[] = "$Id$";

#include <float.h>
#include <limits.h>
#include <stdlib.h>
#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include "nltransfer.h"
#include "nlint.h"
#include "nlparams.h"
#include "nlsummint.h"
#include "nltsummint.h"
#include "nlbpparse.h"
     
#define NL_OP_NS "transfer."
const char *g_op_name[] = {
    NL_OP_NS "disk.read.start",
    NL_OP_NS "disk.read.end",
    NL_OP_NS "disk.write.start",
    NL_OP_NS "disk.write.end",
    NL_OP_NS "net.read.start",
    NL_OP_NS "net.read.end",
    NL_OP_NS "net.write.start",
    NL_OP_NS "net.write.end"
};
const char *g_op_sname[] = {
    NL_OP_NS "disk.read.summ",
    NL_OP_NS "disk.write.summ",
    NL_OP_NS "net.read.summ",
    NL_OP_NS "net.write.summ"
};

/* human-readable name for operation */
const char *g_op_hname[] = {
    "disk read",
    "disk write",
    "net read",
    "net write"
};

/* now, use .summ instead
const char *g_op_rname[] = {
    NL_OP_NS "disk.read.result",
    NL_OP_NS "disk.write.result",
    NL_OP_NS "net.read.result",
    NL_OP_NS "net.write.result"
};
*/

#define NL_TRANSFER_START_EVENT(op) (g_op_name[2 * (op)])
#define NL_TRANSFER_END_EVENT(op)   (g_op_name[2 * (op) + 1])
#define NL_TRANSFER_SUMM_EVENT(op)  (g_op_sname[(op)])
#define NL_TRANSFER_RESULT_EVENT(op)  (g_op_sname[(op)])

/* guid is first identifier */
const int NL_TRANSFER_GUID_POS = 0;
/* stream.id is second */
const int NL_TRANSFER_STREAMID_POS = 1;

/* -- Visitor functions (internal) -- */

/* state needed for figuring out number of distinct streams */
struct nstreams_data_t {
    NL_transfer_op_t op;        /* operation we're looking for */
    unsigned nstream;           /* stream counter */
    const char *guid;           /* optional GUID that must match */
    unsigned guid_len;          /* length of GUID [use memcmp, it may have NULs] */
};

/* state needed for returning stream #i */
struct getstream_data_t {
    NL_transfer_result_t *stream_result;        /* space for result */
    unsigned num_streams;       /* the number of streams */
    NL_transfer_streamid_t stream_id;   /* sid we're looking for, 0 for 'all' */
    int stream_pos;             /* counter of # of stream to match, starting at 0 */
    NL_transfer_op_t op;        /* operation we're looking for */
    const char *guid;           /* optional GUID that must match */
    unsigned guid_len;          /* length of GUID [use memcmp, it may have NULs] */
    unsigned char cum;          /* flag, 0=interval data, 1=cumulative data */
};

inline static int
match_guid(const char *g, unsigned glen, NL_summstate_T state)
{
    /* extract guid field */
    NL_fld_t *fld = state->id_fields[NL_TRANSFER_GUID_POS];
    /* compare its value with (g,glen) */
    return (glen == fld->vlen && !memcmp(fld->value, g, glen));
}

/*
 * Visit summstate, while counting number of different streams
 */
static void visit_summstate_nstreams(NL_summvisitor_T self, void *x)
{
    NL_summstate_T state = (NL_summstate_T) x;
    struct nstreams_data_t *data;
    int i, match;

    data = (struct nstreams_data_t *) self->data;
    /* if guid was given, it must match */
    if (data->guid && !match_guid(data->guid, data->guid_len, state)) {
        goto bottom;
    }
    /* operation must also match */
    for (i = 0, match = 1; match && (i < 2); i++) {
        const char *e;
        e = i ? NL_TRANSFER_END_EVENT(data->op) :
            NL_TRANSFER_START_EVENT(data->op);
        match = match && NL_summseq_selector_equals(state->seq, i,
                                                    e, strlen(e));
    }
    if (!match) {
        goto bottom;
    }
    /* increment #streams seen */
    data->nstream++;

  bottom:
    return;
}

/*
 * Fill in values for result obj
 */
static void
build_result(NL_transfer_result_t * result,
             struct tsumm_data *d,
             struct tsumm_stats *statsp)
{
    /* counts */
    result->count = statsp->n;
    result->value_count = statsp->nv;
    /* duration */
    result->duration = statsp->dur;
    /* time */
    result->time_min = statsp->t_m;
    result->time_max = statsp->t_x;
    result->time_sum = statsp->t_s.s;
    if (statsp->n >= d->variance_baseline) {
        result->time_sd = NL_wvar_sd(statsp->t_v);
        result->time_sd_sum = statsp->n * result->time_sd;
        result->time_var = NL_wvar_variance(statsp->t_v);
        result->time_var_sum = statsp->n * result->time_var;
    }
    else {
        result->time_sd = result->time_sd_sum = NAN;
        result->time_var = result->time_var_sum = NAN;
    }
    /* value */
    result->value_min = statsp->v_m;
    result->value_max = statsp->v_x;
    result->value_sum = statsp->v_s.s;
    if (statsp->nv >= d->variance_baseline) {
        result->value_sd = NL_wvar_sd(statsp->v_v);
        result->value_sd_sum = statsp->nv * result->value_sd;
        result->value_var = NL_wvar_variance(statsp->v_v);
        result->value_var_sum = statsp->nv * result->value_var;
    }
    else {
        result->value_sd = result->value_sd_sum = NAN;
        result->value_var = result->value_var_sum = NAN;
    }
    /* ratio of value/time */
    result->ratio_min = statsp->r_m;
    result->ratio_max = statsp->r_x;
    result->ratio_sum = statsp->r_s.s;
    if (statsp->nv >= d->variance_baseline) {
        result->ratio_sd = NL_wvar_sd(statsp->r_v);
        result->ratio_sd_sum = statsp->nv * result->ratio_sd;
        result->ratio_var = NL_wvar_variance(statsp->r_v);
        result->ratio_var_sum = statsp->nv * result->ratio_var;
    }
    else {
        result->value_sd = result->value_sd_sum = NAN;
        result->value_var = result->value_var_sum = NAN;
    }
}

/*
 * Add values in 'x' to 'y'
 */
static void add_result(NL_transfer_result_t * y, NL_transfer_result_t * x)
{
    /* counts, duration */
    y->count += x->count;
    y->value_count += x->value_count;
    /* longest duration is the "real" one */
    y->duration = MAX(x->duration, y->duration);
    /* time */
    y->time_min = MIN(y->time_min, x->time_min);
    y->time_max = MAX(y->time_max, x->time_max);
    y->time_sum += x->time_sum;
    y->time_sd_sum += x->time_sd * x->count;
    y->time_var_sum += x->time_var * x->count;
    if (x->value_count > 0) {
        /* value */
        y->value_min = MIN(y->value_min, x->value_min);
        y->value_max = MAX(y->value_max, x->value_max);
        y->value_sum += x->value_sum;
        y->value_sd_sum += x->value_sd * x->value_count;
        y->value_var_sum += x->value_var * x->value_count;
        /* ratio */
        y->ratio_min = MIN(y->ratio_min, x->ratio_min);
        y->ratio_max = MAX(y->ratio_max, x->ratio_max);
        y->ratio_sum += x->ratio_sum;
        y->ratio_sd_sum += x->ratio_sd * x->value_count;
        y->ratio_var_sum += x->ratio_var * x->value_count;
    }
}

/*
 * Visit summstate while searching for a given stream/operation
 */
static void visit_summstate_getstream(NL_summvisitor_T self, void *x)
{
    NL_summstate_T state = (NL_summstate_T) x;
    struct tsumm_data *d;
    struct tsumm_stats *statsp;
    NL_fld_t *fld;
    struct getstream_data_t *data;
    NL_transfer_streamid_t value;
    int i, match;
    NL_transfer_op_t op;
    NL_summseq_T seq = state->seq;

    data = (struct getstream_data_t *) self->data;
    op = data->op;
    /* if we already matched our 1 stream, stop now */
    if (data->num_streams > 0 && data->stream_id > 0) {
        goto bottom;
    }
    /* if guid was given, it must match */
    if (data->guid && !match_guid(data->guid, data->guid_len, state)) {
        goto bottom;
    }
    /* operation must also match */
    for (i = 0, match = 1; match && (i < 2); i++) {
        const char *e;
        e = i ? NL_TRANSFER_END_EVENT(op) : NL_TRANSFER_START_EVENT(op);
        match = match && NL_summseq_selector_equals(seq, i, e, strlen(e));
    }
    if (!match) {
        goto bottom;
    }
    /* We're most likely going to build a result, so
     * set up pointers to summary state and statistics 
     */
    d = (struct tsumm_data *)state->data;
    if (data->cum)
        statsp = &d->stats[1];
    else
        statsp = &d->stats[0];
    /* for 1 particular stream, by position */
    if (data->stream_pos >= 0) {
        if (data->num_streams == data->stream_pos) {
            build_result(data->stream_result, d, statsp);
            /* set stream id so we know we matched */
            fld = state->id_fields[1];
            data->stream_id = *((NL_transfer_streamid_t *) fld->value);
        }
    }
    /* for 1 particular stream, by id */
    else if (data->stream_id > 0) {
        fld = state->id_fields[1];
        value = *((NL_transfer_streamid_t *) fld->value);
        if (value != data->stream_id) {
            goto bottom;
        }
        build_result(data->stream_result, d, statsp);
    }
    /* otherwise add to average for all streams */
    else {
        NL_transfer_result_t tmp_result;

        build_result(&tmp_result, d, statsp);
        add_result(data->stream_result, &tmp_result);
    }
    data->num_streams++;

  bottom:
    return;
}

/* 
 * Find out if this sequence is of the correct type 
 */
static inline unsigned is_transfer_sequence(NL_summseq_T seq)
{
    unsigned match = 0;
    NL_transfer_op_t op;
    int i, len;

    if (NL_summseq_get_len(seq) != 2) {
        return 0;
    }

    for (op = NL_TRANSFER_DISK_READ; !match && op < NL_TRANSFER_NOEVENT;
         op++) {
        const char *e[2] = { NL_TRANSFER_START_EVENT(op),
            NL_TRANSFER_END_EVENT(op)
        };
        for (i = 0, match = 1; match && (i < 2); i++) {
            len = strlen(e[i]);
            match = match && NL_summseq_selector_equals(seq, i, e[i], len);
        }
    }
    return match;
}

/*
 * Look at each summary sequence, and only continue
 * with those that have the right start/end events.
 */
static void visit_summseq(NL_summvisitor_T visitor, void *x)
{
    NL_summseq_T seq = (NL_summseq_T) x;

    if (is_transfer_sequence(seq)) {
        NL_summvisitor_walk_table(visitor, NL_summseq_get_states(seq));
    }
}

/* -- Internal function declarations -- */

 /* build NL_params_T from parameter values */
static NL_params_T set_info(NL_summ_T summ, int64_t interval,
                           NL_level_t level);
/* add all the  NL_TRANSFER_* events to the summarizer */
static int add_events(NL_summ_T summ, NL_params_T params);

/* -- External functions -- */

/*
 * Initialize summarizer.
 */
int NL_transfer_init(NL_summ_T summ, int64_t interval, NL_level_t level)
{
    NL_params_T params;
    int result = 0;

    if (NULL == summ || level < NL_LVL_NOLOG || level > NL_LVL_USER) {
        result = -1;
    }
    else {
        params = set_info(summ, interval, level);
        if (NULL == params) {
            result = -1;
        }
        else {
            result = add_events(summ, params);
            /* free params; copied by add_events() */
            NL_params_del(params);
        }
    }
    return result;
}

static NL_params_T
set_info(NL_summ_T summ, int64_t interval, NL_level_t level)
{
    NL_params_T params = NL_params();
    const char *level_name;
    int32_t i32;
    double dbl;
    
    /* interval */
    if (interval < 0LL) {
        interval = 0LL;
    }
     NL_params_append(params, NLTSUMM_P_INTERVAL, &interval, sizeof(interval));
    /* level */
    level_name = NL_get_level_name(level);
    if (NULL == level_name) {
        goto error;
    }
    NL_params_append(params, NLTSUMM_P_LVL,
                     (void*)level_name, strlen(level_name));
    i32 = 1;
    NL_params_append(params, NLTSUMM_P_VARBASE, &i32, 4);
    dbl = 0;
    NL_params_append(params, NLTSUMM_P_MIN, &dbl, sizeof(dbl));
    dbl = 1e300;
    NL_params_append(params, NLTSUMM_P_MAX, &dbl, sizeof(dbl));

    return params;

  error:
    NL_params_del(params);
    return NULL;
}

static int add_events(NL_summ_T summ, NL_params_T orig_params)
{
    NL_transfer_op_t op;
    NL_summseq_T sequence;
    int r;
    int64_t i64;
    NL_params_T params;
    const char *event, *sevent;

    for (op = NL_TRANSFER_DISK_READ; op < NL_TRANSFER_NOEVENT; op++) {
        unsigned i;
        sequence = NL_summseq();
        /* copy parameters for each sequence 
         * since they will free them, separately, when done
         */
        params = NL_params_copy(orig_params);
        /* add start and end events to sequence */
        for (i = 0; i < 2; i++) {
            switch (i) {
            case 0:
                event = NL_TRANSFER_START_EVENT(op);
                break;
            case 1:
                event = NL_TRANSFER_END_EVENT(op);
                break;
            default:
                assert(0);
            }
            r = (NL_summseq_add_selector(sequence, "event",
                                         (char *) event, strlen(event)) ||
                 NL_summseq_add_id_field(sequence, i, "guid") ||
                 NL_summseq_add_id_field(sequence, i, "stream.id") ||
                 NL_summseq_add_aux_field(sequence, i, "block.id")) ||
                (i == 1
                 && NL_summseq_add_value_field(sequence, i, "bytes"));
            if (r) {
                NL_err_add("add_events[%s]", event);
                goto error;
            }
        }
        /* finish intialization of sequence */
        sevent = NL_TRANSFER_SUMM_EVENT(op);
        NL_params_append(params, NLTSUMM_P_EVENT, (void*)sevent,
                         strlen(sevent));
        i64 = 0LL;
        NL_params_append(params, NLTSUMM_P_INTERVAL, &i64, 8);
        r = NL_summseq_set_info(sequence, params, NL_tsumm_init,
                                NL_tsumm_process, NL_tsumm_flush,
                                NL_tsumm_free_data);
        if (r) {
            NL_err_add("NL_summseq_set_info failed");
            goto error;
        }
        NL_summseq_set_consume(sequence, 1);
        NL_summ_add_sequence(summ, sequence);
    }
    return 0;

  error:
    return -1;
}

/*
 * Look at each summary sequence, and set consume to 0
 * on those that have the right start/end events.
 */
static void visit_passthrough(NL_summvisitor_T visitor, void *x)
{
    NL_summseq_T seq = (NL_summseq_T) x;

    if (is_transfer_sequence(seq)) {
        NL_summseq_set_consume(seq, 0);
    }
}

/*
 * Set !consume
 */
void NL_transfer_set_passthrough(NL_summ_T summ)
{
    NL_summvisitor_T visitor;

    /* init visitor */
    visitor = NL_summvisitor();
    visitor->visit_summseq = visit_passthrough;
    /* start visiting */
    NL_summ_accept(summ, visitor);
}

/*
 * Indicate start of operation for a given stream.
 */
void
NL_transfer_start(NL_log_T log,
                  NL_level_t level,
                  NL_transfer_op_t op,
                  const char *guid,
                  NL_transfer_streamid_t stream_id,
                  NL_transfer_blockid_t block_id)
{
    const char *real_guid = guid ? guid : "0";
    NL_write(log, level, NL_TRANSFER_START_EVENT(op),
             "guid=s stream.id=l block.id=l", real_guid, stream_id,
             block_id);
}

/*
 * Indicate start of operation for a given stream, with user-supplied timestamp.
 */
void
NL_transfer_start_ts(NL_log_T log,
                     struct timeval *ts,
                     NL_level_t level,
                     NL_transfer_op_t op,
                     const char *guid,
                     NL_transfer_streamid_t stream_id,
                     NL_transfer_blockid_t block_id)
{
    const char *real_guid = guid ? guid : "0";
    NL_write_ts(log, ts, level, NL_TRANSFER_START_EVENT(op),
                "guid=s stream.id=l block.id=l",
                real_guid, stream_id, block_id);
}


/*
 * Indicate end of operation for a given stream.
 */
void
NL_transfer_end(NL_log_T log,
                NL_level_t level,
                NL_transfer_op_t op,
                const char *guid,
                NL_transfer_streamid_t stream_id,
                NL_transfer_blockid_t block_id, double bytes)
{
    const char *real_guid = guid ? guid : "0";
    NL_write(log, level, NL_TRANSFER_END_EVENT(op),
             "guid=s stream.id=l block.id=l bytes=d",
             real_guid, stream_id, block_id, bytes);
}

/*
 * Finalize summarizer.
 */
void NL_transfer_finalize(NL_summ_T summ)
{
    if (summ) {
        NL_summ_flush(summ, NULL);
    }
}

/*
 * Get number of distinct streams.
 */
unsigned
NL_transfer_get_num_streams(NL_summ_T summ,
                            NL_transfer_op_t operation, const char *guid)
{
    struct nstreams_data_t data;
    NL_summvisitor_T visitor;

    if (!summ) {
        NL_err_add("summarizer is NULL");
        goto error;
    }
    /* initialize */
    data.nstream = 0;
    data.guid = guid;
    data.guid_len = guid ? strlen(guid) : 0;
    data.op = operation;
    /* init visitor */
    visitor = NL_summvisitor();
    visitor->data = &data;
    visitor->visit_summseq = visit_summseq;
    visitor->visit_summstate = visit_summstate_nstreams;
    /* start visiting */
    NL_summ_accept(summ, visitor);

    return data.nstream;
  error:
    return 0;
}

/*
 * Get result for given stream and operation. 
 */
int
NL_transfer_get_result(NL_summ_T summ,
                       NL_transfer_op_t operation,
                       const char *guid,
                       int stream_pos,
                       NL_transfer_streamid_t stream_id,
                       NL_transfer_result_t * resultp)
{
    struct getstream_data_t data;
    NL_summvisitor_T visitor;

    /* initialize */
    data.op = operation;
    data.guid = guid;
    data.guid_len = guid ? strlen(guid) : 0;
    data.stream_id = stream_id;
    data.stream_pos = stream_pos;
    data.num_streams = 0;
    data.cum = 1; /* always get cumulative stats */
    memset(resultp, 0, sizeof(NL_transfer_result_t));
    resultp->time_min = resultp->value_min = resultp->ratio_min = DBL_MAX;
    resultp->time_max = resultp->value_max = resultp->ratio_max = DBL_MIN;
    data.stream_result = resultp;
    /* init visitor */
    visitor = NL_summvisitor();
    visitor->data = &data;
    visitor->visit_summseq = visit_summseq;
    visitor->visit_summstate = visit_summstate_getstream;
    /* start visiting */
    NL_summ_accept(summ, visitor);
    /* pre-calculate means as sums/counts */
    resultp->time_mean = resultp->value_mean = resultp->ratio_mean = 0;
    if (resultp->count > 0) {
        resultp->time_mean = resultp->time_sum / resultp->count;
        resultp->time_sd = resultp->time_sd_sum / resultp->count;
        resultp->time_var = resultp->time_var_sum / resultp->count;
    }
    else {
        resultp->time_min = resultp->time_max = NAN;
    }
    if (resultp->value_count > 0) {
        resultp->value_mean = resultp->value_sum / resultp->value_count;
        resultp->ratio_mean = resultp->ratio_sum / resultp->value_count;
        resultp->value_sd = resultp->value_sd_sum / resultp->value_count;
        resultp->ratio_sd = resultp->ratio_sd_sum / resultp->value_count;
        resultp->value_var = resultp->value_var_sum / resultp->value_count;
        resultp->ratio_var = resultp->ratio_var_sum / resultp->value_count;
    }
    else {
        resultp->value_min = resultp->ratio_min = NAN;
        resultp->value_max = resultp->ratio_max = NAN;
    }
    /* copy in metadata */
    resultp->stream_id = data.stream_id;

    return (data.num_streams > 0 ? data.num_streams : -1);
}

/*
 * Walk through table and for each stream
 * retrieve the result and reformat as a string.
 */
char *NL_transfer_get_result_string(NL_summ_T summ,
                                    const char *guid)
{
    const int BUFCHUNK = 16384; /* max. size of one log line */
    int r, i, n, nbytes, len, size;
    NL_transfer_op_t op;
    char *buf;
    const char *print_guid;

    size = 2 * BUFCHUNK;
    buf = malloc(size);
    buf[0] = '\0';
    len = 0;
    print_guid = guid ? guid : "0";
    for (op = 0; op < NL_TRANSFER_NOEVENT; op++) {
        n = NL_transfer_get_num_streams(summ, op, guid);
        /*printf("@@ op %s has %d streams\n", NL_TRANSFER_SUMM_EVENT(op),n);*/
        for (i = 0; i < n; i++) {
            NL_transfer_result_t rslt;
            r = NL_transfer_get_result(summ, op, guid, (int) i, 0, &rslt);
            if (r < 0)
                continue;
            if (rslt.value_count == 0) {
                rslt.time_min = rslt.time_max = rslt.time_sd = NAN;
                rslt.value_min = rslt.value_max = rslt.value_sd = NAN;
                rslt.ratio_min = rslt.ratio_max = rslt.ratio_sd = NAN;
            }
            nbytes = NL_sprintf(buf + len, NL_TRANSFER_RESULT_EVENT(op),
                                NL_LVL_INFO,
                                "guid=s stream.id=l "
                                "n=l nv=l dur=d "
                                "t.m=d t.x=d t.s=d t.sd=d "
                                "v.m=d v.x=d v.s=d v.sd=d "
                                "r.m=d r.x=d r.s=d r.sd=d",
                                print_guid, rslt.stream_id,
                                rslt.count, rslt.value_count, rslt.duration,
                                rslt.time_min, rslt.time_max,
                                rslt.time_sum, rslt.time_sd,
                                rslt.value_min, rslt.value_max,
                                rslt.value_sum, rslt.value_sd,
                                rslt.ratio_min, rslt.ratio_max,
                                rslt.ratio_sum, rslt.ratio_sd);
            if (nbytes <= 0) {
                NL_err_add
                    ("NL_sprintf failed while making transfer string");
                goto error;
            }
            len += nbytes;
            if (size - len + 1 < BUFCHUNK) {
                size += BUFCHUNK;
                buf = realloc(buf, size);
                if (NULL == buf) {
                    NL_err_add("realloc() of buffer failed");
                    goto error;
                }
            }
        }
    }

    return buf;

  error:
    return NULL;
}

/*
 * Calculate bottleneck.
 *
 * Larger numbers are better (faster) ; it's bytes/sec.
 *
 * The values in 'inst' are in the same order as the
 * operations in the NL_transfer_op_t enumeration.
 * 
 */
static void bottleneck_alg1(double *inst, NL_transfer_btl_t *bp)
#define IS_SLOWER(x,y) (((x) * (1+thresh)) < (y))
{
    double thresh = 0.2; /* threshhold for determining signif. delta */
    int i, j, tmp, has_slowest;
    int order[NL_TRANSFER_NOEVENT];

   /* begin with glass half-empty */
    bp->result = NL_BTL_UNKNOWN;
        
    /* initial ordering, also check for data */    
    for (i=0; i < NL_TRANSFER_NOEVENT; i++) {
        if (inst[i] == 0) {
            bp->result = NL_BTL_MISSING_DATA;
            return; 
        }
        order[i] = i;
    }
    /* 
      Do a selection sort, rearranging indices in the
      order[] array to represent the ordering from min.. max 
    */
    for (i=0; i < NL_TRANSFER_NOEVENT - 1; i++) {
        for (j=i+1; j < NL_TRANSFER_NOEVENT; j++) {
            if (inst[order[i]] > inst[order[j]]) {
                tmp = order[i];
                order[i] = order[j];
                order[j] = tmp;
            }
        }
    }
    /* debugging */
    /*
    printf("@@\n");
    for (i=0; i < NL_TRANSFER_NOEVENT; i++) {
        double mbs = inst[order[i]] * 8 / 1000000;
        printf("@@ event(%d) %s => %lf Mb/s\n", order[i], 
               g_op_sname[order[i]], mbs);
    }
    printf("@@\n");
    */
    /* is the slowest one much slower than the 2nd slowest? */
    has_slowest = IS_SLOWER(inst[order[0]], inst[order[1]]);
    /* first the cases where there is a clear loser */
    if (has_slowest) {
        /* is disk read slowest? */
        if (order[0] == NL_TRANSFER_DISK_READ) {
            bp->result = NL_BTL_KNOWN;
            bp->location = NL_BTL_DISK_READ;       
        }
        /* net read? */
        else if (order[0] == NL_TRANSFER_NET_READ) {
            bp->result = NL_BTL_KNOWN;
            bp->location = NL_BTL_NET;               
        }
        /* disk write? */
        else if (order[0] == NL_TRANSFER_DISK_WRITE) {
            bp->result = NL_BTL_KNOWN;
            bp->location = NL_BTL_DISK_WRITE;               
        }
#if 0
        /* net write should NOT be slowest! */
        else {
            bp->result = NL_BTL_BAD_DATA;            
        }
#else
		else {
			/* if net write is slowest, maybe that's
			 * because it got pushback from disk.write
			 */
			if (order[1] == NL_TRANSFER_DISK_WRITE) {
				bp->result = NL_BTL_KNOWN;
				bp->location = NL_BTL_DISK_WRITE_MAYBE;
			}
		}
#endif
    }
    /* now the cases where the 1st two are close */
    if (bp->result == NL_BTL_UNKNOWN) {
        int are_close;
        /* 
          since disk.write pushes on net.read, assume
          that disk.write is the bottleneck if they are
          close, unless they are also close to the next
          one (net.write or disk.read), in which case
          give up..
         */
         are_close = (order[0] == NL_TRANSFER_DISK_WRITE &&
                      order[1] == NL_TRANSFER_NET_READ) ||
                     (order[1] == NL_TRANSFER_DISK_WRITE &&
                      order[0] == NL_TRANSFER_NET_READ);
        if (are_close && IS_SLOWER(inst[order[1]], inst[order[2]])) {
            bp->result = NL_BTL_KNOWN;
            bp->location = NL_BTL_DISK_WRITE_MAYBE;
        }
    }    
}
#undef IS_SLOWER

/*
 * Deduce bottleneck from combined result strings
 */
int NL_transfer_get_bottleneck(const char *result1,
                               const char *result2,
                               NL_transfer_btl_t *bp)
{
    NL_bpparse_T parser;
    NL_rec_T recp;
    NL_fld_t *fldp;
    char *endptr;
    char vstr[NL_MAX_STR];
    double r_s, nv;
    double *inst;
    int r, i, recnum;
    uint32_t nvt[4];
            
    /* make sure there is some data */
    if ((!result1 || 0 == strlen(result1)) && 
        (!result2 || 0 == strlen(result2))) {
        bp->result = NL_BTL_MISSING_DATA;       
        goto bottom;
    }


    /* feed data into parser */
    parser = NL_bpparse();
    if (result1)
        NL_bpparse_add_str(parser, result1);
    if (result2)
        NL_bpparse_add_str(parser, result2);

/* Use this to get a field's value as a NUL-terminated string */
# define VSTR(f) do { \
    memcpy(vstr, (f)->value, (f)->vlen); \
    vstr[(f)->vlen] = '\0'; \
} while(0)            

    /* sum up instantaneous throughputs */
    inst = bp->inst_thru = calloc(sizeof(double), NL_TRANSFER_NOEVENT);
    memset(&nvt, 0, sizeof(nvt));
	recnum = 0;
    for(;;) {
        r = NL_bpparse_next_rec(parser, &recp);
		recnum++;
        if (-1 == r) {
			NL_err_add("parse error with record #%d: %s", recnum, 
			           NL_bpparse_get_err(parser));
            goto error;
	    }
        if (NULL == recp)
            break;
        /* find event */
        fldp = NL_rec_find_field(recp, "event", 5);
        if (!fldp)
            continue; /* no event field (!) */

        /* figure out which summary event (if any) */
        VSTR(fldp);
        for (i=0; i < NL_TRANSFER_NOEVENT; i++) {
            if (!strcmp(vstr, g_op_sname[i]))
                break;
        }
        if (i == NL_TRANSFER_NOEVENT)
            continue; /* not a summary event */
        /* compute value we're using for throughput */
        /* get 'r.s' => sum of bytes/sec ratio */
        fldp = NL_rec_find_field(recp, "r.s", 3);
        if (!fldp) {
            NL_err_add("missing standard field 'r.s' in summary event");
            goto error;
        }
        VSTR(fldp);            
        r_s = strtod(vstr, &endptr);
        if (NULL == endptr) {
            NL_err_add("numeric field 'r.s' cannot be parsed as a number");
            goto error;
        }
        /* get 'nv' => number of reads/writes */
        fldp = NL_rec_find_field(recp, "nv", 2);
        if (!fldp){
            NL_err_add("missing standard field 'nv' in summary event");
            goto error;
        }
        VSTR(fldp);  
        nv = strtod(vstr, &endptr);
        if (NULL == endptr) {
            NL_err_add("numeric field 'nv' cannot be parsed as a number");
            goto error;
        }
        /* 
           add r.s/nv => average bytes per second to
           running total for this operation
         */ 
        if (nv > 0) {
            inst[i] += r_s / nv;
            nvt[i]++;
        }
    }
    
    for(i=0; i < NL_TRANSFER_NOEVENT; i++)
    {
        if (nvt[i] > 0)
            inst[i] = inst[i] / (double)nvt[i];
    }
    /* now apply our algorithm to the results */
    bottleneck_alg1(inst, bp);

            
bottom:
    return 0;

error:
    return -1;
}

/*
 * Convenience fn. to stringify bottleneck
 */
char * NL_transfer_bottleneck_str(NL_transfer_btl_t *bp)
{
    char *s = malloc(128);
    
    switch (bp->result) {
        case NL_BTL_KNOWN:
            switch (bp->location) {
                case NL_BTL_DISK_READ: 
                    strcpy(s, "disk read"); break;
                case NL_BTL_DISK_WRITE: 
                    strcpy(s, "disk write"); break;
                case NL_BTL_DISK_WRITE_MAYBE: 
                    strcpy(s, "maybe disk write"); break;
                case NL_BTL_NET:
                    strcpy(s, "network"); break;
            }
            break;
        case NL_BTL_UNKNOWN:
            strcpy(s, "Unknown");
			break;
        case NL_BTL_MISSING_DATA:
            strcpy(s, "Not enough data");
			break;
        case NL_BTL_BAD_DATA:
            strcpy(s, "Bad data");
			break;
        case NL_BTL_SYSERR:
            strcpy(s, "System error");
			break;
        default:
            sprintf(s,"Internal error: unknown result code %d", bp->result);
    }    
    
    return s;
}

/*
 * Convenience fn. to get a name for an operation
 */
const char *NL_transfer_op_name(NL_transfer_op_t op)
{
	return g_op_hname[op];
}
