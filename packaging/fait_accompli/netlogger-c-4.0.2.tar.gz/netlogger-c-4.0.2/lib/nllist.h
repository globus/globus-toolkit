#ifndef NL_LIST_H_INCLUDED
#    define NL_LIST_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
  Minimal list API.
 */

#    ifdef __cplusplus
extern "C" {
#    endif
    typedef void (*NL_list_free_data) (void *);

#    define T NL_list_T
    typedef struct T *T;

    extern T NL_list(void);
    extern void NL_list_append(T self, void *data);
    extern void *NL_list_get(T self, unsigned i);
    extern int NL_list_replace(T self, unsigned i, void *data,
                               NL_list_free_data fn);
    extern int NL_list_remove(T self, void *data);
    extern void NL_list_insert(T self, unsigned i, void *data);
    extern void *NL_list_iter(T self);
    extern unsigned NL_list_len(T self);
    extern void *NL_list_next_node(T self, void *node);
    void *NL_list_node_data(void *node);
    extern void NL_list_del(T self, NL_list_free_data fn);

#    undef T

#    ifdef __cplusplus
}
#    endif
#endif                          /* .._INCLUDED */
