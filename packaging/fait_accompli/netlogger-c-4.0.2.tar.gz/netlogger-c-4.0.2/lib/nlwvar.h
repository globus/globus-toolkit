
#ifndef NL_WVAR_INCLUDED
#    define NL_WVAR_INCLUDED

/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/

/*
 
Compute variance using West's algorithm, as described in:
Chan and Lewis,"Computing Standard Deviations: Accuracy",
Communications of the ACM, Sep. 1979, Vol 22, No. 19
http://doi.acm.org/10.1145/359146.359152

*/

#    ifdef __cplusplus
extern "C" {
#    endif

/* Error value returned by NL_wvar_variance or NL_wvar_sd
 * if not enough data points. */
#    define NL_NOT_ENOUGH_DATA (-1)

#    define T NL_wvar_T
    typedef struct T *T;

/** 
 *1 Constructor.
 *
 *p (unsigned) baseline Minimum number of values required to give a result.
 */
    T NL_wvar_new(unsigned baseline);

/** 
 * Add number to data set 
 *
 *p (NL_wvar_T) self Instance of variance object
 *p (double) x Data point to add
 *
 */
    void NL_wvar_add(T self, double x);

/**
 * Clear values (equivalent to delete+new with same baseline).
 */
    void NL_wvar_clear(T self);

/** 
 *1 Get current estimate of variance 
 *
 *p (NL_wvar_T) self Instance of variance object.
 *
 *r (double) Variance or NL_NOT_ENOUGH_DATA if less than 'baseline'
 *           data points have been added.
 */
    double NL_wvar_variance(T self);

/** 
 *1 Get current estimate of standard deviation (just sqrt of variance) 
 *
 *p (NL_wvar_T) self Instance of variance object.
 *
 *r (double) Variance or NL_NOT_ENOUGH_DATA if less than 'baseline'
 *           data points have been added.
 */
    double NL_wvar_sd(T);

/** 
 *1 Destructor 
 *
 *p (NL_wvar_T) self Instance of variance object.
 */
    void NL_wvar_del(T self);

#    undef T

#    ifdef __cplusplus
}
#    endif
#endif                          /* if included */
