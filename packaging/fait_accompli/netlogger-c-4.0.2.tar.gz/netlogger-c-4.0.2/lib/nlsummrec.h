#ifndef NL_SUMMREC_H_INCLUDED
#    define NL_SUMMREC_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* Summarized record */

#    include "nl.h"

#    ifdef __cplusplus
extern "C" {
#    endif
/* Opaque types */ struct NL_summseq_T;
#    define NL_summseq_T struct NL_summseq_T *

#    define T NL_summrec_T
    typedef struct T *T;

/**
 * Record 'record' is #pos_in_seq in the sequence 'seq'.
 */
    T NL_summrec(NL_rec_T record, int pos_in_seq, NL_summseq_T seq);

/**
 * Return action for subject to invoke on observer.
 */
    NL_observer_cb NL_summrec_get_action(T self);

/**
 * This is the action returned by _get_action().
 * Process a record.
 * Return -1 on failure, 0 else.
 */
    int NL_summrec_process(void *self_arg, void *record_arg);

/**
 * Delete. Do not free contained record or sequence.
 */
    void NL_summrec_del(T self);

#    undef T

#    undef NL_summseq_T

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
