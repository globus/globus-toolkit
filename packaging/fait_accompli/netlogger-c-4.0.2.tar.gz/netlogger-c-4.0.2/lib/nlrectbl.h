#ifndef NLREC_TBL_INCLUDED
#    define NLREC_TBL_INCLUDED

#include "nl.h"

#    ifdef __cplusplus
extern "C" {
#    endif

/* Node */
    typedef struct nl_recnode_t *nl_recnode_t;
    struct nl_recnode_t {
        char *key;
        int keylen;
        void *data;
        nl_recnode_t nextp;
    };

/* Table */
    struct nl_rectbl_t {
        NL_free_fn free_fn;
        nl_recnode_t *nodes;
    };
    typedef struct nl_rectbl_t *nl_rectbl_t;

/**
 * Size of record table.
 * Important that this is the
 * same for all such tables, since the
 * precomputed index otherwise could not
 * be used between 2 tables w/ the same key.
 */
#    define NLRECTBL_SZ 64
#    define NLRECTBL_MOD 63
/**
 * Hash function
 * P = pointer to character array
 * L = length of  character array
 * C = hash code (OUT)
 */
#    define NLRECTBL_HASH(P,L,C)			\
for( (C) = 0, ii = 0; ii < (L); ii++ )		\
  (C) = 127 * (C) + (P)[ii];			\
(C) = (C) & NLRECTBL_MOD;

/* External API */
    extern nl_rectbl_t nl_rectbl_new(NL_free_fn free_fn);
    extern void nl_rectbl_del(nl_rectbl_t);
    extern void *nl_rectbl_get(nl_rectbl_t, const char *key, int keylen);
    extern void *nl_rectbl_geti(nl_rectbl_t, int hash_index,
                                const char *key, int keylen);
    extern void nl_rectbl_put(nl_rectbl_t, const char *key, int keylen,
                              void *data, int *hash_index);
    typedef void (*nl_rectbl_visitfn_t) (nl_rectbl_t, nl_recnode_t,
                                         void *data);
    extern void nl_rectbl_apply(nl_rectbl_t, nl_rectbl_visitfn_t,
                                void *data);

/* This is somewhat faster than the function call version */
#    define NL_RECTBL_GETI(S,IX,K,L,R) do {		\
  nl_recnode_t P;				\
  register int I = IX;				\
  for ( P = S->nodes[ I ]; P; P = P->nextp ) {	\
    if ( (P)->keylen == (L) &&			\
	 !memcmp(P->key, (K), (L)) )		\
      break;					\
  }						\
  (R) = (P) ? (P)->data : NULL;			\
} while(0)

#    ifdef __cplusplus
}
#    endif
#endif                          /* NLREC_TBL_INCLUDED */
