#ifndef NL_ERR_INCLUDED
#    define NL_ERR_INCLUDED

/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/

/* Usually only do this in .c files
 * but here we need to conditionally define
 * a macro.
 */
#    ifdef HAVE_CONFIG_H
#        include "nlconfig.h"
#    endif

/**
 * Simple error reporting functions.

Store up errors in fixed-size buffer, dump/reset buffer
as requested.

*/

#    include <stdarg.h>

#    ifdef __cplusplus
extern "C" {
#    endif
/* error message buffer size */
#    ifndef NL_ERR_MAX
#        define NL_ERR_MAX 65535
#    endif
/* other formatting constants */
#    define NL_ERR_DDD "..."
#    define NL_ERR_SEP " / "
/**
 * Add an error.
 *
 * Parameters:
 *  s   = Format string, passed to sprintf()
 *  ... = Values for format string (none is OK)
 * Return:
 *  0 = Added error message.
 *  1 = Message truncated due to space limitations
 * -1 = Error buffer full, or other error. Did nothing.
  */ extern int
     NL_err_add(const char *s, ...);
#    if NL_VAARGS
/* Use macro varargs to redefine the NL_err
 * function to automagically prepend
 * file and line number to all messages.
 */
    extern int NL_err_addv(const char *s, ...);
#        define NL_err_add( S, ... ) NL_err_addv("(%s:%d) " S , __FILE__ , __LINE__ , ## __VA_ARGS__ )
#    else
/* Do nothing */
#    endif

#    ifdef __cplusplus
}
#    endif
#endif                          /* NL_ERR_INCLUDED */
