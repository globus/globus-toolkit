/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/* Summarized record */
#ifdef lint
static const volatile char rcsid[] =
    "$Id: nlsummrec.c 130 2007-08-22 14:09:32Z dang $";
#endif

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
/* time headers */
#if TIME_WITH_SYS_TIME
#    include <sys/time.h>
#    include <time.h>
#else
#    if HAVE_SYS_TIME_H
#        include <sys/time.h>
#    else
#        include <time.h>
#    endif
#endif
#include <stdlib.h>
#include <string.h>

#include "nlint.h"
#include "nlsummseq.h"
#include "nlsummstate.h"
#include "nlsummrec.h"

#define NL_MAX_IDLEN 2048

#define T NL_summrec_T
struct T {
    NL_observer_cb action;
    NL_summseq_T sequence;
    /* where record is in sequence */
    unsigned position;
    /* where ids are in record */
    unsigned *ids;
    unsigned ids_n;
    /* where values are in record */
    unsigned *values;
    double *dvalues;            /* actual values */
    unsigned values_n;
    /* identifier buffer */
    char id_buf[NL_MAX_IDLEN];
    /* (copy of) function to process a record */
    NL_summseq_process_fn summarize;
    /* whether records should be marked 'consumed' */
    int consume;
};

T NL_summrec(NL_rec_t * record, int pos_in_seq, NL_summseq_T seq)
{
    T self = (T) malloc(sizeof(struct T));
    int result;

    self->sequence = seq;
    self->position = pos_in_seq;
    self->action = NL_summrec_process;
    self->summarize = NL_summseq_get_summary_fn(seq);
    self->consume = NL_summseq_get_consume(seq);

    /* Get positions of identifying and value fields
     * from the associated summary-sequence object.
     * Preallocate the appropriate number of field pointers.
     */
    result = NL_summseq_get_ids(seq, record, pos_in_seq,
                                &self->ids, &self->ids_n);
    if (result == -1) {
        free(self);
        self = NULL;
    }
    else {
        result = NL_summseq_get_values(seq, record, pos_in_seq,
                                       &self->values, &self->values_n);
        if (result == -1) {
            free(self->ids);
            free(self);
            self = NULL;
        }
        else {
            self->dvalues = malloc(sizeof(double) * self->values_n);
        }
    }

    return self;
}

/**
 * Return function pointer to NL_summrec_process()
 */
NL_observer_cb NL_summrec_get_action(T self)
{
    return self->action;
}

/* construct identifier by concatenating id field values */
static inline int
concat_id(NL_fld_t ** fields, unsigned *pos, unsigned n, char *buf)
{
    int i, vlen, offs;

    offs = 0;
    for (i = 0; i < n && offs < NL_MAX_IDLEN; i++) {
        vlen = fields[pos[i]]->vlen;
        if (offs + vlen > NL_MAX_IDLEN) {
            vlen = NL_MAX_IDLEN - offs;
        }
        memcpy(buf + offs, fields[pos[i]]->value, vlen);
        offs += vlen;
    }
    return offs;
}

/* extract id values, into allocated vector of allocated buffers */
static inline NL_fld_t **get_id_fields(NL_fld_t ** fields, unsigned *pos,
                                       unsigned n)
{
    NL_fld_t **result;
    int i;

    result = malloc(n * sizeof(NL_fld_t *));
    for (i = 0; i < n; i++) {
        result[i] = NL_fld_clone(fields[pos[i]]);
    }

    return result;
}

int NL_summrec_process(void *self_arg, void *record_arg)
{
    T self = (T) self_arg;
    NL_rec_t *rec = (NL_rec_t *) record_arg;
    int i, id_len, result;
    NL_summstate_T sst;
    unsigned is_new;

    /* concatenate id's for lookup */
    id_len = concat_id(rec->fields, self->ids, self->ids_n, self->id_buf);
    sst =
        NL_summseq_get_state(self->sequence, self->id_buf, id_len,
                             &is_new);
    if (NULL == sst) {
        /* should create new if not there, so NULL is err */
        result = -1;
    }
    else {
        struct timeval *tvp;
        if (NL_summstate_first_access(sst, self->position)) {
            /* first time for this state at this position */
            /* make sure there is enough space for the values */
            result = NL_summstate_set_num_values(sst, self->values_n);
            if (0 == result && is_new) {
                /* first time for this state in any position */
                sst->id_fields = get_id_fields(rec->fields, self->ids,
                                               self->ids_n);
                sst->id_fields_n = self->ids_n;
                sst->sequence_len = NL_summseq_get_len(self->sequence);
            }
        }
        /* set position */
        sst->pos = self->position;
        /* set values */
        for (i = 0; i < self->values_n; i++) {
            sst->values[i] =
                *((double *) rec->fields[self->values[i]]->value);
        }
        sst->values_n = self->values_n;
        /* set time */
        tvp = (struct timeval *) rec->fields[NL_dtfld]->value;
        sst->ts_usec =
            (int64_t) tvp->tv_sec * 1000000LL + (int64_t) tvp->tv_usec;
        /* summarize! */
        result = self->summarize(sst);
        /* consume? */
        rec->consumed = self->consume;
    }
    return result;
}


void NL_summrec_del(T self)
{
    if (self) {
        free(self);
    }
}

#undef T
