/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/
/*
Simple error reporting functions.

Store up errors in fixed-size buffer, dump/reset buffer
as requested.

*/
#ifndef lint
static const volatile char rcsid[] =
    "$Id: nlerr.c 121 2007-08-19 23:19:37Z dang $";
#endif

#ifdef HAVE_CONFIG_H
#    include "nlconfig.h"
#endif
#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "nl.h"
#include "nlerr.h"

/* error message buffer */
char g_error[NL_ERR_MAX + 1];

/* count of errors, -1=uninitialized */
unsigned int g_error_num = -1;

/* buffer-full flag */
unsigned char g_error_full = 0;

/**
 * Init/reset error reporting
 */
void NL_err_clear()
{
    memset(g_error, 0, sizeof(g_error));
    g_error_num = 0;
    g_error_full = 0;
}

/**
 * Get last error(s)
 */
const char *NL_err_str(void)
{
    if (g_error_num < 0) {
        NL_err_clear();
    }
    return g_error;
}


/**
 * Add an error
 */
#if NL_VAARGS
/* In this case, NL_err_add() has been redefined to call addv() */
int NL_err_addv(const char *s, ...)
#else
int NL_err_add(const char *s, ...)
#endif
{
    char buf[NL_ERR_MAX];
    int n, glen, elen, r;
    va_list ap;

    if (g_error_full) {
        goto full;
    }

    if (g_error_num < 0) {
        NL_err_clear();
    }

    if (!s) {
        /* empty message, just ignore it */
        return 0;
    }

    glen = strlen(g_error);
    elen = strlen(NL_ERR_DDD) + strlen(NL_ERR_SEP);
    n = NL_ERR_MAX - glen - elen;
    if (n < 0) {
        /* internal error! */
        g_error_full = 1;
        goto full;
    }
    else if (n == 0) {
        strcat(g_error, NL_ERR_SEP);
        strcat(g_error, NL_ERR_DDD);
        g_error_full = 1;
        goto full;
    }
    /* adjust max length to include separator
     * that will be prepended, 
     * and add 1 so vsnprintf goes right up to the 'end' of the allowed space,
     * since it subtracts 1 to allow for '\0' 
     */
    if (g_error_num > 0) {
        n = n - strlen(NL_ERR_SEP) + 1;
    }
    va_start(ap, s);
    r = vsnprintf(buf, n, s, ap);
    va_end(ap);
    if (g_error_num > 0) {
        strcat(g_error, NL_ERR_SEP);
    }
    strcat(g_error, buf);

    g_error_num++;

    /* vsnprintf doesn't say how _much_ the string was truncated, so
     * just return 1 for truncation and zero otherwise */
    return (r >= n) ? 1 : 0;

  full:
    return -1;
}
