#ifndef NL_SUMMSTATE_H_INCLUDED
#    define NL_SUMMSTATE_H_INCLUDED
/* 
Copyright (c) 2006, The Regents of the University of California, through 
Lawrence Berkeley National Laboratory (subject to receipt of any required 
approvals from the U.S. Dept. of Energy).  All rights reserved.
*/

/**
 * @file nlsummstate.h State of a summarized event sequence.
 */

#    include <assert.h>
#    include <string.h>                /* memset */
#    include "nl.h"

#    ifdef __cplusplus
extern "C" {
#    endif
 /** @addtogroup nlsummint
  * @{
          *//* Opaque types */ struct NL_summseq_T;

/* Package a record and level together for
 * transferring to NL_summ_write_record(), callback
 * for the observer.
 */
#    define T NL_summstate_reclevel_T
    struct T {
        NL_rec_T record;
        NL_level_t level;
    };
    typedef struct T *T;
    extern T NL_summstate_reclevel(NL_rec_T record, NL_level_t level);
    extern void NL_summstate_reclevel_del(T self);
#    undef T

#    define T NL_summstate_T
    typedef struct T *T;
    struct T {
        void *data;
        NL_free_fn free_data;
        struct NL_summseq_T *seq;
        int64_t ts_usec;
        double *values;
        unsigned values_n, values_sz;
        /* matched id fields */
        NL_fld_T *id_fields;
        unsigned id_fields_n;
        unsigned pos;
        unsigned sequence_len;
        /* keep track of first access by position */
        unsigned char *first_access;
        unsigned first_access_n;
    };

    extern T NL_summstate(struct NL_summseq_T *parent,
                          void *initial_data, NL_free_fn free_data);

/**
 * Is this the first time we accessed this position?
 * Post: next call will return False (0)
 */
    extern unsigned NL_summstate_first_access(T self, unsigned pos);

/**
 * Set number of values to store.
 * If new value is greater than current, will expand to max
 * of all values given.
 * Does reallocation if necessary, so returns 0 on success, -1 on failure
 * of the realloc().
 */
    extern int NL_summstate_set_num_values(T self, unsigned n);

/**
 * Convenience method to write a record.
 */
    extern int NL_summstate_write_record(T self, void *rec,
                                         NL_level_t level);

    extern void NL_summstate_del(T self);

#    undef T

/** @} */

#    ifdef __cplusplus
}
#    endif
#endif                          /* ..._INCLUDED */
