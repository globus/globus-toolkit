#ifndef NL_DBG_H_INCLUDED
#    define NL_DBG_H_INCLUDED

#    include <unistd.h>

#    define _ADD_CR(s)                s "\n"
#    define _ADD_EVENT(s)            "event=nl." s " "
#    define _ADD_TS                  "ts=%s "
#    if 0
#        define _ADD_TIDFMT              "thread=%d "
#        define _ADD_TIDVAL              pthread_self()
#    else
#        define _ADD_TIDFMT              "pid=%d "
#        define _ADD_TIDVAL              getpid()
#    endif

#    ifdef DEBUG
#        define DPRINT(e, fmt, args...)       do {                              \
        struct timeval tv;                                              \
        struct tm *tm_p; char buf[28];                                  \
        int i, usec;                                                    \
        gettimeofday(&tv,0);                                            \
        if ( NULL !=  (tm_p = gmtime((time_t *)&tv.tv_sec)) &&          \
             0 != strftime(buf, 21,  "%Y-%m-%dT%H:%M:%S.", tm_p)) {     \
            usec = tv.tv_usec;                                          \
            for (i = 0; i < 6; i++) {                                   \
                buf[25 - i] = '0' + (usec % 10);                        \
                usec /= 10;                                             \
            }                                                           \
            buf[26] = 'Z'; buf[27] = '\0';                              \
            fprintf(stderr, _ADD_TS _ADD_EVENT(e) _ADD_TIDFMT _ADD_CR(fmt), buf, _ADD_TIDVAL, ##args); \
        }                                                               \
    } while (0)
#    else
#        define DPRINT(e, fmt, args...)       do { } while (0)
#    endif

/* identical to above, but will always print instead
 * of just when DEBUG is defined
 */
#    define EPRINT(e, fmt, args...)       do {                              \
        struct timeval tv;                                              \
        struct tm *tm_p; char buf[28];                                  \
        int i, usec;                                                    \
        gettimeofday(&tv,0);                                            \
        if ( NULL !=  (tm_p = gmtime((time_t *)&tv.tv_sec)) &&          \
             0 != strftime(buf, 21,  "%Y-%m-%dT%H:%M:%S.", tm_p)) {     \
            usec = tv.tv_usec;                                          \
            for (i = 0; i < 6; i++) {                                   \
                buf[25 - i] = '0' + (usec % 10);                        \
                usec /= 10;                                             \
            }                                                           \
            buf[26] = 'Z'; buf[27] = '\0';                              \
            fprintf(stderr, _ADD_TS _ADD_EVENT(e) _ADD_CR(fmt), buf, ##args); \
        }                                                               \
    } while (0)

#endif
