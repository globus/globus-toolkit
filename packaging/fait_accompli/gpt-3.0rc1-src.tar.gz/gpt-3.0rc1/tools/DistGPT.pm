package DistGPT;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA);

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter);

{
my %names = (
             zlib => "zlib-1",
             perlzlib => "Compress-Zlib",
             perltar => "Archive-Tar",
             oldautoconf => "autoconf-2.13",
             oldautomake => "automake-1.4",
             oldlibtool => "libtool-1.3.5",
             autoconf => "autoconf-2.5",
             automake => "automake-1.7",
             libtool => "libtool-1.4",
             filespec => "File-Spec",
             podparser => "PodParser",
             md5 => "Digest-MD5",
             core => "globus_core",
             gpt => "packaging_tools",
            );

my @buildorder = (
             "zlib",
             "perlzlib",
             "perltar",
             "oldautoconf",
             "oldautomake",
             "oldlibtool",
             "autoconf",
             "automake",
             "libtool",
             "filespec",
             "podparser",
             "md5",
             "core",
             "gpt",
            );
  sub name_mask {
    my $mask = shift;
    return $names{$mask};
  }

  sub mask_keys {
    return \@buildorder;
  }
}

sub new {
  my ($that, %args)  = @_;
  my $class = ref($that) || $that;
  my $me  = {
             name_masks => {},
             gtar_location => $args{'gtar'},
             gunzip_location => $args{'gunzip'},
             buildlist => $args{'building'},
            };
  bless $me, $class;

  return $me;

}

sub match {
  my ($me, $in_candidates) = @_;

  for my $k (@{ $me->get_keys() } ) {

    my $n = name_mask($k);

    my @candidates = grep { m!$n! } @$in_candidates;

    die "ERROR: Could not find $n\n" if ! @candidates;

    $me->{$k} = $candidates[0];
#    print "    $candidates[0]\n";

  }
}

sub find_perl {

  my $perl_location = shift;

  if (defined $perl_location) {
    my $result = `$perl_location packaging_tools/find_perl5.005`;
    die "ERROR: Specified perl is not >= 5.005.\n" 
      if ! $result =~ m!Perl\s+is\s+fine!;
    return $perl_location
  }

  my @paths = split /:/, $ENV{'PATH'};

  for my $d (@paths) {

    last if defined $perl_location;

    if (-f "$d/perl" ) {
      my $result = `$d/perl packaging_tools/find_perl5.005`;
      $perl_location = "$d/perl" if $result =~ m!Perl\s+is\s+fine!;
    }
  }

  die "ERROR: Can't find perl >= 5.005. Use -with-perl=<location> flag\n" 
    if ! defined $perl_location;

  return $perl_location;
}

sub get_keys {
  my ($me) = @_;
  my @list;

  if (defined $me->{'buildlist'}) {
    @list = grep { $_  ne 'zlib' and $_ ne 'core' } @{ mask_keys() };
    return \@list;
  }

  @list = grep { $_ ne 'gpt' } @{ mask_keys() };
  return \@list;
}

sub probe_for_tools {
  my ($me) = @_;

  my @paths = split /:/, $ENV{'PATH'};

  for my $d (@paths) {

    if (! defined $me->{'gtar_location'}) {
      if (-f "$d/gtar" ) {
        my $result = `$d/gtar --version`;
        $me->{'gtar_location'} = "$d/gtar" if $result =~ m!GNU\s+tar!;
      }
      if (-f "$d/tar" ) {
        my $result = `$d/tar --version`;
        $me->{'gtar_location'} = "$d/tar" if $result =~ m!GNU\s+tar!;
      }
    }
    if (! defined $me->{'gunzip_location'}) {
      if (-f "$d/gunzip" ) {
        my $result = `$d/gunzip --version 2>&1`;
        $me->{'gunzip_location'} = "$d/gunzip" if $result =~ m!gunzip\s+!;
      }
    }
  }

  die "ERROR: Can't find GNU tar. Use -with-gtar=<location> flag\n" 
    if ! defined $me->{'gtar_location'};
  die "ERROR: Can't find GNU zip. Use -with-gunzip=<location> flag\n" 
    if ! defined $me->{'gunzip_location'};
}



1;
__END__
