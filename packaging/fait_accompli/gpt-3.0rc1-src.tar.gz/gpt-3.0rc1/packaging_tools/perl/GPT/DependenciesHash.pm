package Grid::GPT::DependenciesHash;
use Grid::GPT::Package;
use Archive::Tar;
use strict;
use Carp;
use Data::Dumper;

my %dep_hash_struct = (
	names => {},
	objects => {},
	pkgstring => {}
);

sub new {
	 my $class  = shift;
   	 my $self  = {
	        %dep_hash_struct,
		    };
    bless $self, $class;
    return $self;
}
	
sub fill_hash {
  my ($self, $pkgdir) = @_;
  my @packagelist;

  	opendir(PACKAGESDIR, "$pkgdir") or die "can't opendir $pkgdir: $!";
          while (defined(my $file = readdir(PACKAGESDIR))) {
	      # do something with "$dirname/$file"
	      if (! ($file =~ m/^\./)){
	      #ignore entries that start with "." 
		  if ($file =~ m!\.tar\.gz!){ 
		 	push @packagelist, $file; 
		  }
	      }   
	  } #end while
	  closedir(PACKAGESDIR);


	foreach my $file (@packagelist){
		my $metadatafile;
		my $metadataobj;
		my $metadata;

	        chomp $file;
        	my $tar= Archive::Tar->new();
##        	$tar->read($pkgdir."/".$file);

  my $ret = $tar->read($pkgdir."/".$file);
  confess "Unreadable TAR file: $pkgdir/$file" if !defined( $ret );

        	my @tarfiles=$tar->list_files();
        	foreach my $try (@tarfiles){
                	chomp $try;
                	if ($try =~ /pkg_data.*\.gpt/){
	                	$metadatafile=$try;
                        	last;}
		} #end foreach my $try
		$metadata=$tar->get_content($metadatafile);
		$metadataobj = Grid::GPT::Package->new();
		$metadataobj->read_metadata_file($metadata);

		%{$self->{names}}->{$file}=\$metadataobj;
		%{$self->{objects}}->{\$metadataobj}=$file;
		%{$self->{pkgstring}}->{$metadataobj->{'Name'}."-".$metadataobj->{'Flavor'}."_".$metadataobj->{'Package_Type'}}=\$metadataobj;
	} # end foreach my $file
}
	

sub AUTOLOAD {
	use vars qw($AUTOLOAD);
    my $self = shift;
    my $type = ref($self) || croak "$self is not an object";
    my $name = $AUTOLOAD;
    $name =~ s/.*://;   # strip fully-qualified portion
    unless (exists $self->{$name} ) {
        croak "Can't access `$name' field in object of class $type";
    } 
    if (@_) {
        return $self->{$name} = shift;
    } else {
        return $self->{$name};
    } 
}




END { }       # module clean-up code here (global destructor)
