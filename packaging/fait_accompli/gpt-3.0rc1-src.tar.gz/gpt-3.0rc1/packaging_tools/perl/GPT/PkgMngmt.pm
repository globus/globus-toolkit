package Grid::GPT::PkgMngmt;

use strict;
use Carp;
use Cwd;
use Archive::Tar;
use Pod::Usage;

require Exporter;
use vars       qw($VERSION @ISA);

require Grid::GPT::Algorithms;

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter);

sub new {
  my ($that, %args)  = @_;
  my $class = ref($that) || $that;

  my $me  = {
             locations => $args{'locations'},
             log => $args{'log'},
            };

  bless $me, $class;
  return $me;
}

sub install {
  my ($me, %args) = @_;
  my ($bundles) = ($args{'bndls'});

  my @pkgs = @{$args{'pkgs'}};

  my @rpms = grep { 
    Grid::GPT::Algorithms::check_input_file
        (file => $_->gptpkgfile(full=>1))
          eq 'NATIVE_PKG' } @pkgs;

  $me->install_pkgs(pkgs => \@rpms, format => 'native') if @rpms;

  my @gpts = grep { 
    Grid::GPT::Algorithms::check_input_file
        (file => $_->gptpkgfile(full=>1))
          eq 'BIN_PKG' } @pkgs;

  $me->install_pkgs(pkgs => \@pkgs, format => 'gpt') if @gpts;

  $me->install_bundles($bundles) if @$bundles;

  $me->refresh_cache();

}

sub remove {
  my ($me, %args) = @_;
  my ($pkgs, $bundles) = ($args{'pkgs'}, $args{'bndls'});

  $me->remove_pkgs(pkgs => $pkgs);

  $me->remove_bundles($bundles);
  $me->refresh_cache();
}

sub install_pkgs {
  my ($me, %args) = @_;

  my ($pkgs, $format) = ($args{'pkgs'}, $args{'format'});

  $me->_install_rpms($pkgs) if $format eq 'native';

  if ($format ne 'native') {
    for my $p(@$pkgs) {
      $me->_install_gpt_pkg($p);
    }
  }

    for my $p(@$pkgs) {
      pkg_format_file(pkgdir => $me->{'locations'}->{'pkgdir'},
                      pkg => $p,
                      format => $format, mode => 'WRITE');
    }

}

sub remove_pkgs {
  my ($me, %args) = @_;

  my ($pkgs) = ($args{'pkgs'});

  my @natives = grep {$_->format() eq 'native'} @$pkgs;
  my @gpts = grep {$_->format() eq 'gpt'} @$pkgs;

  $me->_remove_rpms(\@natives) if @natives;

  for my $p (@gpts) {
    $me->_remove_gpt_pkg($p);
  }

  for my $p (@$pkgs) {

    $me->_remove_setup($p);

    pkg_format_file(pkgdir => $me->{'locations'}->{'pkgdir'},
                    pkg => $p,
                    mode => 'REMOVE');
  }

}

sub install_bundles {
  my ($me, $bundles) = @_;

if( ! -w $me->{'locations'}->{'installdir'} )
{
  print "Can't write to $me->{'locations'}->{'installdir'}\n";
}

if( ! -r $me->{'locations'}->{'installdir'} )
{
  print "Can't read from $me->{'locations'}->{'installdir'}\n";
}

  for $b (@$bundles) {
    $b->save_bundle_def($me->{'locations'}->{'installdir'});
    $me->{'log'}->inform("Bundle " . $b->label() . 
                         " successfully installed.",1);
  }
}


sub remove_bundles {
  my ($me, $bundles) = @_;
  for $b (@$bundles) {
    if (-f $b->{'BundleDefFile'}) {
      my $result = system("rm -f $b->{'BundleDefFile'}"); 
       $me->{'log'}->inform("Bundle " . $b->label() . " removed.",1);
    }
  }
}

sub _install_gpt_pkg {
  my ($me, $pkg) = @_;

  my $result;


  my $startdir = cwd();

  my $tar = Archive::Tar->new();
##  $tar->read($pkg->gptpkgfile(full =>1));

  my $ret = $tar->read($pkg->gptpkgfile(full =>1));
  confess "Unreadable TAR file"  if !defined( $ret );

  my @tarfiles = $tar->list_files();

  my $msg = "Installing files: \n\t" . join "\n\t", @tarfiles;
  $me->{'log'}->debug($msg);


  if (! @tarfiles) {
    $me->{'log'}->error("ERROR: Problem installing " . 
                        $pkg->gptpkgfile(full =>1) . 
                        ".\n Empty file list.");
  }

if( ! -w $me->{'locations'}->{'installdir'} )
{
  print "Can't write to $me->{'locations'}->{'installdir'}\n";
}

if( ! -r $me->{'locations'}->{'installdir'} )
{
  print "Can't read from $me->{'locations'}->{'installdir'}\n";
}

  chdir $me->{'locations'}->{'installdir'};
  my $retval= $tar->extract(@tarfiles);
  if (!($retval)){
    my $msg =  $tar->error();
    $msg .=  $retval . "is the return from extract_archive\n";
    $msg .= "did not successfully install $pkg->gptpkgfile(full =>1) \n";
    $msg .= "$me->{'locations'}->{'installdir'}\n";
    $me->{'log'}->error($msg);
   $result = 0;
  }else {
    $me->{'log'}->inform($pkg->label() . " successfully installed.");
    $result++;
  }

  my ($login,$pass,$uid,$gid) = getpwuid($<)
    or die "$< not in passwd file";

  if ($login eq 'root') {
    chown $<, $(, @tarfiles;
  }

  chdir $startdir;
  return $result;
}

sub _install_rpms {
  my ($me, $pkgs) = @_;


  my $relocate = good_rpm();
  Pod::Usage::pod2usage(-verbose => 0, 
                        -exitval => 1,
                        -output =>  \*STDERR,
                        -message => 
                        "ERROR: You need at least version 4.0.3 of rpm\n") 
      if ! $relocate; 

  my $forceflag = defined $me->{'force'} ? '--force' : '';
  my $vvflag = defined $me->{'verbose'} ? '-v' : '';
  my $rpmprefix  = "--prefix $me->{'locations'}->{'installdir'}";

  my $fileline = "";
  for my $p (@$pkgs) {
    my $f = $p->gptpkgfile(full =>1);
    $fileline .= "\\\n  $f";
  }


  $me->{'log'}->inform("Executing: rpm -i $forceflag $vvflag  $rpmprefix $fileline\n");

  my $result;

  $result = system("rpm -i $forceflag $vvflag  $rpmprefix $fileline"); 
  return $result;
}

sub _remove_gpt_pkg
{
  my ($me, $p) = @_;
  my $retval = 0;
  my $installdir = $me->{'locations'}->{'installdir'};
  for my $f(@{$p->{'filelist'}->getFilelistFiles()}) 
    {
      if (-f "$installdir/$f") {
        my $result = system("rm -f $installdir/$f");
        $me->{'log'}->error("WARNING problems removing file $installdir/$f\n") 
          if $result;
        $retval += $result;
      }
    }
  $me->{'log'}->inform($p->label() . " successfully removed.") 
    if ! $retval;

}

sub pkg_format_file
{
  my (%args) = @_;

  my ($mode, $format, $pkg) = ($args{'mode'}, $args{'format'}, $args{'pkg'});
  my ($pkgname, $flavor, $pkgtype) = 
    (
     defined $args{'pkgname'} ? $args{'pkgname'} : $pkg->pkgname(), 
     defined $args{'flavor'} ? $args{'flavor'} : $pkg->flavor(), 
     defined $args{'pkgtype'} ? $args{'pkgtype'} : $pkg->pkgtype(), 
    );

  my $pkgdir = $args{'pkgdir'};

  my $file = "$pkgdir/" . $pkgname ."/"
    . $flavor . $pkgtype . ".format";

  if ($mode eq "WRITE") {
    open FILE, ">$file";
    print FILE "$format\n";
    close FILE;
    return undef;
  }

  if ($mode eq "READ") {
#    return undef if ! -f $file;
    open FILE, $file;
    my $format = <FILE>;
    close FILE;
    chomp $format;
    return $format;
  }

  if ($mode eq "REMOVE") {
    return undef if ! -f $file;
    system ("rm -f $file");
    return undef;
  }

  return undef;
}

sub _remove_setup
{
  my ($me, $p) = @_;
  my $setupdir = "$me->{locations}->{'setupdir'}"; 
  return ! defined $p->setupname();
  my $d = $p->setupname();
  my $f = $p->pkgname();
  if (-f "$setupdir/$d/$f.gpt") {
    my $result = system("rm -f $setupdir/$d/$f.gpt");
    $me->{'log'}->error("WARNING problems removing file setupdir/$d/$f.gpt\n") 
      if $result;
  }
}

sub _remove_rpms
{
  my ($me, $pkgs) = @_;
  my $forceflag = defined $me->{'force'} ? '--force' : '';
  my $vvflag = defined $me->{'verbose'} ? '-v' : '';
  my $fileline = "";
  for my $p (@$pkgs) {
    my $f = $p->pkgname() . "_" . $p->flavor() . "_" . $p->pkgtype();
    my ($rpmname) = $f =~ m!(\D+)-\d!;

      my $query = `rpm -q $rpmname 2>&1`;

      next if $query =~ m!not\s+installed!;

      $fileline .= "\\\n $f";
    }
  $me->{'log'}->inform("Executing: rpm -e $forceflag $vvflag $fileline\n");
  my $result = system("rpm -e $forceflag $vvflag $fileline");

  if ($result) {
    $me->{'log'}->error("ERROR: rpm cannot remove the packages $fileline\n");
    exit 1;
  }

  return;
}



sub good_rpm {
  my $rpmversion = `rpm --version`;
##  my ($d1, $d2, $d3) = $rpmversion =~ m!(\d)\.(\d)\.(\d)!;

my @d = $rpmversion =~ m!(\d+)\.(\d+)(?:\.(\d+))?!;

my $d1 = (defined($d[0])) ? $d[0] : 0;
my $d2 = (defined($d[1])) ? $d[1] : 0;
my $d3 = (defined($d[2])) ? $d[2] : 0;

  return 1 if $d1 > 4;
  return 0 if $d1 < 4;
  return 1 if $d2 > 0;
  return 1 if $d3 >=  3;
  return 0;
}

sub refresh_cache {
   my ($me) = @_;
   return if ! defined eval "require Grid::GPT::InstallationCache";

   require Grid::GPT::InstallationCache;

   Grid::GPT::InstallationCache::refresh(locations => $me->{'locations'});

}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
