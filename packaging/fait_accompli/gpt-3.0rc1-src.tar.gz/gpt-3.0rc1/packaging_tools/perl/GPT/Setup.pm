package Grid::GPT::Setup;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);


# This module is included by scripts outside of GPT and so require the 
use Config;
# @INC fiddling
my $gpt_path = $ENV{GPT_LOCATION};
@INC = ("$gpt_path/lib/perl", "$gpt_path/lib/perl/$Config{'archname'}", @INC);

require Grid::GPT::V1::Package;
require Grid::GPT::V1::Version;
require Grid::GPT::V1::Dependencies;

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

sub new {
    my ($that, %args)  = @_;
    my $class = ref($that) || $that;
    my $self  = {
		 package_name => $args{'package_name'},
                 setup_name => $args{'setup_name'},
                 setup_version => $args{'setup_version'}
		};
    bless $self, $class;
    
    my $globusdir = defined $args{'globusdir'} ? $args{'globusdir'} : 
      $ENV{'GLOBUS_LOCATION'};
    if (!defined($globusdir)) {
      die "Please set GLOBUS_LOCATION\n";
    } 

    my $pkgfile = "$globusdir/etc/globus_packages/$self->{'package_name'}/pkg_data_noflavor_pgm.gpt";
    my $pkgfile_static = "$globusdir/etc/globus_packages/$self->{'package_name'}/pkg_data_noflavor_pgm_static.gpt";

    if (!defined $args{'setup_name'}) {

      if (! -f $pkgfile){
      	die "ERROR: $self->{'package_name'} is not installed.\n" if ! -f $pkgfile_static;
	$pkgfile=$pkgfile_static;
      }
      $self->{'pkg'}= new Grid::GPT::V1::Package;
      $self->{'pkg'}->read_metadata_file($pkgfile);

    } else {

      die "Error: package name = $args{'package_name'}, setup name = $args{'setup_name'}, \
and setup version = $args{'setup_version'} all need to be defined in Setup\n" 
        if !defined  $args{'package_name'} or 
          ! defined $args{'setup_name'} or 
            ! defined $args{'setup_version'};

      $args{'setup_version'} =~ m!(d+)\.(d+)\.d+!;
      my ($major, $minor, $age) = ($1, $2, $3);

      my $version = new Grid::GPT::V1::Version(type => 'aging',
                                          major => $major,
                                          minor => $minor,
                                          age => $age);

      $self->{'pkg'}= new Grid::GPT::Package(Package_Type => 'pgm',
                                             Name => $args{'package_name'},
                                             Flavor => 'noflavor',
                                             Setup_Name => $args{'setup_name'},
                                             Setup_Version => $version
                                            );
      
    }
      $self->{'pkgfile'} = $pkgfile;
      $self->{'setupdir'} = "$globusdir/etc/globus_packages/setup";

      $self->check_setup_deps;
    return $self;
}

sub check_setup_deps {
	my $self=shift;
	my $flavor=$self->{'pkg'}->Flavor;
	my $linktype=undef();

	my $disposable= new Grid::GPT::V1::Dependencies;
	$disposable->get_dependencies($self->{'pkg'}, "check",$flavor,$linktype,"silent");
	my $result=$disposable->check_setup_dependencies;

        if (scalar keys %{%$result->{'not-setup'}}){
              for my $nset (keys %{%$result->{'not-setup'}}) {
                    for my $pkg (@{%$result->{'not-setup'}->{$nset}}){
                          print "$pkg requires $nset to be set up \n";
	            }
              }
              exit 1;
        }
																				     }
	
sub finish {
  my ($self) = @_;
  my $setupname = $self->{'pkg'}->{'Setup_Name'};

  if (! -d "$self->{'setupdir'}") {
    my $result = system("mkdir $self->{'setupdir'}");
  }

  if (! -d "$self->{'setupdir'}/$setupname") {
    my $result = system("mkdir $self->{'setupdir'}/$setupname");
  }

  my $filename = "$self->{'setupdir'}/$setupname/$self->{'package_name'}.gpt";

  if (-f $self->{'pkgfile'}) {
    my $result = system("cp $self->{'pkgfile'} $filename");
  } else {
    $self->{'pkg'}->output_metadata_file($filename);
  }

}
sub DESTROY {}

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Setup - Perl extension for writing setup package metadata

=head1 SYNOPSIS

  use Grid::GPT::Setup;
  my $metdata = new Grid::GPT::Setup(package_name =>'globus_trusted_ca_setup', 
                                     organization => 'globus');

  $metdata->finish();

=head1 DESCRIPTION

I<Grid::GPT::Setup> is used to write setup package metadata. The
metadata that is written indicates to the packaging tools that the
package has been set up. The library should be included in all setup
scripts.  The library has been set up as a perl object to allow for
future expansion

=over 4

=item new

Creates a new object with the package_name.  The function also reads
the package metadata file for the remaining information.

=item finish

Writes metatdata into
$GLOBUS_LOCATION/etc/globus_packages/setup/<setup_format_name> to
indicate that the setup is complete.

=head1 AUTHOR

Eric Blau <eblau@ncsa.uiuc.edu> Michael Bletzinger <mbletzin@ncsa.uiuc,edu>

=head1 SEE ALSO

perl(1) GRID::GPT::VERSION(1).

=cut
