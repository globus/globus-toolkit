package Grid::GPT::PkgMngmt::Archive;
use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;
require AutoLoader;
use Data::Dumper;
use Grid::GPT::FilelistFunctions;
use Grid::GPT::PkgMngmt::BuildEnv;
use Cwd;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
);
$VERSION = '0.01';

{
  my %environment;
  sub check_for_compress {
    my ($self) = shift;
    return $environment{'compress'} if defined $environment{'compress'};
    if (defined eval { require Compress::Zlib}) {
      $environment{'compress'} = 1;
    } else {
      $environment{'compress'} = 0;      
    }
    return $environment{'compress'};
  }
  
  sub get_gpmconf {
    
    if (! defined ($environment{'gpmconf'})) {
      my $gpath = $ENV{GPT_LOCATION};
      
      if (!defined($gpath))
        {
          $gpath = $ENV{GLOBUS_LOCATION};
          
        }
      
      if (!defined($gpath))
        {
          die "GPT_LOCATION or GLOBUS_LOCATION needs to be set before running this script"
        }
      $environment{'gpmconf'} = "$gpath/etc/" . 
        Grid::GPT::PkgMngmt::BuildEnv::mypackage();
    }
    return $environment{'gpmconf'};
  }
  
  sub get_target {
    
    return $environment{'target'} if defined $environment{'target'};
    my $gpath = get_gpmconf();
    
    $environment{'target'} = 
      `cat $gpath/globus_build.conf`;
    chomp($environment{'target'});
    return $environment{'target'};
    
  }
}

if (defined eval { require Archive::Tar}) {
  require Archive::Tar;
} else {
  die "ERROR: Cannot find the module Archive::Tar
If it is installed in a non-standard location make sure that PERL5LIB points to the location.
You can get the module from www.cpan.org";
}

# Preloaded methods go here.
sub new {
  my ($class, %arg) = @_;
  my $me = {
            rpm => $arg{'rpm'},
            buildno => $arg{'buildno'},
            verbose => $arg{'verbose'},
	    log => $arg{'log'},
            locations => $arg{'locations'},
            license => $arg{'license'},
            gptfiles => {},
            rpmfiles => {},
	   };

  #
  # default rpm gpt prefix is /usr/grid.  if our relevant argument to new() was undefined, use
  # the default instead.
  #

  my $gpt_rpm_prefix = $arg{'gpt_rpm_prefix'};

  if ( !defined($gpt_rpm_prefix) )
  {
    $gpt_rpm_prefix = "/usr/grid";
  }

  $gpt_rpm_prefix =~ s:\s+::g;
  $gpt_rpm_prefix =~ s:/+:/:g;
  $gpt_rpm_prefix =~ s:[^/]/$::g;

  if ( $gpt_rpm_prefix !~ /^\// )
  {
    die("ERROR: Value supplied for RPM prefix is not an absolute pathname!");
  }

  #
  # hopefully the trinomial operator will catch any potential weirdness with undef'd variables
  #

  $me->{gpt_rpm_prefix} = ( defined($gpt_rpm_prefix) ? $gpt_rpm_prefix : "/usr/grid" );

  #
  # set the buildno default if not passed to us
  #

  my $buildno = $arg{'buildno'};
  if ( !defined($buildno) )
  {
    $buildno = 1;
  }

  #
  # hopefully the trinomial operator will catch any potential weirdness with undef'd variables
  #

  $me->{buildno} = ( defined($buildno) ? $buildno : 1 );

  $me->{'filelist_funcs'} = 
    new Grid::GPT::FilelistFunctions(log => $arg{'log'},
                                     locations => $arg{'locations'},
                                     error_out_missing => 1,
                                    );
  $me->{'target'} = get_target();

  die "Native packages not support for this platform\n" 
    if defined $me->{'rpm'} and ! $me->{'target'} =~ m!linux!;

  bless $me, $class;

  return $me;
}


sub archive {
  my ($me, $pkgs) = @_;


  for my $p (@$pkgs) {
    my $printname = $p->label();
    if ($p->format() eq 'link') {
      if (defined $me->{'log'}) {
        $me->{'log'}->inform("SKIPPING VIRTUAL PACKAGE $printname");
      } else {
        print "SKIPPING VIRTUAL PACKAGE $printname\n";
      }
      next;
    }

    if (defined $me->{'log'}) {
      $me->{'log'}->inform_piece("CREATING PACKAGES FOR $printname...");
    } else {
      print "CREATING PACKAGES FOR $printname...";
    }

    $me->{'filelist_funcs'}->copy_flavored_pgm_files(flavor => $p->flavor(),
                                                    pkgtype => $p->pkgtype(),
                                                    filelist => $p->filelist()->getFilelistFiles(),
                                                    pkgname => $p->pkgname(),
                                                    restore => 1);

    my $result = $me->gpt_pkg($p);
    if ($result) {
      if (defined $me->{'log'}) {
        $me->{'log'}->inform_piece("..gpt");
      } else {
        print "..gpt";
      }
    }

    $result = $me->rpm($p) if defined $me->{'rpm'} and $result;

    if ($result and defined $me->{'rpm'}) {
      if (defined $me->{'log'}) {
        $me->{'log'}->inform_piece("..rpm");
      } else {
        print "..rpm";
      }
    }

    if ($result ) {
      if (defined $me->{'log'}) {
        $me->{'log'}->inform_piece("..DONE\n");
      } else {
        print "..DONE\n";
      }
    } else {
      if (defined $me->{'log'}) {
        $me->{'log'}->inform_piece("..NOT CREATED\n");
      } else {
        print "..NOT CREATED\n";
      }
    }
  }
}

sub gpt_pkg {
  my ($me, $pkg) = @_;
  my ($name, $pkgtype, $flavor, $rawfilelist, $version) = 
    ($pkg->pkgname(),
     $pkg->pkgtype(),
     $pkg->flavor(),
     $pkg->filelist()->getFilelistFiles(),
     $pkg->version_label()
    );
  my $startdir = cwd();
  chdir $me->{'locations'}->{'installdir'};

  #strip leading /

  my @filelist;

  for my $f (@$rawfilelist) {
    $f =~ s!^/+!!;
    push @filelist, $f;
  }

  $me->{'filelist_funcs'}->check_missing_files(\@filelist);

  my $got_some_files = 0;

  my $archive_ext = "tar.gz";
  $archive_ext = "tar" if ! check_for_compress();
  my $tarfile =
    "$startdir/$name-$version-$me->{'target'}-$flavor-$pkgtype.$archive_ext";
  $tarfile =
    "$startdir/$name-$version-$me->{'buildno'}-$me->{'target'}-${flavor}-$pkgtype.$archive_ext"
      if $pkgtype eq 'pgm_static';
#  print "BEFORE:\n @filelist\n";
  my $tar = Archive::Tar->new();
  my $result = $tar->add_files(@filelist);
  my @files = $tar->list_files();
  $got_some_files++ if @files;
#     print  "AFTER:\n", @files, "\n";
  if (check_for_compress()) {
    $tar->write($tarfile, 9);
  } else {
    $tar->write($tarfile);
  }
  my $tarname = $tarfile;
  $tarname =~ s!$startdir/!!; 
  $me->{'gptfiles'}->{$pkg->label()} = $tarname;
  $me->{'current_tarfile'} = $tarfile;
  $me->{'current_pkgdir'} = $startdir;
  chdir $startdir;
  return $got_some_files > 0;
}

sub rpm {
  my ($me, $pkg) = @_;
  my ($name, $pkgtype, $flavor, $filelist, $version) = 
    ($pkg->pkgname(),
     $pkg->pkgtype(),
     $pkg->flavor(),
     $pkg->filelist()->getFilelistFiles(),
     $pkg->version_label()
    );

  my ($binpkgname, $pkgdir) = ($me->{'current_tarfile'}, $me->{'current_pkgdir'});
  my $gpmconf = get_gpmconf();

  Grid::GPT::FilelistFunctions::mkinstalldir("$pkgdir/rpm/SOURCES");
  Grid::GPT::FilelistFunctions::mkinstalldir("$pkgdir/rpm/BUILD");
  Grid::GPT::FilelistFunctions::mkinstalldir("$pkgdir/rpm/RPMS");
  Grid::GPT::FilelistFunctions::mkinstalldir("$pkgdir/rpm/SRPMS");
  Grid::GPT::FilelistFunctions::mkinstalldir("$pkgdir/rpm/tmp");
  Grid::GPT::FilelistFunctions::mkinstalldir("$pkgdir/rpm/SPECS");


  open(TEMPLATE, "$gpmconf/gpt_rpm.spec");
  my $specname = $binpkgname;
  $specname =~ s!\.tar(?:\.gz)?!.spec!;
  $specname =~ s!$pkgdir!$pkgdir/rpm/SPECS!;
  open(SPEC, ">$specname");

#  print "Creating specfile $specname\n";

  my $rpmstuff = ($pkg->depnode())->rpm();
  my $stupidrpmworthlessdir = "$rpmstuff->{'GPT_PACKAGE_GPT'}-$rpmstuff->{'GPT_VERSION_GPT'}";
  Grid::GPT::FilelistFunctions::mkinstalldir("$pkgdir/$stupidrpmworthlessdir");
  my $tar = Archive::Tar->new();


  my ($rootname) = $binpkgname =~ m!/([^/]+\.tar.gz)!; 
  my $result = `cp $binpkgname rpm/SOURCES/$rootname`;
  my $tarfile = "rpm/SOURCES/$ {stupidrpmworthlessdir}-rpm.tar.gz";
  $tar->add_files("$stupidrpmworthlessdir" , "rootname");
  my @files = $tar->list_files();
#  print  "AFTER:\n", @files, "\n";
  $tar->write($tarfile, 9);

  #
  # assume our initial formatting of gpt_rpm_prefix was correct
  #

  my $gpt_rpm_prefix = $me->{'gpt_rpm_prefix'};
  $rpmstuff->{'GPT_PREFIX_GPT'} = $gpt_rpm_prefix;

  $rpmstuff->{'GPT_BIN_PKG_NAME_GPT'} = $rootname;
  $rpmstuff->{'GPT_PKG_RELEASE_GPT'} = defined $me->{'buildno'} 
    and $pkgtype eq "pgm_static" ? $me->{'buildno'} : '0';
  $rpmstuff->{'GPT_FILELIST_GPT'} = join ("", map { "${gpt_rpm_prefix}/$_\n" } @$filelist );
  $rpmstuff->{'GPT_LICENSE_GPT'} = defined $me->{'license'} ? 
    $me->{'license'} : Grid::GPT::PkgMngmt::BuildEnv::default_rpm_license();
  for my $l (<TEMPLATE>) {
    for my $k (keys %$rpmstuff) {
      $l =~ s!$k!$rpmstuff->{$k}!g;
    }
    print SPEC $l;
  }
  close TEMPLATE;
  close SPEC;
  my $rpmcmd = "rpm";
  $rpmcmd .= defined $me->{'verbose'} ? " -v" : " ";
  $rpmcmd .= " --define '_topdir $pkgdir/rpm' --define '_tmppath $pkgdir/rpm/tmp' -ba $specname";

  print "$rpmcmd\n" if defined $me->{'verbose'};
  $result = `$rpmcmd 2>&1`;

  print $result if defined $me->{'verbose'};
  my @lines = split /\n/, $result;

  my $finished;
  for my $l (@lines) {
    my ($file) = $l =~ m!Wrote: (.+)!;
    if ($file =~ m!/RPMS/!) {
      my ($basename) = $file =~ m!/([^/]+)$!;
      my $cresult = `cp $file $me->{'current_pkgdir'}/$basename`;
      $me->{'rpmfiles'}->{$pkg->label()} = "$basename";
      $finished++;
      last;
    }
  }

  $result = `rm -rf $pkgdir/$stupidrpmworthlessdir`;
  return $finished;
}




# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::PkgMngmt:Archive - Perl extension for archiving globus binaries.

=head1 SYNOPSIS

  use Archive;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Archive was created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head1 AUTHOR

A. U. Thor, a.u.thor@a.galaxy.far.far.away

=head1 SEE ALSO

perl(1).

=cut
