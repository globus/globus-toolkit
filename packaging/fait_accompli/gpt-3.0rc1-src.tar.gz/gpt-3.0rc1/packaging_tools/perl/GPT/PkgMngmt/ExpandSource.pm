package Grid::GPT::PkgMngmt::ExpandSource; 
use strict; 
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;
require Grid::GPT::PkgMngmt::Archive;
require Archive::Tar;
require AutoLoader;
use Data::Dumper;
use Grid::GPT::FilelistFunctions;
use Grid::GPT::PackageFactory;
use Grid::GPT::PkgMngmt::BuildEnv;
use Grid::GPT::PkgMngmt::Inform;
use Cwd;
use File::Find;
use Carp;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT            = qw();
$VERSION           = '0.01';

# Preloaded methods go here.
sub open_bundle 
{
  require Grid::GPT::Algorithms;
  my (%arg)        = @_;
  my $startdir     = cwd();

  my @sources;
  my $builddir     = $arg{'locations'}->{'builddir'};

  my $file       = Grid::GPT::FilelistFunctions::abspath($arg{'file'});

  my $filetype = Grid::GPT::Algorithms::check_input_file(file => $file);

  if( $filetype eq 'SRC_BUNDLE' or $filetype eq 'SRC_2xBUNDLE' )
  {
    chdir $builddir;
    my @list       = untar($file);
    my @pl         = grep {m!packaging_list!} @list;
  
    open(PL, "$pl[0]") ||
      die "ERROR: $pl[0] could not be accessed for bundle $arg{'file'}\n";

    chdir $startdir;

    for my $l (<PL>) 
    {
      next if $l !~ m!\w!;
      chomp $l;

      my @tarfiles = grep { m!$l\-\d! } @list;

      if (! @tarfiles) 
      {
        print "ERROR: Archive not found for package $l\nArchive:\n";
        for (@list) 
        {
          print "\t$_\n";
        }
        exit 1;
      }
      my $src = new Grid::GPT::PkgMngmt::ExpandSource(
                                        tarfile => "$builddir/$tarfiles[0]",
                                        locations => $arg{'locations'});
      push @sources, $src;
    }
    close PL;
    return \@sources;
  }

  if ($filetype eq 'SRC_PKG') 
    {
      my $src = new Grid::GPT::PkgMngmt::ExpandSource(tarfile => $arg{'file'}, 
                                                      locations => $arg{'locations'});
      return undef if ! defined $src;

      $sources[0] = $src;
      return \@sources;
  }

  if ($filetype ne 'UNKNOWN')
    {
      print STDERR "ERROR: $arg{'file'} is a binary bundle or package.  Use gpt-install\n";
      return undef;
    }
  
    print STDERR "ERROR: $arg{'file'} is not a GPT source package or bundle\n";
    return undef;

}

sub new {
  my ($class, %arg) = @_;
  # set the following directories
  # patch directory.
  # source directory.
  
  my $me = { srcdir    => $arg{'srcdir'},
             topsrcdir => $arg{'srcdir'},
             srcfile   => $arg{'srcfile'},
             patchdir  => $arg{'patchdir'},
             locations  => $arg{'locations'},
             tarfile   => $arg{'tarfile'} };
  $|++; # need for timely print outputs
  
  for my $f ('topsrcdir','srcdir','patchdir','tarfile','srcfile') 
  {
    next if ! defined $me->{$f};

    $me->{$f} = Grid::GPT::FilelistFunctions::abspath($me->{$f});
    
    if (! defined -f $me->{$f}) {
      print STDERR "ERROR: $me->{$f} is not a valid path\n";
      return undef;
    }
  }
  
  bless $me, $class;
  
  return $me;
}

sub setup_source {
  my ($me, %args)        = @_;
  my $log = $me->{'log'} = $args{'log'};
   my $startdir          = cwd();

  $me->{'srcdir'}        = $startdir if ! defined $me->{'srcdir'};

  $me->expand() if defined $me->{'tarfile'};
  $me->{'topsrcdir'}     = $me->{'srcdir'} if ! defined $me->{'topsrcdir'};

  my $result             = opendir(DIR, $me->{'srcdir'});
  if (! $result) {
    $log->error("ERROR can't access $me->{'srcdir'}\n");
    return 1;
  }
  my @contents           = readdir(DIR);

  if (! defined ($me->{'patchdir'})) 
  {
    my $patchdir = findindir(qr/patches/, "patch directories",\@contents, $log);
    $me->{'patchdir'}    = Cwd::abs_path("$me->{'srcdir'}/$patchdir") 
      if defined $patchdir;
  }
  if (! defined $me->{'srcfile'}) 
  {
    my $pkgdata          = findindir( qr/^pkgdata$/, 
                                      "pkgdata directory",
                                      \@contents, 
                                      $log );

    if (defined ($pkgdata)) 
    {
      $me->{'srcfile'}   = "$me->{'srcdir'}/pkgdata/pkg_data_src.gpt.in";
      if (! -f $me->{'srcfile'}) 
      {
        $log->error( "ERROR: Source pkgdata file not found. Are you sure" .
                     " this is a source package?");
        return 1;
      }
    } 
    else 
    {
      $me->{'srcfile'}   = "$me->{'srcdir'}/pkg_data_src.gpt";
      if (! -f $me->{'srcfile'}) 
      {
        $log->error("ERROR: Source pkgdata file not found. Are you sure" .
                    " this is a source package?");
        return 1;
      }
    }
  }


  # extract pkg metadata
  my $factory = new Grid::GPT::PackageFactory;
  $log->inform("Scanning $me->{'srcfile'}");
  $me->{'pkg'} = $factory->type_of_package($me->{'srcfile'});
  if (! defined $me->{'pkg'}) {
    $log->error("ERROR: $me->{'srcfile'} is not a package data file");
    return 1;
  }
  $me->{'pkg'}->{'disable_version_checking'} = $args{'disable_version_checking'};
  $me->{'pkg'}->read_metadata_file($me->{'srcfile'});

  if (defined $me->{'pkg'}->{'SrcDir'}) {
    $me->{'srcdir'} = "$me->{'srcdir'}/$me->{'pkg'}->{'SrcDir'}";
    return 0;
  }

  if (! -f "$me->{'srcdir'}/Makefile.in" and ! -f "$me->{'srcdir'}/INSTALL") 
  {
    my @subdirs = 
      grep { -f "$me->{'srcdir'}/$_/Makefile.in" or 
             -f "$me->{'srcdir'}/$_/INSTALL" }
        grep { -d "$me->{'srcdir'}/$_" } 
          @contents;

      if (@subdirs > 1) 
      {
        $log->error("ERROR: Found multiple sources in " .
                    "$me->{'srcdir'}/[ @subdirs ]");
        return 1;
      }

    $me->{'srcdir'} .= "/$subdirs[0]" if @subdirs;
  }

  return 0;
}

sub findindir
{
  my ($expression, $lookfor, $contents, $log) = @_;
  my @hits = grep {m!$expression!} @$contents;

  if (@hits > 1 ) 
  {
    $log->error("ERROR: Too many $lookfor found");
    die;
  }

  return $hits[0] if @hits;
  return undef;
};


sub expand 
{
  my ($me)        = @_;
  my $startdir    = cwd();
  my $builddir       = $me->{'locations'}->{'builddir'};
  
  return if !defined $me->{'tarfile'};
  
  # need to untar a source tarball
  
  chdir $builddir;
  
  $me->{'log'}->inform("UNPACKING $me->{'tarfile'}");

  my @list        = untar($me->{'tarfile'});

  my $srcdir      = $list[0];
  $srcdir         =~ s!(^[^/]+)/.+!$1!;

  $me->{'srcdir'} = "$builddir/$srcdir";

  chdir $startdir; 
}

sub expand_unpatched_source 
{
  my ($me, $tarfile) = @_;
 
  my $startdir       = cwd();
  croak "I'm untarring source\n"; 
  chdir $me->{'srcdir'};

  my $unpatched_srcdir;
  
  print "UNPACKING $tarfile\n";
  my @list           = untar($tarfile);
  chdir $startdir; 
}

sub untar 
{
  my($file, $log)    = @_;
  my $cmd;

  if ($file =~ m!\.gz$!) 
  {
    $cmd             = Grid::GPT::PkgMngmt::BuildEnv::gunzip() . " < $file | " .
                       Grid::GPT::PkgMngmt::BuildEnv::tar() . " xvf -";
  }
  else
  {
    $cmd             = Grid::GPT::PkgMngmt::BuildEnv::tar() . " xvf $file";
  }

  my @list           = `$cmd 2>&1`;
  if ($?) 
  {
    if (defined $log) 
    {
      $log->error("$file could not be untarred:$?");
      die;
    } 
    else 
    {
      die "$file could not be untarred:$?\n";
    }
  }

  for (@list) 
  {
    s!^(?:x\s+)?(?:\./)?!!;
    s!,.+$!!;
    chomp;
  }

  return @list;
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::PkgMngmt:ExpandSource - Perl extension for expanding source packages
and bundles.

=head1 SYNOPSIS

  use ExpandSource;
  my $src = new Grid::GPT::PkgMngmt::ExpandSource(srcdir => $s,
                                        srcfile => $srcfile,
                                       );
  my @sources = Grid::GPT::PkgMngmt::ExpandSource::open_bundle(file => "$startdir/$t", 
                                                     builddir => $tmpdir);

 for my $o (@sources) {
   $o->setup();
 }

=head1 DESCRIPTION

B<Grid::GPT::PkgMngmt::ExpandSource> is used to unarchive a source package or bundle and prepare the contents for building.


=head1 METHODS

=over 4

=item open_bundle(file => "$startdir/$t", builddir => $tmpdir)

This is a class function that untars a source bundle and returns a
list of ExpandSource objects.  Each object represents a source
package.  A bundle is an archive of source packages with a file called
I<packaging_list> which lists the packages in build dependent order.
For example here is the contents of the globus_gsi_bundle.tar.gz:

   -rw-r--r-- mbletzin/mbletzin 152868 2001-09-25 10:59:03 ./gsi/globus_core-2.0.tar.gz
   -rw-r--r-- mbletzin/mbletzin 8557949 2001-09-25 10:50:02 ./gsi/globus_openssl-0.9.6b.tar.gz
   -rw-r--r-- mbletzin/mbletzin  120013 2001-09-25 10:59:04 ./gsi/globus_core_setup-2.0.tar.gz
   -rw-r--r-- mbletzin/mbletzin  248338 2001-09-25 10:59:06 ./gsi/globus_ssl_utils-2.0.tar.gz
   -rw-r--r-- mbletzin/mbletzin  161845 2001-09-25 10:59:09 ./gsi/globus_gssapi_gsi-2.0.tar.gz
   -rw-r--r-- mbletzin/mbletzin  120526 2001-09-25 10:59:10 ./gsi/globus_gss_assist-2.0.tar.gz
   -rw-r--r-- mbletzin/mbletzin      52 2001-09-25 10:59:10 ./gsi/packaging_list

The contents of the packaging_list file is:

   core
   core_setup
   openssl
   ssl_utils
   gssapi_gsi
   gss_assist

=item setup_source

This object function expands the source tarball if necessary and sets
the attributes that describe the build directory.


=back

=head1 ATTRIBUTES

=over 4

=item srcdir

Points to the top of the source directory

=item srcfile

Points to the location of the source package metadata.

=item patchdir

Points to the directory containing patches for the source packages.
This should not be used for now because of portability problems with
the patch command.

=item builddir

Directory in which the sources are expanded.

=item tarfile

Name of the source package to be expanded.

=item globusdir

Location where the globus packaging tools are installed.

=item build_instructions

Contents of the build_instructions file.  Currently this is not being
used.

=item filelist

Contents of the filelist file.  The file is needed for those packages
which don't generate filelists as part of their build process.

=back

=head1 AUTHOR

Michael Bletzinger <mbletzin@ncsa.uiuc,edu>

=head1 SEE ALSO

perl(1) globus-build(1).

=cut
