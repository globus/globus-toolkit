package Grid::GPT::PackageFactory;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::V1::Package;
use Grid::GPT::V1::Bundle;

# set the version for version checking
$VERSION     = 0.01;
my $_DEBUG   = 0;

my %table;

sub new { 
  my $that   = shift;
  my $class  = ref($that) || $that;
  my $self   = {};

  bless $self, $class;
  return $self;
}

sub type_of_package {
  my $self   = shift;
  my ($filename,$pkg_type) = @_;

  $filename  = "$ {filename}_$pkg_type.gpt" if(defined($pkg_type));
  my $xml    = new Grid::GPT::XML;

  $xml->read($filename);

  my $root   = $xml->{'roottag'};

# Check to see if we can understand this format

  if( $root->{'name'}    eq 'GPTPackageMetadata' )
  {
    return( undef );
  }
  elsif( $root->{'name'} eq 'gpt_package_metadata' )
  {
    return( new Grid::GPT::V1::Package );
  }
  elsif( $root->{'name'} eq 'GPTBundleData' )
  {
    return( new Grid::GPT::V1::Bundle );
  }
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Package - Perl extension for reading packaging metadata files

=head1 SYNOPSIS

  use Grid::GPT::Package;
  my $pkg = new Grid::GPT::Package;

  $pkg->read_metadata_file('src_metadata.xml');
  my $bin_pkg = $pkg->convert_metadata($type, $build_flavor);
  $bin_pkg->output_metadata_file("$ {type}_metadata.xml");

=head1 DESCRIPTION

I<Grid::GPT::Package> is used to manage (ie. read, write, convert)
packaging metadata. The data is stored in XML format that follows the
file F<package.dtd>.

=head1 Metadata Fields

=over 4

=item Name

Name of the package.

=item Version

A L<Grid::GPT::V1::Version|Grid::GPT::V1::Version> object.

=item Format_Version

A number which defines the metadata format version.

=item Package_Type

The package type one of "data", "dev", "doc", "pgm",
"pgm_static", "rtl", "src", or virtual.

=item Flavor

The build flavor a binary package was generated with. N/A to src
packages.

=item Version_Label

For a virtual package, this field contains the version description of
the external library.

=item With_Flavor

Yes or no if the src package should be built using build flavors. N/A
to binary packages.

=item Description

A paragraph or two that adds information about this package release.
This is not used by any tools.

=item Functional_Group

A "/" delimited string that indicates what group the package is a part
of.  This is used for bundles.

=item Version_Stability

An indicater about the stibility of the package release. Can be one of
I<experimental>, I<alpha>, I<beta>, or I<production>.

=item Source_Dependencies

Hash of hashes of
L<Grid::GPT::SourceDependency|Grid::GPT::SourceDependency> objects.
The top level hash is keyed by the dependency type. The lower level
hashes are keyed by a combination of package name and package
type. N/A to binary packages.

=item Binary_Dependencies

Hash of hashes of
L<Grid::GPT::BinaryDependency|Grid::GPT::BinaryDependency> objects.
The top level hash is keyed by the dependency type. The lower level
hashes are keyed by a combination of package name and package
type. N/A to src packages.

=item Setup_Dependency

Gives the name and version requirements of a setup package.  Setup
packages are packages that need to be configured or "setup" by the
package installer.

=item Source_Setup_Dependencies

A list of Setup_Dependencies paired with the binary package type that
needs it.  Only for src packages.

=item cflags

String of flags to include for preprocessing.  Only applicable to src
and dev packages.

=item external_includes

String of flags to include external directories containing header
files.  Only applicable to src and dev packages.


=item pkg_libs

String of flags which are used to link libraries provided by the
package.  Only applicable to src and dev packages.  Note that when a
package is converted from src to dev, each library will be appended
with "_<flavor>".


=item external_libs

String of flags to include external libraries.  Only applicable to src
and dev packages.


=item Filelist

For virtual and setup packages only, a Package object can contain a
list of Filelist references. Each reference contains a directory
(Dir), A flag on whether the files are flavored or not (Flavored), A
field indicating which binary package the files belong to
(Package_Type), and a list of filename (Files).  Flavored files in
setup packages are currently not supported.


=item Setup_Name

A Package object can contain the name of a setup package format.  This
name is used for setup dependencies. This name gets passed on to pgm
and pgm_static types.

=item Setup_Version

A Package object can contain the version of a setup package format.
This version is used for setup dependencies. This gets passed on
to pgm and pgm_static types.



=item Post_Install_Message

For setup packages only, a Package object can contain a setup
requirements message.  This message details the tasks that need to be
done to complete the installation of a setupo package. The message is
displayed to the user after the package is installed.


=item Post_Install_Program

For setup packages only, a Package object can contain a setup
requirements program.  This is the program that needs to be run to
complete the setup.


=item doctype

The documentation type for the XML input/output.

=item system

The dtd or schema used in the XML input/output.

=back


=head1 Methods

=over 4

=item new

Create a new I<Grid::GPT::Package> object.

=item read_metadata_file(filename)

load metadata from an input file.  Any of the metadata package format
types can be used as inputs.

=item output_metadata_file(filename)

Dumps the metadata into an output file in xml format

=item convert_metadata(pkg_type)

Converts a src package metadata object into a binary metadata object
of the given package type.  The binary metadata object is returned as
a reference.

=back



=head1 AUTHOR

Eric Blau <eblau@ncsa.uiuc.edu> Michael Bletzinger <mbletzin@ncsa.uiuc,edu>

=head1 SEE ALSO

perl(1) Grid::GPT::SourceDependency(1) Grid::GPT::BinaryDependency(1) Grid::GPT::XML(1) Grid::GPT::V1::Version(1)..

=cut
