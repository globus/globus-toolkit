package Grid::GPT::PkgMngmt::SetupBuildFlavors;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

use Grid::GPT::BuildFlavors;
use Grid::GPT::PkgMngmt::Build;

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter Grid::GPT::GPTObject);

{
  my %environment;

  sub get_core_src {
    
    if (! defined ($environment{'core_src'})) {
      my $gpath = $ENV{GPT_LOCATION};
      
      if (!defined($gpath))
        {
          $gpath = $ENV{GLOBUS_LOCATION};
          
        }
      
      if (!defined($gpath))
        {
          die "GPT_LOCATION or GLOBUS_LOCATION needs to be set before running this script"
        }
      $environment{'core_src'} = "$gpath/etc/" . 
        Grid::GPT::PkgMngmt::BuildEnv::mypackage();

      $environment{'core_src'} .= "/globus_core-src.tar.gz";

    }
    return $environment{'core_src'};
  }
}

sub new {
    my ($that, %args)  = @_;
    my $class = ref($that) || $that;

    my $me  = {
               all => $args{'all'},
               standard => $args{'std'},
               list => defined $args{'list'} ? [ @{$args{'list'}} ]: [],
               core => new Grid::GPT::BuildFlavors(core => 1, 
                                                   cfg => $args{'conffile'},
                                                   std => $args{'std'},
                                                  ),
               installed => 
               new Grid::GPT::BuildFlavors(installed => 1, 
                                               installdir => 
                                               $args{'installdir'}
                                              ),
               newflavors => [],
               installdir => $args{'installdir'},
              };

    bless $me, $class;

    @{$me->{'list'}} = @{$me->{'core'}->{'flavors'}} 
      if defined $args{'std'} or defined $args{'all'};

    $me->verify_flavor_list();

    return $me;
}

sub check_flavor {
  my ($me, $flavor) = @_;

  my @core_flavors = grep { $_ eq $flavor } @{$me->{'core'}->{'flavors'}};
  my @installed_flavors = grep { $_ eq $flavor } 
    @{$me->{'installed'}->{'flavors'}};

  return "NOT_DEFINED" if ! @core_flavors and ! @installed_flavors;
  return "INSTALLED" if @installed_flavors;
  return "DEFINED";
}


sub verify_flavor_list {
  my ($me) = @_;
  my @bad_flavors;

  return if ! defined $me->{'list'};
  for my $f (@{$me->{'list'}}) {
    my $result = $me->check_flavor($f);
    push @bad_flavors, $f if $result eq "NOT_DEFINED";
    push @{$me->{'newflavors'}}, $f if $result eq "DEFINED";
  }
  if (@bad_flavors) {
    print STDERR "ERROR: The following build flavors are not defined\n";
    for my $f(@bad_flavors) {
      print "\t$f\n";
    }
    exit 1;
  }
}

sub add_flavors {
  my ($me, $flavors) = @_;
  push @{$me->{'list'}}, @$flavors;
}

sub setup_macros {
  my ($me, %args) = @_;
  my ($static, $macros, $nogptswitches) = ($args{'static'}, 
                                           $args{'macros'},
                                          $args{'have_build_instructions'});

  my $flavors = $me->{'installed'}->clone();
  # add the static option to all of the flavors.
  # We do it this way instead of via CONFIGOPTS_GPTMACRO so that
  # The option can be overriden by the user or by pkg build instructions.

  my $static_option = defined ($static) ? 
    {label => "static", switch => " --enable-static-only"} :
      {label => "dynamic", switch => ""};

  for my $f (@{$flavors->{'flavors'}}) {
    $flavors->{$f}->add_configure_option(%$static_option);
  }

  #Convert the flavors to macros
  $flavors->build_macros($macros, $nogptswitches);
}

sub build_core {
  my ($me, %args) = @_;

  return if ! @{$me->{'newflavors'}};

  my ($logdir, 
      $verbose, 
      $macros, 
      $static,
      $coresrc,
      $factory) = (
                   $args{'logdir'},
                   $args{'verbose'},
                   Grid::GPT::GPTObject::replicate($args{'macros'}),
                   $args{'static'},
                   $args{'coresrc'},
                   $args{'factory'},
                  );

  my $srcargs = defined $coresrc ? 
    { srcdir => $coresrc } : { tarfile => get_core_src() };

  my $src = new Grid::GPT::PkgMngmt::ExpandSource(%$srcargs);


  my $logname = undef;
  $logname = $logdir . "/globus_core.log"
    if( defined($logdir) );

  my $log = 
    new Grid::GPT::PkgMngmt::Inform(
                                    verbose => $verbose, 
                                    log => $logname,
                                    name => 'gpt-build',
                                   );
  my $filelist_funcs = 
    new Grid::GPT::FilelistFunctions(
                                     installdir => $me->{'installdir'}, 
                                     log=> $log
                                    );

  $src->setup_source(log => $log);


  my $pkg = $factory->type_of_package($src->{'srcfile'});
  $pkg->read_metadata_file($src->{'srcfile'});

  my $static_option = defined ($static) ? 
    {label => "static", switch => " --enable-static-only"} :
      {label => "dynamic", switch => ""};

  for my $f (@{$me->{'core'}->{'flavors'}}) {
    $me->{'core'}->{$f}->add_configure_option(%$static_option);
  }

  #Convert the flavors to macros
  $me->{'core'}->build_macros($macros);


  my $build = new Grid::GPT::PkgMngmt::Build(
                                             srcobj => $src, 
                                             name => 'globus_core', 
                                             globusdir => $me->{'installdir'}, 
                                             verbose => $verbose, 
                                             log => $log,
                                             build_instructions =>
                                             [
                                              {command => 
                                               "MAKE_GPTMACRO distclean 2>&1; rm -f $src->{'srcdir'}/config.cache"},
                                              {command => "CONFIGENV_GPTMACRO $src->{'srcdir'}/configure CONFIGOPTS_GPTMACRO FLAVOR_CONFIGOPTS_GPTMACRO"},
                                              {command => "MAKE_GPTMACRO"},
                                              {command => "MAKE_GPTMACRO install"}
                                             ],
                                             macros => $macros,
                                             static => $static,
                                             ignore_errors => 1,
                                            );

    for my $f (@{$me->{'newflavors'}}) {

      my $result = $build->build($f);
      $filelist_funcs->check_installed_files(name => 'globus_core',
                                             flavor => $f,
                                             static => $static,
                                             pkg => $pkg,
                                             srcdir => $src->{'topsrcdir'});
    }

    $filelist_funcs->check_installed_files(name => 'globus_core',
                                           flavor => 'noflavor',
                                           static => $static,
                                           pkg => $pkg,
                                           srcdir => $src->{'topsrcdir'});

  $me->{'installed'} = 
    new Grid::GPT::BuildFlavors(installed => 1, 
                                installdir => $me->{'installdir'},
                               );

  my (@good_flavors, @bad_flavors);
  my $message = "WARNING: The following flavors are not supported for this platform:\n";
  for my $f (@{$me->{'list'}}) {
    my $result = $me->check_flavor($f);
    if ($result eq "INSTALLED") {
      push @good_flavors, $f;
    } else {
      push @bad_flavors, $f;
      $message .= "\t$f\n";
    }
  }
  $log->error($message) if @bad_flavors;
  $me->{'list'} = \@good_flavors;
  $log->action("rm -rf $src->{'srcdir'}");
}


sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $me = shift;
  my $type = ref($me) || croak "$me is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $me->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $me->{$name} = shift;
  } else {
    return $me->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)



1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::PkgMngmt::SetupBuildFlavors - Perl extension for managing package version metadata

=head1 SYNOPSIS

  use Grid::GPT::PkgMngmt::SetupBuildFlavors;
  my $a_ver = new Grid::GPT::PkgMngmt::SetupBuildFlavors(type =>'aging', major => '4', minor =>'6', age =>'2');
  my $s_ver = new Grid::GPT::PkgMngmt::SetupBuildFlavors(type =>'simple', major => '3');
  my $r_ver = new Grid::GPT::PkgMngmt::SetupBuildFlavors(type =>'range', upper_major => '3', lower_major => '2');

  my $result = $a_ver->is_compatible($s_ver);

=head1 DESCRIPTION

I<Grid::GPT::PkgMngmt::SetupBuildFlavors> is used to manage package version metadata. The
version metadata is to used to describe the version of a package as
well as dependencies to packages.

=head1 SetupBuildFlavors Metadata Types

There are several ways to express information about the compatibility
of the different versions.  This package supports the following
schemes which are called version metadata types.

=over 4

=item aging

This metadata is used to describe the version of a package. It consists of the following fields:

=over 4

=item major 

This is the main version number of the package.

=item minor

This is a number used to version bug fixes that maintain binary compatibility.

=item age

This number denotes the backward compatability of the package.  For
example a package with a major number of 5 and an age of 2 is
compatible back to version 3.

=back

=item simple

This metadata is used to describe the version requirements of a package dependency.
It consists of only a major version number.  The dependency indicates
with this metadata that it will accept a version if the major number
falls with in the age range of the package fulfilling the dependency.

=item range

This metadata is also used to describe the version requirements of a
package dependency.  The range is compared to the specific version
number of the package fulfilling the dependency.  Not that the age
criteria is not used here.  The metadata consists of the following:

=over 4

=item upper_major

The newest major version number accepted. 

=item lower_major

The oldest major version number accepted. 

=item upper_minor

The newest minor version number accepted. 

=item lower_minor

The oldest minor version number accepted. 

=back

=back

=head1 Methods

=over 4

=item new

Create a new I<Grid::GPT::PkgMngmt::SetupBuildFlavors> object.  The following named arguments are accepted

=over 4

=item type

The type of version metadata this object will contain.

=item major

The major version number (used for aging and simple types).

=item minor

The minor version number (used only for the aging type).

=item age

The age of the major version (used only for the aging type).

=item upper_major

The newest major number allowed (used only for the range type).

=item upper_minor

The newest minor number allowed (used only for the range type).

=item lower_major

The oldest major number allowed (used only for the range type).

=item lower_minor

The oldest minor number allowed (used only for the range type).


=item obj

This passes in a L<Grid::GPT::XML|Grid::GPT::XML> version object.  The
version metadata is extracted from the object.

=back

=item is_compatible

Determines if the aging version metadata fulfills the requirements of
another version metadata which can be either simple version metadata
or range version metadata.  Returns 1 if the requirement is fulfilled.
Returns 0 otherwise.

=item validate

Determines if the version metadata is complete.

=item write_tag(xml_obj)

Adds version contents into an L<Grid::GPT::XML|Grid::GPT::XML> object. 

=item create_version_list(xml_obj)

Class function which creates a list of SetupBuildFlavors objects from a
L<Grid::GPT::XML|Grid::GPT::XML> object.  The function returns a
reference to the list.


=item convert_version_list2xml(version_list_reference, xml_obj)

Class function which adds the contents of all SetupBuildFlavors objects in a
list reference to an L<Grid::GPT::XML|Grid::GPT::XML> object.

=back

=head1 SetupBuildFlavorsing Examples

As an example consider the installed package foo which has a version
number of 5.3.  As was mentioned in the previous section, this
specifies a compatibility range of 2 to 5.  Now we want to install
package fum which depends on foo.  The following table shows how the
versioning works:


    SetupBuildFlavors specification for   SetupBuildFlavors
    Dependency foo to fum       Type           Dependency is met
    
    1                           Simple         No 
    1 to 4                      Range          No
    4 to 4                      Range          No
    3                           Simple         Yes
    3 to 6                      Range          Yes


=head1 AUTHOR

Eric Blau <eblau@ncsa.uiuc.edu> Michael Bletzinger <mbletzin@ncsa.uiuc,edu>

=head1 SEE ALSO

perl(1) GRID::GPT::XML(1).

=cut
