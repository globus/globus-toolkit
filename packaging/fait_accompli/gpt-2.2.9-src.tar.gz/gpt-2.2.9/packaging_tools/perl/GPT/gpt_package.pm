package Grid::GPT::gpt_package;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::V1::Version;
use Grid::GPT::V1::BaseDependency;
use Grid::GPT::V1::SourceDependency;
use Grid::GPT::V1::BinaryDependency;
use Grid::GPT::V1::BuildFlavors;

# set the version for version checking
$VERSION     = 0.01;


sub new { 
    my ($that, %args)  = @_;
    my $class = ref($that) || $that;
    my $self  = {};
    my $f;
    for  $f (sort keys %args) { 
      $self->{$f} = $args{$f};
    } 
    bless $self, $class;

if((defined $args{installed_pkg})&&
   (defined $args{flavor})&&
   (defined $args{type}))
{ 
  $self->path_namer($args{installed_pkg}, $args{flavor}, $args{type});
} 
else
{  
  if((!(defined $args{installed_pkg}))&&
     (!(defined $args{flavor}))&&
     (!(defined $args{type})))
  { 
    return $self;
  }  
  else
  { 
    die "ERROR: Please specify name flavor and type: $!\n";
  } 
} 
return $self;
}

sub path_namer
{
  my ($self, $name, $f, $t)=@_;
  my $globus=$ENV{GLOBUS_LOCATION};
  my $path="$globus/etc/globus_packages/$name/pkg_data_".$f."_$t.gpt";
 
  $self->read_metadata_file($path);
}
 	
sub read_metadata_file {
  # my (%metadata);
  my $self=shift;
  my ($filename,$pkg_type) = @_;
  $filename= "$ {filename}_$pkg_type.gpt" if(defined($pkg_type));
  my $xml = new Grid::GPT::XML;
  $xml->read($filename);

}


sub read
{
  my $self = shift;
  my $xml = shift;

  my $root = $xml->{'roottag'};
  $self->{'Name'} = $root->{'attributes'}->{'Name'};
  $self->{'Format_Version'} = $root->{'attributes'}->{'Format_Version'};

# Check to see if we can understand this format

  $self->{'doctype'} = $xml->{'doctype'};
  $self->{'system'} = $xml->{'system'};

#  print Dumper $xml;
  for my $c (@{$root->{'contents'}}) {
    next if ref($c) ne 'HASH';

    if ($c->{'name'} eq 'Aging_Version') {
      $self->{'Version'} = new Grid::GPT::Version(obj => $c);
      next;
    }

    if ($c->{'name'} eq 'Description') {
      $self->{'Description'} = $c->{'contents'}->[0];
      next;
    }

    if ($c->{'name'} eq 'Functional_Group') {
      $self->{'Functional_Group'} = $c->{'contents'}->[0];
      next;
    }

    if ($c->{'name'} eq 'Version_Stability') {
      $self->{'Version_Stability'} = $c->{'attributes'}->{'Release'};
      next;
    }

if ($c->{'name'} eq 'PackageIdentifier') {
  $self->{'Package_Identifier'} = $c->{'attributes'}->{'Release'};
  next;
}


    if ($c->{'name'} =~ m!(.+)_pkg$!) {
      $self->{'Package_Type'} = $1;

      for my $sc (@{$c->{'contents'}}) {
	next if ref($sc) ne 'HASH';

	# With_Flavor's value is an attribute
	if ($sc->{'name'} eq 'With_Flavors') {
	  $self->{'With_Flavors'} = $sc->{'attributes'}->{'build'};
	  next;
	}

        if ($sc->{'name'} eq 'Setup') {
          $self->{'Setup_Name'} = $sc->{'attributes'}->{'Name'};
          for my $setc (@{$sc->{'contents'}}) {
            next if ref($setc) ne 'HASH';
            if ($setc->{'name'} eq 'Aging_Version') {
              $self->{'Setup_Version'} = new Grid::GPT::Version(obj => $setc);
              last;
            }
          }
        }

        if ($sc->{'name'} eq 'Post_Install_Message') {
          $self->{'Post_Install_Message'} = $sc->{'contents'}->[0];
          next;
        }

        if ($sc->{'name'} eq 'Post_Install_Program') {
          $self->{'Post_Install_Program'} = $sc->{'contents'}->[0];
          next;
        }

	# Pass any SourceDependency XML to SourceDependencies.pm
	if ($sc->{'name'} eq 'Source_Dependencies') {
	  $self->{'Source_Dependencies'} = {} 
	    if ! defined $self->{'Source_Dependencies'};
          Grid::GPT::BaseDependency::add_xml_to(
                                                xml =>$sc, 
                                                depshash => 
                                                $self->{'Source_Dependencies'});
	  next;
        }


	# Build Environment data is a list in contents
	if ($sc->{'name'} eq 'Build_Environment') {
	  for my $bc (@{$sc->{'contents'}}) {
	    next if ref($bc) ne 'HASH';
	    my $name = $bc->{'name'};
	    # Each build environment field has its value in the content array 
	    # which has 1 element
	    $self->{$name} = $bc->{'contents'}->[0];
	  }
	  next;
	}

	# Build Instructions is a list of Build_Step elements in contents
	if ($sc->{'name'} eq 'Build_Instructions') {
	  for my $bc (@{$sc->{'contents'}}) {
	    next if ref($bc) ne 'HASH';
	    my $name = $bc->{'name'};
            if ($name eq 'Build_Step') {
              $self->{'Build_Instructions'} = [] 
                if ! defined $self->{'Build_Instructions'};
              my ($command, $args) = (
                                      $bc->{'contents'}->[0],
                                      $bc->{'attributes'}->{'Macro_Args'}
                                     );
              $command =~ s!\n$!!s;
              my $buildstep = {command => $command, args => $args};
              push @{$self->{'Build_Instructions'}}, $buildstep;
              next;
            }
            if ($name eq 'flavors') {
              $self->{'Build_Flavor_Choices'} = 
                new Grid::GPT::BuildFlavors(xml => $bc);
            }
	  }
	  next;
	}

	# Filelist data has a couple of attributes and a list of files in the contents
	if ($sc->{'name'} eq 'Filelist') {
	  $self->{Filelists} = [] if ! defined $self->{Filelists};
	  # Grab the Dir and Flavored attributes
	  my $filelist = $sc->{'attributes'};
	  $filelist->{'Files'} = [];
	  # Extract each filename
	  for my $bc (@{$sc->{'contents'}}) {
	    next if ref($bc) ne 'HASH';
	    my $name = $bc->{'name'};
	    # Each File field has its value in the content array 
	    # which has 1 element
	    push @{$filelist->{'Files'}}, $bc->{'contents'}->[0];
	  }
	  push @{$self->{Filelists}}, $filelist;
	  next;
	}

	if ($sc->{'name'} eq 'Flavor') {
	    # Flavor has its value in the content array 
	    # which has 1 element
	  $self->{'Flavor'} = $sc->{'contents'}->[0];
	  next;
	}

	if ($sc->{'name'} eq 'Source_Setup_Dependency') {
	  my $setuppkg = $sc->{'attributes'}->{'PkgType'};
          for my $ssc (@{$sc->{'contents'}}) {
            next if ref($ssc) ne 'HASH';
            $self->add_setup_dep($ssc, $setuppkg);
          }
	  next;
	}

	if ($sc->{'name'} eq 'Version_Label') {
	    # Version_Label has its value in the content array 
	    # which has 1 element
	  $self->{'Version_Label'} = $sc->{'contents'}->[0];
	  next;
	}

	# Pass any BinaryDependency XML to BinaryDependencies.pm
	if ($sc->{'name'} eq 'Binary_Dependencies') {
	  $self->{'Binary_Dependencies'} = {} 
	    if ! defined $self->{'Binary_Dependencies'};
          Grid::GPT::BaseDependency::add_xml_to(xml => $sc, 
                                                depshash =>  
                                                $self->{'Binary_Dependencies'});
	  next;
	}
	if ($sc->{'name'} eq 'Setup_Dependency') {
          $self->add_setup_dep($sc);
	  next;
	}
      }      
    }
  }
}

sub add_setup_dep
  {
    my ($self, $setup, $pkgtype) = @_;
    my $name = $setup->{'attributes'}->{'Name'};
    my $versions;
    for my $v(@{$setup->{'contents'}}) {
      next if ref $v ne 'HASH';
      $versions = Grid::GPT::Version::create_version_list($v);
    }
    my $obj = { name => $name, type => $pkgtype, versions => $versions};
    my $setuptype = 'Source_Setup_Dependencies';
    $setuptype = 'Setup_Dependencies' if ! defined $pkgtype;
    if (!defined ($self->{$setuptype})) {
      $self->{$setuptype} = [];
    }
    push @{$self->{$setuptype}}, $obj;
  }

sub convert_metadata {		
  #takes pkg_type and flavor as its arguments
  #returns reference to new (converted) metadata
	my $self=shift;
	my ($pkg_type, $flavor) = @_;
	my $converted=new Grid::GPT::Package;

	for my $n ('Name', 'Version', 'Format_Version', 'doctype', 'system', 
                   'Description', 'Version_Stability', 'Package_Identifier', 'Functional_Group') {
	  $converted->{$n} = $self->{$n};
	}

	$converted->{'Package_Type'} = $pkg_type;
	if (! defined $Grid::GPT::Definitions::noflavor_pkg_types{$pkg_type}) {
		$converted->{'Flavor'} = $flavor 
	}else{
		$converted->{'Flavor'} = "noflavor";
	}


        for my $n ('Post_Install_Message', 'Post_Install_Program', 
                   'Setup_Name') {
          $converted->{$n} = $self->{$n};
        }
        $converted->{'Setup_Version'} = $self->{'Setup_Version'}->clone() 
          if defined $self->{'Setup_Version'};
        
        $converted->{'Binary_Dependencies'} = 
          Grid::GPT::SourceDependency::get_bindeps_from($self->{'Source_Dependencies'}, $pkg_type);

        for my $setup (@{$self->{'Source_Setup_Dependencies'}}) {
          if ($pkg_type eq $setup->{'type'}) {
            $converted->{'Setup_Dependencies'} = [] 
              if ! defined $converted->{'Setup_Dependencies'};
            my $bsetup = replicate($setup);
            $bsetup->{'type'} = undef;
            push @{$converted->{'Setup_Dependencies'}}, $bsetup;
          }
        }

	if ($pkg_type eq 'dev') {
	  for my $n ('cflags' , 'external_includes', 'pkg_libs', 'external_libs') {

	    $converted->{$n} = $self->{$n};
	    if ($n eq 'pkg_libs') {
	      $converted->{$n} =~ s!(-l\w+)\s+!$ {1}_$flavor !g;
	      $converted->{$n} =~ s!(-l\w+)$!$ {1}_$flavor!;
	    }
	  }
	}

return $converted
}

sub clone {
    my $self = shift;
    my $clone = new();
    replicate($self, $clone);
    return $clone;
}

sub replicate {
  my ($rold) = @_;
  if (ref(\$rold) eq 'SCALAR') {
    return $rold;
  } elsif (ref($rold) eq 'ARRAY') {
    my @list = @$rold;
    return \@list;
  } elsif (ref($rold) eq 'HASH') {
    my $rnew = {};
    for my $e (sort keys %$rold) {
      $rnew->{$e} = replicate($rold->{$e});
    }
    return $rnew
  }
}

sub write_metadata_file {
  my $self=shift;
  my ($filename)=@_;

print $filename, "\n";
  my $writer = new Grid::GPT::XML($filename);
  
  $writer->doctype("gpt_package_metadata","globus_package.dtd");
  $writer->startTag("gpt_package_metadata", Name => $self->{'Name'},
		    Format_Version => $self->{'Format_Version'});
  $writer->characters("\n");
  
  $self->{'Version'}->write_tag($writer);
  $writer->dataElement('Description', $self->{'Description'});
  $writer->characters("\n");
  $writer->dataElement('Functional_Group', $self->{'Functional_Group'});
  $writer->characters("\n");
  $writer->emptyTag("Version_Stability", Release=> $self->{'Version_Stability'});
  $writer->characters("\n");
  $writer->emptyTag("PackageIdentifier", Release=> $self->{'Package_Identifier'}
);
  $writer->characters("\n");
 
  $writer->startTag("$self->{'Package_Type'}_pkg");

  $writer->characters("\n");
  
  # Write With_Flavors data
  if (defined $self->{'With_Flavors'}) {
    $writer->emptyTag("With_Flavors", build=> $self->{'With_Flavors'});
  $writer->characters("\n");
  }
  
  # Write out Flavor
  if (defined $self->{'Flavor'}) {
    $writer->dataElement('Flavor', $self->{'Flavor'});
    $writer->characters("\n");
  }
  # Write out Version_Label
  if (defined $self->{'Version_Label'}) {
    $writer->dataElement('Version_Label', $self->{'Version_Label'});
    $writer->characters("\n");
  }
  # Write Dependency Data
  if (defined($self->{'Source_Dependencies'})) {
    Grid::GPT::BaseDependency::get_xml_from($self->{'Source_Dependencies'}, 
                                            $writer,
                                            'Source_Dependencies')
  }
  
  if (defined($self->{'Binary_Dependencies'})) {
    Grid::GPT::BaseDependency::get_xml_from($self->{'Binary_Dependencies'}, 
                                            $writer,
                                            'Binary_Dependencies')
    }
  if (defined($self->{'Source_Setup_Dependencies'})) {
    for my $t (@{$self->{'Source_Setup_Dependencies'}}) {
      write_setup_deps->($writer, $t);
    }
  }
  if (defined($self->{'Setup_Dependencies'})) {
    for my $t (@{$self->{'Setup_Dependencies'}}) {
      write_setup_deps->($writer, $t);
    }
  }
  

  #Write out Build Enviromnment
  if ($self->{'Package_Type'} eq 'src' or $self->{'Package_Type'} eq 'dev' ) {
    $writer->startTag("Build_Environment");
    $writer->characters("\n");
    for my $n ('cflags' , 'external_includes', 'pkg_libs', 'external_libs') {
      $writer->dataElement($n, $self->{$n});
      $writer->characters("\n");
    }
    $writer->endTag("Build_Environment");
    $writer->characters("\n");
  }

  #Write out Build Instructions
  if ($self->{'Package_Type'} eq 'src' and 
      defined $self->{'Build_Instructions'}) {
    $writer->startTag("Build_Instructions");
    $writer->characters("\n");
    for my $s (@{$self->{'Build_Instructions'}}) {
      my %args;
      $args{'Macro_Args'} = $s->{'args'}
        if defined $s->{'args'};
     $writer->dataElement('Build_Step', $s->{'command'},%args);
      $writer->characters("\n");
    }
    $self->{'Build_Flavor_Choices'}->write_xml_choices($writer) 
      if defined $self->{'Build_Flavor_Choices'};
    $writer->endTag("Build_Instructions");
    $writer->characters("\n");
  }

  if (defined $self->{'Post_Install_Message'}) {
    $writer->dataElement('Post_Install_Message', 
                         $self->{'Post_Install_Message'});
    $writer->characters("\n");
  }

  if (defined $self->{'Post_Install_Program'}) {
    $writer->dataElement('Post_Install_Program', 
                         $self->{'Post_Install_Program'});
    $writer->characters("\n");
  }

  # Write out setup package fields
  

  if (defined $self->{'Setup_Name'}) {

    $writer->startTag('Setup', Name => $self->{'Setup_Name'});
    $writer->characters("\n");
    $self->{'Setup_Version'}->write_tag($writer);
    $writer->endTag('Setup');    
    $writer->characters("\n");
  }


  $writer->endTag("$self->{'Package_Type'}_pkg");
  $writer->characters("\n");
  $writer->endTag('gpt_package_metadata');
  $writer->write($filename);
}

sub write_setup_deps
  {
    my ($writer, $setup) = @_;
    my ($name, $pkgtype, $versions) = 
      ( $setup->{'name'}, $setup->{'type'}, $setup->{'versions'});
    $writer->startTag("Source_Setup_Dependency", PkgType => $pkgtype) 
      if defined $pkgtype;
    $writer->characters("\n");
    $writer->startTag("Setup_Dependency", Name => $name);
    $writer->characters("\n");
    Grid::GPT::Version::convert_version_list2xml($versions, $writer);
    $writer->endTag("Setup_Dependency");
    $writer->characters("\n");
    $writer->endTag("Source_Setup_Dependency") if defined $pkgtype;
    $writer->characters("\n");
  }

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Package - Perl extension for reading packaging metadata files

=head1 SYNOPSIS

  use Grid::GPT::Package;
  my $pkg = new Grid::GPT::Package;

  $pkg->read_metadata_file('src_metadata.xml');
  my $bin_pkg = $pkg->convert_metadata($type, $build_flavor);
  $bin_pkg->output_metadata_file("$ {type}_metadata.xml");

=head1 DESCRIPTION

I<Grid::GPT::Package> is used to manage (ie. read, write, convert)
packaging metadata. The data is stored in XML format that follows the
file F<package.dtd>.

=head1 Metadata Fields

=over 4

=item Name

Name of the package.

=item Version

A L<Grid::GPT::Version|Grid::GPT::Version> object.

=item Format_Version

A number which defines the metadata format version.

=item Package_Type

The package type one of "data", "dev", "doc", "pgm",
"pgm_static", "rtl", "src", or virtual.

=item Flavor

The build flavor a binary package was generated with. N/A to src
packages.

=item Version_Label

For a virtual package, this field contains the version description of
the external library.

=item With_Flavor

Yes or no if the src package should be built using build flavors. N/A
to binary packages.

=item Description

A paragraph or two that adds information about this package release.
This is not used by any tools.

=item Functional_Group

A "/" delimited string that indicates what group the package is a part
of.  This is used for bundles.

=item Version_Stability

An indicater about the stibility of the package release. Can be one of
I<experimental>, I<alpha>, I<beta>, or I<production>.

=item Source_Dependencies

Hash of hashes of
L<Grid::GPT::SourceDependency|Grid::GPT::SourceDependency> objects.
The top level hash is keyed by the dependency type. The lower level
hashes are keyed by a combination of package name and package
type. N/A to binary packages.

=item Binary_Dependencies

Hash of hashes of
L<Grid::GPT::BinaryDependency|Grid::GPT::BinaryDependency> objects.
The top level hash is keyed by the dependency type. The lower level
hashes are keyed by a combination of package name and package
type. N/A to src packages.

=item Setup_Dependency

Gives the name and version requirements of a setup package.  Setup
packages are packages that need to be configured or "setup" by the
package installer.

=item Source_Setup_Dependencies

A list of Setup_Dependencies paired with the binary package type that
needs it.  Only for src packages.

=item cflags

String of flags to include for preprocessing.  Only applicable to src
and dev packages.

=item external_includes

String of flags to include external directories containing header
files.  Only applicable to src and dev packages.


=item pkg_libs

String of flags which are used to link libraries provided by the
package.  Only applicable to src and dev packages.  Note that when a
package is converted from src to dev, each library will be appended
with "_<flavor>".


=item external_libs

String of flags to include external libraries.  Only applicable to src
and dev packages.


=item Filelist

For virtual and setup packages only, a Package object can contain a
list of Filelist references. Each reference contains a directory
(Dir), A flag on whether the files are flavored or not (Flavored), A
field indicating which binary package the files belong to
(Package_Type), and a list of filename (Files).  Flavored files in
setup packages are currently not supported.


=item Setup_Name

A Package object can contain the name of a setup package format.  This
name is used for setup dependencies. This name gets passed on to pgm
and pgm_static types.

=item Setup_Version

A Package object can contain the version of a setup package format.
This version is used for setup dependencies. This gets passed on
to pgm and pgm_static types.



=item Post_Install_Message

For setup packages only, a Package object can contain a setup
requirements message.  This message details the tasks that need to be
done to complete the installation of a setupo package. The message is
displayed to the user after the package is installed.


=item Post_Install_Program

For setup packages only, a Package object can contain a setup
requirements program.  This is the program that needs to be run to
complete the setup.


=item doctype

The documentation type for the XML input/output.

=item system

The dtd or schema used in the XML input/output.

=back


=head1 Methods

=over 4

=item new

Create a new I<Grid::GPT::Package> object.

=item read_metadata_file(filename)

load metadata from an input file.  Any of the metadata package format
types can be used as inputs.

=item output_metadata_file(filename)

Dumps the metadata into an output file in xml format

=item convert_metadata(pkg_type)

Converts a src package metadata object into a binary metadata object
of the given package type.  The binary metadata object is returned as
a reference.

=back



=head1 AUTHOR

Eric Blau <eblau@ncsa.uiuc.edu> Michael Bletzinger <mbletzin@ncsa.uiuc,edu>

=head1 SEE ALSO

perl(1) Grid::GPT::SourceDependency(1) Grid::GPT::BinaryDependency(1) Grid::GPT::XML(1) Grid::GPT::Version(1)..

=cut
