package Grid::GPT::V1::DepClass;
use Grid::GPT::V1::Package;
use strict;

my %dep_struct = (
	deps_list => [],
	rev_deps	=> {},
	compile_deps => {},
	pgm_link_deps => {},
	lib_link_deps => {},
	runtime_link_deps => {},
	Runtime_deps => {},
	Runtime_Link_deps => {},
	Regeneration_deps => {},
	Compile_deps => {},
	counts => {},
	pkgobj => []
);

sub new {
	 my $class  = shift;
	 my $pkgobj = shift;
   	 my $self  = {
	        %dep_struct,
		    };
		    #	$self->pkgobj=$pkgobj;
    bless $self, $class;
    return $self;
}
	
END { }


package Grid::GPT::V1::Dependencies;

use strict;
use Carp;
use Grid::GPT::V1::Package;
use Grid::GPT::V1::Version;
use Grid::GPT::V1::BuildFlavors;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

# your exported package globals go here,
# as well as any optionally exported functions
@EXPORT_OK   = qw($Var1 %Hashit &func3);

use vars qw($Var1 %Hashit);
# non-exported package globals go here
use vars      qw(@more $stuff);

# initialize package globals, first exported ones
$Var1   = '';
%Hashit = ();

# then the others (which are still accessible as $Some::Module::stuff)
$stuff  = '';
@more   = ();

# all file-scoped lexicals must be created before
# the functions below that use them.

# file-private lexicals go here
my $priv_var    = '';
my %secret_hash = ();

# here's a file-private function as a closure,
# callable as &$priv_func.
my $priv_func = sub {
    # stuff goes here.
};

# make all your functions, whether exported or not;
# remember to put something interesting in the {} stubs

my %deptree = (
	packagelist  => [],
	packagehash	=> {},
	metadatacache	=> {},
	compile => {},
	pgm_link => {},
	lib_link => {},
	data_runtime => {},
	pgm_runtime => {},
	lib_runtime => {},
	Compile => {},
	Build_Link => {},
	Regeneration => {},
	Runtime_Link => {},
	Runtime => {}
	
);

sub new {
    my $class  = shift;
    my $self  = {
        %deptree,
    };
    bless $self, $class;
    return $self;
} 

sub intuit_pkg_type {
  my ($self, $dep, $pkg_type, $linktype) = @_;
#print "dep is $dep, initial pkg_type is $pkg_type, linktype is $linktype \n";
#print Dumper $pkg_type;
  if (! defined $pkg_type or $pkg_type eq ''){
  	return 'dev' if $dep eq 'compile';
  	return 'dev' if $dep eq 'pgm_link';
  	if ($dep eq 'lib_link'){
  		return 'dev' if $linktype eq 'static';
  		return 'dev' if $linktype eq 'shared';
  	}
  }
  die "ERROR: Package type needs to be defined for $dep\n"
    if ! defined $pkg_type or $pkg_type eq '';
  return $pkg_type;
}                   	


sub get_dependencies{		#returns a list of metadata objects
	my $self=shift;
	my $head=shift;
	my $instorbuild=shift;
	my $flavor=shift;
	my $linktype=shift;
	my $verbosity=shift;
	my $holder=undef();
	my @errorlist;
	my $deparray=undef();
	my $globusdir = $ENV{'GLOBUS_LOCATION'};
		if (!defined($globusdir)) {
		  die "Please set GLOBUS_LOCATION\n";
		} 
		#if ($instorbuild eq "install" | $instorbuild eq "check"){
		#	 $deparray= $Grid::GPT::V1::Definitions::installation_dependencies{$head->{'Package_Type'}};
		#}else{
		if ($head->{'Package_Type'} eq 'src'){
			my @tmparray;
			if ($instorbuild eq "build"){
			   @tmparray=('compile','pgm_link','lib_link');
			}else{
			   @tmparray=('compile','pgm_link','lib_link','data_runtime',
							'pgm_runtime','lib_runtime');
			}
		 	$deparray=\@tmparray;
		}else{
			my @tmparray;
			if ($instorbuild eq "build"){
			   @tmparray=('Compile', 'Build_Link', 'Runtime_Link');
			}else{
			   @tmparray=('Compile', 'Build_Link', # we're ignoring this for the moment 'Regeneration', 
							'Runtime_Link', 'Runtime');
			}
			$deparray=\@tmparray;
		}

		#}

if (! defined $flavor){
	if (defined $head->{'Flavor'}){
 	  $flavor=$head->{'Flavor'};
	}
}else{
	if ($flavor eq "noflavor"){
		 if (defined $head->{'Flavor'}){
			 $flavor=$head->{'Flavor'};
		 }
	 }
}

if ($instorbuild eq 'check'){
	#check to see if the package is already in the packagehash
	 if (! (defined
	 $self->{packagehash}->{$head->{'Name'}."-".$head->{'Flavor'}."_".$head->{'Package_Type'}})){
	   %{$self->{packagehash}}->{$head->{'Name'}."-".$head->{'Flavor'}."_".$head->{'Package_Type'}}= \$head;
   } # end if ! defined
} # end if $instorbuild eq check
				

	foreach my $deptype (@$deparray){
		if ($instorbuild eq "install"){
			$holder=$head->{'Binary_Dependencies'};
		} else {
			if ($head->{'Package_Type'} eq 'src'){
				$holder=$head->{'Source_Dependencies'};
			}else{
				$holder=$head->{'Binary_Dependencies'};
			}
		}
		if (defined $holder->{$deptype}){
		foreach my $dep (keys %{$holder->{$deptype}}){
			my $md=undef();
			if ($instorbuild eq "source"){
				my $depobject=$holder->{$deptype}->{$dep};
				my $type=$depobject->{'pkg_type'};
				my $name=$depobject->{'name'};
				  my (@realname) = split '-', $name;
				  if (@realname[(scalar(@realname)-1)] =~ m/_src$|_pgm$|_rtl$|_data$|_doc$|_dev$|_pgm_static$/){
					  my $rest=pop @realname;
				  }
				  $name = join '-', @realname;
				  if (! ($name =~ m/-_src$/)){
				  	$name=$name."-_src"
				  }
				  
				 if (!(defined $self->{'metadatacache'}->{$name})){
					 push (@errorlist, $name);
				 }else{
					 my $mdref=$self->{'metadatacache'}->{$name};
					 $md= $$mdref;
					 my $versiontrue=undef(); 
					foreach my $versiontest (@{$depobject->versions}){
						if ((! defined $versiontrue) and $versiontest->is_compatible( $versiontest, $md->Version)){
							if (! (defined $self->{packagehash}->{$md->{'Name'}."-_src"})){
								$versiontrue=1; 
								push (@{$self->{packagelist}}, \$md); %{$self->packagehash}->{$md->{'Name'}."-_src"}= \$md; 
								if ($verbosity ne "silent"){ 
									print "ADDING $md->{'Name'} to packagelist: deptype is $deptype \n";
								}
								#put it in the hash for deptype, too.  
								%{$self->{$deptype}}->{$md->{'Name'}."-_src"}= \$md; 
								#recurse because we haven't followed this tree yet #print "recursing: \n";
								my @errlist = $self->get_dependencies($md, $instorbuild, $flavor,$linktype,  $verbosity); 
								if (defined  @errlist){
									push (@errorlist, @errlist);
								}
							}else{
								#add it to the deptype too 
								%{$self->{$deptype}}->{$md->{'Name'}."-_src"}= \$md; 
								if (!($verbosity eq "silent")){
									print "ADDING $md->{'Name'} to deptype hash: deptype is $deptype \n";
								}
							}
						}else{ 
							#Version mismatch--dependency failed 
							if (!($verbosity eq "silent")){
								print "Version mismatch--dependency FAILED\n";
								push (@errorlist, $name);
							}
						}
					} #end foreach my $versiontest
				 } #end else
			}
							

			if ($instorbuild eq "install"){ 
				my $depobject=$holder->{$deptype}->{$dep};
				#my $type, my @rest = split (/_/, $dep);
				#my $name = split (/$type._/, $dep);
				my $type=$depobject->{'pkg_type'};
				my $name=$depobject->{'name'};
				if ($head->{'Package_Type'} eq "pgm_static"){
					if ($type eq "pgm"){
						$type = "pgm_static";
						$md=$self->open_installed_metadata($name,$flavor, $type);
						if (!$md){
							$type = "pgm";
							$md=$self->open_installed_metadata($name,$flavor, $type);
						}
					}
				}else{
				$md=$self->open_installed_metadata($name,$flavor, $type);
				}
				if ($md) {
					foreach my $versiontest (@{$depobject->versions}){ 
						if (($versiontest->is_compatible( $versiontest, $$md->Version))){
							 if (! (defined $self->{packagehash}->{$$md->{'Name'}."-".$$md->{'Flavor'}."_".$$md->{'Package_Type'}})){
								push (@{$self->{packagelist}}, $md);
							
            							$self->{packagehash}=>{$$md->{'Name'}."-".$$md->{'Flavor'}."_".$$md->{'Package_Type'}}== $md; 
					
								#recurse
								my @errlist = $self->get_dependencies($$md, $instorbuild, $flavor,$linktype,  $verbosity);
								if (defined  @errlist){
									push (@errorlist, @errlist);
								}
							}
						} else { push (@errorlist, $name."-".$flavor."_".$type);}
					} #end foreach
				} #end if $md 
					 else { push (@errorlist, $name."-".$flavor."_".$type);}
			}else{  #we're building, not installing.
				if ($instorbuild eq "build"){

#Note that the indenting here gets really bad--we're still in the foreach
#  foreach my $deptype (@$deparray){ , and will be until almost the end of
# this function.
#I'm not changing the indentation now, as on standard width terminals this is 
#hard enough to read as it is.

				my $depobject=$holder->{$deptype}->{$dep};
				#chop $dep;
if (!($verbosity eq "silent")){ 				
print "dep is ", $depobject->{'name'},"\n";
}
#print Dumper $depobject;
				 $md= Grid::GPT::V1::Package->new();

#let's intuit the package type if we can, so that it doesn't have to be in the
#metadata.  The subroutine above to do this was shamelessly stolen from the
#SourceDependency module, but is slightly different, so it's here in
#Dependencies

my $dep_pkg_type;
$dep_pkg_type= Grid::GPT::V1::Dependencies->intuit_pkg_type($deptype, $depobject->pkg_type,$linktype);

#Now, let's figure out if we need flavored or non-flavored

my $effectiveflavor;
if ($dep_pkg_type eq 'hdr'){
		$effectiveflavor="noflavor"
}else{
	$effectiveflavor=$flavor;
}

if ($deptype eq 'pgm_link' or $deptype eq 'lib_link'){
	if ($linktype eq 'shared'){
		#		my $checkfilename=$globusdir."/etc/globus_packages/".$depobject->name."/pkg_data_".$effectiveflavor."_rtl.gpt";
		#if (-e $checkfilename){
		my $installed=$self->is_installed($depobject->name, $effectiveflavor, "rtl");
		if ($installed){
			if ($verbosity ne "silent"){
			print $depobject->name."-".$effectiveflavor."_rtl found, so will be able to link\n";
		}
		}else{
  			#Dependency metadata for rtl package file not installed
			#	print "When looking at $deptype dependency, $checkfilename not found \n";
                    print "Dependency metadata file not found--dependency
FAILED\n";
# if (defined $dep){
                    push (@errorlist, $depobject->name."-".$effectiveflavor."_rtl"); 	
		}
	}
}

#my $mdfilename=$globusdir."/etc/globus_packages/".$depobject->name."/pkg_data_".$effectiveflavor."_".$dep_pkg_type.".gpt";

if ($verbosity ne "silent"){ 
	#print "Looking for ", $mdfilename,"\n";
}
			my $mdref=undef();
			if ($linktype eq "static"){
				if ($dep_pkg_type eq "pgm"){
					$dep_pkg_type = "pgm_static"; 
				}
			}
				if ($head->{'Package_Type'} eq "pgm_static"){
					if ($dep_pkg_type eq "pgm"){
						$dep_pkg_type = "pgm_static";
						$mdref=$self->open_installed_metadata($depobject->name,$effectiveflavor, $dep_pkg_type);
						if (!$mdref){
							$dep_pkg_type = "pgm";
							$mdref=$self->open_installed_metadata($depobject->name,$effectiveflavor, $dep_pkg_type);
						}
					}
				}else{
				$mdref=$self->open_installed_metadata($depobject->name, $effectiveflavor, $dep_pkg_type);
				}

			if ($mdref){
				$md=${$mdref};  #get rid of reference
				#}

#Correct the metadata entry in case we've read in a virtual package
#This is a big hack, and pretty clearly shows my objection to virtual packages
#metadata having Package_Type of "virtual"

	if ($md->{'Package_Type'} eq 'virtual'){
		$md->{'Package_Type'}=$dep_pkg_type;
	}
#print "metadata that has been read is:\n";
#print Dumper $md;
#print "depobject->versions is: \n";
#print Dumper @{$depobject->versions};

			my $versiontrue=undef();
			foreach my $versiontest (@{$depobject->versions}){
				if ((! defined $versiontrue) and 
					$versiontest->is_compatible( $versiontest, $md->Version)){

					if (! (defined
$self->{packagehash}->{$md->{'Name'}."-".$md->{'Flavor'}."_".$md->{'Package_Type'}})){
						$versiontrue=1;
						push (@{$self->{packagelist}}, \$md);
					   %{$self->packagehash}->{$md->{'Name'}."-".$md->{'Flavor'}."_".$md->{'Package_Type'}}= \$md;
					   if ($verbosity ne "silent"){
print "ADDING $md->{'Name'} _ $md->{'Package_Type'} to packagelist: deptype is $deptype \n";
					   }

				#put it in the hash for deptype, too.
				%{$self->{$deptype}}->{$md->{'Name'}."_".$md->{'Package_Type'}}= \$md;
	
						#recurse because we haven't followed this tree yet
						#print "recursing: \n";
						my @errlist = $self->get_dependencies($md, $instorbuild, $flavor,$linktype,  $verbosity);
						if (defined  @errlist){
							push (@errorlist, @errlist);
						}

					}else{ #add it to the deptype too
				%{$self->{$deptype}}->{$md->{'Name'}."_".$md->{'Package_Type'}}= \$md;
				if (!($verbosity eq "silent")){ 
print "ADDING $md->{'Name'} _ $md->{'Package_Type'} to deptype hash: deptype is $deptype \n";
				}
					}


				}else{
						#Version mismatch--dependency failed
						if (!($verbosity eq "silent")){ 
						print "Version mismatch--dependency FAILED\n";
						print Dumper $md;
						}

						#	if (defined $dep){
						push (@errorlist, $depobject->name."-".$effectiveflavor."_".$dep_pkg_type);
							 #push (@errorlist, $dep);
						#}
				}
			}#end foreach my $versiontest

				} else {  #the else for if (-e ($mdfilename))
					#Dependency metadata file not installed--dependency failed
					if (!($verbosity eq "silent")){ 
					print "Dependency metadata file not found--dependency FAILED\n";
					}	
					#if (defined $dep){
					push (@errorlist, $depobject->name."-".$effectiveflavor."_".$dep_pkg_type);
					#	push (@errorlist, $dep);
					#}
				}
			}
		} 
	}#end if build
	}else{
			#There were no dependencies for this dependency type
		}
#print Dumper $self;
#print Dumper @errorlist;
 	}
return @errorlist;
}	
	
sub is_installed
{
	  my ($self, $name, $f, $t)=@_;
	  my $globus=$ENV{GLOBUS_LOCATION};
	  my $path="$globus/etc/globus_packages/$name/pkg_data_".$f."_$t.gpt";

	  if (-e $path){
		  return $path;
	  }else{
		  return 0;
	  }
}


sub open_installed_metadata
{
	my ($self, $name, $f, $t)=@_;
	my $md=undef();
	#first we'll see if it's in the cache
	#if (defined %{$self->{'metadatacache'}->{$name."-".$f."_".$t}}){ 
	if (defined %{$self->{'metadatacache'}}->{$name."-".$f."_".$t}){
		$md=%{$self->{'metadatacache'}}->{$name."-".$f."_".$t};
		return $md;
	}else{
		my $g='noflavor';
		if (defined %{$self->{'metadatacache'}}->{$name."-".$g."_".$t}){
			$md=%{$self->{'metadatacache'}}->{$name."-".$g."_".$t};
			return $md;
		}else{

	 	my $metadataname=$self->is_installed($name, $f, $t);
		if ($metadataname){
			 my $pkgobj=Grid::GPT::V1::Package->new(); 
			 $pkgobj->read_metadata_file($metadataname);
			 return \$pkgobj;
		 }else{
			 my $metadataname=undef();
			 #metadata file not found, evidently, so error out
			 #if our flavor is noflavor, we need to try all possible flavors, as any flavor is a match.
			 if ($f eq "noflavor"){
			   my $flavors = new Grid::GPT::V1::BuildFlavors(core => 1);
			   my $isincache = 0;
			   foreach my $flav (@{$flavors->{'flavors'}}){
				if (defined %{$self->{'metadatacache'}}->{$name."-".$flav."_".$t}){
					$md=%{$self->{'metadatacache'}}->{$name."-".$flav."_".$t};
					return $md;
				}else{
			  	 if (!$metadataname){
			  	 	$metadataname=$self->is_installed($name, $flav, $t);
			  	 }
				}
			   }
			   if ($metadataname){
				   my $pkgobj=Grid::GPT::V1::Package->new(); 
				   $pkgobj->read_metadata_file($metadataname); 
				   return \$pkgobj;
			   }
		         } #end if $f eq noflavor
									     

			 #We'll try for a noflavor package first
			 my $metadataname=$self->is_installed($name, 'noflavor', $t);
			 if ($metadataname){ 
				  my $pkgobj=Grid::GPT::V1::Package->new(); 
				  $pkgobj->read_metadata_file($metadataname); 
				  return \$pkgobj;
			 }else{
				return 0;
			}
		}
	}
	}

}


sub get_dependent_fields {
	 my $self=shift;
	 my $field=shift;
	 my @returnlist;
	if (!($self->packagelist)){
	foreach my $item ($self->packagelist) {
		push @returnlist ,$self->packagehash->{$item}->{$field};

	}
	}
	return \@returnlist;
}

		
sub check_setup_dependencies{
	#if (defined $head->Setup_Dependencies){
        my $self=shift;
        my $globusdir = $ENV{'GLOBUS_LOCATION'};
        my %rethash = (
			'setup' => {},
			'not-setup' => {}
		);
			
        foreach my $packagekey (keys %{$self->{'packagehash'}}){
		my $package=$self->{'packagehash'}->{$packagekey};
                if (defined $$package->{'Setup_Dependencies'}){
			for my $setupdep (@{$$package->{'Setup_Dependencies'}}){
				if (-e $globusdir."/etc/globus_packages/setup/".$setupdep->{'name'}) {
				if (defined $rethash{'setup'}){
					#push @{$rethash{'setup'}}, $setupdep->{'name'};
					push @{$rethash{'setup'}->{$setupdep->{'name'}}}, $$package->{'Name'}."_".$$package->{'Package_Type'};
				}
				}else{
				if (defined $rethash{'not-setup'}){
					#push @{$rethash{'not-setup'}}, $setupdep->{'name'};
					 push @{$rethash{'not-setup'}->{$setupdep->{'name'}}}, $$package->{'Name'}."_".$$package->{'Package_Type'};
				}
				       }
	      }
	      }

         }
	return \%rethash;

}

sub AUTOLOAD {
	use vars qw($AUTOLOAD);
    my $self = shift;
    my $type = ref($self) || croak "$self is not an object";
    my $name = $AUTOLOAD;
    $name =~ s/.*://;   # strip fully-qualified portion
    unless (exists $self->{$name} ) {
        croak "Can't access `$name' field in object of class $type";
    } 
    if (@_) {
        return $self->{$name} = shift;
    } else {
        return $self->{$name};
    } 
}




END { }       # module clean-up code here (global destructor)
