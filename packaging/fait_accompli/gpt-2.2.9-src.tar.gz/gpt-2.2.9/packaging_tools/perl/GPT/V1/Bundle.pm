package Grid::GPT::Bundle;

use strict;
use Carp;
use Grid::GPT::Package;
use Grid::GPT::Version;
use Archive::Tar;
use File::Copy;
use File::Basename;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

# your exported package globals go here,
# as well as any optionally exported functions
@EXPORT_OK   = qw($Var1 %Hashit &func3);

use vars qw($Var1 %Hashit);
# non-exported package globals go here
use vars      qw(@more $stuff);

# initialize package globals, first exported ones
$Var1   = '';
%Hashit = ();

# then the others (which are still accessible as $Some::Module::stuff)
$stuff  = '';
@more   = ();

# all file-scoped lexicals must be created before
# the functions below that use them.

# file-private lexicals go here
my $priv_var    = '';
my %secret_hash = ();

# here's a file-private function as a closure,
# callable as &$priv_func.
my $priv_func = sub {
    # stuff goes here.
};

# make all your functions, whether exported or not;
# remember to put something interesting in the {} stubs

my %bundle_struct = (
	packagelist  => [],
	packagehash	=> {},
	description => "",
	filelist => "",
	tarfile => "",
	tmpdir => "",
	bundle => "",
	name => ""
);

sub new {
    my $class  = shift;
	my $file = shift;
    my $self  = {
        %bundle_struct,
    };
    bless $self, $class;
	if ($self->open_bundle($file)){
    	return $self;
	}
} 

sub open_bundle {
	my $self=shift; 
	my $file=shift;

	if (!defined $file){
		return undef;
	}
	$self->is_a_bundle($file);
	my $bundle=Archive::Tar->new();
	$bundle->read($file);
	$self->{name}=$file;
	
	#$self->{description}=$bundle-get_content("bundle_description.gpt");
	#$self->{filelist}=$bundle->get_content("filelist.gpt");
	$self->{tarfile}=$bundle;
	return $self;
}

sub open_package {
	my $self=shift;
	my $file=shift;

	my $bundle=Archive::Tar->new();
    $bundle->read($file);
}

sub unbundle_packages {
	my $self=shift;		
#	my $file=shift;
	my $tmpdir=shift;


	my $time=time();
	my $tmpd=$tmpdir."/"."gpt_bundle-"."$$"."-".$time;
	$self->{tmpdir}=$tmpd;
	if (!(-e "$tmpd")){
	print "Making $tmpd \n";
	   mkdir("$tmpd",0700) || die "cannot mkdir $tmpd: $!";
	}

	if ($self->is_a_bundle){
		my $tar = $self->{tarfile};
		my @tarfiles=$tar->list_files();
		my %tarhash;
		foreach my $try (@tarfiles){
			$tarhash{$try}=$tar->get_content($try);
		}

		foreach my $package (keys %tarhash){
			#print "$package: \n";
			my $name=$tmpd."/".$package;
			my $tart= Archive::Tar->new();
			open FOO, ">".$name;
			print FOO $tarhash{$package};
			close FOO;
		#	chomp $name;
	#		if((basename($name) eq "packagelist") or (basename($name) eq "bundle.gpt")){
#				print "We found $name which is bundle.gpt or packagelist\n";
#			}else{
#				push @{$self->{packagelist}}, $name;
#			}
			
		}
		@{$self->{packagelist}}=split(/\n/,$tarhash{"packagelist"});
	}else{
	#We have a simple package, not a bundle, so just copy it to the tmpdir
		#print "$self->{name} \n";
		copy($self->{name}, $tmpd."/".basename($self->{name}))
    or die "copy failed: $!";	
		push @{$self->{packagelist}}, basename($self->{name});
		#print Dumper @{$self->{packagelist}};
		
	}
	  


}	
	
sub tmpdir_cleanup{
	my $self =shift;
	my $tar = $self->{tarfile};
	my $tmpdir = $self->{tmpdir};
	if ($self->is_a_bundle()){
	#print "$self->{name} is supposedly a bundle\n";
    		my @tarfiles=$tar->list_files();
	
		foreach my $file (@tarfiles){
			my $name=$tmpdir."/".$file;
			unlink($name) or warn "couldn't unlink $name: $!";
		}
	}else{
	#	print "We're just a package\n";
		my $unlinkname="$tmpdir"."/".basename($self->{name});
		unlink("$unlinkname") or warn "couldn't unlink $tar: $!";
	}	
	rmdir ($tmpdir) or warn "couldn't remove $tmpdir/$$: $!"; 
}
		
		

sub is_a_bundle {
	my $self=shift;
	my $file=shift;
	my $bundle=undef();
	if (defined $self->{bundle}){
		if ($self->{bundle} eq '1'){
			return 1;
		}else{
#			return undef;
		}
	}
	if (defined $file){
	 $bundle=Archive::Tar->new();
	$bundle->read($file);
	}else{
	 $bundle= $self->{tarfile};
	}
#print Dumper $bundle;
    my @tarfiles=$bundle->list_files();
    foreach my $try (@tarfiles){
#print "$try \n";
	#Just look for a file named packagelist
        if ($try =~ /packagelist/){
		{
			$self->{bundle}=1;
			return 1;
		}
            }    
	}
	$self->{bundle}=0;
	return undef;
}

sub AUTOLOAD {
	use vars qw($AUTOLOAD);
    my $self = shift;
    my $type = ref($self) || croak "$self is not an object";
    my $name = $AUTOLOAD;
    $name =~ s/.*://;   # strip fully-qualified portion
    unless (exists $self->{$name} ) {
        croak "Can't access `$name' field in object of class $type";
    } 
    if (@_) {
        return $self->{$name} = shift;
    } else {
        return $self->{$name};
    } 
}




END { }       # module clean-up code here (global destructor)
