package Grid::GPT::Comp::GPTSourceDependency;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS %binary_dependencies);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Definitions;
require Grid::GPT::V1::BaseDependency;
require Grid::GPT::Comp::BuildType;
require Grid::GPT::Comp::RuntimeType; 
require Grid::GPT::Comp::SetupType; 
use Grid::GPT::DepNode;
use Grid::GPT::DepIndexes;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG      = 0;

@ISA         = qw(Exporter Grid::GPT::V1::BaseDependency);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

# your exported package globals go here,
# as well as any optionally exported functions
@EXPORT_OK   = qw($Var1 %Hashit &func3);

use vars qw($Var1 %Hashit);
# non-exported package globals go here
use vars      qw(@more $stuff);

# initialize package globals, first exported ones
my %src2bin_dependencies =  (
   'compile' => {
                 pgm=> undef,
                 pgm_static=> undef,
                 dev=> 'Compile',
                 data=> undef,
                 doc=> undef,
                 rtl=> undef
                },
   'pgm_link' => {
                  pgm=> 'Runtime_Link',
                  pgm_static=> 'Regeneration',
                  dev=> undef,
                  data=> undef,
                  doc=> undef,
                  rtl=> undef
                 },
   'lib_link' => {
                  pgm=> undef,
                  pgm_static=> undef,
                  dev=> 'Build_Link',
                  data=> undef,
                  doc=> undef,
                  rtl=> 'Runtime_Link'
                 },
   'data_runtime' => {
                      pgm=> undef,
                      pgm_static=> undef,
                      dev=> undef,
                      data=> 'Runtime',
                      doc=> undef,
                      rtl=> undef
                     },
   'doc_runtime' => {
                     pgm=> undef,
                     pgm_static=> undef,
                     dev=> undef,
                     data=> undef,
                     doc=> 'Runtime',
                     rtl=> undef
                    },
   'lib_runtime' => {
                     pgm=> undef,
                     pgm_static=> undef,
                     dev=> undef,
                     data=> undef,
                     doc=> undef,
                     rtl=> 'Runtime'
                    },
   'pgm_runtime' => {
                     pgm=> 'Runtime',
                     pgm_static=> 'Runtime',
                     dev=> undef,
                     data=> undef,
                     doc=> undef,
                     rtl=> undef
                    },

  );


sub new {
    my ($that, $obj)  = @_;
    my $class = ref($that) || $that;

    my $self  = { };
    bless $self, $class;

if( $_DEBUG > 0 )
{
  print "GPTSourceDependencies:\n";
}

    if (defined($obj))
    {
if( $_DEBUG > 1 )
{
print Dumper $obj;
}
      foreach my $tag (@{$obj->{'contents'}})
      {
        next if ref($tag) ne 'HASH';
        my $itemName = $tag->{'name'};

        if( $itemName eq 'BuildType' )
        {
          $self->{'BuildType'} = new Grid::GPT::Comp::BuildType( $tag );
if( $_DEBUG > 0 )
{
  print "  BuildType: ";
  print Dumper $self->{'BuildType'}, "\n";
}
        }
        elsif( $itemName eq 'RuntimeType' )
        {
          $self->{'RuntimeType'} = new Grid::GPT::Comp::RuntimeType( $tag );
if( $_DEBUG > 0 )
{
  print "  RuntimeType: ";
  print Dumper $self->{'RuntimeType'}, "\n";
}
        }
        elsif( $itemName eq 'SetupType' )
        {
          $self->{'SetupType'} = new Grid::GPT::Comp::SetupType( $tag );
if( $_DEBUG > 0 )
{
  print "  SetupType: ";
  print Dumper $self->{'SetupType'}, "\n";
}
        }
      }
    }
if( $_DEBUG > 0 )
{
  print Dumper $self;
}
    return $self;
}

sub write_tag
{
  my ($self, $xml) = @_;

  $xml->startTag('SourceDependencies');
  $xml->characters("\n");

  $self->{'BuildType'}->write_tag($xml)
    if defined $self->{'BuildType'};

  $self->{'RuntimeType'}->write_tag($xml)
    if defined $self->{'RuntimeType'};

  $self->{'SetupType'}->write_tag($xml)
    if defined $self->{'SetupType'};

  $xml->endTag('SourceDependencies');
  $xml->characters("\n");

  return;
}

sub getSrcDepType
{
  my $self = shift;
  my @list = keys(%{$self});

  return $list[0]; 
}

sub getDependencyType
{
  my $self = shift;

print "Calling: ", $self->getSrcDepType, "\n";

  return( $self->{$self->getSrcDepType}->getDepType );
}














sub fulfills_dependency {
  my ($self, $name, $version, $pkg_type) = @_;




  return undef if $name ne $self->{'name'};

  if ($self->{'pkg_type'} eq 'pgm' or $self->{'pkg_type'} eq 'pgm_static') {
    return undef if $pkg_type ne 'pgm' and $pkg_type ne 'pgm_static';
  } else {
    return undef if $pkg_type ne $self->{'pkg_type'};
  }

  for my $v (@{$self->{'versions'}}) {
    my $result = $version->is_compatible($v);
    return $v if $result;
  }
  return undef;
}

sub validate {
  my ($self) = @_;

  die "ERROR: Dependency needs a name\n" if ! defined $self->{'name'};
  die "ERROR: Dependency $self->{'name'} needs to know its package type\n" 
    if ! defined $self->{'my_pkg_type'};

  die "ERROR: Dependency $self->{'name'} needs to have at least one version\n" 
    if @{$self->{'versions'}} == 0;

  my $deps_supported = 0;
  for my $d (@{$binary_dependencies{$self->{'my_pkg_type'}}}) {
    if ($d eq $self->{'type'}) {
      $deps_supported++;
      last;
    }
  }
  die "ERROR: Dependency $self->{'name'} of type $self->{'pkg_type'} does not support dependency type $self->{'type'}\n" if ! $deps_supported;
  
}

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}
sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
