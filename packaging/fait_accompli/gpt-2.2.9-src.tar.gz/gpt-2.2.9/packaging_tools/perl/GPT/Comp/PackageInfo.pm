package Grid::GPT::Comp::PackageInfo;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Definitions;
use Grid::GPT::Comp::ContactInfo;
use Grid::GPT::Comp::PackageDocs;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG   = 0;

@ISA         = qw(Exporter);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],


sub new {
    my ($that, $obj)  = @_;
    my $class = ref($that) || $that;

    
    my $self  = { };
    bless $self, $class;

    if (defined($obj)) 
    {
      foreach my $tag (@{$obj->{'contents'}})
      {
        next if ref($tag) ne 'HASH';
 
        my $itemName = $tag->{'name'};
        if( $itemName eq 'Description' )
        {
          $self->{'Description'} = $tag->{'contents'}->[0];
        }
        elsif( $itemName eq 'ContactInfo' )
        {
          push @{$self->{'ContactInfo'}},(new Grid::GPT::Comp::ContactInfo($tag));
        }
        elsif( $itemName eq 'PackageDocs' )
        {
          push @{$self->{'PackageDocs'}},(new Grid::GPT::Comp::PackageDocs($tag));
        }
      }
    }
    return $self;
}

sub write_tag {
  my ($self, $xml) = @_;

  $xml->startTag( 'PackageInfo' );
  $xml->characters("\n");
  $xml->dataElement('Description', $self->{'Description'});
  $xml->characters("\n");

##  $self->{'ContactInfo'}->write_tag($xml);
  foreach my $obj ( @{$self->{'ContactInfo'}} )
  {
    $obj->write_tag( $xml );
  }

##  $self->{'PackageDocs'}->write_tag($xml);
  foreach my $obj ( @{$self->{'PackageDocs'}} )
  {
    $obj->write_tag( $xml );
  }


  $xml->endTag( 'PackageInfo' );
  $xml->characters("\n");
  return;
}

sub getContactName
{
  my $self = shift;
  my $names;

  foreach my $obj ( @{$self->{'ContactInfo'}} )
  {
    push( @{$names}, $obj->getContactName() );
  }

  return( $names );
}

sub getContactEmail
{
  my $self = shift;
  my $email;

  foreach my $obj ( @{$self->{'ContactInfo'}} )
  {
    push( @{$email}, $obj->getContactEmail() );
  }

  return( $email );
}

sub getDocsDesc
{
  my $self = shift;
  my $desc;

  foreach my $obj ( @{$self->{'PackageDocs'}} )
  {
    push( @{$desc}, $obj->getPackageDocsDesc() );
  }

  return( $desc );
}

sub getDocsURL
{
  my $self = shift;
  my $url;

  foreach my $obj ( @{$self->{'PackageDocs'}} )
  {
    push( @{$url}, $obj->getPackageDocsURL() );
  }

  return( $url );
}














	

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
