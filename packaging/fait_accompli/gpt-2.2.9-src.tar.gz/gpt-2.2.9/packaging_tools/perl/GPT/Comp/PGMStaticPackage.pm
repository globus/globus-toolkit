package Grid::GPT::Comp::PGMStaticPackage;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Comp::GPTBuildFlavors;
use Grid::GPT::PackageFactory;
use Grid::GPT::Comp::FeatureSetID;
use Grid::GPT::Comp::PackageInfo;
use Grid::GPT::Comp::PackageReleaseInfo;
use Grid::GPT::Comp::Src2BinDependency;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG      = 0;

my %src2bin_dependencies =  (
   'pgm_link'    => ['Regeneration','BinaryRuntime','rtl'],
   'pgm_runtime' => ['Runtime','BinaryRuntime','rtl'],
   'pgm_setup'   => ['Setup','BinaryRuntime','rtl'],
  );


sub new 
{ 
    my ($that, %args)  = @_;
    my $class = ref($that) || $that;
    my $self  = {};
    bless $self, $class;
    return $self;
}

sub read
{
  my $self = shift;
  my $package = shift;

#  print Dumper $xml;
if( $_DEBUG > 0 )
{
  print "PGMStaticPackage:\n";
}

  $self->{'PackageType'} = 'PGMStaticPackage';

  for my $sc (@{$package->{'contents'}}) {
    next if ref($sc) ne 'HASH';

if( $_DEBUG > 0 )
{
  print "\tPackage Next: ", $sc->{'name'}, "\n";
}

        if ($sc->{'name'} eq 'PostInstallMessage') {
          $self->{'PostInstallMessage'} = $sc->{'contents'}->[0];
if( $_DEBUG > 0 )
{
  print "\t\tPostInstallMessage: ", $sc->{'contents'}->[0], "\n";
}
          next;
        }

        if ($sc->{'name'} eq 'PostInstallProgram') {
          $self->{'PostInstallProgram'} = $sc->{'contents'}->[0];
if( $_DEBUG > 0 )
{
  print "\t\tPostInstallProgram: ", $sc->{'contents'}->[0], "\n";
}
          next;
        }

	if ($sc->{'name'} eq 'Flavor') {
	    # Flavor has its value in the content array 
	    # which has 1 element
	  $self->{'Flavor'} = $sc->{'contents'}->[0];
if( $_DEBUG > 0 )
{
  print "\t\t  Flavor: ", $self->{'Flavor'}, "\n";
} 
	  next;
	}

	# Pass any BinaryDependency XML to BinaryDependencies.pm
	if ($sc->{'name'} eq 'BinaryDependencies') {
if( $_DEBUG > 0 )
{
  print "\t\t  BinaryDependencies:\n";
}
          push @{$self->{'BinaryDependencies'}}, (new Grid::GPT::Comp::GPTBinaryDependency( $sc ));
	  next;
	}
  }
  return $self;
}

sub write_tag
{
  my ($self, $xml) = @_;

  $xml->startTag('PGMStaticPackage');
  $xml->characters("\n");

  $xml->dataElement( 'Flavor', $self->{'Flavor'} );
  $xml->characters("\n");

  foreach my $obj (@{$self->{'BinaryDependencies'}})
  {
    $obj->write_tag($xml);
  }

  $xml->dataElement( 'PostInstallMessage', $self->{'PostInstallMessage'} );
  $xml->characters("\n");

  $xml->dataElement( 'PostInstallProgram', $self->{'PostInstallProgram'} );
  $xml->characters("\n");

  $xml->endTag('PGMStaticPackage');
  $xml->characters("\n");

  return;
}

sub convert_data
{
  #takes pkg_type and flavor as its arguments
  #returns reference to new (converted) metadata
  my $self     = shift;
  my $obj      = shift;
  my ($flavor) = @_;
  my $converted;
  my $class = ref($self) || $self;
  $converted = {};

  bless $converted, $class;

##print "PGMStaticPackage::convert_data\n";

  $converted->{'PackageType'}        = 'PGMStaticPackage';
  $converted->{'Flavor'}             = $flavor;
  $converted->{'PostInstallMessage'} = $obj->{'PostInstallMessage'};
  $converted->{'PostInstallProgram'} = $obj->{'PostInstallProgram'};

  my $converter=new Grid::GPT::Comp::Src2BinDependency;

  $converter->convertSrc2Bin( 'PGMStaticPackage',
                              $flavor,
                              $obj->{'SourceDependencies'},
                              $converted,
                              %src2bin_dependencies );

  return $converted;
}
























sub add_setup_dep
  {
    my ($self, $setup, $pkgtype) = @_;
    my $name = $setup->{'attributes'}->{'Name'};
    my $versions;
    for my $v(@{$setup->{'contents'}}) {
      next if ref $v ne 'HASH';
      $versions = Grid::GPT::Version::create_version_list($v);
    }
    my $obj = { name => $name, type => $pkgtype, versions => $versions};
    my $setuptype = 'SourceSetupDependencies';
    $setuptype = 'SetupDependencies' if ! defined $pkgtype;
    if (!defined ($self->{$setuptype})) {
      $self->{$setuptype} = [];
    }
    push @{$self->{$setuptype}}, $obj;
  }

sub convert_metadata {		
  #takes pkg_type and flavor as its arguments
  #returns reference to new (converted) metadata
	my $self=shift;
	my ($pkg_type, $flavor) = @_;
	my $converted=new Grid::GPT::Package;

	for my $n ('Name', 'Version', 'FormatVersion', 'doctype', 'system', 
                   'Description', 'VersionStability', 'FunctionalGroup') {
	  $converted->{$n} = $self->{$n};
	}

	$converted->{'Package_Type'} = $pkg_type;
	if (! defined $Grid::GPT::Definitions::noflavor_pkg_types{$pkg_type}) {
		$converted->{'Flavor'} = $flavor 
	}else{
		$converted->{'Flavor'} = "noflavor";
	}


        for my $n ('PostInstallMessage', 'PostInstallProgram', 
                   'SetupName') {
          $converted->{$n} = $self->{$n};
        }
        $converted->{'Setup_Version'} = $self->{'SetupVersion'}->clone() 
          if defined $self->{'SetupVersion'};
        
        $converted->{'BinaryDependencies'} = 
          Grid::GPT::SourceDependency::get_bindeps_from($self->{'SourceDependencies'}, $pkg_type);

        for my $setup (@{$self->{'SourceSetupDependencies'}}) {
          if ($pkg_type eq $setup->{'type'}) {
            $converted->{'SetupDependencies'} = [] 
              if ! defined $converted->{'SetupDependencies'};
            my $bsetup = replicate($setup);
            $bsetup->{'type'} = undef;
            push @{$converted->{'SetupDependencies'}}, $bsetup;
          }
        }

	if ($pkg_type eq 'dev') {
	  for my $n ('cflags' , 'ExternalIncludes', 'PackageLibs', 'Externallibs') {

	    $converted->{$n} = $self->{$n};
	    if ($n eq 'pkg_libs') {
	      $converted->{$n} =~ s!(-l\w+)\s+!$ {1}_$flavor !g;
	      $converted->{$n} =~ s!(-l\w+)$!$ {1}_$flavor!;
	    }
	  }
	}

return $converted
}

sub clone {
    my $self = shift;
    my $clone = new();
    replicate($self, $clone);
    return $clone;
}

sub replicate {
  my ($rold) = @_;
  if (ref(\$rold) eq 'SCALAR') {
    return $rold;
  } elsif (ref($rold) eq 'ARRAY') {
    my @list = @$rold;
    return \@list;
  } elsif (ref($rold) eq 'HASH') {
    my $rnew = {};
    for my $e (sort keys %$rold) {
      $rnew->{$e} = replicate($rold->{$e});
    }
    return $rnew
  }
}

sub output_metadata_file {
  my $self=shift;
  my ($filename)=@_;
  my $writer = new Grid::GPT::XML($filename);
  
  $writer->doctype("gpt_package_metadata","globus_package.dtd");
  $writer->startTag("gpt_package_metadata", Name => $self->{'Name'},
		    Format_Version => $self->{'Format_Version'});
  $writer->characters("\n");
  
  $self->{'Version'}->write_tag($writer);
  $writer->dataElement('Description', $self->{'Description'});
  $writer->characters("\n");
  $writer->dataElement('Functional_Group', $self->{'FunctionalGroup'});
  $writer->characters("\n");
  $writer->emptyTag("Version_Stability", Release=> $self->{'VersionStability'});
  $writer->characters("\n");
 
  $writer->startTag("$self->{'PackageType'}_pkg");

  $writer->characters("\n");
  
  # Write With_Flavors data
  if (defined $self->{'WithFlavors'}) {
    $writer->emptyTag("WithFlavors", build=> $self->{'WithFlavors'});
  $writer->characters("\n");
  }
  
  # Write out Flavor
  if (defined $self->{'Flavor'}) {
    $writer->dataElement('Flavor', $self->{'Flavor'});
    $writer->characters("\n");
  }
  # Write out Version_Label
  if (defined $self->{'VersionLabel'}) {
    $writer->dataElement('VersionLabel', $self->{'VersionLabel'});
    $writer->characters("\n");
  }
  # Write Dependency Data
  if (defined($self->{'SourceDependencies'})) {
    Grid::GPT::BaseDependency::get_xml_from($self->{'SourceDependencies'}, 
                                            $writer,
                                            'SourceDependencies')
  }
  
  if (defined($self->{'Binary_Dependencies'})) {
    Grid::GPT::BaseDependency::get_xml_from($self->{'BinaryDependencies'}, 
                                            $writer,
                                            'BinaryDependencies')
    }
  if (defined($self->{'SourceSetupDependencies'})) {
    for my $t (@{$self->{'SourceSetupDependencies'}}) {
      write_setup_deps->($writer, $t);
    }
  }
  if (defined($self->{'SetupDependencies'})) {
    for my $t (@{$self->{'SetupDependencies'}}) {
      write_setup_deps->($writer, $t);
    }
  }
  

  #Write out Build Enviromnment
  if ($self->{'PackageType'} eq 'src' or $self->{'PackageType'} eq 'dev' ) {
    $writer->startTag("BuildEnvironment");
    $writer->characters("\n");
    for my $n ('cflags' , 'ExternalIncludes', 'PackageLibs', 'ExternalLibs') {
      $writer->dataElement($n, $self->{$n});
      $writer->characters("\n");
    }
    $writer->endTag("BuildEnvironment");
    $writer->characters("\n");
  }

  #Write out Build Instructions
  if ($self->{'PackageType'} eq 'src' and 
      defined $self->{'BuildInstructions'}) {
    $writer->startTag("BuildInstructions");
    $writer->characters("\n");
    for my $s (@{$self->{'BuildInstructions'}}) {
      my %args;
      $args{'Macro_Args'} = $s->{'args'}
        if defined $s->{'args'};
     $writer->dataElement('BuildStep', $s->{'command'},%args);
      $writer->characters("\n");
    }
    $self->{'BuildFlavorChoices'}->write_xml_choices($writer) 
      if defined $self->{'BuildFlavorChoices'};
    $writer->endTag("BuildInstructions");
    $writer->characters("\n");
  }

  if (defined $self->{'PostInstallMessage'}) {
    $writer->dataElement('PostInstallMessage', 
                         $self->{'PostInstallMessage'});
    $writer->characters("\n");
  }

  if (defined $self->{'PostInstallProgram'}) {
    $writer->dataElement('PostInstallProgram', 
                         $self->{'PostInstallProgram'});
    $writer->characters("\n");
  }

  # Write out setup package fields
  

  if (defined $self->{'SetupName'}) {

    $writer->startTag('Setup', Name => $self->{'SetupName'});
    $writer->characters("\n");
    $self->{'SetupVersion'}->write_tag($writer);
    $writer->endTag('Setup');    
    $writer->characters("\n");
  }


  $writer->endTag("$self->{'PackageType'}_pkg");
  $writer->characters("\n");
  $writer->endTag('GPTPackageMetadata');
  $writer->write($filename);
}

sub write_setup_deps
  {
    my ($writer, $setup) = @_;
    my ($name, $pkgtype, $versions) = 
      ( $setup->{'name'}, $setup->{'type'}, $setup->{'versions'});
    $writer->startTag("SourceSetupDependency", PkgType => $pkgtype) 
      if defined $pkgtype;
    $writer->characters("\n");
    $writer->startTag("SetupDependency", Name => $name);
    $writer->characters("\n");
    Grid::GPT::Version::convert_version_list2xml($versions, $writer);
    $writer->endTag("SetupDependency");
    $writer->characters("\n");
    $writer->endTag("SourceSetupDependency") if defined $pkgtype;
    $writer->characters("\n");
  }

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
