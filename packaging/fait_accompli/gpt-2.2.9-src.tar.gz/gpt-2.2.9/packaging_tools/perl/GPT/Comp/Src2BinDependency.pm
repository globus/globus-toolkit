package Grid::GPT::Comp::Src2BinDependency;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Comp::GPTBuildFlavors;
use Grid::GPT::PackageFactory;
use Grid::GPT::Comp::FeatureSetID;
use Grid::GPT::Comp::PackageInfo;
use Grid::GPT::Comp::PackageReleaseInfo;
use Grid::GPT::Comp::SourcePackage;
use Grid::GPT::Comp::DataPackage;
use Grid::GPT::Comp::DevPackage;
use Grid::GPT::Comp::DocPackage;
use Grid::GPT::Comp::HeaderPackage;
use Grid::GPT::Comp::PGMPackage;
use Grid::GPT::Comp::PGMStaticPackage;
use Grid::GPT::Comp::RTLPackage;
use Grid::GPT::Comp::SetupPackage;
use Grid::GPT::Comp::TestPackage;


# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG      = 0;

my %src2bin_dependencies =  (
   'compile' => {
                 ''=> 'Compile'
                },
   'pgm_link' => {
                  ''=> 'Build_Link'
                 },
   'lib_link' => {
                  ''=> 'Build_Link'
                 },
   'data_runtime' => {
                      pgm=> 'Runtime',
                      pgm_static=> undef,
                      dev=> undef,
                      data=> 'Runtime',
                      doc=> undef,
                      rtl=> undef
                     },
   'doc_runtime' => {
                     pgm=> undef,
                     pgm_static=> undef,
                     dev=> undef,
                     data=> undef,
                     doc=> 'Runtime',
                     rtl=> undef
                    },
   'lib_runtime' => {
                     pgm=> undef,
                     pgm_static=> undef,
                     dev=> undef,
                     data=> undef,
                     doc=> undef,
                     rtl=> 'Runtime'
                    },
   'pgm_runtime' => {
                     pgm=> 'Runtime',
                     pgm_static=> 'Runtime',
                     dev=> undef,
                     data=> undef,
                     doc=> undef,
                     rtl=> undef
                    },
   'data_setup' => {
                     pgm=> 'Setup',
                     pgm_static=> 'Setup',
                     dev=> 'Setup',
                     data=> 'Setup',
                     doc=> 'Setup',
                     rtl=> 'Setup'
                    },
   'doc_setup' => {
                     pgm=> 'Setup',
                     pgm_static=> 'Setup',
                     dev=> 'Setup',
                     data=> 'Setup',
                     doc=> 'Setup',
                     rtl=> 'Setup'
                    },
   'pgm_setup' => {
                     pgm=> 'Setup',
                     pgm_static=> 'Setup',
                     dev=> 'Setup',
                     data=> 'Setup',
                     doc=> 'Setup',
                     rtl=> 'Setup'
                    },
   'lib_setup' => {
                     pgm=> 'Setup',
                     pgm_static=> 'Setup',
                     dev=> 'Setup',
                     data=> 'Setup',
                     doc=> 'Setup',
                     rtl=> 'Setup'
                    },

  );


sub new { 
    my ($that, %args)  = @_;
    my $class = ref($that) || $that;
    my $self  = {};
    my $f;
    for  $f (sort keys %args) { 
      $self->{$f} = $args{$f};
    } 
    bless $self, $class;
    return $self;
}

sub convertSrc2Bin
{
  my $self   = shift;
  my $type   = shift;
  my $flavor = shift;
  my $src    = shift;
  my $result = shift;
  my %map    = @_;

##print "Src2BinDependency::convertSrc2Bin\n";

  my $numOfRuntimeDeps = 0;
  my $numOfBuildDeps   = 0;
  my $binDep;

  foreach my $obj (@{$src})
  {

    my $srcDepType = $obj->getSrcDepType;
    my $oldType = $obj->{$srcDepType}->getDepType;

    if( defined $map{$oldType} )
    {
      my ($type,$objType,$pkgType) = @{$map{$oldType}};

      if( $objType eq 'BinaryBuild' )
      {
        my $oldType = $obj->{$srcDepType}->getDepType;
        my $oldDeps = $obj->{$srcDepType}->getDependency;
        my $lastType = undef;

  push @{$result->{'BinaryDependencies'}}, (new Grid::GPT::Comp::GPTBinaryDependency);

        foreach my $deps (@{$oldDeps})
        {
          if( !defined $lastType )
          {
            ## First time in.  Create new BinaryBuild object and begin to 
            ## attach dependencies.

            $lastType = $type;
            $result->{'BinaryDependencies'}[$numOfBuildDeps]->{'BinaryBuild'} =
               new Grid::GPT::Comp::BinaryBuild( type => $type, dependency => $deps );
          }
          elsif( $type eq $lastType )
          {
            ## Same type of dependency as the last one, so it gets put into
            ## the same array.

            push @{$result->{'BinaryDependencies'}[$numOfBuildDeps]->{'BinaryBuild'}->{'Dependency'}}, $deps;
          }
          elsif( $type ne $lastType )
          {
            ## New type of dependency.  Create a new BinaryDependency object and
            ## a new BinaryBuild object and attach dependency.

            $lastType = $type;

            push @{$result->{'BinaryDependencies'}}, 
                     new Grid::GPT::Comp::GPTBinaryDependency;

            $numOfBuildDeps++;

            $result->{'BinaryDependencies'}[$numOfBuildDeps]->{'BinaryBuild'} =
            new Grid::GPT::Comp::BinaryBuild( type => $type );
            push @{$result->{'BinaryDependencies'}[$numOfBuildDeps]->{'BinaryBuild'}->{'Dependency'}}, $deps;
          }
        }
        $numOfBuildDeps++;
      }
      elsif( $objType eq 'BinaryRuntime' ) 
      {
        my $oldType  = $obj->{$srcDepType}->getDepType;
        my $oldDeps  = $obj->{$srcDepType}->getDependency;
        my $lastType = undef;

  push @{$result->{'BinaryDependencies'}}, (new Grid::GPT::Comp::GPTBinaryDependency);

        foreach my $deps (@{$oldDeps})
        {
          if( $srcDepType eq 'BuildType' )
          {

            my $newDeps = new Grid::GPT::Comp::Dependency;
            $newDeps->setPackageType( $pkgType );
            $newDeps->setAllowed( $deps->getAllowed );
            $newDeps->setName( $deps->getName );
            $newDeps->setCompatibilityRequirement( $deps->getCompatibilityRequirement );
            $deps = $newDeps;
          }

          if( !defined $lastType )
          {
            ## First time in.  Create new BinaryBuild object and begin to 
            ## attach dependencies.

            $lastType = $type;
            $result->{'BinaryDependencies'}[$numOfRuntimeDeps]->{'BinaryRuntime'} = new Grid::GPT::Comp::BinaryRuntime( type => $type, dependency => $deps );
          }
          elsif( $type eq $lastType )
          {
            ## Same type of dependency as the last one, so it gets put into
            ## the same array.

            push @{$result->{'BinaryDependencies'}[$numOfRuntimeDeps]->{'BinaryRuntime'}->{'Dependency'}}, $deps;
          }
          elsif( $type ne $lastType )
          {
            ## New type of dependency.  Create a new BinaryDependency object and
            ## a new BinaryBuild object and attach dependency.

            $lastType = $type;

            push @{$result->{'BinaryDependencies'}}, 
                new Grid::GPT::Comp::GPTBinaryDependency;

            $numOfRuntimeDeps++;

            $result->{'BinaryDependencies'}[$numOfRuntimeDeps]->{'BinaryRuntime'} = new Grid::GPT::Comp::BinaryRuntime( type => $type );
            push @{$result->{'BinaryDependencies'}[$numOfRuntimeDeps]->{'BinaryRuntime'}->{'Dependency'}}, $deps;
          }  
        }
        $numOfRuntimeDeps++;
      }
    }
  }
  return $result;
}













sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
