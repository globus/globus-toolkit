package Grid::GPT::Comp::PackageDocs;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Definitions;
use Grid::GPT::Comp::ContactInfo;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG   = 0;

@ISA         = qw(Exporter);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

sub new {
    my ($that, $obj)  = @_;
    my $class = ref($that) || $that;
    
    my $self  = { };
    bless $self, $class;

    if (defined($obj)) 
    {
      $self->{'description'}  = $obj->{'attributes'}->{'PackageDocsDesc'};
      $self->{'url'}          = $obj->{'attributes'}->{'PackageDocsURL'};
    }

    return $self;
}

sub write_tag {
  my ($self, $xml) = @_;

  $xml->emptyTag( 'PackageDocs',
                  PackageDocsDesc  => $self->{'description'},
                  PackageDocsURL   => $self->{'url'} );
  $xml->characters("\n");

  return;
}

sub getPackageDocsDesc
{
  my $self = shift;
  return( $self->{'description'} );
}

sub getPackageDocsURL
{
  my $self = shift;
  return( $self->{'url'} );
}

1;
__END__

















	
sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

