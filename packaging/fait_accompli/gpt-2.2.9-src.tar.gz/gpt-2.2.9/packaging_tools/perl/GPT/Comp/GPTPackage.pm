package Grid::GPT::Comp::GPTPackage;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Comp::GPTBuildFlavors;
use Grid::GPT::PackageFactory;
use Grid::GPT::Comp::FeatureSetID;
use Grid::GPT::Comp::PackageInfo;
use Grid::GPT::Comp::PackageReleaseInfo;
use Grid::GPT::Comp::SourcePackage;
use Grid::GPT::Comp::DataPackage;
use Grid::GPT::Comp::DevPackage;
use Grid::GPT::Comp::DocPackage;
use Grid::GPT::Comp::HeaderPackage;
use Grid::GPT::Comp::PGMPackage;
use Grid::GPT::Comp::PGMStaticPackage;
use Grid::GPT::Comp::RTLPackage;
use Grid::GPT::Comp::SetupPackage;
use Grid::GPT::Comp::TestPackage;
use Grid::GPT::Comp::Src2BinDependency;
use Grid::GPT::Definitions;


# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG      = 0;


sub new { 
    my ($that, %args)  = @_;
    my $class = ref($that) || $that;
    my $self  = {};
    my $f;
    for  $f (sort keys %args) { 
      $self->{$f} = $args{$f};
    } 
    bless $self, $class;

if((defined $args{installed_pkg})&&
   (defined $args{flavor})&&
   (defined $args{type}))
{ 
  $self->path_namer($args{installed_pkg}, $args{flavor}, $args{type});
} 
else
{  
  if((!(defined $args{installed_pkg}))&&
     (!(defined $args{flavor}))&&
     (!(defined $args{type})))
  { 
    return $self;
  }  
  else
  { 
    die "ERROR: Please specify name flavor and type: $!\n";
  } 
} 
return $self;
}

sub path_namer
{
  my ($self, $name, $f, $t)=@_;
  my $globus=$ENV{GLOBUS_LOCATION};
  my $path="$globus/etc/globus_packages/$name/pkg_data_".$f."_$t.gpt";
 
  $self->read_metadata_file($path);
}
 	

sub read
{
  my $self     = shift;
  my $filename = shift;

  my $xml = new Grid::GPT::XML;

  $xml->read($filename);

  my $root = $xml->{'roottag'};
  $self->{'Name'} = $root->{'attributes'}->{'Name'};
  $self->{'FormatVersion'} = $root->{'attributes'}->{'FormatVersion'};

# Check to see if we can understand this format

  $self->{'doctype'} = $xml->{'doctype'};
  $self->{'system'} = $xml->{'system'};

#  print Dumper $xml;


  for my $c (@{$root->{'contents'}}) {
    next if ref($c) ne 'HASH';

if( $_DEBUG > 0 )
{
print "Next: ", $c->{'name'}, "\n";
}
    if ($c->{'name'} eq 'FeatureSetIdentity') {
      ##$self->{'FeatureSetID'} = new Grid::GPT::Comp::FeatureSetID($c);
      push @{$self->{'FeatureSetID'}}, (new Grid::GPT::Comp::FeatureSetID($c));
      next;
    }

    if ($c->{'name'} eq 'PackageInfo') 
    {
if( $_DEBUG > 0 )
{
  print "PackageInfo:\n";
}
      $self->{'PackageInfo'} = new Grid::GPT::Comp::PackageInfo($c);
      next;
    }

    if( $c->{'name'} eq 'PackageReleaseInfo' )
    {
if( $_DEBUG > 0 )
{
  print "PackageReleaseInfo\n";
}
      $self->{'PackageReleaseInfo'} = new Grid::GPT::Comp::PackageReleaseInfo($c);
      next;
    }

    if ($c->{'name'} =~ m!(.+)Package$!) {
if( $_DEBUG > 0 )
{
  print $1, ": \n";
}
      my $packFact = new Grid::GPT::PackageFactory;
      my $package = $packFact->create($1, 0);
      $self->{'Package'} = $package->read( $c );
    }
  }
if( $_DEBUG > 1 )
{
  print Dumper $self;
}
}

sub write_metadata_file {
  my $self=shift;
  my ($filename)=@_;

  my $writer = new Grid::GPT::XML($filename);
  
  $writer->doctype("GPTPackageMetadata",$self->{'system'});
  $writer->startTag("GPTPackageMetadata", Name => $self->{'Name'},
		    FormatVersion => $self->{'FormatVersion'});
  $writer->characters("\n");

  ##$self->{'FeatureSetID'}->write_tag($writer);
  foreach my $obj (@{$self->{'FeatureSetID'}})
  {
    $obj->write_tag( $writer );
  }

  $self->{'PackageInfo'}->write_tag($writer);

  $self->{'PackageReleaseInfo'}->write_tag($writer);

  $self->{'Package'}->write_tag($writer);

$writer->write($filename);
}

sub convert_metadata 
{		
  #takes pkg_type and flavor as its arguments
  #returns reference to new (converted) metadata
  my $self=shift;
  my ($pkg_type, $flavor) = @_;
  my $converted;
  my $class = ref($self) || $self;
  $converted = {};
  
  bless $converted, $class;

##print "GPTPackage::convert_metadata\n";

  $converted->{'Name'}               = $self->{'Name'};
  $converted->{'FormatVersion'}      = $self->{'FormatVersion'};

# Check to see if we can understand this format

  $converted->{'doctype'}            = $self->{'doctype'};
  $converted->{'system'}             = $self->{'system'};
  $converted->{'FeatureSetID'}       = $self->{'FeatureSetID'};
  $converted->{'PackageInfo'}        = $self->{'PackageInfo'};
  $converted->{'PackageReleaseInfo'} = $self->{'PackageReleaseInfo'};

my $packFact = new Grid::GPT::PackageFactory;
my $package = $packFact->create($pkg_type, 0);

  $converted->{'Package'}            = $package->convert_data( $self->{'Package'}, $flavor );

  return $converted;
}

sub getSourceDependencies
{
  my ($self, $obj) = @_;
  $self->{'Package'}->getSourceDependencies($obj);
}

sub getBinaryDependencies
{
  my ($self, $obj) = @_;
  $self->{'Package'}->getBinaryDependencies($obj);
}

sub getName
{
  my $self = @_;
  return( $self->{'Name'} );
}

sub getFormatVersion
{
  my $self = @_;
  return( $self->{'FormatVersion'} );
}

sub getDescription
{
  my $self = @_;
  return $self->{'PackageInfo'}->Description();
}

sub getContactName
{
  my $self = @_;
  return $self->{'PackageInfo'}->getContactName();
}

sub getContactEmail
{
  my $self = @_;
  return $self->{'PackageInfo'}->getContactEmail();
}

sub getDocsDesc
{
  my $self = @_;
  return $self->{'PackageInfo'}->getPackageDocsDesc();
}

sub getDocsURL
{
  my $self = @_;
  return $self->{'PackageInfo'}->getPackageDocsURL();
}

sub getPackageReleaseStability
{
  my $self = @_;
  return;
}

sub getReleaseCompatibilityMajor
{
  my $self = @_;
  return;
}

sub getReleaseCompatibilityMinor
{
  my $self = @_;
  return;
}

sub getReleaseCompatibilityAge
{
  my $self = @_;
  return;
}

sub getFeatureSubName
{
  my $self = @_;
  return;
}

sub getFeatureCompatibilityMajor
{
  my $self = @_;
  return;
}

sub getFeatureCompatibilityMinor
{
  my $self = @_;
  return;
}

sub getFeatureCompatibilityAge
{
  my $self = @_;
  return;
}



sub type
{
  my ($self, $obj) = @_;

  return( $self->{'Package'}->type( $obj ) );
}











##################################
################################## OLD STUFF
##################################

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
