package Grid::GPT::Comp::GPTBuildFlavors;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Definitions;
use Grid::GPT::Comp::FlavorConfig;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG   = 0;

@ISA         = qw(Exporter);

{
  my $globals = {format_version => "0.1"};
  sub xml_format_version { return $globals->{'format_version'}};
}

##package Grid::GPT::Flavor;

sub new {
    my ($that, $obj)  = @_;
    my $class = ref($that) || $that;
    my $self  = { };
    bless $self, $class;

    foreach my $tag (@{$obj->{'contents'}})
    {
      next if ref($tag) ne 'HASH';

      my $itemName = $tag->{'name'};
      if( $itemName eq 'FlavorConfig' )
      {
        push @{$self->{'FlavorConfig'}}, (new Grid::GPT::Comp::FlavorConfig( $tag ));
if( $_DEBUG > 0 )
{
  print "  FlavorConfig: ";
  print Dumper $self->{'FlavorConfig'}, "\n";
}
      }
    }
    return $self;
}

sub write_tag {
  my ($self, $xml) = @_;

  $xml->startTag( 'FlavorChoice');
  $xml->characters("\n");

  foreach my $obj ( @{$self->{'FlavorConfig'}} )
  {
    $obj->write_tag( $xml );
  }
  $xml->endTag( 'FlavorChoice' );
  $xml->characters("\n");

  return;
}


















sub DESTROY {}
END { }       # module clean-up code here (global destructor)



1;
__END__
