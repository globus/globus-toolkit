package Grid::GPT::Comp::DepIndexesSingle;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

use Grid::GPT::DepNode;
use Data::Dumper;
require Grid::GPT::DepIndexes;
require Grid::GPT::Comp::Singleton;

# set the version for version checking
$VERSION     = 0.01;

@ISA = qw(Exporter Grid::GPT::DepIndexes Grid::GPT::Comp::Singleton);

sub _new_instance 
{
  my ($that)  = @_;
  my $me = $that->new;

  $me;
}

sub add_dependency {
  my ($me, $dep) = @_;
  my $object = new Grid::GPT::DepNode(depnode => $dep);
  $me->add_object(depnode => $object,
                  deptype => $object->deptype(),
                  pkgname => $object->pkgname(),
                  flavor => $object->flavor(),
                  pkgtype => $object->pkgtype());
}
sub add_pkgnode {
  my ($me, %args) = @_;
  my $object = $args{'depnode'};
  $me->add_object(depnode => $object,
                  deptype => $args{'deptype'},
                  pkgname => $object->pkgname(),
                  flavor => $object->flavor(),
                  pkgtype => $object->pkgtype());
}


sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
