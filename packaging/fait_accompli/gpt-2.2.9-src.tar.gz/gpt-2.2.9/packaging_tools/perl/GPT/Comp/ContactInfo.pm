package Grid::GPT::Comp::ContactInfo;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Definitions;
use Grid::GPT::Comp::PackageDocs;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG   = 0;

@ISA         = qw(Exporter);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

sub new {
    my ($that, $obj)  = @_;
    my $class = ref($that) || $that;
    
    my $self  = { };
    bless $self, $class;

    if (defined($obj)) 
    {
      $self->{'name'}  = $obj->{'attributes'}->{'ContactName'};
      $self->{'email'} = $obj->{'attributes'}->{'ContactEmail'};
    }
    return $self;
}

sub write_tag {
  my ($self, $xml) = @_;

  $xml->emptyTag( 'ContactInfo',
                  ContactName  => $self->{'name'},
                  ContactEmail => $self->{'email'} );
  $xml->characters("\n");

  return;
}

sub getContactName
{
  my $self = shift;
  return( $self->{'name'} );
}

sub getContactEmail
{
  my $self = shift;
  return( $self->{'email'} );
}








	
sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
