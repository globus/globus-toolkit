package Grid::GPT::Comp::CompatibilityID;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::Definitions;
require Grid::GPT::GPTObject;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG   = 0;

@ISA         = qw(Exporter  Grid::GPT::GPTObject);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

sub convert_version_list2xml {
  my ($versionlist, $xml) = @_;

  $xml->startTag('Version');
  $xml->characters("\n");
  for my $v (@$versionlist) {
    $v->write_tag($xml);
  }
  $xml->endTag('Version');
  $xml->characters("\n");
}

sub new {
    my ($that, $obj)  = @_;
    my $class = ref($that) || $that;
    my $self  = { };
    bless $self, $class;
    if (defined($obj)) 
    {
if( $_DEBUG > 1 )
{
print Dumper $obj;
}
      $self->{'major'} = $obj->{'attributes'}->{'Major'};
      $self->{'minor'} = $obj->{'attributes'}->{'Minor'};
      $self->{'age'} = $obj->{'attributes'}->{'Age'};

if( $_DEBUG > 0 )
{
print "\tCompatibilityID:\n";
print "\t  Major: ", $self->{'major'}, "\n";
print "\t  Minor: ", $self->{'minor'}, "\n";
print "\t  Age  : ", $self->{'age'}, "\n";
}
    }

if( $_DEBUG > 1 )
{
  print Dumper $self;
}
    return $self;
}

sub write_tag {
  my ($self, $xml) = @_;

  $xml->emptyTag('CompatibilityIdentifier', 
		  Major => $self->{'major'}, 
		  Minor => $self->{'minor'}, 
		  Age => $self->{'age'});
  $xml->characters("\n");
  return;
}









	
sub is_compatible {
  my ($self, $other) = @_;
  my ($aging_obj, $other_obj);
#  die "ERROR: Invalid version comparison $self->{'type'} $other->{'type'}\n" 
#    if $self->{'type'} ne 'aging' and $other->{'type'} ne 'aging';

  if ($self->{'type'} eq 'aging') {
    $aging_obj = $self;
    $other_obj = $other;
  } else {
    $aging_obj = $other;
    $other_obj = $self;    
  }


    if ($other_obj->{'type'} eq 'simple') {
      my $lower = $aging_obj->{'major'} - $aging_obj->{'age'};
      if ($other_obj->{'major'} >= $lower and 
	  $other_obj->{'major'} <= $aging_obj->{'major'}) {
	return 1;
      } else {
	return 0;
      }
    }
    
    if ($other_obj->{'type'} eq 'range' ) {
      return 0 if $aging_obj->{'major'} > $other_obj->{'upper_major'};
      return 0 if $aging_obj->{'major'} < $other_obj->{'lower_major'};
      return 1 if ! defined  $other_obj->{'upper_minor'} 
      or ! defined $other_obj->{'lower_minor'};
      return 0 if $aging_obj->{'minor'} > $other_obj->{'upper_minor'};
      return 0 if $aging_obj->{'minor'} < $other_obj->{'lower_minor'};
      return 1;
    }

}

sub validate {
  my ($self) = @_;

  if ($self->{'type'} eq 'aging') {

    die "ERROR: Major version not defined\n" if ! defined $self->{'major'};
    die "ERROR: Minor version not defined\n" if ! defined $self->{'minor'};
    die "ERROR: Age not defined\n" if ! defined $self->{'age'};

    die "ERROR: Range not used for this version type\n" 
      if defined $self->{'upper_major'} or defined $self->{'upper_minor'}
    or defined $self->{'lower_major'} or defined $self->{'lower_minor'};

  } elsif ($self->{'type'} eq 'simple') {

    die "ERROR: Major version not defined\n" if ! defined $self->{'major'};

    die "ERROR: Minor version not used for this version type\n" 
      if defined $self->{'minor'};
    die "ERROR: Age not used for this version type\n" if defined $self->{'age'};
    die "ERROR: Range not used for this version type\n" 
      if defined $self->{'upper_major'} or defined $self->{'upper_minor'}
    or defined $self->{'lower_major'} or defined $self->{'lower_minor'};

  } elsif ($self->{'type'} eq 'range') {

     die "ERROR: Upper range of major version not defined\n" 
       if ! defined $self->{'upper_major'};
     die "ERROR: Lower range of major version not defined\n" 
       if ! defined $self->{'lower_major'};

     die "ERROR: Invalid major version range\n" 
       if $self->{'upper_major'} < $self->{'lower_major'}; 
     die "ERROR: Invalid minor version range\n" 
       if $self->{'upper_major'} == $self->{'lower_major'} 
     and $self->{'upper_minor'} < $self->{'lower_minor'}; 
     
   
   } 
   elsif ($self->{'type'} eq 'label')
   {
     die "ERROR: Vrsion label not defined\n" 
       if ! defined $self->{'ver_label'};
   }
   else {
     die "ERROR: Version type $self->{'type'} not recognized\n";
   }
}

sub label {
  my ($self) = @_;
  return "" if $self->{'type'} ne 'aging';
  my ($major, $minor) = ($self->{'major'}, $self->{'minor'});
  return "$major.$minor";
}

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
