# Allow the flavor name to be overideden by the user
my $globus_flavor_name = shift;

my $gpath = $ENV{GPT_LOCATION};
if (!defined($gpath))
{
  $gpath = $ENV{GLOBUS_LOCATION};

}
if (!defined($gpath))
{
   die "GPT_LOCATION or GLOBUS_LOCATION needs to be set before running this script"
}

@INC = (@INC, "$gpath/lib/perl");

require Grid::GPT::Setup;
my $metadata = new Grid::GPT::Setup(package_name => "gt3_hostinfo");

my $globusdir = $ENV{GLOBUS_LOCATION};

my $gt3dir = "$globusdir/GT3/";
my $setupdir = "$globusdir/setup/globus/";
my $vardir = "$gt3dir/var/";
my $libexecdir = "$gt3dir/libexec";
my $etcdir = "$globusdir/etc/";

my $result = `$setupdir/setup-gt3-hostinfo-scripts --with-flavor=$globus_flavor_name`;

if (! -d "$gt3dir")
{
	$result = system("mkdir $gt3dir");
}

print "\nCreating directories...\n";
if (! -d "$vardir")
{
	$result = system("mkdir $vardir");
}
if (! -d "$libexecdir")
{
	$result = system("mkdir $libexecdir");
}

print "\nCreating...\n";

print "	$libexecdir/grid-info-script-initializer\n";
$result = system("chmod 0755 $setupdir/grid-info-script-initializer");
$result = system("cp grid-info-script-initializer $libexecdir");

print "	$libexecdir/grid-info-common\n";
$result = system("chmod 0755 $setupdir/grid-info-common");                                 
$result = system("cp grid-info-common $libexecdir");  

print "	$libexecdir/grid-info-cpu*\n";
$result = system("chmod 0755 $setupdir/grid-info-cpu*");                                 
$result = system("cp grid-info-cpu* $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-cpu*.in");

print "	$libexecdir/grid-info-fs*\n";
$result = system("chmod 0755 $setupdir/grid-info-fs*");                                 
$result = system("cp grid-info-fs* $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-fs*.in");

print "	$libexecdir/grid-info-mem*\n";
$result = system("chmod 0755 $setupdir/grid-info-mem*");                                 
$result = system("cp grid-info-mem* $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-mem*.in");

print "	$libexecdir/grid-info-net*\n";
$result = system("chmod 0755 $setupdir/grid-info-net*");                                 
$result = system("cp grid-info-net* $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-net*.in");

print "	$libexecdir/grid-info-platform*\n";
$result = system("chmod 0755 $setupdir/grid-info-platform*");                                 
$result = system("cp grid-info-platform* $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-platform*.in");

print "	$libexecdir/grid-info-os*\n";
$result = system("chmod 0755 $setupdir/grid-info-os*");                                 
$result = system("cp grid-info-os* $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-os*.in");

print "	$libexecdir/grid-info-host\n";
$result = system("chmod 0755 $setupdir/grid-info-host");                                 
$result = system("cp grid-info-host $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-host.in");

print "	$libexecdir/grid-info-partial-host\n";
$result = system("chmod 0755 $setupdir/grid-info-partial-host");                                 
$result = system("cp grid-info-partial-host $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-partial-host.in");


print "	$libexecdir/grid-info-runtime\n";
$result = system("chmod 0755 $setupdir/grid-info-runtime");                                 
$result = system("cp grid-info-runtime $libexecdir");  
$result = system("rm -f $libexecdir/grid-info-runtime.in");


print "	$etcdir/globus-host-providers.conf\n";
$result = system("chmod 0644 $setupdir/globus-host-providers.conf");
$result = system("cp globus-host-providers.conf $etcdir");  


print "Done\n";
$metadata->finish();
