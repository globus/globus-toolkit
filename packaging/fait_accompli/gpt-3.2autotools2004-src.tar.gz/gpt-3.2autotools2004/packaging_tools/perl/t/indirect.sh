#!/bin/sh

t/testcommand.sh $*