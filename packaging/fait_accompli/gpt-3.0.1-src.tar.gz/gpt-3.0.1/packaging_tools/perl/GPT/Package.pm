package Grid::GPT::Package;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::XML;
use Grid::GPT::PackageFactory;
use Grid::GPT::gpt_package;

# set the version for version checking
$VERSION     = 0.01;

my $_DEBUG      = 0;
##my $xmlReader;

sub new { 
    my ($that, %args)  = @_;
    my $class = ref($that) || $that;
    my $self  = {};
    $self->{'xmlReader'} = {};
    my $f;
    for  $f (sort keys %args) { 
      $self->{$f} = $args{$f};
    } 
    bless $self, $class;

if( defined $args{package} )
{
  $self->{'xmlReader'} = $args{package};
  return $self;
}
elsif((defined $args{installed_pkg})&&
   (defined $args{flavor})&&
   (defined $args{type}))
{ 
  $self->path_namer($args{installed_pkg}, $args{flavor}, $args{type});
} 
else
{  
  if((!(defined $args{installed_pkg}))&&
     (!(defined $args{flavor}))&&
     (!(defined $args{type})))
  { 
    return $self;
  }  
  else
  { 
    die "ERROR: Please specify name flavor and type: $!\n";
  } 
} 
return $self;
}

sub path_namer
{
  my ($self, $name, $f, $t)=@_;
  my $globus=$ENV{GLOBUS_LOCATION};
  my $path="$globus/etc/globus_packages/$name/pkg_data_".$f."_$t.gpt";
 
  $self->read_metadata_file($path);
}
 	
sub read_metadata_file {
  # my (%metadata);
  my $self=shift;
  my ($filename,$pkg_type) = @_;
  $filename= "$ {filename}_$pkg_type.gpt" if(defined($pkg_type));
  my $xml = new Grid::GPT::XML;
  my $packFact = new Grid::GPT::PackageFactory;

  $xml->read($filename);

  my $root = $xml->{'roottag'};
  my $format;


# Check to see if we can understand this format

  die "ERROR: Cannot parse $filename
      You need to upgrade your packaging tools" 
    if $root->{'attributes'}->{$format} >= 2.0;

  $self->{'xmlReader'} = $packFact->create( $root->{'name'}, "0.01" );
  $self->{'xmlReader'}->read( $xml ); 
return;
}

sub convert_data {
  my $self   = shift;
  my $type   = shift;
  my $flavor = shift;


##print "Package::convert_data\n";

  my $c = $self->{'xmlReader'}->convert_metadata( $type, $flavor );

  ##$c->write_metadata_file( "newDevFile.txt" );

  return $c;
}

sub getSourceDependencies
{
  my ($self, $obj) = @_;

  return( $self->{'xmlReader'}->getSourceDependencies($obj) );
}

sub getBinaryDependencies
{
  my ($self, $obj) = @_;

  return( $self->{'xmlReader'}->getBinaryDependencies($obj) );
}







sub add_setup_dep
  {
    my ($self, $setup, $pkgtype) = @_;
    my $name = $setup->{'attributes'}->{'Name'};
    my $versions;
    for my $v(@{$setup->{'contents'}}) {
      next if ref $v ne 'HASH';
      $versions = Grid::GPT::V1::Version::create_version_list($v);
    }
    my $obj = { name => $name, type => $pkgtype, versions => $versions};
    my $setuptype = 'SourceSetupDependencies';
    $setuptype = 'SetupDependencies' if ! defined $pkgtype;
    if (!defined ($self->{$setuptype})) {
      $self->{$setuptype} = [];
    }
    push @{$self->{$setuptype}}, $obj;
  }

sub convert_metadata {		
  #takes pkg_type and flavor as its arguments
  #returns reference to new (converted) metadata
	my $self=shift;
	my ($pkg_type, $flavor) = @_;
	my $converted=new Grid::GPT::Package;

	for my $n ('Name', 'Version', 'FormatVersion', 'doctype', 'system', 
                   'Description', 'VersionStability', 'PackageIdentifier', 'FunctionalGroup') {
	  $converted->{$n} = $self->{$n};
	}

	$converted->{'Package_Type'} = $pkg_type;
	if (! defined $Grid::GPT::Definitions::noflavor_pkg_types{$pkg_type}) {
		$converted->{'Flavor'} = $flavor 
	}else{
		$converted->{'Flavor'} = "noflavor";
	}


        for my $n ('PostInstallMessage', 'PostInstallProgram', 
                   'SetupName') {
          $converted->{$n} = $self->{$n};
        }
        $converted->{'Setup_Version'} = $self->{'SetupVersion'}->clone() 
          if defined $self->{'SetupVersion'};
        
        $converted->{'BinaryDependencies'} = 
          Grid::GPT::SourceDependency::get_bindeps_from($self->{'SourceDependencies'}, $pkg_type);

        for my $setup (@{$self->{'SourceSetupDependencies'}}) {
          if ($pkg_type eq $setup->{'type'}) {
            $converted->{'SetupDependencies'} = [] 
              if ! defined $converted->{'SetupDependencies'};
            my $bsetup = replicate($setup);
            $bsetup->{'type'} = undef;
            push @{$converted->{'SetupDependencies'}}, $bsetup;
          }
        }

	if ($pkg_type eq 'dev') {
	  for my $n ('cflags' , 'ExternalIncludes', 'PackageLibs', 'Externallibs') {

	    $converted->{$n} = $self->{$n};
	    if ($n eq 'pkg_libs') {
	      $converted->{$n} =~ s!(-l\w+)\s+!$ {1}_$flavor !g;
	      $converted->{$n} =~ s!(-l\w+)$!$ {1}_$flavor!;
	    }
	  }
	}

return $converted
}

sub clone {
    my $self = shift;
    my $clone = new();
    replicate($self, $clone);
    return $clone;
}

sub replicate {
  my ($rold) = @_;
  if (ref(\$rold) eq 'SCALAR') {
    return $rold;
  } elsif (ref($rold) eq 'ARRAY') {
    my @list = @$rold;
    return \@list;
  } elsif (ref($rold) eq 'HASH') {
    my $rnew = {};
    for my $e (sort keys %$rold) {
      $rnew->{$e} = replicate($rold->{$e});
    }
    return $rnew
  }
}

sub output_metadata_file {
  my $self=shift;
  my ($filename)=@_;



  $self->{'xmlReader'}->write_metadata_file( $filename );



  return;





  my $writer = new Grid::GPT::XML($filename);
  
  $writer->doctype("gpt_package_metadata","globus_package.dtd");
  $writer->startTag("gpt_package_metadata", Name => $self->{'Name'},
		    Format_Version => $self->{'Format_Version'});
  $writer->characters("\n");
  
  $self->{'Version'}->write_tag($writer);
  $writer->dataElement('Description', $self->{'Description'});
  $writer->characters("\n");
  $writer->dataElement('Functional_Group', $self->{'FunctionalGroup'});
  $writer->characters("\n");
  $writer->emptyTag("Version_Stability", Release=> $self->{'VersionStability'});
  $writer->characters("\n");
  $writer->emptyTag("PackageIdentifier", Release=> $self->{'PackageIdentifier'})
;
  $writer->characters("\n");
 
  $writer->startTag("$self->{'PackageType'}_pkg");

  $writer->characters("\n");
  
  # Write With_Flavors data
  if (defined $self->{'WithFlavors'}) {
    $writer->emptyTag("WithFlavors", build=> $self->{'WithFlavors'});
  $writer->characters("\n");
  }
  
  # Write out Flavor
  if (defined $self->{'Flavor'}) {
    $writer->dataElement('Flavor', $self->{'Flavor'});
    $writer->characters("\n");
  }
  # Write out Version_Label
  if (defined $self->{'VersionLabel'}) {
    $writer->dataElement('VersionLabel', $self->{'VersionLabel'});
    $writer->characters("\n");
  }
  # Write Dependency Data
  if (defined($self->{'SourceDependencies'})) {
    Grid::GPT::BaseDependency::get_xml_from($self->{'SourceDependencies'}, 
                                            $writer,
                                            'SourceDependencies')
  }
  
  if (defined($self->{'Binary_Dependencies'})) {
    Grid::GPT::BaseDependency::get_xml_from($self->{'BinaryDependencies'}, 
                                            $writer,
                                            'BinaryDependencies')
    }
  if (defined($self->{'SourceSetupDependencies'})) {
    for my $t (@{$self->{'SourceSetupDependencies'}}) {
      write_setup_deps->($writer, $t);
    }
  }
  if (defined($self->{'SetupDependencies'})) {
    for my $t (@{$self->{'SetupDependencies'}}) {
      write_setup_deps->($writer, $t);
    }
  }
  

  #Write out Build Enviromnment
  if ($self->{'PackageType'} eq 'src' or $self->{'PackageType'} eq 'dev' ) {
    $writer->startTag("BuildEnvironment");
    $writer->characters("\n");
    for my $n ('cflags' , 'ExternalIncludes', 'PackageLibs', 'ExternalLibs') {
      $writer->dataElement($n, $self->{$n});
      $writer->characters("\n");
    }
    $writer->endTag("BuildEnvironment");
    $writer->characters("\n");
  }

  #Write out Build Instructions
  if ($self->{'PackageType'} eq 'src' and 
      defined $self->{'BuildInstructions'}) {
    $writer->startTag("BuildInstructions");
    $writer->characters("\n");
    for my $s (@{$self->{'BuildInstructions'}}) {
      my %args;
      $args{'Macro_Args'} = $s->{'args'}
        if defined $s->{'args'};
     $writer->dataElement('BuildStep', $s->{'command'},%args);
      $writer->characters("\n");
    }
    $self->{'BuildFlavorChoices'}->write_xml_choices($writer) 
      if defined $self->{'BuildFlavorChoices'};
    $writer->endTag("BuildInstructions");
    $writer->characters("\n");
  }

  if (defined $self->{'PostInstallMessage'}) {
    $writer->dataElement('PostInstallMessage', 
                         $self->{'PostInstallMessage'});
    $writer->characters("\n");
  }

  if (defined $self->{'PostInstallProgram'}) {
    $writer->dataElement('PostInstallProgram', 
                         $self->{'PostInstallProgram'});
    $writer->characters("\n");
  }

  # Write out setup package fields
  

  if (defined $self->{'SetupName'}) {

    $writer->startTag('Setup', Name => $self->{'SetupName'});
    $writer->characters("\n");
    $self->{'SetupVersion'}->write_tag($writer);
    $writer->endTag('Setup');    
    $writer->characters("\n");
  }


  $writer->endTag("$self->{'PackageType'}_pkg");
  $writer->characters("\n");
  $writer->endTag('GPTPackageMetadata');
  $writer->write($filename);
}

sub write_setup_deps
  {
    my ($writer, $setup) = @_;
    my ($name, $pkgtype, $versions) = 
      ( $setup->{'name'}, $setup->{'type'}, $setup->{'versions'});
    $writer->startTag("SourceSetupDependency", PkgType => $pkgtype) 
      if defined $pkgtype;
    $writer->characters("\n");
    $writer->startTag("SetupDependency", Name => $name);
    $writer->characters("\n");
    Grid::GPT::V1::Version::convert_version_list2xml($versions, $writer);
    $writer->endTag("SetupDependency");
    $writer->characters("\n");
    $writer->endTag("SourceSetupDependency") if defined $pkgtype;
    $writer->characters("\n");
  }

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $self = shift;
  my $type = ref($self) || croak "$self is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $self->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $self->{$name} = shift;
  } else {
    return $self->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Package - Perl extension for reading packaging metadata files

=head1 SYNOPSIS

  use Grid::GPT::Package;
  my $pkg = new Grid::GPT::Package;

  $pkg->read_metadata_file('src_metadata.xml');
  my $bin_pkg = $pkg->convert_metadata($type, $build_flavor);
  $bin_pkg->output_metadata_file("$ {type}_metadata.xml");

=head1 DESCRIPTION

I<Grid::GPT::Package> is used to manage (ie. read, write, convert)
packaging metadata. The data is stored in XML format that follows the
file F<package.dtd>.

=head1 Metadata Fields

=over 4

=item Name

Name of the package.

=item Version

A L<Grid::GPT::V1::Version|Grid::GPT::V1::Version> object.

=item Format_Version

A number which defines the metadata format version.

=item Package_Type

The package type one of "data", "dev", "doc", "pgm",
"pgm_static", "rtl", "src", or virtual.

=item Flavor

The build flavor a binary package was generated with. N/A to src
packages.

=item Version_Label

For a virtual package, this field contains the version description of
the external library.

=item With_Flavor

Yes or no if the src package should be built using build flavors. N/A
to binary packages.

=item Description

A paragraph or two that adds information about this package release.
This is not used by any tools.

=item Functional_Group

A "/" delimited string that indicates what group the package is a part
of.  This is used for bundles.

=item Version_Stability

An indicater about the stibility of the package release. Can be one of
I<experimental>, I<alpha>, I<beta>, or I<production>.

=item Source_Dependencies

Hash of hashes of
L<Grid::GPT::SourceDependency|Grid::GPT::SourceDependency> objects.
The top level hash is keyed by the dependency type. The lower level
hashes are keyed by a combination of package name and package
type. N/A to binary packages.

=item Binary_Dependencies

Hash of hashes of
L<Grid::GPT::BinaryDependency|Grid::GPT::BinaryDependency> objects.
The top level hash is keyed by the dependency type. The lower level
hashes are keyed by a combination of package name and package
type. N/A to src packages.

=item Setup_Dependency

Gives the name and version requirements of a setup package.  Setup
packages are packages that need to be configured or "setup" by the
package installer.

=item Source_Setup_Dependencies

A list of Setup_Dependencies paired with the binary package type that
needs it.  Only for src packages.

=item cflags

String of flags to include for preprocessing.  Only applicable to src
and dev packages.

=item external_includes

String of flags to include external directories containing header
files.  Only applicable to src and dev packages.


=item pkg_libs

String of flags which are used to link libraries provided by the
package.  Only applicable to src and dev packages.  Note that when a
package is converted from src to dev, each library will be appended
with "_<flavor>".


=item external_libs

String of flags to include external libraries.  Only applicable to src
and dev packages.


=item Filelist

For virtual and setup packages only, a Package object can contain a
list of Filelist references. Each reference contains a directory
(Dir), A flag on whether the files are flavored or not (Flavored), A
field indicating which binary package the files belong to
(Package_Type), and a list of filename (Files).  Flavored files in
setup packages are currently not supported.


=item Setup_Name

A Package object can contain the name of a setup package format.  This
name is used for setup dependencies. This name gets passed on to pgm
and pgm_static types.

=item Setup_Version

A Package object can contain the version of a setup package format.
This version is used for setup dependencies. This gets passed on
to pgm and pgm_static types.



=item Post_Install_Message

For setup packages only, a Package object can contain a setup
requirements message.  This message details the tasks that need to be
done to complete the installation of a setupo package. The message is
displayed to the user after the package is installed.


=item Post_Install_Program

For setup packages only, a Package object can contain a setup
requirements program.  This is the program that needs to be run to
complete the setup.


=item doctype

The documentation type for the XML input/output.

=item system

The dtd or schema used in the XML input/output.

=back


=head1 Methods

=over 4

=item new

Create a new I<Grid::GPT::Package> object.

=item read_metadata_file(filename)

load metadata from an input file.  Any of the metadata package format
types can be used as inputs.

=item output_metadata_file(filename)

Dumps the metadata into an output file in xml format

=item convert_metadata(pkg_type)

Converts a src package metadata object into a binary metadata object
of the given package type.  The binary metadata object is returned as
a reference.

=back



=head1 AUTHOR

Eric Blau <eblau@ncsa.uiuc.edu> Michael Bletzinger <mbletzin@ncsa.uiuc,edu>

=head1 SEE ALSO

perl(1) Grid::GPT::SourceDependency(1) Grid::GPT::BinaryDependency(1) Grid::GPT::XML(1) Grid::GPT::V1::Version(1)..

=cut
