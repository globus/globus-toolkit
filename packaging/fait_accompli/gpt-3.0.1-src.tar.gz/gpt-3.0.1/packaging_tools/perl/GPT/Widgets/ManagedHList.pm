package Grid::GPT::Widgets::ManagedHList;

use strict;
use Tk;
require Tk::HList;
use Data::Dumper;

#use AutoLoader qw(AUTOLOAD);


# Preloaded methods go here.
sub new {
  my ($class, %args) = @_;
  my $me = {
	    parent => $args{'-parent'}, # reference to parent widget
            headers => $args{'-headers'}, # list of header labels
            edit => $args{'-edit'}, # function to edit an entry object
            fill => $args{'-fill'}, # function to transform an entry object into a
                                   # hash of table entries indexed by headers.
            objs => {}, # list of entry objects indexed
            num_objs => 0, # number of entry objects being managed
            edited_obj => -1 # index of object being edited. -1 means none.
	   };
  bless $me, $class;
  $me->{'widget'} = $args{'-parent'}->Scrolled('HList', -header => 1,
                                            -columns => scalar @{$args{'-headers'}},
                                            -width => $args{'-width'}, 
                                            -height => $args{'-height'},
                                            -scrollbars => 'e',
                                            -itemtype => 'text')->pack();

  for my $h (0..$#{$me->{'headers'}}) {
    $me->{'widget'}->header('create',$h,-text => $me->{'headers'}->[$h]);
  }
  $me->{'widget'}->configure(-command => [$me => 'edit']);
  return $me;
}


sub edit {
  my ($me, $entry) = @_;

  if (defined($entry)) {
    my $index = $entry;
    $index =~ s!managedlistentry!!;
    $me->{'edited_obj'} = $index;
    my $obj = $me->{'objs'}->{$index};
    &{$me->{'edit'}}(sub {$me->modify(shift);}, $obj);
  } else {
    &{$me->{'edit'}}(sub {$me->add(shift);});    
  }

}

sub modify {
  my ($me, $obj) = @_;
  my $contents = &{$me->{'fill'}}($obj);
  my $entry = "managedlistentry$me->{'edited_obj'}";
  $me->{'objs'}->{$me->{'edited_obj'}} =  $obj;

  $me->{'edited_obj'} = -1;

  for my $c(1..$#{$me->{'headers'}}) {
    my $hindex = $me->{'headers'}->[$c]; 
    $me->{'widget'}->itemConfigure($entry,$c, -text =>  $contents->{$hindex});
  }

}


sub add {

  my ($me, $obj) = @_;
  my $contents = &{$me->{'fill'}}($obj);
  my $entry = 'managedlistentry' . $me->{'num_objs'};

  $me->{'widget'}->add($entry, -data => $entry);

  $me->{'objs'}->{$me->{'num_objs'}} =  $obj;

  $me->{'num_objs'}++;
  
  for my $c(0..$#{$me->{'headers'}}) {
    my $hindex = $me->{'headers'}->[$c]; 
    $me->{'widget'}->itemCreate($entry,$c, -text =>  $contents->{$hindex});
  }
}

sub clear {

  my ($me) = @_;
  $me->{'objs'} = {};
  $me->{'num_objs'} = 0;
  $me->{'edit_objs'} = -1;
  $me->{'widget'}->delete('all');
}

sub done {
  my $me = shift;
  my $setup = $me->export_setup();
  &{$me->{'update'}}($setup);
  $me->{'toplevel'}->withdraw();
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Widgets::ManagedHList - Perl extension for blah blah blah

=head1 SYNOPSIS

  use ManagedHList;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for ManagedHList, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.


=head1 AUTHOR

A. U. Thor, a.u.thor@a.galaxy.far.far.away

=head1 SEE ALSO

perl(1).

=cut
