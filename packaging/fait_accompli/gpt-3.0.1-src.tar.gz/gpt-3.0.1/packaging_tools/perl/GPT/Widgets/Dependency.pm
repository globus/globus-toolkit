package Grid::GPT::Widgets::Dependency;

use strict;
use Tk;
use Tk::Menubutton;
require Tk::BrowseEntry;
require Tk::HList;
use Grid::GPT::V1::SourceDependency;
use Grid::GPT::Widgets::Version;
use Data::Dumper;

#use AutoLoader qw(AUTOLOAD);


# Preloaded methods go here.
sub new {
  my ($class, %args) = @_;
  my $me = {
	    parent => $args{'parent'},
            name => "",
            runpkg => "N/A",
            rundep_pgm => 0,
            rundep_data => 0,
            rundep_doc => 0,
	   };
  bless $me, $class;

  $me->{'depslist'} = $args{'indexes'}->{'name'} if defined $args{'indexes'};
  
  $me->{'toplevel'} = $me->{'parent'}->Toplevel(-title => 'Dependency');
  my $f = $me->{'toplevel'}->Frame(-width => 100)->pack();
  my $nf = $f->Frame->pack();
  my $nlabel = $nf->Label(-text => "Name:", -justify => 'left')->pack(-side => 'left');
  my $n = $nf->Entry( -relief => 'sunken', 
                      -width => 40, 
                      -textvariable => \$me->{'name'})->pack();

  my $Bl = $f->Label(-text => "Build Dependencies")->pack(-side => 'top');
  my $buildf = $f->Frame(-borderwidth => '5', -relief => 'ridge')->pack();
  my $buildstart = $buildf->Label(-text => "Needed because ")->pack(-side => 'left', -anchor => 'w');

  my %dep_desc = ('compile', "its headers are being #include'd by my package",
                 'pgm_link',"my programs link with its libraries",
                 'lib_link', "my libraries depend on its libraries"
                 );
  for my $b(sort keys %dep_desc) {
    my $rb1= $buildf->Checkbutton(-variable => \$me->{"builddep $b"}, 
                                   -justify => 'left', 
                                   -text =>$dep_desc{$b}
                                  )->pack(-anchor => 'w');

  }
  my $rl = $f->Label(-text => "Runtime Dependencies")->pack(-side => 'top');
  for my $p("data files", "programs", "libraries", "documents") {
    my $runf = $f->Frame(-borderwidth => '5', -relief => 'ridge')->pack(-anchor => 'w');
    my $runstart = $runf->Label(-text => "Needed because my $p")->pack(-side => 'left',-anchor => 'w');
    my $runbf = $runf->Frame()->pack(-side => 'left');


    my %pkg_desc = ('pgm','run its programs',
                    'data','read its data files',
                    'doc','link its documents');

    for my $t ('pgm','data','doc') {
      my $rb1= $runbf->Checkbutton(-variable => \$me->{"$p rundep $t"}, 
                                   -justify => 'left', 
                                   -text =>$pkg_desc{$t}
                                  )->pack(-anchor => 'w');
    }
  }

  my $vf = $f->Frame->pack(-side => 'left');
  my $vl = $f->Label(-text => "Versions")->pack(-side => 'top');

  my @vheaders = ('Type', "Specification");

  $me->{'versionlist'} = new 
    Grid::GPT::Widgets::ManagedHList(-parent => $f,
                                     -headers => \@vheaders,
                                     -width => 20,
                                     -height => 8,
                                     -edit => sub {$me->edit(shift,shift); },
                                     -fill => sub{$me->fill_content(shift);},
                                    );
  my $b2 = $vf->Button(-text =>'Done', -command => sub{$me->done()}, 
		    -width => 10)->pack();
  my $b3 = $vf->Button(-text =>'Add Version', 
                       -command => sub{$me->{'versionlist'}->edit()}, 
                       -width => 10)->pack();

  $me->{'versiondisplay'} = new Grid::GPT::Widgets::Version($me->{'toplevel'});
  $me->{'toplevel'}->withdraw();
  return $me;
}

sub display {
  my ($me, $update_func, $name) = @_;
  $me->{'update'} = $update_func;
  $me->clear_dep();
  if (defined ($name)) {
    $me->import_dep($name);
    $me->{'depref'} = $name;
  }
  $me->{'toplevel'}->deiconify();  
}

sub import_dep {
  my ($me, $dep) = @_;
  $me->{'name'} = $dep;

  my $versions = $me->{'depslist'}->{$dep}->[0]->{'versions'};
  for my $v (@$versions) {
    $me->{'versionlist'}->add($v);
  }

  my %pkg_desc =  ("data_runtime", "data files", 
                   "pgm_runtime", "programs", 
                  "lib_runtime" , "libraries", 
                  "doc_runtime" , "documents" );
  my %build_deps;

   for my $d (@{$me->{'depslist'}->{$dep}}) {
    my $desc = $pkg_desc{$d->{'type'}};
    my $pkg = $d->{'pkg_type'};
    if (defined ($desc)) {
      $me->{"$desc rundep $pkg"} = 1;
    } else {
      $me->{"builddep $d->{'type'}"} = 1;
    }
  }
}

sub export_dep {
  my ($me) = @_;
  my @deps;

  my %pkg_desc = ( "data files", "data_runtime", 
                   "programs", "pgm_runtime", 
                   "libraries", "lib_runtime", 
                   "documents", "doc_runtime");

  my @versions;
  for my $v(sort keys %{$me->{'versionlist'}->{'objs'}}) {
    push @versions, $me->{'versionlist'}->{'objs'}->{$v};  
  }  
  for my $p("data files", "programs", "libraries", "documents") {
    for my $t ('pgm','data','doc') {
      if ($me->{"$p rundep $t"}) {
        push @deps, new 
          Grid::GPT::V1::SourceDependency(name => $me->{'name'},
                                      versions => \@versions,
                                      type => $pkg_desc{$p},
                                      pkg_type => $t
                                     );
      } 
    }
  }
  for my $p ("compile", "pgm_link", "lib_link") {
    if ($me->{"builddep $p"}) {
      push @deps, new 
        Grid::GPT::V1::SourceDependency(name => $me->{'name'},
                                    versions => \@versions,
                                    type => $p,
                                   );
      } 
  }

  $me->{'depslist'}->{$me->{'name'}} = \@deps; 

  return $me->{'name'};
}

sub clear_dep {
  my ($me) = @_;
  $me->{'depref'} = {};
  $me->{'name'} = "";
  for my $p("data files", "programs", "libraries", "documents") {
    for my $t ('pgm','data','doc') {
      $me->{"$p rundep $t"} = 0;
    }
  }
  for my $p("compile", "pgm_link", "lib_link") {
      $me->{"builddep $p"} = 0;
  }
  $me->{'versionlist'}->clear();
}

sub edit {
  my ($me, $func, $entry) = @_;
  if (defined($entry)) {
    $me->{'versiondisplay'}->display($func, $entry);
  } else {
    $me->{'versiondisplay'}->display($func);
  }
}


sub fill_content {
  my ($me, $version) = @_;
  my $spec;
  if ($version->{'type'} eq 'simple') {
    $spec = "$version->{'major'}";
    $spec .= ".$version->{'minor'}" if defined $version->{'minor'};
  } else {
    $spec = "$version->{'lower_major'}";
    $spec .= ".$version->{'lower_minor'}" if defined $version->{'lower_minor'};
    $spec .= " to $version->{'upper_major'}";
    $spec .= ".$version->{'upper_minor'}" if defined $version->{'upper_minor'};
  }
  
 return {Type => $version->{'type'}, Specification=> $spec };

}

sub done {
  my $me = shift;
  my $deps = $me->export_dep();
  &{$me->{'update'}}($deps);
  $me->{'toplevel'}->withdraw();
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Widgets::Dependency - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Dependency;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Dependency, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.


=head1 AUTHOR

A. U. Thor, a.u.thor@a.galaxy.far.far.away

=head1 SEE ALSO

perl(1).

=cut
