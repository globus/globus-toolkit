#! perl

use strict;
use Getopt::Long;
use Config;
use Cwd;

#
# Do a perl check for version >= 5.005.  See 'gpt-translate-interpreter' should you
# need to alter the invocation path to a valid perl interpreter in the GPT front-end
# programs.
#

if ( ! ( defined eval "require 5.005" ) )
{
    die "GPT requires at least Perl version 5.005";
}

my $gpath = $ENV{GPT_LOCATION};

if (!defined($gpath))
{
  $gpath = $ENV{GLOBUS_LOCATION};

}

if (!defined($gpath))
{
   error_out("GLOBUS_LOCATION and GPT_LOCATION need to be set before running this script");
}

@INC = ("$gpath/lib/perl", "$gpath/lib/perl/$Config{'archname'}", @INC);

require Pod::Usage;

my $file;
my $tar;
my @tarfiles;
my @bundlearray;
my @consolidated_files;
my @packagetars;
my $metadatafile=undef();
my $metadata;
my $metadataobj;
my $force=undef();
my $help=undef();
my $verbose;
my $version;
my $tmpdir="/tmp";
my $skipping;

my $globusdir = $ENV{'GLOBUS_LOCATION'};

# sub pod2usage {
#   print "gpt-install [--force -tmpdir=<path> -installdir=<path> -help ] packages or bundles(s) \n";
#   exit shift;
# }
 
GetOptions( 'force'=> \$force, 
            'help|?' => \$help, 
            'verbose|?' => \$verbose, 
            'tmpdir=s'=> \$tmpdir,
            'installdir=s'=> \$globusdir,
            'version' => \$version)
  or Pod::Usage::pod2usage(1);
 
Pod::Usage::pod2usage(0) if $help;
require Grid::GPT::GPTIdentity;
Grid::GPT::GPTIdentity::print_gpt_version() if defined $version;

require Grid::GPT::FilelistFunctions;
require Grid::GPT::PkgDist;
require Grid::GPT::Installation;
require Archive::Tar;

my @files = @ARGV;
if (@files == 0) {
  print "ERROR: please specify at least one file to install\n"; 
  Pod::Usage::pod2usage(1);
}

if (!defined($globusdir)) {
  error_out( "Please set GLOBUS_LOCATION or use the -installdir flag \n");
  Pod::Usage::pod2usage(1);
}
 
Grid::GPT::FilelistFunctions::mkinstalldir($globusdir);
$globusdir = Grid::GPT::FilelistFunctions::abspath($globusdir);

Grid::GPT::FilelistFunctions::mkinstalldir($tmpdir);
$tmpdir = Grid::GPT::FilelistFunctions::abspath($tmpdir);

my $time=time();
my $tmpd=$tmpdir."/"."gpt_bundle-"."$$"."-".$time;
$tmpdir=$tmpd;
if (!(-e "$tmpd")){
  print "Making $tmpd \n" if defined $verbose;
  mkdir("$tmpd",0700) || die "cannot mkdir $tmpd: $!";
}

my $currentdir=cwd();



for my $f (@files){
  unpack_bundle($f);
}

if (grep {m!\.rpm$!} @packagetars) {
  my $result = install_rpms(\@packagetars);
  cleanup();
  exit ! $result;
}

#map { print "$_\n" } @packagetars;

my $dist = new Grid::GPT::PkgDist(with_filelists =>1, 
                                  pkgdir =>$tmpdir, 
                                  pkgtars => \@packagetars);



#map { $_->printnode() } @{$dist->{'pkgs'}};

my $installation = 
  new Grid::GPT::Installation(pkgdir => "$globusdir/etc/globus_packages", 
                              with_filelists => 1);

my $badnews = "";
my $fatal;
my @pkglist;

for my $p (@{$dist->{'pkgs'}}) {

  
  # check for package conflict

  # Add some pgm heuristics
  my $flavor = $p->pkgtype() =~ m!pgm! ? 'ANY' : $p->flavor();

  my $installed_pkgs = $installation->query(
                                            pkgname => $p->pkgname(),
                                            flavor => $flavor,
                                            pkgtype => $p->pkgtype(),
                                           );
  if ($p->pkgtype() =~ m!pgm!) {
    my $pkgtype = $p->pkgtype eq 'pgm' ? 'pgm_static' : 'pgm';
    my $installed_static_pkgs = $installation->query(
                                                     pkgname => $p->pkgname(),
                                                     flavor => $flavor,
                                                     pkgtype => $pkgtype,
                                                    );
    push @$installed_pkgs, @$installed_static_pkgs 
      if defined $installed_static_pkgs;
  }

  if (@$installed_pkgs) {

    if (defined $verbose) {
      $badnews .= "Skipping " if ! defined $force;
      $badnews .= "package ".($p->label(full=>1)). ":\n";
      for my $i (@$installed_pkgs) {
        $badnews .= "   ".($i->label(full=>1))." already installed\n";
      }

    } else {
      $badnews .= ($p->label()). " already installed\n" if ! defined $force;
    }
    push @pkglist, $p if defined $force;
    next;
  }

  # check for file conflicts
  my $fileconflicts = $installation->check_files($p);
  if (@$fileconflicts) {
    $fatal++;
    $badnews .= "Package ".($p->label()). " has file conflicts with the following:\n";
    for my $i (@$fileconflicts) {
      $badnews .= "   $i->{'file'} owned by ".($i->{'pkgnode'}->label())."\n";
    }
    push @pkglist, $p if defined $force;
    next;
  }

  push @pkglist, $p;
}

if (defined $fatal) {
  print "ERROR:\n" if ! defined $force;
  print "WARNING:\n" if defined $force;
  print $badnews;
  if (! defined $force) {
    cleanup();
    exit 1;
  }
} else {
  print "WARNING:\n" if defined $verbose;
  print $badnews;
}

for my $p (@pkglist) {
  my $result = install_pkg($p->gptpkgfile(full =>1), $p->label(full =>1));

  my $pkgdata = $p->{'depnode'};

}


#cleanup bundle tmpdir stuff
cleanup();
	

sub unpack_bundle {
  my ($file) = @_;
  
  if ($file =~ m!\.rpm$!) {
    push @packagetars, $file;
    return;
  }
  $file = Grid::GPT::FilelistFunctions::abspath($file);

  my $tar= Archive::Tar->new();
  $tar->read($file);
  my @tarfiles=$tar->list_files();
  
  my @pkglist = grep { /packagelist$/ } @tarfiles;
  
  
  if (! @pkglist) {
    push @packagetars, $file;
    return;
  }


  my @bundlefiles=split /\n/, $tar->get_content($pkglist[0]);
  chomp @bundlefiles;


  @packagetars = map { "$tmpdir/$_" } @bundlefiles;

  chdir $tmpdir;
  my $retval= $tar->extract(@tarfiles);
  if (!($retval)){
    print $tar->error();
    print $retval, "is the return from extract\n";
    print "did not successfully unpack $file \n";
    print "$currentdir was the current dir \n";
  }
  chdir $currentdir;

}


sub install_pkg {
  my ($file, $label) = @_;

  my $result;

  my $tar = Archive::Tar->new();
  $tar->read($file);
  my @tarfiles = $tar->list_files();
  chdir $globusdir;
  my $retval= $tar->extract(@tarfiles);
  if (!($retval)){
    print $tar->error();
    print $retval, "is the return from extract_archive\n";
    print "did not successfully install $file \n";
    print "$currentdir was the current dir \n";
   $result = 0;
  }else {
    print $label, " successfully installed.\n";
    $result++;
  }
  my ($login,$pass,$uid,$gid) = getpwuid($<)
    or die "$< not in passwd file";

  if ($login eq 'root') {
    chown $<, $(, @tarfiles;
  }

  chdir $currentdir;
  return $result;
}

sub install_rpms {
  my ($files) = @_;

  my $relocate = good_rpm();

  die "ERROR: You need at least version 4.0.4 of rpm\n" if ! $relocate;

  my $forceflag = defined $force ? '--force' : '';
  my $vvflag = defined $verbose ? '-vv' : '';
  my $rpmprefix  = defined $relocate ? "--prefix $globusdir" : '';

  my $fileline = "";
  print "Installing...";
  for my $f (@$files) {
    my ($rpmname) = $f =~ m!([^\.]+)-\d\.!;

    my $query = `rpm -q $rpmname 2>&1`;

    next if $query !~ m!not\s+installed!;
    print $rpmname,",";

    $fileline .= " $f";
  }

#  print "rpm -i $forceflag  -$vvflag  --prefix $globusdir $fileline\n";
#  my $result = system("rpm -i  $vvflag  $forceflag --prefix $globusdir $fileline");
#  print "rpm -i $forceflag $vvflag  $rpmprefix $fileline\n";
  my $result = system("rpm -i $forceflag $vvflag  $rpmprefix $fileline");
  print "..DONE\n";
  return $result;
}

sub good_rpm {
  my $rpmversion = `rpm --version`;
  my ($d1, $d2, $d3) = $rpmversion =~ m!(\d)\.(\d)\.(\d)!;
  return 1 if $d1 > 4;
  return 0 if $d1 < 4;
  return 1 if $d2 > 0;
  return 1 if $d3 >=  4;
  return 0;
}

sub error_out{
	my $errormsg=shift;
	
	cleanup();
	print STDERR $errormsg;
}

sub cleanup{

  cleandir($tmpdir);
}

sub cleandir() {
  my ($top) = @_;
  opendir(DIR, $top);
  my @contents = readdir DIR;
  closedir DIR;
  my @dirs = grep { -d "$top/$_" and ! m!^\.! } @contents;
  my @files = grep { ! -d $_ } map { "$top/$_" } @contents;
  for my $f (@files) {
    unlink($f) or warn "couldn't unlink $f: $!";
  }
  for my $d (@dirs) {
    cleandir("$top/$d");
  }
  rmdir $top;
}

=head1 NAME

B<gpt-install> - Installs a new GPT package. 

=head1 SYNOPSIS

gpt-install [--force -tmpdir=<path> -installdir=<path> -help ] packages or 
bundles(s) 

=head1 DESCRIPTION

B<gpt-install> takes a GPT described package or bundle and installs
it. The program can install either RPM's or GPT packages.

=head1 OPTIONS

=over 8

=item B<-force>

Forces all action to be taken, regardless of state.

=item B<-tempdir> 

Place to unpack bundles.

=item B<-installdir>

Directory to which files shall be written. Default is $GLOBUS_LOCATION


=back

=head1 SEE ALSO

gpt-uninstall(1) gpt-query(1) gpt-verify(1)

=head1 AUTHOR

Michael Bletzinger E<lt>mbletzin.ncsa.uiuc.eduE<gt> and Eric Blau
E<lt>eblau.ncsa.uiuc.eduE<gt>

=cut
