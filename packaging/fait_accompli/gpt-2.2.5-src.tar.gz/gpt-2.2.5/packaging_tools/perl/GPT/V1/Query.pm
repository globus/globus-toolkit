package Grid::GPT::V1::Query;

use strict;
use Carp;
use Grid::GPT::V1::Package;
use Grid::GPT::V1::Version;
use Grid::GPT::V1::Dependencies;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter);
@EXPORT      = qw(&open_metadata_file &func2 &func4);
%EXPORT_TAGS = ( );     # eg: TAG => [ qw!name1 name2! ],

# your exported package globals go here,
# as well as any optionally exported functions
@EXPORT_OK   = qw($Var1 %Hashit &func3);

use vars qw($Var1 %Hashit);
# non-exported package globals go here
use vars      qw(@more $stuff);

# initialize package globals, first exported ones
$Var1   = '';
%Hashit = ();

# then the others (which are still accessible as $Some::Module::stuff)
$stuff  = '';
@more   = ();

# all file-scoped lexicals must be created before
# the functions below that use them.

# file-private lexicals go here
my $priv_var    = '';
my %secret_hash = ();

# here's a file-private function as a closure,
# callable as &$priv_func.
my $priv_func = sub {
    # stuff goes here.
};

# make all your functions, whether exported or not;
# remember to put something interesting in the {} stubs

my %queryobj = (
	installedlist => []
	
);

sub new {
    my $class  = shift;
    my $self  = {
        %queryobj,
    };
    bless $self, $class;
    return $self;
} 
	


sub query{		#returns the list of installed packages, optionally filtered.
	my $self=shift;
	my $filtername=shift;
	my $filtertype=shift;
	my @errorlist=undef();
	my @packagelist=undef();
	my @packagetypelist=undef();
	my $globusdir = $ENV{'GLOBUS_LOCATION'};
		if (!defined($globusdir)) {
		  die "Please set GLOBUS_LOCATION\n";
		} 
		opendir(PACKAGESDIR, "$globusdir/etc/globus_packages") or die "can't
opendir $globusdir/etc/globus_packages: $!";

	while (defined(my $file = readdir(PACKAGESDIR))) {
    # do something with "$dirname/$file"
		if (! ($file =~ m/^\./)){		#ignore entries that start with "."

			if (! defined $filtername){
				$filtername="\w*";
			}
			if ($file =~ /$filtername/){
				push @packagelist, $file;
			}
		}
	}
	closedir(PACKAGESDIR);

	if (defined @packagelist){
		foreach my $package (@packagelist) {
			#print $package,"\n";
			opendir(DIR, "$globusdir/etc/globus_packages/$package") or die "can't opendir $globusdir/etc/globus_packages/$package: $!";
			while (defined(my $file = readdir(DIR))) {
				if ( $file =~ s/$\.gpt//){		#look for .gpt files
					$file =~ s/^pkg_data_//;	#strip off leading pkg_data_


	 				if (! defined $filtertype){
                		$filtertype="\w*";
            		}
            		if ($file =~ /$filtertype$/){
					push @packagetypelist, (join '-', $package,$file);
					#print "file is $package/$file \n";
					}
				}
			}
		}	
	}
	if (defined @packagetypelist){
#print Dumper @packagetypelist;
		return @packagetypelist;
	}
} #close query_all


		

sub AUTOLOAD {
	use vars qw($AUTOLOAD);
    my $self = shift;
    my $type = ref($self) || croak "$self is not an object";
    my $name = $AUTOLOAD;
    $name =~ s/.*://;   # strip fully-qualified portion
    unless (exists $self->{$name} ) {
        croak "Can't access `$name' field in object of class $type";
    } 
    if (@_) {
        return $self->{$name} = shift;
    } else {
        return $self->{$name};
    } 
}




END { }       # module clean-up code here (global destructor)
