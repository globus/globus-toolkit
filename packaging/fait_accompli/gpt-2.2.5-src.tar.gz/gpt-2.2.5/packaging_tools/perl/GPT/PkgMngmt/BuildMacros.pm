package Grid::GPT::PkgMngmt::BuildMacros;
use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;
require AutoLoader;
use Data::Dumper;
use Grid::GPT::PkgMngmt::Inform;
use Grid::GPT::PkgMngmt::ExpandSource;
use Grid::GPT::FilelistFunctions;
use Cwd;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw(
);
$VERSION = '0.01';

{
  my %environment;
  sub find_make {
    my ($self) = shift;
    return $environment{'make'} if defined $environment{'make'};
    for my $command ("make", "gmake") {
      my $result = `$command --version 2>/dev/null`;
      if ($result =~ /GNU/) {
	$environment{'make'} = $command;
	return $command;
      }
    }
    die "Could not find GNU make in your \$PATH\n";
  }
    
}

# Preloaded methods go here.
sub new {
  my ($class, %arg) = @_;
  my $me = {
            usermacros => $arg{'macros'},
            log => $arg{'log'},
            installed_flavors =>
            $arg{'installed_flavors'},
            flavor_choices =>
            $arg{'flavor_choices'},
            globusdir => $arg{'globusdir'},
	   };

  $me->{'CONFIGOPTS_GPTMACRO'} = $arg{'macros'}->{'CONFIGOPTS_GPTMACRO'};
  $me->{'BUILDDIR_GPTMACRO'} = $arg{'srcobj'}->{'srcdir'};
  $me->{'PATCHDIR_GPTMACRO'} = $arg{'srcobj'}->{'patchdir'};
  $me->{'GLOBUSDIR_GPTMACRO'} = $arg{'globusdir'}; 
  $me->{'ENV_GPTMACRO'} = "LDFLAGS='-L$arg{'globusdir'}/lib';";

  $me->{'STATIC_LINK_GPTMACRO'} = defined $arg{'static'} ? "yes" : "no";

  $me->{'INSTALLDIR_GPTMACRO'} = $me->{'GLOBUSDIR_GPTMACRO'};

  $me->{'filelist_funcs'} = 
    new Grid::GPT::FilelistFunctions(log => $arg{'log'},
                                     installdir => $me->{'INSTALLDIR_GPTMACRO'},
                                    );
  bless $me, $class;


  $me->{'MAKE_GPTMACRO'} = find_make();

  for my $m (sort keys %{$arg{'macros'}}) {
    $me->{$m} = $arg{'macros'}->{$m};
  }


  #setup the run macros
  $me->{'RUN_FLAVOR_INSTALL_GPTMACRO'} = sub {
    $me->{'flavored_filelist'} = 
      $me->{'filelist_funcs'}->flavor_install(srcdir => $arg{'srcobj'}->{'topsrcdir'},
                                              flavor => $_[0],
                                             );
  };
  $me->{'RUN_FLAVOR_MAKEFILES_GPTMACRO'} = sub {
    $me->flavor_makefiles(@_);
  };
  return $me;
}

sub override {
  my ($me, $macro, $value) = @_;
  $me->{'setasides'}->{$macro} = $me->{$macro};
  $me->{$macro} = $value;
}

sub default {
  my ($me, $macro) = @_;
  $me->{$macro} = $me->{'setasides'}->{$macro};
}

sub expand {
  my ($me, $buildstep, $flavor) = @_;
  my $command = $buildstep->{'command'};
  if ($command =~ m!(RUN_\w+_GPTMACRO)!s) {
    my $runsub = $1;
    if (defined($me->{$runsub})) {
      $me->{'log'}->inform($command);
      &{$me->{$runsub}}($flavor, $buildstep->{'args'});
      return undef;
    }
  }

  # substitute in flavored config options
  if (defined $flavor and $command =~ m!CONFIG\w+_GPTMACRO!) {
    my $opts = $me->setup_flavor_macros($flavor);
    $command =~ s!FLAVOR_CONFIGOPTS_GPTMACRO!$opts->{'switches'}!g 
      if defined $opts->{'switches'};
    $command =~ s!CONFIGENV_GPTMACRO!$opts->{'env'}!g if defined $opts->{'env'}
  }

  # set the flavor macro
  $me->{'FLAVOR_GPTMACRO'} = $flavor;

  # Substitute in the macro values.
  for my $m (sort keys %$me) {
    next if $m !~ m!GPTMACRO!;
    my $mvalue = $me->{$m};
    if ($m eq 'CONFIGOPTS_GPTMACRO') {
      $command =~ s!(\W)$m!$1$mvalue!g;
      $command =~ s!^$m!$mvalue!g;
    } else {
      $command =~ s!$m!$1$mvalue!g;
    }
  }
    
  # Remove undefined macros
  $command =~ s!\w+_GPTMACRO!!g;

  return $command;
}

sub setup_flavor_macros {
  my ($me, $flavor) = @_;
  my $m = "$ {flavor}_CONFIGOPTS_GPTMACRO";
  my $opts = {};

  if (defined $me->{'flavor_choices'}) {
    $opts = $me->{'installed_flavors'}->{$flavor}->
      translate_configure_line($me->{'flavor_choices'});
  } else {
    $opts->{'switches'} = $me->{$m};
  }

  $opts->{'env'} = $me->setup_env($flavor, $opts->{'env'});

  return $opts;
}

sub setup_env {
  my ($me, $flavor, $env) = @_;

  my %flavored_envs = map {split /=/, $_}
    split(/;/, defined $env ? $env : $me->{"$ {flavor}_ENV_GPTMACRO"});
  my %envs = map {split /=/, $_}
    split(/;/, $me->{"ENV_GPTMACRO"});

  for my $v (sort keys %flavored_envs ) {
#    print "Flavored ENV: $v = $flavored_envs{$v}\n";
    if (! defined $envs{$v}){
      $envs{$v} = $flavored_envs{$v};
      next;
    } else {
#      print "Normal ENV: $v = $envs{$v}\n";
    }
    $flavored_envs{$v} =~ s![\"\']!!g;
    $envs{$v} =~ s![\"\']!!g;
    $envs{$v} = "'$envs{$v} $flavored_envs{$v}'";
#    print "ENVs: $v = $envs{$v}\n";
  }

  my $envline;
  for my $v (sort keys %envs) {
    next if $v !~ m!\w!; 
    $envline .= "$v=$envs{$v}; export $v; ";
  }
  return $envline;
}

sub flavor_makefiles {
  my ($me, $flavor, $arglist) = @_;
  my $makesub = sub {$me->flavor_a_makefile(shift, $flavor, $arglist)};
  scan_for_makefiles($me->{'BUILDDIR_GPTMACRO'}, $makesub);
}

sub scan_for_makefiles {
  my ($dir, $sub) = @_;
  opendir(DIR, $dir);
  my @dirlist = readdir(DIR);
  close DIR;
  for my $f(@dirlist) {
    next if $f =~ m!^\.+!;
    &{$sub}("$dir/$f") if -f "$dir/$f";
    scan_for_makefiles("$dir/$f", $sub);
  }
}

sub flavor_a_makefile {
  my ($me, $file, $flavor, $arglist) = @_;

  return if $file !~ m![Mm]akefile(?:\.in)?! and 
    $file !~ m!configure! and
        $file !~ m!\.(?:mk|mak)! and # for openldap *.mk files
          $file !~ m!shlib/!; # openssl shared libarary creation script.

  return if $file =~ m!\.gpm_orig!;

  my (@libs, @regexes, $apos);
  while ($arglist =~ m!(\w+)\s*=\s*\'([^\']+)\'!g) {
    my ($name, $args, $apos) = ($1, $2, pos());
    if ($name eq 'libs') {
      my @mylibs = split m!\s+!, $args;
      push @libs,@mylibs;
    }
    if ($name eq "regex") {
      $args =~ m!(.*)FLAVOR(.*)!;
      push @regexes, {pre => $1, post => $2};
    }
    pos $apos;
  }


  my $bakfile = "$file.gpm_orig";

  my $result;

  if (! -f $bakfile) {
    $result = `mv $file $bakfile`;
#    $me->{'log'}->inform("Creating $bakfile");
  }


  local (*OLDFILE, *NEWFILE);
  open (OLDFILE, $bakfile) || die "Could not open $bakfile\n";
  open (NEWFILE, ">$file") || die "Could not open $file\n";

  $me->{'log'}->inform("Modifying $file");

  my $line;
  while ($line = <OLDFILE>) {
    my $newline = $line;

    for my $l (@libs) {
      $newline =~ s!-l$l(\W)!-l$ {l}_$flavor$1!g;
      $newline =~ s!lib$l([\$\.])!lib$ {l}_$flavor$1!g;
      $newline =~ s!lib$l(_la)!lib$ {l}_$ {flavor}$1!g;
    }
    for my $r (@regexes) {
#      print "|$newline| $r->{'pre'} $r->{'post'}\n" if $file =~ m!Makefile.org!;
      $newline =~ 
        s!\Q$r->{'pre'}$r->{'post'}\E!$r->{'pre'}_$flavor$r->{'post'}!g;
#      print "after:$newline" if $file =~ m!Makefile.org!;
    }
    print NEWFILE $newline
  }

  close NEWFILE;
  close OLDFILE;

  $result = `chmod 755 $file` if $file =~ m!configure!;

}
# Autoload methods go after =cut, and are processed by the autosplit program.

1;

__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::PkgMngmt:BuildMacros - Perl extension for managing globus-build macros..

=head1 SYNOPSIS

  use BuildMacros;
  $me->{'macros'} = new Grid::GPT::PkgMngmt::BuildMacros(srcobj => $arg{'srcobj'},
                                               globusdir => $arg{'globusdir'},
                                               flavors => $arg{'flavors'},
                                               macros => $macros,
                                               log => $me->{'log'},
                           static => $arg{'static'},
                                               installed_flavors =>
                                               $arg{'installed_flavors'},
                                               flavor_choices =>
                                               $arg{'flavor_choices'},
                                              );


  for my $bs (@build_instructions) {

    my $build_step = $me->{'macros'}->expand($bs,$flavor);

    next if ! defined $build_step;
   }

=head1 DESCRIPTION

b<Grid::GPT::PkgMngmt::BuildMacros> is used to manage build macros and expand
them inside a build instruction.


=head1 MACRO TYPES

b<Grid::GPT::PkgMngmt::BuildMacros> manages three different types of macros.

The first type is a simple expansion macro.  Which gets expanded with
the same value every time the macro is encountered.  BUILDDIR_GPTMACRO
is an example of this.

The second type are flavored macros. The value of these macros are
changed depending on the build flavor label.  An example of this is

=head1 MACROS

=over 4

=item CONFIGOPTS_GPTMACRO

This macro contains configuration options that are always invoked
regardless of the build flavor.

=item BUILDDIR_GPTMACRO

This macro contains the absolute path to the top level directory of
the source being built.

=item PATCHDIR_GPTMACRO

This macro contains the absolute path to the directory containing
patches for a source package.

=item GLOBUSDIR_GPTMACRO

This macro points to the directory containing all of the installed
files need to build a source package.  It also is the installation
location for the source package.  During the build process it contains
the same value as the environmental variable $GLOBUS_LOCATION.

=item CONFIGENV_GPTMACRO

This macro contains the environmental variables that are set before
running configure.  These variables are a combination of both flavored
and non-flavored variables.  The flavored variables are contained in
the macro flavor_ENV_GPTMACRO.  The non-flavored variables are
contained in the macro ENV_GPTMACRO.

  $me->{'ENV_GPTMACRO'} = "CPPFLAGS='-I$arg{'globusdir'}/include -I$arg{'globusdir'}/include/FLAVOR_GPTMACRO'; LDFLAGS='-L$arg{'globusdir'}/lib';";

  $me->{'STATIC_LINK_GPTMACRO'} = defined $arg{'static'} ? "yes" : "no";

  $me->{'INSTALLDIR_GPTMACRO'} = $me->{'GLOBUSDIR_GPTMACRO'};

  $me->{'MAKE_GPTMACRO'} = find_make();

  $me->{'RUN_FLAVOR_INSTALL_GPTMACRO'} = sub {
    $me->{'flavored_filelist'} = 
      $me->{'filelist_funcs'}->flavor_install(@_);
  };
  $me->{'RUN_FLAVOR_MAKEFILES_GPTMACRO'} = sub {

=back



=head1 METHODS

=over 4

=item new





=back

=head1 AUTHOR

A. U. Thor, a.u.thor@a.galaxy.far.far.away

=head1 SEE ALSO

perl(1).

=cut
