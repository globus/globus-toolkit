package Grid::GPT::PkgMngmt::BuildEnv; 
use strict; 
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;
require AutoLoader;
use Data::Dumper;
use Cwd;

@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
$VERSION = '0.01';

# Preloaded methods go here.
sub tar { return "/bin/gtar" };
sub gunzip {return "/usr/bin/gunzip"};
sub gzip {return "/usr/bin/gzip"};
sub mypackage {return "gpt"};
sub default_rpm_license {return "GPL"};

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::PkgMngmt:BuildEnv - Perl extension for archiving globus binaries.

=head1 SYNOPSIS

  use BuildEnv;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for BuildEnv was created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head1 AUTHOR

A. U. Thor, a.u.thor@a.galaxy.far.far.away

=head1 SEE ALSO

perl(1).

=cut
