/**********************************************
 * Developed by:
 * Grid Computing Group
 * Computer Science Department
 * University of Virginia
 *
 * Author: Glenn Wasson (wasson@virginia.edu) 
 **********************************************/

using System;
using System.Net;
using System.Net.Sockets;
using edu.virginia.cs.gcg.GSISockets;
using System.IO;
using System.Text;

namespace edu.virginia.cs.gcg.httpg 
{
	class HttpgWebResponse : WebResponse 
	{
		private GSISocket ss;
	
		Version protocolVersion;
		public Version ProtocolVersion 
		{
			get { return protocolVersion; }
			set { protocolVersion = value; }
		}

		HttpStatusCode statusCode;
		public HttpStatusCode StatusCode
		{
			get { return statusCode; }
			set { statusCode = value; }
		}

		string statusDescription;
		public string StatusDescription
		{
			get { return statusDescription;	}
			set { statusDescription = value; }
		}

		string contentEncoding;
		public string ContentEncoding
		{
			get
			{
				return contentEncoding;
			}
			set 
			{
				contentEncoding = value;
			}
		}

		DateTime lastModified;
		public DateTime LastModified
		{
			get 
			{
				return lastModified;
			}
			set 
			{
				lastModified = value;
			}
		}

		string server;
		public string Server 
		{
			get 
			{
				return server;
			}
			set 
			{
				server = value;
			}
		}

		long contentLength;
		public override long ContentLength
		{
			get
			{
				return contentLength;
			}
			set
			{
				contentLength = value;
			}
		}

		string contentType;
		public override string ContentType
		{
			get
			{
				return contentType;
			}
			set
			{
				contentType = value;
			}
		}

		WebHeaderCollection headers = null;
		public override WebHeaderCollection Headers
		{
			get
			{
				return headers;
			}
		}

		public HttpgWebResponse(GSISocket s) 
		{
			ss = s;
			headers = new WebHeaderCollection();
		}

		public override Stream GetResponseStream()
		{
			// check the headers to see if the encoding is chunked
			// - if so, we'll read the whole response in and pass out a memory stream
			// - otherwise, just return the real stream
			// A question: what if the encoding is not chunked, and yet 
			//             the content length is not set?

			string[] chunk = null;
			byte[] buf = null;

			chunk = headers.GetValues("Transfer-Encoding");
			if ((chunk != null) && (chunk.Length == 1) && (chunk[0] == "chunked")) 
			{
				buf = ReadChunkedResponse();
				MemoryStream ms = new MemoryStream(buf, false);
				return ((Stream) ms);
			}
			else
				return ((Stream) new NetworkStream(ss, FileAccess.Read, true));
		}

		private byte[] ReadChunkedResponse()
		{
			// read in the buffer and decode it
			// - store it in a byte array
			byte[] junk = new Byte[1];
			int chunkSize;
			String msg = null;

			chunkSize = ReadChunkSize();
			while (chunkSize != 0) 
			{
				byte[] chunk = new byte[chunkSize];
				ss.Receive(chunk);
				// after chunksize bytes, there should be a CRLF or just an LF
				ss.Receive(junk);
				if (junk[0] == (byte)13)
					ss.Receive(junk);
				// what if junk is not an LF?
				msg += Encoding.ASCII.GetString(chunk);
				chunkSize = ReadChunkSize();
			}

			// since strings are dynamically sized, it is easier to store the chunks
			// in a string and then convert the string back to a buffer of bytes
			return Encoding.ASCII.GetBytes(msg);
		}


		private int ReadChunkSize() 
		{
			// read bytes until you get the CRLF (13 and 10)
			// then return the data before that
			byte[] b = new byte[1];
			byte[] buf = new byte[10];
			bool notDone = true;
			int numRead, i, mul = 1, val = 0, ptr = 0;
			string crap = null;

			while (notDone) 
			{
				numRead = 0;
				numRead = ss.Receive(b);
				// scan for the chars
				if ((numRead == 1) && (b[0] == (byte)13))
				{
					ss.Receive(b);
					if ((b[0] == (byte)10) || (b[0] == (byte)';')) 
					{
						// if we read either an LF (which is the end of line for sure)
						// or a ; (which is the start of the extra params), 
						// we can stop counting the chunk size
						if (ptr == 0) return 0;
					
						for (i=ptr-1; i >= 0; i--)
						{
							if (isValid(buf[i])) 
							{
								// skip invalid start bytes (like CR)
								val += fromHex(buf[i]) * mul;
								mul *= 16;
							}
							// if it's not valid, what do we do?
						}
						return val;
					}
					else 
					{
						buf[ptr] = (byte)13;
						ptr++;
					}
				}
				else 
				{
					buf[ptr] = b[0];
					ptr++;
					crap = Encoding.ASCII.GetString(buf);
				}
			}

			return 0;
		}

		private bool isValid(byte b)
		{
			// checks if this byte represents a valid hex char
			string validChars = "0123456789abcdefABCDEF";

			if (validChars.IndexOf(Convert.ToChar(b)) != -1)
				return true;
			else
				return false;
		}

		private int fromHex(byte b) 
		{
			if ((b < 65) && (b >= 48)) 
			{
				byte[] arr = new byte[1];
				arr[0] = b;
				return Convert.ToInt32(Encoding.ASCII.GetString(arr));
			}

			switch (b)
			{
				case 65:	// A
					return 10;
				case 97:	// a
					return 10;
				case 66:
					return 11;
				case 98:
					return 11;
				case 67:
					return 12;
				case 99:
					return 12;
				case 68:
					return 13;
				case 100:
					return 13;
				case 69:
					return 14;
				case 101:
					return 14;
				case 70:
					return 15;
				case 102:
					return 15;
				default:
					return -1;
			}
		}

		public void AddHeader (string value)
		{
			// should have a more private way to do this since
			// the headers property is supposed to be 'get' only
			// - this means we'd have to parse up all the HTTP 
			//   headers before creating an HttpgWebResponse
			headers.Add(value);
		}

		public void AddHeader (string key, string value)
		{
			headers.Add(key, value);
		}
	}

}