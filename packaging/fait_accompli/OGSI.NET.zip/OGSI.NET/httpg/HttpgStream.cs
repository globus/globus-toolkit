/**********************************************
 * Developed by:
 * Grid Computing Group
 * Computer Science Department
 * University of Virginia
 *
 * Author: Glenn Wasson (wasson@virginia.edu) 
 **********************************************/

using System;
using edu.virginia.cs.gcg.GSISockets;
using System.Net.Sockets;
using System.IO;
using System.Text;

namespace edu.virginia.cs.gcg.httpg
{
	/// <summary>
	/// Summary description for HttpgStream.
	/// - Handles setting the Content-Length attribute of the HTTP request
	/// - In future versions, the SoapHttpClientProtocol class should correctly
	///   handle this for non-built in protocols
	/// </summary>
	public class HttpgStream : MemoryStream
	{
		private string headersSoFar = null;
		private GSISocket ss;

		public HttpgStream(GSISocket sock, string headers) : base()
		{
			ss = sock;
			headersSoFar = headers;
		}

		public override void Close()
		{
			// ok, we're going to close this memory stream, but first we need to
			// 1. figure the length of the data in the stream
			// 2. send the headers complete with the Content-Length
			// 3. send the contents of the memory stream
			char[] trimChars = new Char[1];
			trimChars[0] = (char) 0x0;

			byte[] buf = this.GetBuffer();
			// This is tricky... the size of the buffer is its capacity and not the length of
			// the data in the buffer. Convert it to a string and trim() to get that info.
			string bufStr = Encoding.ASCII.GetString(buf);
			int buflen = bufStr.TrimEnd(trimChars).Length;
			headersSoFar += "Content-Length: " + Convert.ToString(buflen) + "\r\n\r\n"; // add an extra blank line too
			ss.Send(Encoding.ASCII.GetBytes(headersSoFar));
			ss.Send(buf, buflen, SocketFlags.None);
			base.Close();
		}
	}
}
