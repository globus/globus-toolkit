/**********************************************
 * Developed by:
 * Grid Computing Group
 * Computer Science Department
 * University of Virginia
 *
 * Author: Glenn Wasson (wasson@virginia.edu) 
 **********************************************/


using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Runtime.InteropServices;

namespace edu.virginia.cs.gcg.GSISockets {
	/// <summary>
	/// Specifies all the possible security protocols.
	/// </summary>
	/// <remarks>TLSv1 and SSLv3 are currently the most widely used security protocols.</remarks>
	public enum SecurityType : int {
		/// <summary>No security will be used; the SecuritySocket will act as a normal Socket.</summary>
		None = 0,
		/// <summary>SSL version 2 will be used.</summary>
		SSLv2 = 2,
		/// <summary>SSL version 3 will be used.</summary>
		SSLv3 = 3,
		/// <summary>TLS version 1 will be used.</summary>
		TLSv1 = 1
	}

	public class GSISocket : Socket {
		/// <summary>
		/// Initializes the TLS/SSL library.
		/// </summary>
		/// <returns>Returns zero when successful or a negative number otherwise.</returns>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureInit")]	
		protected static extern int SecureInit();
		/// <summary>
		/// Initializes the SSL_DATA structure to use during the connection.
		/// </summary>
		/// <param name="socket">The handle of the Socket that will be used for the connection.</param>
		/// <param name="method">
		/// The security protocol to use. It can be one of the following values:
		/// <list type="table">
		///	 <listheader>
		///	  <term>Value</term>
		///   <description>Description</description>
		///  </listheader>
		///  <item>
		///   <term>1</term>
		///   <description>Transport Layer Security (TLS) version 1</description>
		///  </item>
		///  <item>
		///   <term>2</term>
		///   <description>Secure Socket Layer (SSL) version 2</description>
		///  </item>
		///  <item>
		///   <term>3</term>
		///   <description>Secure Socket Layer (SSL) version 3</description>
		///  </item>
		/// </list>
		/// </param>
		/// <param name="errcode">A buffer to hold error messages strings.</param>
		/// <param name="errcodesize">The capacity of the error message buffer.</param>
		/// <returns>Returns a valid IntPtr when successful, IntPtr.Zero otherwise.</returns>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureStart")]	
		protected static extern IntPtr SecureStart(IntPtr socket, int method, StringBuilder errcode, int errcodesize);
		/// <summary>
		/// Initiate the TLS/SSL handshake with an TLS/SSL server.
		/// </summary>
		/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
		/// <returns>Returns zero when successful, or a negative number otherwise.</returns>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureNegotiate")]	
		protected static extern int SecureNegotiate(IntPtr ssldata);
		/// <summary>
		/// Transmits data securely to the server.
		/// </summary>
		/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
		/// <param name="buffer">The buffer of bytes to send to the remote server.</param>
		/// <param name="length">The number of bytes in the buffer.</param>
		/// <returns>Returns zero when successful, or a negative number otherwise.</returns>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureWrite")]	
		protected static extern int SecureWrite(IntPtr ssldata, byte [] buffer, int length);

		/// <summary>
		/// Performs delegation of GSI credentials
		/// </summary>
		/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
		/// <param name="errCode">A buffer to hold error message strings.</param>
		/// <param name="errCodeSize">The capacity of the error message buffer.</param>
		/// <returns>1 on success, 0 on failure</returns>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureDelegate")]	
		protected static extern int SecureDelegate(IntPtr ssldata, StringBuilder errCode, int errCodeSize);

		/// <summary>
		/// Receives data from the server.
		/// </summary>
		/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
		/// <param name="buffer">The storage location for the received data.</param>
		/// <param name="length">The maximum number of bytes to receive.</param>
		/// <returns>
		/// This method can return one of the following values:
		/// <list type="table">
		///	 <listheader>
		///	  <term>Value</term>
		///   <description>Description</description>
		///  </listheader>
		///  <item>
		///   <term>&gt;0</term>
		///   <description>The read operation was successful; the return value is the number of bytes actually read from the TLS/SSL connection.</description>
		///  </item>
		///  <item>
		///   <term>0</term>
		///   <description>The read operation was not successful. The reason may either be a clean shutdown due to a "close notify" alert sent by the peer. It is also possible, that the peer simply shut down the underlying transport and the shutdown is incomplete.</description>
		///  </item>
		///  <item>
		///   <term>&lt;0</term>
		///   <description>The read operation was not successful, because either an error occurred or action must be taken by the calling process.</description>
		///  </item>
		/// </list>
		/// </returns>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureRead")]	
		protected static extern int SecureRead(IntPtr ssldata, byte [] buffer, int length);
		/// <summary>
		/// Uninitializes the SSL_DATA structure.
		/// </summary>
		/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureEnd")]	
		protected static extern void SecureEnd(IntPtr ssldata);
		/// <summary>
		/// Uninitializes the TLS/SSL library.
		/// </summary>
		[DllImport(@"GSISocketLib.dll", EntryPoint="SecureExit")]	
		protected static extern void SecureExit();
		/// <summary>
		/// Initializes the SSL library.
		/// </summary>
		/// <remarks>Applications that use the SecureSocket class must always call this method at startup (before using a SecureSocket).</remarks>
		public static void Initialize() {
			if (!Initialized) {
				if (SecureInit() < 0)
					throw new System.ComponentModel.Win32Exception(0, "WinSock failed to initialize.");
				Initialized = true;
			}
		}
		/// <summary>
		/// Uninitializes the SSL library.
		/// </summary>
		/// <remarks>Applications that use the SecureSocket class should always call this method before terminating.</remarks>
		public static void CleanUp() {
			if (Initialized) {
				SecureExit();
				Initialized = false;
			}
		}
		/// <summary>
		/// Initializes a new instance of the Socket class.
		/// </summary>
		/// <param name="addressFamily">One of the AddressFamily values.</param>
		/// <param name="socketType">One of the SocketType values.</param>
		/// <param name="protocolType">One of the ProtocolType values. </param>
		/// <exception cref="SocketException">The combination of addressFamily, socketType, and protocolType results in an invalid socket.</exception>
		/// <remarks>The SecurityType property of this SecureSocket will default to SecurityType.None.</remarks>
		public GSISocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType) : this(addressFamily, socketType, protocolType, SecurityType.None) {}
		/// <summary>
		/// Initializes a new instance of the Socket class.
		/// </summary>
		/// <param name="addressFamily">One of the AddressFamily values.</param>
		/// <param name="socketType">One of the SocketType values.</param>
		/// <param name="protocolType">One of the ProtocolType values. </param>
		/// <param name="securityType">Specifies the security protocol to use.</param>
		/// <exception cref="SocketException">The combination of addressFamily, socketType, and protocolType results in an invalid socket.</exception>
		public GSISocket(AddressFamily addressFamily, SocketType socketType, ProtocolType protocolType, SecurityType securityType) : base(addressFamily, socketType, protocolType) {
			StringBuilder ecode = new StringBuilder();
			ecode.EnsureCapacity(500);
			if (securityType != SecurityType.None) {
				if (protocolType != ProtocolType.Tcp || socketType != SocketType.Stream)
					throw new SocketException();
			}
			m_SecurityType = securityType;
			if (SecurityType != SecurityType.None) {
				SecurityData = SecureStart(this.Handle, (int)SecurityType, ecode, ecode.Capacity);
				if (SecurityData == IntPtr.Zero) 
				{
					// This code used to throw a SocketException(), but this often resulted in the error message
					// "the operation completed successfully". It now throws an ApplicationException() and shows
					// info from the OpenSSL library.
					//throw new SocketException();
					throw new ApplicationException(ecode.ToString());
				}
			}
		}
		/// <summary>
		/// Establishes a connection to a remote device.
		/// </summary>
		/// <param name="remoteEP">An EndPoint that represents the remote device.</param>
		/// <exception cref="ArgumentNullException">The remoteEP parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the Socket or the negotiation failed.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>If the SecurityType property is set to either SSL or TLS, the SecureSocket will start negotiating with the server.</remarks>
		public new void Connect(EndPoint remoteEP) {
			base.Connect(remoteEP);
			if (this.SecurityType != SecurityType.None)
				if (!Initialized)
					throw new SocketException();
				int res = SecureNegotiate(SecurityData);
				if (res < 0)
					throw new SocketException();
		}
		/// <summary>
		/// Sends data to a connected Socket, starting at the indicated location in the data.
		/// </summary>
		/// <param name="buffer">The data to be sent.</param>
		/// <returns>The number of bytes sent to the Socket.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will transmit data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Send(byte[] buffer) {
			if (buffer == null)
				throw new ArgumentNullException();
			return Send(buffer, 0, buffer.Length, SocketFlags.None);
		}
		/// <summary>
		/// Sends data to a connected Socket, starting at the indicated location in the data.
		/// </summary>
		/// <param name="buffer">The data to be sent.</param>
		/// <param name="socketFlags">A bitwise combination of the SocketFlags values.</param>
		/// <returns>The number of bytes sent to the Socket.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will transmit data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Send(byte[] buffer, SocketFlags socketFlags) {
			if (buffer == null)
				throw new ArgumentNullException();
			return Send(buffer, 0, buffer.Length, socketFlags);
		}
		/// <summary>
		/// Sends data to a connected Socket, starting at the indicated location in the data.
		/// </summary>
		/// <param name="buffer">The data to be sent.</param>
		/// <param name="size">The number of bytes to send.</param>
		/// <param name="socketFlags">A bitwise combination of the SocketFlags values.</param>
		/// <returns>The number of bytes sent to the Socket.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will transmit data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Send(byte[] buffer, int size, SocketFlags socketFlags) {
			if (buffer == null)
				throw new ArgumentNullException();
			return Send(buffer, 0, size, socketFlags);
		}
		/// <summary>
		/// Sends data to a connected Socket, starting at the indicated location in the data.
		/// </summary>
		/// <param name="buffer">The data to be sent.</param>
		/// <param name="offset">The position in the data buffer to begin sending data.</param>
		/// <param name="size">The number of bytes to send.</param>
		/// <param name="socketFlags">A bitwise combination of the SocketFlags values.</param>
		/// <returns>The number of bytes sent to the Socket.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will transmit data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Send(byte[] buffer, int offset, int size, SocketFlags socketFlags) {
			if (SecurityType != SecurityType.None) {
				if (buffer == null)
					throw new ArgumentNullException();
				if (offset < 0 || offset >= buffer.Length || size > buffer.Length - offset)
					throw new ArgumentException();
				if (!Initialized)
					throw new SocketException();
				int ret;
				if (offset == 0) {
					ret = SecureWrite(SecurityData, buffer, size);
					if (ret < 0)
						throw new SocketException();
					return ret;
				} else {
					byte[] tosend = new byte[size];
					Array.Copy(buffer, offset, tosend, 0, size);
					ret = SecureWrite(SecurityData, tosend, size);
					if (ret < 0)
						throw new SocketException();
					return ret;
				}
			} else {
				return base.Send(buffer, offset, size, socketFlags);
			}
		}

		/// <summary>
		/// Performs delegation of GSI credentials
		/// </summary>
		/// <returns>1 for success, 0 for failure</returns>
		public int PerformDelegation()
		{
			StringBuilder errBuf = new StringBuilder();
			errBuf.EnsureCapacity(500);
			int ret = SecureDelegate(SecurityData, errBuf, errBuf.Capacity);
			if (ret != 1)
				throw new ApplicationException(errBuf.ToString());
			return ret;
		}

		/// <summary>
		/// Receives data from a connected Socket in a specific location of the receive buffer.
		/// </summary>
		/// <param name="buffer">The storage location for received data.</param>
		/// <returns>The number of bytes received.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will receive data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Receive(byte[] buffer) {
			if (buffer == null)
				throw new ArgumentNullException();
			return Receive(buffer, 0, buffer.Length, SocketFlags.None);
		}

		/// <summary>
		/// Receives data from a connected Socket in a specific location of the receive buffer.
		/// </summary>
		/// <param name="buffer">The storage location for received data.</param>
		/// <param name="socketFlags">A bitwise combination of the SocketFlags values.</param>
		/// <returns>The number of bytes received.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will receive data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Receive(byte[] buffer, SocketFlags socketFlags) {
			if (buffer == null)
				throw new ArgumentNullException();
			return Receive(buffer, 0, buffer.Length, socketFlags);
		}

		/// <summary>
		/// Receives data from a connected Socket in a specific location of the receive buffer.
		/// </summary>
		/// <param name="buffer">The storage location for received data.</param>
		/// <param name="size">The number of bytes to receive.</param>
		/// <param name="socketFlags">A bitwise combination of the SocketFlags values.</param>
		/// <returns>The number of bytes received.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will receive data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Receive(byte[] buffer, int size, SocketFlags socketFlags) {
			if (buffer == null)
				throw new ArgumentNullException();
			return Receive(buffer, 0, size, socketFlags);
		}

		/// <summary>
		/// Receives data from a connected Socket in a specific location of the receive buffer.
		/// </summary>
		/// <param name="buffer">The storage location for received data.</param>
		/// <param name="offset">The location in buffer to store the received data.</param>
		/// <param name="size">The number of bytes to receive.</param>
		/// <param name="socketFlags">A bitwise combination of the SocketFlags values.</param>
		/// <returns>The number of bytes received.</returns>
		/// <exception cref="ArgumentNullException">The buffer parameter is a null reference (Nothing in Visual Basic).</exception>
		/// <exception cref="ArgumentOutOfRangeException">The offset or size parameter exceeds the size of buffer.</exception>
		/// <exception cref="SocketException">An operating system error occurs while accessing the socket or the SSL library hasn't been initialized.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		/// <remarks>This method will receive data in a secure manner if the SecurityType property is set to either SSL or TLS. If the SecurityType property is set to None, it will act like a normal Socket.</remarks>
		public new int Receive(byte[] buffer, int offset, int size, SocketFlags socketFlags) {
			if (SecurityType != SecurityType.None) {
				if (buffer == null)
					throw new ArgumentNullException();
				if (offset < 0 || offset >= buffer.Length || size > buffer.Length - offset)
					throw new ArgumentException();
				if (!Initialized)
					throw new SocketException();
				if (offset == 0) {
					return SecureRead(SecurityData, buffer, size);
				} else {
					byte[] received = new byte[size];
					int ret = SecureRead(SecurityData, received, size);;
					Array.Copy(received, 0, received, offset, size);
					return ret;
				}
			} else {
				return base.Receive(buffer, offset, size, socketFlags);
			}
		}
		/// <summary>
		/// Disables sends and receives on a Socket.
		/// </summary>
		/// <param name="how">The SocketShutdown value specifying the operation that will no longer be allowed.</param>
		/// <exception cref="SocketException">An error occurs while closing the Socket.</exception>
		/// <exception cref="ObjectDisposedException">The Socket has been closed.</exception>
		public new void Shutdown(SocketShutdown how) {
			SecureEnd(SecurityData);
			SecurityData = IntPtr.Zero;
			base.Shutdown(how);
		}
		/// <summary>
		/// Forces a Socket connection to close.
		/// </summary>
		public new void Close() {
			if (SecurityData != IntPtr.Zero) {
				SecureEnd(SecurityData);
				SecurityData = IntPtr.Zero;
			}
			base.Close();
		}
		/// <summary>
		/// Disposes of the unmanaged resources (other than memory) used by the Socket, and optionally disposes of the managed resources.
		/// </summary>
		~GSISocket() {
			if (SecurityData != IntPtr.Zero) {
				SecureEnd(SecurityData);
				SecurityData = IntPtr.Zero;
			}		
		}
		/// <summary>
		/// Gets the security protocol to use.
		/// </summary>
		/// <value>One of the SecurityType values.</value>
		public SecurityType SecurityType {
			get {
				return m_SecurityType;
			}
		}
		/// <summary>
		/// Gets or sets the pointer to the SSL data.
		/// </summary>
		/// <value>An IntPtr pointing to an SSL_DATA structure.</value>
		protected IntPtr SecurityData {
			get {
				return m_SecurityData;
			}
			set {
				m_SecurityData = value;
			}
		}
		/// <summary>
		/// Gets or sets a value that indicates whether the SSL library has been initialized or not.
		/// </summary>
		/// <value>A boolean value that indicates whether the SSL library has been initialized or not.</value>
		protected static bool Initialized {
			get {
				return m_Initialized;
			}
			set {
				m_Initialized = value;
			}
		}
		/// <summary>
		/// Retruns a value that indicates whether the Secure Socket library has been initialized or not.
		/// </summary>
		/// <returns>True if the SSL library has been initialized, false otherwise.</returns>
		public static bool IsInitialized() {
			return Initialized;
		}
		// private variables
		/// <summary>Holds the value of the SecurityType property.</summary>
		private SecurityType m_SecurityType;
		/// <summary>Holds the value of the SecurityData property.</summary>
		private IntPtr m_SecurityData;
		/// <summary>Holds the value of the Initialized property.</summary>
		private static bool m_Initialized;
	}
}