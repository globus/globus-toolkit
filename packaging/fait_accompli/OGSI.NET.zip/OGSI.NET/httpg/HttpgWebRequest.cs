/**********************************************
 * Developed by:
 * Grid Computing Group
 * Computer Science Department
 * University of Virginia
 *
 * Author: Glenn Wasson (wasson@virginia.edu) 
 **********************************************/

using System;
using System.Net;
using System.Net.Sockets;
using edu.virginia.cs.gcg.GSISockets;
using System.Runtime.InteropServices;
using System.IO;
using System.Text;
using edu.virginia.cs.gcg.httpg;

namespace edu.virginia.cs.gcg.httpg 
{
	public class HttpgWebRequest : WebRequest, IWebRequestCreate
	{
		private GSISocket ss;
		private HttpgStream theStream;
		Uri requestUri;

		public override Uri RequestUri
		{
			get 
			{
				return requestUri;
			}
		}

		int timeout;
		public override int Timeout
		{
			get { return timeout; }
			set { timeout = value; }
		}

		string method;
		public override string Method
		{
			get 
			{
				return method;
			}
			set
			{
				method = value;
			}
		}

		WebHeaderCollection headers;
		public override WebHeaderCollection Headers
		{
			get
			{
				return headers;
			}
			set
			{
				headers = value;
			}
		}

		long contentLength;
		public override long ContentLength
		{
			get
			{
				return contentLength;
			}
			set
			{
				contentLength = value;
			}
		}

		string contentType;
		public override string ContentType
		{
			get
			{
				return contentType;
			}
			set
			{
				contentType = value;
			}
		}

		ICredentials credentials;
		public override ICredentials Credentials
		{
			get
			{
				return credentials;
			}
			set
			{
				credentials = value;
			}
		}

		bool preAuthenticate;
		public override bool PreAuthenticate
		{
			get 
			{
				return preAuthenticate;
			}
			set 
			{
				preAuthenticate = value;
			}
		}

		string connectionGroupName;
		public override string ConnectionGroupName 
		{
			get
			{
				return connectionGroupName;
			}
			set
			{
				connectionGroupName = value;
			}
		}

		bool sendChunked;
		public bool SendChunked
		{
			get
			{
				return sendChunked;
			}
			set
			{
				sendChunked = value;
			}
		}

		string userAgent;
		public string UserAgent
		{
			get 
			{
				return userAgent;
			}
			set
			{
				userAgent = value;
			}
		}

		bool keepAlive;
		public bool KeepAlive
		{
			get
			{
				return keepAlive;
			}
			set
			{
				keepAlive = value;
			}
		}

		string expect;
		public string Expect
		{
			get
			{
				return expect;
			}
			set
			{
				if (value == null)
					expect = "100-continue";
				else
					expect += " " + value;
			}
		}

		public HttpgWebRequest() 
		{
			theStream = null;
			ss = null;
			connectionGroupName = null;
			sendChunked = false;
			expect = "100-continue";
			keepAlive = true;
		}

		public new WebRequest Create(Uri uri) 
		{
			// don't actually open the stream here because some properties may need to be set before
			// openning a stream (the caller will open it with GetRequestStream() or it will be opened
			// when GetResponse() is called)
			GSISocket.Initialize();
			HttpgWebRequest wr = new HttpgWebRequest();
			wr.requestUri = uri;
			wr.headers = new WebHeaderCollection();
			return ((WebRequest) wr);
		}

		public override Stream GetRequestStream() 
		{
			// create a SecureSocket and connect it to the peer
			// then cast that socket to a stream to return from request
			// - you need to send data on this stream for this class to work
			byte[] headline = new byte[512];
			String headlineStr = null;
			int duh;

			if (theStream != null)
				return theStream;

			// currently, only SSLv3 over TCP is supported
			String hostname = RequestUri.Host;
			int portnum = RequestUri.Port;		// normally should be 8443

			try 
			{
				ss = new GSISocket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp, SecurityType.SSLv3);
				ss.Connect(new IPEndPoint(Dns.Resolve(hostname).AddressList[0], portnum));
				duh = ss.PerformDelegation();
			} 
			catch (Exception e) 
			{
				System.Console.WriteLine("the following error occurred in connecting the GSISocket: " + e.ToString());
			}

			// build the http headers across to start the request
			if (method == "POST") 
			{
				headlineStr = "POST " + RequestUri.AbsolutePath + RequestUri.Query + " HTTP/1.1\r\n" + 
					"Host: " + RequestUri.Host + ":" + RequestUri.Port + "\r\n";

				// content type header
				headlineStr += "Content-Type: " + contentType + "\r\n";
				// send keep alive if requested
				if (keepAlive)
					headlineStr += "Connection: Keep-Alive\r\n";
				// send expect header
				headlineStr += "Expect: " + expect + "\r\n";

				// send anything in the headers array
				for (int i=0; i<headers.Count; i++) 
				{
					headlineStr += headers.GetKey(i) + ": " + headers.GetValues(i)[0] + "\r\n";
				}
			}
			else if (method == "GET")
			{
			}
			else
				throw new InvalidOperationException("Invalid Method Type: " + method);

			theStream = new HttpgStream(ss, headlineStr);
			return (Stream) theStream;
		}

		public override IAsyncResult BeginGetRequestStream(AsyncCallback cb, Object state)
		{
			IAsyncResult r = null;
			return r;
		}

		public override Stream EndGetRequestStream(IAsyncResult result)
		{
			Stream s = null;
			return s;
		}

		public override IAsyncResult BeginGetResponse(AsyncCallback cb, Object state)
		{
			IAsyncResult r = null;
			return r;
		}

		public override WebResponse EndGetResponse(IAsyncResult result) 
		{
			HttpgWebResponse httpgWebResp = null;
			return httpgWebResp;
		}

		private int FindNextEndOfLine(byte[] buf, int startAt, ref bool crlf) 
		{
			for (int i=startAt; i<buf.Length-1; i++)
				if (buf[i] == 10) 
				{
					if ((i >= 1) && (buf[i-1] == 13)) 
					{
						crlf = true;
						return i-1;
					}
					else 
					{
						crlf = false;
						return i;
					}
				}

			crlf = false;
			return -1;
		}

		private byte[] ReadHeaderBuf(GSISocket ss)
		{
			// read all the header lines and the CRLF that follows them
			byte[] headerlines = new byte[4096];
			byte[] b = new byte[1];
			int numRead = 0, ptr = 0, lastLineStart = 0;

			while (true) 
			{
				numRead = 0;
				numRead = ss.Receive(b);
				// scan for the chars (first the CR)
				if ((numRead == 1) && (b[0] == (byte)13))
				{
					ss.Receive(b);
					if (b[0] == (byte)10) 
					{
						if (lastLineStart == ptr)
							return headerlines;
						else
						{
							// add CRLF to the buffer
							headerlines[ptr++] = (byte)13;
							headerlines[ptr++] = (byte)10;
							lastLineStart = ptr;
						}
					}
					else 
					{
						headerlines[ptr] = (byte)13;
						ptr++;
					}
				}
				else if ((numRead == 1) && (b[0] == (byte)10)) 
				{
					// although HTTP lines should end with CRLF, sometimes it's just LF
					if (lastLineStart == ptr)
						return headerlines;
					else
					{
						headerlines[ptr++] = (byte)10;
						lastLineStart = ptr;
					}
				}
				else 
				{
					headerlines[ptr] = b[0];
					ptr++;
					string crap = Encoding.ASCII.GetString(headerlines);
				}
			}
		}

		private void ReadHeader(HttpgWebResponse webResp)
		{
			int ptr = 0, ptr2 = 0;
			byte[] headerBuf = null;
			String headerLine = null;
			String[] headerLineParts = new String[2];
			String[] timeFormats = {"F", "f", "G", "g"};
			// I set this to be British style because the times are GMT
			System.IFormatProvider format =
				new System.Globalization.CultureInfo("en-GB", true);
			string respStat = null;
			string[] respParts = null;
			bool crlfEOL = false;

			headerBuf = ReadHeaderBuf(ss);
			// hope that we've read the full header now... if not, we'll figure it out
			ptr = FindNextEndOfLine(headerBuf, 0, ref crlfEOL);
			// the first line should always be the response code line
			respStat = Encoding.ASCII.GetString(headerBuf, 0, ptr);
			respParts = respStat.Split(new char[]{' '}, 3);		

			// if we got the "continue" header, just ignore it and read the headers again
			while (StringToStatus(respParts[1]) == HttpStatusCode.Continue) 
			{
				headerBuf = ReadHeaderBuf(ss);
				// hope that we've read the full header now... if not, we'll figure it out
				ptr = FindNextEndOfLine(headerBuf, 0, ref crlfEOL);
				respStat = Encoding.ASCII.GetString(headerBuf, 0, ptr);
				respParts = respStat.Split(new char[]{' '}, 3);
			}
		
			if (crlfEOL == true)
				ptr = ptr + 2;
			else
				ptr = ptr + 1;

			// - respParts[0] is the html version
			respParts[0].Trim();
			if (respParts[0] == "HTTP/1.0")
				webResp.ProtocolVersion = HttpVersion.Version10;
			else if (respParts[0] == "HTTP/1.1")
				webResp.ProtocolVersion = HttpVersion.Version11;
		
			// respParts[1] is the status code
			webResp.StatusCode = StringToStatus(respParts[1]);

			// respParts[2] is the description of the status (e.g. OK)
			webResp.StatusDescription = String.Copy(respParts[2]);

			// get header lines
			while (true) 
			{
				ptr2 = FindNextEndOfLine(headerBuf, ptr, ref crlfEOL);
				if (ptr2 == -1)
					break;
				headerLine = Encoding.ASCII.GetString(headerBuf, ptr, ptr2-ptr);

				// set some properties based on this header
				if (headerLine.StartsWith("Content-Length:"))
					webResp.ContentLength = (long) Convert.ToInt64(headerLine.Substring(15, headerLine.Length-15));
				else if (headerLine.StartsWith("Content-Type:")) 
				{
					webResp.ContentType = headerLine.Substring(13, headerLine.Length-13).Trim();
				}
				else if (headerLine.StartsWith("Content-Encoding:")) 
				{
					webResp.ContentEncoding = headerLine.Substring(18, headerLine.Length - 18).Trim();
				}
				else if (headerLine.StartsWith("Last-Modified:")) 
				{
					webResp.LastModified = DateTime.ParseExact(headerLine.Substring(14, headerLine.Length-14), timeFormats, format, 
						System.Globalization.DateTimeStyles.AllowWhiteSpaces);
				}
				else if (headerLine.StartsWith("Server:")) 
				{
					webResp.Server = headerLine.Substring(7, headerLine.Length-7).Trim();
				}
				else if (headerLine.StartsWith("Date:")) 
				{
					// this one is a problem because we can't merely stick it in the headers
					// - the # of :'s in the date string messes it up since it is searching
					//   for two parts seperated by 1 colon
					// - also note that Date is a string and not a DateTime since it's 
					//   going into the general "headers" and not a specific property of
					//   the HttpgWebResponse
					string tempDate = headerLine.Substring(5, headerLine.Length-5).Trim();
					webResp.AddHeader("Date", tempDate);
				}
				else 
				{
					webResp.AddHeader(headerLine);
				}

				if (crlfEOL == true)
					ptr = ptr2+2;
				else
					ptr = ptr2+1;
			}
		}

		public override WebResponse GetResponse() 
		{
			// if we have not called GetRequestStream, do it now
			HttpgWebResponse webResp = null;

			if (theStream == null)
				theStream = (HttpgStream) GetRequestStream();

			// read the response header
			webResp = new HttpgWebResponse(ss);
			ReadHeader(webResp);

			// we'll read the main body when the client calls webResp.GetResponseStream()
			return webResp;
		}

		private HttpStatusCode StringToStatus(String stat)
		{
			int statval = Convert.ToInt32(stat);
			switch (statval) 
			{
				case 200: return HttpStatusCode.OK;
				case 404: return HttpStatusCode.NotFound;
				case 500: return HttpStatusCode.InternalServerError;
				case 100: return HttpStatusCode.Continue;
				case 202: return HttpStatusCode.Accepted;
				case 300: return HttpStatusCode.Ambiguous;
				case 502: return HttpStatusCode.BadGateway;
				case 400: return HttpStatusCode.BadRequest;
				case 409: return HttpStatusCode.Conflict;
				case 201: return HttpStatusCode.Created;
				case 417: return HttpStatusCode.ExpectationFailed;
				case 403: return HttpStatusCode.Forbidden;
				case 504: return HttpStatusCode.GatewayTimeout;
				case 410: return HttpStatusCode.Gone;
				case 505: return HttpStatusCode.HttpVersionNotSupported;
				case 411: return HttpStatusCode.LengthRequired;
				case 405: return HttpStatusCode.MethodNotAllowed;
				case 301: return HttpStatusCode.Moved;
				case 204: return HttpStatusCode.NoContent;
				case 203: return HttpStatusCode.NonAuthoritativeInformation;
				case 406: return HttpStatusCode.NotAcceptable;
				case 501: return HttpStatusCode.NotImplemented;
				case 304: return HttpStatusCode.NotModified;
				case 206: return HttpStatusCode.PartialContent;
				case 402: return HttpStatusCode.PaymentRequired;
				case 412: return HttpStatusCode.PreconditionFailed;
				case 407: return HttpStatusCode.ProxyAuthenticationRequired;
				case 302: return HttpStatusCode.Redirect;
				case 307: return HttpStatusCode.RedirectKeepVerb;
				case 303: return HttpStatusCode.RedirectMethod;
				case 416: return HttpStatusCode.RequestedRangeNotSatisfiable;
				case 413: return HttpStatusCode.RequestEntityTooLarge;
				case 408: return HttpStatusCode.RequestTimeout;
				case 414: return HttpStatusCode.RequestUriTooLong;
				case 205: return HttpStatusCode.ResetContent;
				case 503: return HttpStatusCode.ServiceUnavailable;
				case 101: return HttpStatusCode.SwitchingProtocols;
				case 401: return HttpStatusCode.Unauthorized;
				case 415: return HttpStatusCode.UnsupportedMediaType;
				case 306: return HttpStatusCode.Unused;
				case 305: return HttpStatusCode.UseProxy;
				default: return HttpStatusCode.SeeOther; // just something random
			}
		}
	}
}