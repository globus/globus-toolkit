/**********************************************
 * Developed by:
 * Grid Computing Group
 * Computer Science Department
 * University of Virginia
 *
 * Author: Glenn Wasson (wasson@virginia.edu) 
 **********************************************/

#include <stdio.h>
#include <memory.h>
#include <errno.h>
#include <sys/types.h>
#include <WinSock2.h>
#include <assert.h>

#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/x509v3.h>
#include "utils.h"

typedef struct _SSL_DATA {
	int			socket;
	SSL_CTX		*context;
	SSL			*ssl;
	X509		*server_cert;
	SSL_METHOD	*meth;
} SSL_DATA;

// ****** CONFIGURATION: ******
//    Change the following variables if you want non-default values.

// set this to where ever your proxy cert lives
char PROXY_CERT_FILE[] = "c:\\temp\\x509up_user\0";

// set this to the directory where OpenSSL can find other certificates
// needed to perform chain verification
char CERT_DIR[] = "c:\\certificates\0";

// set this to whatever kind of proxy you want delegated by default (see utils.h)
int doLim = UNRESTRICTED_PROXY;
// ****** END CONFIGURATION *******

// this came from a_d2i_fp.c in OpenSSL
#define HEADER_SIZE   8

X509_REQ *ReadCertReq(SSL_DATA* ssldata);
int PushCert(SSL_DATA* ssldata, X509 *x);

void setErrString (char *errBuf, const char *errorString, int sizeOfBuf) {
	int errLen = 0;
	char *localErrBuf = new char[1024];
	strcpy(localErrBuf, errorString);

	long e = 1;
	while (e != 0) {
		e = ERR_get_error();
		if (e != 0) {
			strcat(localErrBuf, " -- lib err: ");
			strcat(localErrBuf, ERR_lib_error_string(e));
			strcat(localErrBuf, "  func err: ");
			strcat(localErrBuf, ERR_func_error_string(e));
			strcat(localErrBuf, "  reason: ");
			strcat(localErrBuf, ERR_reason_error_string(e));
			fprintf(stderr, "%s ", ERR_lib_error_string(e));
			fprintf(stderr, "%s ", ERR_func_error_string(e));
			fprintf(stderr, "%s ", ERR_reason_error_string(e));
		}
	}

	errLen = (int) strlen(localErrBuf);
	if (errLen > sizeOfBuf)
		strncpy(errBuf, localErrBuf, sizeOfBuf-1);
	else
		strcpy(errBuf, localErrBuf);
	delete localErrBuf;
}

/// <summary>
/// Initializes the TLS/SSL library.
/// </summary>
/// <returns>Returns zero when successful or a negative number otherwise.</returns>
int __stdcall SecureInit() {
	WSADATA wsaData;
	if(WSAStartup(MAKEWORD(2,0), &wsaData)!=0) {
		return -1;
	}
	SSLeay_add_ssl_algorithms();
	SSL_load_error_strings();	
	return 0;
}

/// <summary>
/// Initializes the SSL_DATA structure to use during the connection.
/// </summary>
/// <param name="socket">The handle of the Socket that will be used for the connection.</param>
/// <param name="method">
/// The security protocol to use. It can be one of the following values:
/// <list type="table">
///	 <listheader>
///	  <term>Value</term>
///   <description>Description</description>
///  </listheader>
///  <item>
///   <term>1</term>
///   <description>Transport Layer Security (TLS) version 1</description>
///  </item>
///  <item>
///   <term>2</term>
///   <description>Secure Socket Layer (SSL) version 2</description>
///  </item>
///  <item>
///   <term>3</term>
///   <description>Secure Socket Layer (SSL) version 3</description>
///  </item>
/// </list>
/// </param>
/// <param name="errcode">Error string set by this function (if needed)</param>
/// <param name="errcodesize">Size of buffer for error string </param>
/// <returns>Returns a valid IntPtr when successful, IntPtr.Zero otherwise.</returns>
SSL_DATA* __stdcall SecureStart(int socket, int method, char *errcode, int errcodesize) {
	SSL_DATA *data;
	int res = 0;

	if (socket == INVALID_SOCKET) {
		setErrString(errcode, "invalid socket", errcodesize);
		return NULL;
	}

	data = (SSL_DATA*)LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT, sizeof(SSL_DATA));
	if (data == NULL) {
		setErrString(errcode, "SecureStart failed to allocate SSL_DATA struct", errcodesize);
		fprintf(stderr, "%s\n", "SecureStart failed to allocate SSL_DATA struct.");
		return NULL;
	}

	data->socket = socket;
	switch (method) {
		case 1:
			data->meth = TLSv1_client_method();
		case 2:
			data->meth = SSLv2_client_method();
		case 3:
			data->meth = SSLv3_client_method();
	}

	data->context = SSL_CTX_new(data->meth);
		
	if (data->context == NULL) {
		LocalFree(data);
		setErrString(errcode, "SecureStart failed to create new SSL context.", errcodesize);
		fprintf(stderr, "%s\n", "SecureStart failed to create new SSL context.");
		return NULL;
	}

	// now we setup the context to handle mutual authentication (GSI style)
	SSL_CTX_set_verify(data->context, SSL_VERIFY_PEER, NULL);

	// set the cipher to one supported by Globus
	SSL_CTX_set_cipher_list(data->context, "RC4-MD5");

	// set up the trusted certs
	res = SSL_CTX_load_verify_locations(data->context, NULL, CERT_DIR);
	if (res != 1) {
		setErrString(errcode, "SecureStart had problem loading verify locations", errcodesize);	
		return NULL;
	}

	// set the context to use these hardcoded cert and key (I wonder if the fact that usercert.pem is not a proxy
	// will make any difference)
	res = SSL_CTX_use_certificate_chain_file(data->context, PROXY_CERT_FILE);
	if (res != 1) {
		setErrString(errcode, "SecureStart failed to load certificate chain.", errcodesize);
		return NULL;
	}

	res = SSL_CTX_use_RSAPrivateKey_file(data->context, PROXY_CERT_FILE, SSL_FILETYPE_PEM);
	if (res != 1) {
		setErrString(errcode, "SecureStart failed to load RSA private key.", errcodesize);
		return NULL;
	}

	return data;
}

/// <summary>
/// Initiate the TLS/SSL handshake with an TLS/SSL server.
/// </summary>
/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
/// <returns>Returns zero when successful, or a negative number otherwise.</returns>
int __stdcall SecureNegotiate(SSL_DATA* ssldata) {
	ssldata->ssl = SSL_new(ssldata->context);
	if (ssldata->ssl == NULL)
		return -1;
	SSL_set_fd(ssldata->ssl, ssldata->socket);
	int ret = SSL_connect(ssldata->ssl);
	if (ret < 0) {
		int prob = SSL_get_error(ssldata->ssl, ret);
		return prob;
	}

	return 0;
}

int __stdcall SecureDelegate(SSL_DATA* ssldata, char *errCode, int errCodeSize) {
	BYTE *delegBuf = new BYTE[1];
	X509_REQ *reqp = NULL;
	X509 *ncert = NULL;
	X509 *cert  = NULL;
	BIO *in;

	delegBuf[0] = (BYTE) 'D';
	if (SSL_write(ssldata->ssl, delegBuf, 1) < 0) {
		setErrString(errCode, "SecureDelegate failed to initiate the delegation with server. ", errCodeSize);	
		return 0;
	}

	reqp = ReadCertReq(ssldata);
	if (reqp == NULL)
	{
		setErrString(errCode, "SecureDelegation failed to read a certificate request from server. ", errCodeSize);
		return 0;
	}

	// Currently, we reload the proxy cert and key here so that we can get them
	// in the correct format. Future versions will retrieve this data from 
	// internal SSL data structures.
	in = BIO_new(BIO_s_file_internal());
	if (in == NULL)
	{
		setErrString(errCode, "SecureDelegation failed to create a BIO to read certificate file. ", errCodeSize);
		return 0;
	}

	if (BIO_read_filename(in, PROXY_CERT_FILE) <= 0)
	{
		setErrString(errCode, "SecureDelegation failed to read certificate file. ", errCodeSize);
		return 0;
	}
		
	X509 *usercert = NULL;
	usercert = PEM_read_bio_X509(in, NULL, ssldata->context->default_passwd_callback, 
								 ssldata->context->default_passwd_callback_userdata);
	if (in != NULL)
		BIO_free(in);

	// again, the private key is re-read so that it is in the correct form for the signing
	in = BIO_new(BIO_s_file_internal());
	if (in == NULL)
	{
		setErrString(errCode, "SecureDelegation failed to create a BIO to read private key file. ", errCodeSize);
		return 0;
	}

	if (BIO_read_filename(in, PROXY_CERT_FILE) <= 0)
	{
		setErrString(errCode, "SecureDelegation failed to read private key file. ", errCodeSize);		
		return 0;
	}
		
	RSA *rsa = NULL;
	rsa = PEM_read_bio_RSAPrivateKey(in, NULL, ssldata->context->default_passwd_callback, 
		  						     ssldata->context->default_passwd_callback_userdata);
	EVP_PKEY *userkey;
	userkey = EVP_PKEY_new();
	if (! userkey) {
		setErrString(errCode, "SecureDelegation failed to create new private key struct. ", errCodeSize);
		return 0;
	}
	EVP_PKEY_set1_RSA(userkey, rsa);

	if (in != NULL)
		BIO_free(in);

	// sign the cert you just read (use NULL for extensions)
	if (proxy_sign(usercert, userkey, reqp, &ncert, NULL, NULL, RESTRICTED_PROXY))
	{
		setErrString(errCode, "SecureDelegation failed trying to sign proxy cert. ", errCodeSize);
		return 0;
	}
		
	if (PushCert(ssldata, ncert) != 1)	// push proxy cert onto the wire
	{
		setErrString(errCode, "SecureDelegation failed writing proxy cert to server. ", errCodeSize);
		return 0;
	}

	X509_free(ncert);
	EVP_PKEY_free(userkey);
	ncert = NULL;

	return 1;
}

int PushCert(SSL_DATA *ssldata, X509 *x)
{
	char *b;
	unsigned char *p;
	int i,j=0,n,ret=1;

	n=i2d_X509(x,NULL);
	b=(char *)OPENSSL_malloc(n);
	if (b == NULL)
	{
		return(0);
	}

	p=(unsigned char *)b;
	i2d_X509(x,&p);

	for (;;)
	{
		i = SSL_write(ssldata->ssl, (BYTE*) &(b[j]), n);
		if (i == n) break;
		if (i <= 0)
		{
			ret=0;
			break;
		}
		j+=i;
		n-=i;
	}
	OPENSSL_free(b);
	return(ret);
}


// this is a modified version of the OpenSSL function ASN1_d2i_bio (from a_d2i_fp.c) 
// (see "X509_REQ *d2i_X509_REQ_bio(BIO *bp, X509_REQ **req)" in x_all.c).
// - the BIO stuff has been replaced with SSL_read()
X509_REQ *ReadCertReq(SSL_DATA* ssldata)
{
	BUF_MEM *b;
	unsigned char *p;
	int i;
	X509_REQ *ret=NULL;
	ASN1_CTX c;
	int want=HEADER_SIZE;
	int eos=0;
	int off=0;
	int len=0;
	unsigned char **x = NULL;

	b=BUF_MEM_new();
	if (b == NULL)
	{
		return(NULL);
	}

	ERR_clear_error();
	for (;;)
	{
		if (want >= (len-off))
		{
			want-=(len-off);
			if (!BUF_MEM_grow(b,len+want))
			{
				goto err;
			}
			i=SSL_read(ssldata->ssl, (BYTE*)&(b->data[len]), want);
			if ((i < 0) && ((len-off) == 0))
			{
				goto err;
			}
			if (i > 0)
				len+=i;
		}
		/* else data already loaded */
		p=(unsigned char *)&(b->data[off]);
		c.p=p;
		c.inf=ASN1_get_object(&(c.p),&(c.slen),&(c.tag),&(c.xclass),len-off);
		if (c.inf & 0x80)
		{
			unsigned long e;
			e=ERR_GET_REASON(ERR_peek_error());
			if (e != ASN1_R_TOO_LONG)
				goto err;
			else
				ERR_get_error(); /* clear error */
		}
		i=c.p-p;/* header length */
		off+=i;	/* end of data */

		if (c.inf & 1)
		{
			/* no data body so go round again */
			eos++;
			want=HEADER_SIZE;
		}
		else if (eos && (c.slen == 0) && (c.tag == V_ASN1_EOC))
		{
			/* eos value, so go back and read another header */
			eos--;
			if (eos <= 0)
				break;
			else
				want=HEADER_SIZE;
		}
		else 
		{
			/* read in c.slen bytes of data */
			want=(int)c.slen;
			if (want > (len-off))
			{
				want-=(len-off);
				if (!BUF_MEM_grow(b,len+want))
				{
					goto err;
				}
				i=SSL_read(ssldata->ssl, (BYTE*) &(b->data[len]), want);
				if (i <= 0)
				{
					goto err;
				}
				len+=i;
			}
			off+=(int)c.slen;
			if (eos <= 0)
			{
				break;
			}
			else
				want=HEADER_SIZE;
		}
	}

	p=(unsigned char *)b->data;
	ret=d2i_X509_REQ((X509_REQ **)x,&p,off);
err:
	if (b != NULL) BUF_MEM_free(b);
	return(ret);
}


/// <summary>
/// Transmits data securely to the server.
/// </summary>
/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
/// <param name="buffer">The buffer of bytes to send to the remote server.</param>
/// <param name="length">The number of bytes in the buffer.</param>
/// <returns>Returns zero when successful, or a negative number otherwise.</returns>
int __stdcall SecureWrite(SSL_DATA* ssldata, BYTE *buffer, int length) {
	if (SSL_write(ssldata->ssl, buffer, length) < 0) {
		printf("SSL_write failed\n");
		return -1;
	}
	return 0;
}

/// <summary>
/// Receives data from the server.
/// </summary>
/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
/// <param name="buffer">The storage location for the received data.</param>
/// <param name="length">The maximum number of bytes to receive.</param>
/// <returns>
/// This method can return one of the following values:
/// <list type="table">
///	 <listheader>
///	  <term>Value</term>
///   <description>Description</description>
///  </listheader>
///  <item>
///   <term>&gt;0</term>
///   <description>The read operation was successful; the return value is the number of bytes actually read from the TLS/SSL connection.</description>
///  </item>
///  <item>
///   <term>0</term>
///   <description>The read operation was not successful. The reason may either be a clean shutdown due to a "close notify" alert sent by the peer. It is also possible, that the peer simply shut down the underlying transport and the shutdown is incomplete.</description>
///  </item>
///  <item>
///   <term>&lt;0</term>
///   <description>The read operation was not successful, because either an error occurred or action must be taken by the calling process.</description>
///  </item>
/// </list>
/// </returns>
int __stdcall SecureRead(SSL_DATA* ssldata, BYTE *buffer, int length) {
	int ret = SSL_read(ssldata->ssl, buffer, length);
	if (ret < 0)
		return -1;
	return ret;
}

/// <summary>
/// Uninitializes the SSL_DATA structure.
/// </summary>
/// <param name="ssldata">A pointer to the SSL_DATA structure used troughout this connection.</param>
void __stdcall SecureEnd(SSL_DATA* ssldata) {
	SSL_shutdown(ssldata->ssl);
	SSL_free(ssldata->ssl);
	SSL_CTX_free(ssldata->context);
	LocalFree(ssldata);
}

/// <summary>
/// Uninitializes the TLS/SSL library.
/// </summary>
void __stdcall SecureExit() {
	WSACleanup();
}
// END OF FILE
