/**********************************************
 * Developed by:
 * Grid Computing Group
 * Computer Science Department
 * University of Virginia
 *
 * Author: Glenn Wasson (wasson@virginia.edu) 
 **********************************************/

// Original program from OGSI Tech Preview 
//  - modified to work with httpg protocol

using System;
using Globus.Ogsa.Samples;
using System.Net;
using edu.virginia.cs.gcg.GSISockets;
using System.IO;
using System.Text;
using edu.virginia.cs.gcg.httpg;

namespace Globus.Ogsa.Client.Samples {

public class SecureCounterAdd
{
	[STAThread]
	static void Main(string[] args)
	{
		// This line is required to add the httpg protocol to the .NET architecture
		WebRequest.RegisterPrefix("httpg", new HttpgWebRequest());

		try
        {
            if (args.Length < 2)
            {
                Console.WriteLine("usage: SecureCounterClient <value> <url>");
                return;
            }
            CounterSOAPBinding service = new CounterSOAPBinding();
            service.Url = args[1];
            int val = service.add(Convert.ToInt32(args[0]));
            Console.WriteLine("Counter value: {0}", val);
        }
        catch (Exception e)
        {
            Console.WriteLine("Error creating service: {0}", e);
        }
    }
}

}
