This is the OGSI.NET package from the 

Grid Computing Group
Computer Science Department
University of Virginia

Parts of this distribution rely on OpenSSL, which is available from ww.openssl.org.

Although the OpenSSL source is not included in this distribution, compiled versions
of some dlls are. See the file OpenSSL.License.txt for licensing information.

For more information on the OGSI.NET project, see
http://www.cs.virginia.edu/~gsw2c/ogsi.net_faq.html


Glenn Wasson
wasson@virginia.edu