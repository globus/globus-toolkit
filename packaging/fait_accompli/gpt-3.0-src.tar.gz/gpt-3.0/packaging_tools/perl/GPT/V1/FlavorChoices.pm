package Grid::GPT::V1::FlavorChoices;

use strict;
use Carp;

require Exporter;
use vars       qw($VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);
use Data::Dumper;
use Grid::GPT::V1::XML;
use Grid::GPT::V1::Definitions;
use Grid::GPT::V1::FlavorDefinition;
require Grid::GPT::V1::FlavorBase;

# set the version for version checking
$VERSION     = 0.01;

@ISA         = qw(Exporter Grid::GPT::V1::FlavorBase);

sub _init {
    my ($me, %arg)  = @_;
    $me->read_xml($arg{'xml'}) if (defined($arg{'xml'}));
}

sub _nolabel {
    my ($me, $nolabel)  = @_;
    die "ERROR: multiple nolabel\'s defined: $nolabel $me->{'nolabel'}\n"
      if defined $me->{"nolabel"};

    $me->{'nolabel'} = $nolabel;
}

sub write_xml {
  my ($me, %args) = @_;

  $me->write_xml_config(%args);
}

sub permute {
  my ($me, %arg) = @_;
  my ($flavor, $std) = ($arg{'flavor'}, $arg{'std'});
  my @list;
  my $myflavor = $flavor;
  $myflavor = new Grid::GPT::V1::FlavorDefinition if ! defined $flavor;
  for my $c (@{$me->{'configs'}}) {
    my $mystd = $me->is_std($c);
    next if defined $std and ! $mystd;
    my $newflavor = $myflavor->clone();
    $newflavor->add_configure_option($me->labeled($c) => $c, 
                                     switch => $me->{$c}
                                    );
    push @list, $newflavor;
  }
  return \@list;
}

sub AUTOLOAD {
  use vars qw($AUTOLOAD);
  my $me = shift;
  my $type = ref($me) || croak "$me is not an object";
  my $name = $AUTOLOAD;
  $name =~ s/.*://;   # strip fully-qualified portion
  unless (exists $me->{$name} ) {
    croak "Can't access `$name' field in object of class $type";
  } 
  if (@_) {
    return $me->{$name} = shift;
  } else {
    return $me->{$name};
  } 
}

sub DESTROY {}
END { }       # module clean-up code here (global destructor)



1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::V1::BuildFlavors - Perl extension for managing package version metadata

=head1 SYNOPSIS

  use Grid::GPT::V1::BuildFlavors;
  my $a_ver = new Grid::GPT::V1::BuildFlavors(type =>'aging', major => '4', minor =>'6', age =>'2');
  my $s_ver = new Grid::GPT::V1::BuildFlavors(type =>'simple', major => '3');
  my $r_ver = new Grid::GPT::V1::BuildFlavors(type =>'range', upper_major => '3', lower_major => '2');

  my $result = $a_ver->is_compatible($s_ver);

=head1 DESCRIPTION

I<Grid::GPT::V1::BuildFlavors> is used to manage package version metadata. The
version metadata is to used to describe the version of a package as
well as dependencies to packages.

=head1 BuildFlavors Metadata Types

There are several ways to express information about the compatibility
of the different versions.  This package supports the following
schemes which are called version metadata types.

=over 4

=item aging

This metadata is used to describe the version of a package. It consists of the following fields:

=over 4

=item major 

This is the main version number of the package.

=item minor

This is a number used to version bug fixes that maintain binary compatibility.

=item age

This number denotes the backward compatability of the package.  For
example a package with a major number of 5 and an age of 2 is
compatible back to version 3.

=back

=item simple

This metadata is used to describe the version requirements of a package dependency.
It consists of only a major version number.  The dependency indicates
with this metadata that it will accept a version if the major number
falls with in the age range of the package fulfilling the dependency.

=item range

This metadata is also used to describe the version requirements of a
package dependency.  The range is compared to the specific version
number of the package fulfilling the dependency.  Not that the age
criteria is not used here.  The metadata consists of the following:

=over 4

=item upper_major

The newest major version number accepted. 

=item lower_major

The oldest major version number accepted. 

=item upper_minor

The newest minor version number accepted. 

=item lower_minor

The oldest minor version number accepted. 

=back

=back

=head1 Methods

=over 4

=item new

Create a new I<Grid::GPT::V1::BuildFlavors> object.  The following named arguments are accepted

=over 4

=item type

The type of version metadata this object will contain.

=item major

The major version number (used for aging and simple types).

=item minor

The minor version number (used only for the aging type).

=item age

The age of the major version (used only for the aging type).

=item upper_major

The newest major number allowed (used only for the range type).

=item upper_minor

The newest minor number allowed (used only for the range type).

=item lower_major

The oldest major number allowed (used only for the range type).

=item lower_minor

The oldest minor number allowed (used only for the range type).


=item obj

This passes in a L<Grid::GPT::V1::XML|Grid::GPT::V1::XML> version object.  The
version metadata is extracted from the object.

=back

=item is_compatible

Determines if the aging version metadata fulfills the requirements of
another version metadata which can be either simple version metadata
or range version metadata.  Returns 1 if the requirement is fulfilled.
Returns 0 otherwise.

=item validate

Determines if the version metadata is complete.

=item write_tag(xml_obj)

Adds version contents into an L<Grid::GPT::V1::XML|Grid::GPT::V1::XML> object. 

=item create_version_list(xml_obj)

Class function which creates a list of BuildFlavors objects from a
L<Grid::GPT::V1::XML|Grid::GPT::V1::XML> object.  The function returns a
reference to the list.


=item convert_version_list2xml(version_list_reference, xml_obj)

Class function which adds the contents of all BuildFlavors objects in a
list reference to an L<Grid::GPT::V1::XML|Grid::GPT::V1::XML> object.

=back

=head1 BuildFlavorsing Examples

As an example consider the installed package foo which has a version
number of 5.3.  As was mentioned in the previous section, this
specifies a compatibility range of 2 to 5.  Now we want to install
package fum which depends on foo.  The following table shows how the
versioning works:


    BuildFlavors specification for   BuildFlavors
    Dependency foo to fum       Type           Dependency is met
    
    1                           Simple         No 
    1 to 4                      Range          No
    4 to 4                      Range          No
    3                           Simple         Yes
    3 to 6                      Range          Yes


=head1 AUTHOR

Eric Blau <eblau@ncsa.uiuc.edu> Michael Bletzinger <mbletzin@ncsa.uiuc,edu>

=head1 SEE ALSO

perl(1) GRID::GPT::V1::XML(1).

=cut
