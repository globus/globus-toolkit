package Grid::GPT::DepOrdering;
use Data::Dumper;
my %foo=undef();

sub dep_ordering{
#Takes a list of dep-package objects, returns a dependency ordered list...

my @zero_queue;
my %counts;
my %rev_deps;
my %objecthash;
my %deps;
my %setup_deps;
my %noflavor_hash;
my $self=shift;
my @package_list= @_;
my @depslist;
my @returnlist;


#first, fill in the setup_deps hash
foreach my $package (@package_list){
	if (defined $package->{'Setup_Name'}){
		$setup_deps{$package->{'Setup_Name'}}=$package->{'Name'}."-".$package->{'Flavor'}."_".$package->{'Package_Type'};
	}
	if ($package->{'Package_Type'} eq 'src'){
		$objecthash{$package->{'Name'}."-_src"}=\$package;
	}else{
	 	$objecthash{$package->{'Name'}."-".$package->{'Flavor'}."_".$package->{'Package_Type'}}=\$package; 
	}
}
#next, fill in noflavor_deps hash
foreach my $package (@package_list){
	if ($package->{'Package_Type'} ne 'src'){
	   $noflavor_hash{$package->{'Name'}."-noflavor_".$package->{'Package_Type'}}=$package->{'Flavor'};
	   # if pgm_static, put the flavor in the hash for pgm as well
	   if ($package->{'Package_Type'} eq "pgm_static"){
	     if (!defined $noflavor_hash{$package->{'Name'}."-noflavor_pgm"}){
		 $noflavor_hash{$package->{'Name'}."-noflavor_pgm"}=$package->{'Flavor'};
	     }
	   }
        }
}

#First, fill in the rev_deps and dependencies reference counts
foreach $package (@package_list){
	my %dephash;
	if ($package->{'Package_Type'} eq 'src'){
		if (!defined $counts{$package->{'Name'}."-_src"}){
			$counts{$package->{'Name'}."-_src"}=0;
		}
		for my $deptype ('compile', 'pkg_link', 'lib_link'){
			for my $dep (keys %{$package->{'Source_Dependencies'}->{$deptype}}){
				$dep =~ s/_$//;
				#$dephash{$dep}=1;
				$dephash{$dep."-_src"}=1;
			 }
		 }
		 if (defined  $package->{'Setup_Name'}){ #we only want to consider setup deps for ordering when we'ree looking at a setup package.
		  if (defined $package->{'Source_Setup_Dependencies'} ){
			  foreach my $setupdep (@{$package->{'Source_Setup_Dependencies'}}){
				  if (defined $setup_deps{$setupdep->{'name'}}){
					  $dephash{$setup_deps{$setupdep->{'name'}}}=1;
				  }
			  }
		  }
	  	} #endif defined $package->{'Setup_Name'}
	 }#end if src
	 if ($package->{'Package_Type'} ne 'src'){
		   if (!defined $counts{$package->{'Name'}."-".$package->{'Flavor'}."_".$package->{'Package_Type'}}){
		         $counts{$package->{'Name'}."-".$package->{'Flavor'}."_".$package->{'Package_Type'}}=0;
		   }
		my $flavor;
		for my $deptype ('Compile', 'Build_Link', 'Runtime_Link','Runtime'){
			 for my $dep (keys %{$package->{'Binary_Dependencies'}->{$deptype}}){
				 my $i = $package->{'Binary_Dependencies'}->{$deptype}->{$dep};
				 if ($package->{'Flavor'} eq "noflavor"){
					 $flavor=$noflavor_hash{$i->{'name'}."-noflavor_".$i->{'pkg_type'}};
				 }else{
					 $flavor=$package->{'Flavor'};
				 }
				 if ($deptype eq 'Runtime'){
					 if ($i->{'pkg_type'} eq "pgm"){
						 if ($package->{'Package_Type'} eq "pgm_static"){
							 if (defined $objecthash{$i->{'name'}."-".$flavor."_pgm_static"}){
							  $dephash{$i->{'name'}."-".$flavor."_pgm_static"}=1;
						 	}else{
							  
							  $dephash{$i->{'name'}."-".$flavor."_".$i->{'pkg_type'}}=1;
						  	}
						}else{
							$dephash{$i->{'name'}."-".$flavor."_".$i->{'pkg_type'}}=1;
						}
					}else{
					   #for example, runtime deps on rtl packages:	
					   $dephash{$i->{'name'}."-".$flavor."_".$i->{'pkg_type'}}=1;
					}
				}else{
				  $dephash{$i->{'name'}."-".$flavor."_".$i->{'pkg_type'}}=1;
			        }
		         }
	          }
		  if (defined  $package->{'Setup_Name'}){ #we only want to consider setup deps for ordering when we'ree looking at a setup package.
		    if (defined $package->{'Setup_Dependencies'} ){
			  foreach my $setupdep (@{$package->{'Setup_Dependencies'}}){
				  if (defined $setup_deps{$setupdep->{'name'}}){
					  $dephash{$setup_deps{$setupdep->{'name'}}}=1;
				  }
			  }
		    }
	  	  } #endif defined $package->{'Setup_Name'}
	  }#end if not src
			 
	foreach $dep (keys %dephash){ #($package->{dependencies}){
		$counts{$dep}=$counts{$dep}+1;
		#push @{$rev_deps{$dep}},  $package->{'Name'};
		if ($package->{'Package_Type'} ne 'src'){
			push @{$deps{$package->{'Name'}."-".$package->{'Flavor'}."_".$package->{'Package_Type'}}}, $dep;
		}else{
			 push @{$deps{$package->{'Name'}."-_src"}}, $dep;
		 }
	}

} #end foreach $package

	foreach $key (keys %counts){
		if ($counts{$key}==0) {
			push @zero_queue, $key;
		}
	}
#While there is something in the zero_queue, take the first element
#of the queue and put it into the (now ordered) depslist
while (scalar(@zero_queue)){
	$package= shift @zero_queue;
push  @depslist, $package;
foreach $rev (@{$deps{$package}}){
	if (defined $rev){
		$counts{$rev}--;
		if ($counts{$rev}==0) {
			push @zero_queue, $rev;
		}
	}
}
}
foreach my $dep (@depslist){
	if (defined $objecthash{$dep}){
		push @returnlist, $objecthash{$dep}
	}
}
#return @depslist;
return @returnlist;
}

sub new {
	         my $class  = shift;
	         my $self  = {
	                   %foo,
	                      };
									               $self->{'pkgobj'}=$pkgobj;
										           bless $self, $class;
											       return $self;
										       }
END { }
