package Grid::GPT::Widgets::Version;

use strict;
use Tk;
use Tk::Menubutton;
use Data::Dumper;
use Grid::GPT::V1::Version;
#use AutoLoader qw(AUTOLOAD);


# Preloaded methods go here.
sub new {
  my ($class, $parent, $version) = @_;
  my $me = {
	    parent => $parent,
            versiontype => "simple"
	   };
  bless $me, $class;
  
  $me->{'toplevel'} = $parent->Toplevel(-title => 'Version');
  my $f = $me->{'toplevel'}->Frame->pack();
  my $vf = $f->Frame->pack();
  my $nlabel = $vf->Label(-text => "Version")->pack(-side => 'left');
  my $vb1 = $vf->Radiobutton(-text => 'Simple', -value => 'simple', 
                             -variable => \$me->{'versiontype'}, 
                             -command => sub{$me->switch_versions()})->pack();
  my $vb2 = $vf->Radiobutton(-text => 'Range', -value => 'range', 
                             -variable => \$me->{'versiontype'}, 
                             -command => sub{$me->switch_versions()})->pack();

  my $bf = $f->Frame->pack(-side => 'left');
  my $b3 = $bf->Button(-text =>'Done', -command => sub{$me->done()}, 
		    -width => 10)->pack();
  my $verf = $f->Frame->pack();
  $me->{'simplef'} = $verf->Frame->pack();
  $me->{'rangef'} = $verf->Frame;

  for my $field ('Major', 'Minor') {
    my $fr = $me->{'simplef'}->Frame->pack();
    my $lable = $fr->Label( -text => $field)->pack(-side => 'left');
    my $entry = $fr->Entry( -relief => 'sunken', 
                            -width => 4, 
                            -textvariable => \$me->{$field},
                          )->pack();
  }

  for my $field ('Oldest Major', 'Oldest Minor', 'Newest Major', 'Newest Minor') {
    my $fr = $me->{'rangef'}->Frame->pack();
    my $lable = $fr->Label( -text => $field)->pack(-side => 'left');
    my $entry = $fr->Entry( -relief => 'sunken', 
                            -width => 4, 
                            -textvariable => \$me->{$field}
                          )->pack(-side => 'left');
  }

  if (defined $version) {
    $me->display($version);
  } else {
      $me->{'toplevel'}->withdraw();
  }

  return $me;
}

sub display {
  my ($me, $update_func, $version) = @_;
  $me->{'update'} = $update_func;
  if (defined ($version)) {
    $me->import_version($version);
    $me->{'versionref'} = $version;
  } else {
    for my $f ('versionref', 'Major','Minor','Oldest Major',
               'Oldest Minor','Newest Major','Newest Minor') {
      $me->{$f} = undef;
    }
    $me->{'versiontype'} = 'simple';
  }
  $me->switch_versions();
  $me->{'toplevel'}->deiconify();
}

sub import_version {
  my ($me, $version) = @_;
  $me->{'versiontype'} = $version->{'type'};
  $me->{'Major'} = $version->{'major'};
  $me->{'Minor'} = $version->{'minor'};
  $me->{'Oldest Major'} = $version->{'lower_major'};
  $me->{'Oldest Minor'} = $version->{'lower_minor'};
  $me->{'Newest Major'} = $version->{'upper_major'};
  $me->{'Newest Minor'} = $version->{'upper_minor'};
  
}

sub export_version {
  my ($me, $version) = @_;
  $version->{'type'} = $me->{'versiontype'};
  $version->{'major'} = $me->{'Major'};
  $version->{'minor'} = $me->{'Minor'};
  $version->{'lower_major'} = $me->{'Oldest Major'};
  $version->{'lower_minor'} = $me->{'Oldest Minor'};
  $version->{'upper_major'} = $me->{'Newest Major'};
  $version->{'upper_minor'} = $me->{'Newest Minor'};
}

sub switch_versions {
  my ($me) = @_;
  if ($me->{'versiontype'} eq 'simple') {
    $me->{'rangef'}->packForget();
    $me->{'simplef'}->pack();
    return;
  }
    $me->{'simplef'}->packForget();
    $me->{'rangef'}->pack();
}

sub done {
  my $me = shift;
  $me->{'versionref'} = new Grid::GPT::V1::Version 
    if ! defined $me->{'versionref'};
  $me->export_version($me->{'versionref'});
  &{$me->{'update'}}($me->{'versionref'});
  $me->{'toplevel'}->withdraw();
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Widgets::Version - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Version;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Version, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.


=head1 AUTHOR

A. U. Thor, a.u.thor@a.galaxy.far.far.away

=head1 SEE ALSO

perl(1).

=cut
