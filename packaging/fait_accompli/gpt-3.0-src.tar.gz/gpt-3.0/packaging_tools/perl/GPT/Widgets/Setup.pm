package Grid::GPT::Widgets::Setup;

use strict;
use Tk;
use Tk::Menubutton;
require Tk::BrowseEntry;
require Tk::HList;
use Grid::GPT::Widgets::Version;
use Data::Dumper;

#use AutoLoader qw(AUTOLOAD);


# Preloaded methods go here.
sub new {
  my ($class, %args) = @_;
  my $me = {
	    parent => $args{'parent'},
            name => "",
            type  => "pgm",
	   };
  bless $me, $class;

  $me->{'toplevel'} = $me->{'parent'}->Toplevel(-title => 'Setup');
  my $f = $me->{'toplevel'}->Frame(-width => 100)->pack();
  my $nf = $f->Frame->pack();
  my $nlabel = $nf->Label(-text => "Name:", -justify => 'left')->pack(-side => 'left');
  my $n = $nf->Entry( -relief => 'sunken', 
                      -width => 40, 
                      -textvariable => \$me->{'name'})->pack();
  my $pf = $f->Frame->pack();
  my $plabel = $pf->Label(-text => "Package Type:", 
                          -justify => 'left')->pack(-side => 'left');
  my @setup_pkg_types = ('pgm','rtl', 'doc', 'data');
  my $p = $pf->BrowseEntry( -relief => 'sunken', 
                      -width => 6,
                      -choices => \@setup_pkg_types,
                      -textvariable => \$me->{'type'})->pack();

  my $vf = $f->Frame->pack(-side => 'left');
  my $vl = $f->Label(-text => "Versions")->pack(-side => 'top');
  my @vheaders = ('Type', "Specification");
  $me->{'versionlist'} = new 
    Grid::GPT::Widgets::ManagedHList(-parent => $f,
                                     -headers => \@vheaders,
                                     -width => 20,
                                     -height => 8,
                                     -edit => sub {$me->edit(shift,shift); },
                                     -fill => sub{$me->fill_content(shift);},
                                    );

  my $b2 = $vf->Button(-text =>'Done', -command => sub{$me->done()}, 
		    -width => 10)->pack();
  my $b3 = $vf->Button(-text =>'Add Version', 
                       -command => sub{$me->{'versionlist'}->edit()}, 
                       -width => 10)->pack();

  $me->{'versiondisplay'} = new Grid::GPT::Widgets::Version($me->{'toplevel'});
  $me->{'toplevel'}->withdraw();
  return $me;
}

sub display {
  my ($me, $update_func, $name) = @_;
  $me->{'update'} = $update_func;
  $me->clear_setup();
  if (defined ($name)) {
    $me->import_setup($name);
  }
  $me->{'toplevel'}->deiconify();  
}

sub import_setup {
  my ($me, $setup) = @_;
    $me->{'name'} = $setup->{'name'};
    $me->{'type'} = $setup->{'type'};

  for my $v (@{$setup->{'versions'}}) {
    $me->{'versionlist'}->add($v);
  }

}

sub export_setup {
  my ($me) = @_;
  my @deps;
  my @versions;
  for my $v(sort keys %{$me->{'versionlist'}->{'objs'}}) {
    push @versions, $me->{'versionlist'}->{'objs'}->{$v};  
  }  
  my $setup = {name => $me->{'name'},
              type => $me->{'type'},
              versions => \@versions};

  return $setup;
}

sub clear_setup {
  my ($me) = @_;
  $me->{'name'} = "";
  $me->{'type'} = "N/A";
  $me->{'versionlist'}->clear();
}


sub edit {
  my ($me, $func, $entry) = @_;
  if (defined($entry)) {
    $me->{'versiondisplay'}->display($func, $entry);
  } else {
    $me->{'versiondisplay'}->display($func);
  }
}


sub fill_content {
  my ($me, $version) = @_;
  my $spec;
  if ($version->{'type'} eq 'simple') {
    $spec = "$version->{'major'}";
    $spec .= ".$version->{'minor'}" if defined $version->{'minor'};
  } else {
    $spec = "$version->{'lower_major'}";
    $spec .= ".$version->{'lower_minor'}" if defined $version->{'lower_minor'};
    $spec .= " to $version->{'upper_major'}";
    $spec .= ".$version->{'upper_minor'}" if defined $version->{'upper_minor'};
  }
  
 return {Type => $version->{'type'}, Specification=> $spec };

}


sub done {
  my $me = shift;
  my $setup = $me->export_setup();
  &{$me->{'update'}}($setup);
  $me->{'toplevel'}->withdraw();
}

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is stub documentation for your module. You better edit it!

=head1 NAME

Grid::GPT::Widgets::Setup - Perl extension for blah blah blah

=head1 SYNOPSIS

  use Setup;
  blah blah blah

=head1 DESCRIPTION

Stub documentation for Setup, created by h2xs. It looks like the
author of the extension was negligent enough to leave the stub
unedited.

Blah blah blah.

=head2 EXPORT

None by default.


=head1 AUTHOR

A. U. Thor, a.u.thor@a.galaxy.far.far.away

=head1 SEE ALSO

perl(1).

=cut
